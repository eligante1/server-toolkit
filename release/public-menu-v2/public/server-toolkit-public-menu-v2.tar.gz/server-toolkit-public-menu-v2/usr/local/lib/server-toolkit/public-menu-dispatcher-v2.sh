#!/bin/bash -p
# Fixed privileged dispatcher for the public menu-v2 bundle.
set -Eeuo pipefail
IFS=$'\n\t'
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export IFS PATH

if [[ "$-" != *p* ]]; then
  printf '%s\n' \
    'ERROR: public menu dispatcher requires protected Bash.' >&2
  exit 126
fi
if (( EUID != 0 )); then
  printf '%s\n' \
    'ERROR: public menu dispatcher requires effective UID 0.' >&2
  exit 126
fi

readonly PUBLIC_AUDIT_ARTIFACT='/usr/local/lib/server-toolkit/server-toolkit-audit-v1.sh'
readonly PUBLIC_AUDIT_ROLLBACK_LAUNCHER='/usr/local/bin/server-toolkit-audit-v1'
readonly PUBLIC_QUICK_ARTIFACT='/usr/local/lib/server-toolkit/server-toolkit-quick-v2.sh'
readonly PUBLIC_LAST_REPORT_ARTIFACT='/usr/local/lib/server-toolkit/server-toolkit-last-report-v2.sh'
readonly PUBLIC_MENU_CONTROLLER='/usr/local/lib/server-toolkit/public-menu-controller-v2.sh'
readonly PUBLIC_MENU_DISPATCHER='/usr/local/lib/server-toolkit/public-menu-dispatcher-v2.sh'
readonly PUBLIC_MENU_LAUNCHER='/usr/local/bin/server-toolkit'
readonly SONAR_PRESENTATION_LIBRARY='/usr/local/lib/server-toolkit/sonar-presentation-0.4.1-rc4-round2.sh'
readonly PUBLIC_PROGRESS_LIBRARY='/usr/local/lib/server-toolkit/progress-0.4.1-rc4-round2.sh'
readonly PUBLIC_PLATFORM_LIBRARY='/usr/local/lib/server-toolkit/platform-compatibility-0.4.1-rc4-round2.sh'
readonly PUBLIC_PRESSURE_LIBRARY='/usr/local/lib/server-toolkit/pressure-diagnostics-0.4.1-rc4-round2.sh'
readonly PUBLIC_STORAGE_LIBRARY='/usr/local/lib/server-toolkit/storage-diagnostics-0.4.1-rc4-round2.sh'
readonly PUBLIC_APPLICATION_LIBRARY='/usr/local/lib/server-toolkit/application-service-diagnostics-0.4.1-rc4-round2.sh'
readonly PUBLIC_FAILED_SERVICES_LIBRARY='/usr/local/lib/server-toolkit/failed-services-policy-0.4.1-rc4-round2.sh'
readonly PUBLIC_QUICK_CLASSIFIER_LIBRARY='/usr/local/lib/server-toolkit/quick-check-classifier-v2.sh'
readonly PUBLIC_DISPATCH_TRUST_PREFIX=''
readonly PUBLIC_DISPATCH_EXPECTED_OWNER_UID='0'
readonly EXPECTED_AUDIT_SHA256='7e945df73a67f4254627067d8d6ddf1c88fbaf5cea383344cb807a45fd69387e'
readonly EXPECTED_AUDIT_ROLLBACK_SHA256='64172bba0387d931cbc0fd184f03e2ea8b36d6fe9363935837d5d83c8bfd79ea'
readonly EXPECTED_QUICK_SHA256='e00f4d26a1dc49c414eeb1e008ab69db2f698304ba2f4cf21227a2352232de19'
readonly EXPECTED_LAST_REPORT_SHA256='b1feb346c49a06bd1cbe895f0e0ce4617a27ea829d9b01c927579f1ecf6e2adf'
readonly EXPECTED_MENU_CONTROLLER_SHA256='8c89e8b31c0d62c122ee823930083cb6ad30110bffb0c1811ec8c442d55a3320'
readonly EXPECTED_SONAR_SHA256='ddb68cc5150b687cbc186911dea04a4be1995a44afb24d9d2d15271fef5f3f14'
readonly EXPECTED_PROGRESS_SHA256='5ddab9ede8e710b9a4b088421d23ba3011115c7c051a8f495bfe46f8669f8177'
readonly EXPECTED_PLATFORM_SHA256='785a35c8fca526e9178efe08dda86ef596ec84f4b82b08898d64122d23325271'
readonly EXPECTED_PRESSURE_SHA256='574e1949c98ceed6cb9cc8e2d74124f03bc0c0a2cbd901c8fbb1b7e63f5fba26'
readonly EXPECTED_STORAGE_SHA256='e57fec6b33fd7abfefa1a06496749097cd331d2123a74ccafcd790d7d924cfe9'
readonly EXPECTED_APPLICATION_SHA256='9f901b2167ff1a66295bd33a395bfe0e3ffb634d0e2f9fd0895a7644a1dd6f3a'
readonly EXPECTED_FAILED_SERVICES_SHA256='9fa69df50c2e8a0613e828c71839bbf95dcfe2b6528066a442421e92a958cc51'
readonly EXPECTED_QUICK_CLASSIFIER_SHA256='758c56b85634b37c1297fc149ccc03f49fd3349ee4b50dd95a6f3f8737184afa'

dispatcher_error() {
  printf 'ERROR: %s\n' "$1" >&2
  return "${2:-126}"
}

dispatcher_stat_identity() {
  /usr/bin/stat -c '%u:%a:%h' -- "$1" 2>/dev/null ||
    /usr/bin/stat -f '%u:%Lp:%l' "$1" 2>/dev/null
}

dispatcher_trusted_directory() {
  local directory="$1" identity mode numeric
  [[ -d "$directory" && ! -L "$directory" ]] || return 1
  identity="$(dispatcher_stat_identity "$directory")" || return 1
  [[ "${identity%%:*}" == "$PUBLIC_DISPATCH_EXPECTED_OWNER_UID" ]] || return 1
  mode="${identity#*:}"
  mode="${mode%%:*}"
  mode="${mode#0}"
  [[ "$mode" =~ ^[0-7]{3}$ ]] || return 1
  numeric=$((8#$mode))
  (( (numeric & 0022) == 0 ))
}

dispatcher_trusted_parent_chain() {
  local path="$1" parent
  case "$path" in
    "$PUBLIC_DISPATCH_TRUST_PREFIX/usr/local/bin/"*)
      for parent in \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/" \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/usr" \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/usr/local" \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/usr/local/bin"; do
        dispatcher_trusted_directory "$parent" || return 1
      done
      ;;
    "$PUBLIC_DISPATCH_TRUST_PREFIX/usr/local/lib/server-toolkit/"*)
      for parent in \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/" \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/usr" \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/usr/local" \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/usr/local/lib" \
        "$PUBLIC_DISPATCH_TRUST_PREFIX/usr/local/lib/server-toolkit"; do
        dispatcher_trusted_directory "$parent" || return 1
      done
      ;;
    *) return 1 ;;
  esac
}

dispatcher_trusted_regular() {
  local path="$1" expected_mode="$2" identity mode link_count
  dispatcher_trusted_parent_chain "$path" || return 1
  [[ -f "$path" && ! -L "$path" ]] || return 1
  identity="$(dispatcher_stat_identity "$path")" || return 1
  [[ "${identity%%:*}" == "$PUBLIC_DISPATCH_EXPECTED_OWNER_UID" ]] || return 1
  mode="${identity#*:}"
  mode="${mode%%:*}"
  mode="${mode#0}"
  link_count="${identity##*:}"
  [[ "$mode" == "$expected_mode" && "$link_count" == 1 ]]
}

dispatcher_sha256() {
  local value
  [[ -x /usr/bin/sha256sum ]] || return 1
  value="$(/usr/bin/sha256sum -- "$1" 2>/dev/null)" || return 1
  value="${value%% *}"
  [[ "$value" =~ ^[0-9a-f]{64}$ ]] || return 1
  printf '%s\n' "$value"
}

dispatcher_trusted_component() {
  local path="$1" mode="$2" expected_sha256="$3" actual_sha256
  dispatcher_trusted_regular "$path" "$mode" || return 1
  [[ "$expected_sha256" =~ ^[0-9a-f]{64}$ ]] || return 1
  actual_sha256="$(dispatcher_sha256 "$path")" || return 1
  [[ "$actual_sha256" == "$expected_sha256" ]]
}

dispatcher_require_component() {
  local label="$1" path="$2" mode="$3" expected_sha256="$4"
  dispatcher_trusted_component "$path" "$mode" "$expected_sha256" || {
    dispatcher_error "privileged closure component failed validation: $label"
    return 1
  }
}

dispatcher_require_regular() {
  local label="$1" path="$2" mode="$3"
  dispatcher_trusted_regular "$path" "$mode" || {
    dispatcher_error "privileged closure metadata failed validation: $label"
    return 1
  }
}

dispatcher_validate_quick_closure() {
  dispatcher_require_component quick-backend "$PUBLIC_QUICK_ARTIFACT" 700 "$EXPECTED_QUICK_SHA256" || return 1
  dispatcher_require_component progress-library "$PUBLIC_PROGRESS_LIBRARY" 644 "$EXPECTED_PROGRESS_SHA256" || return 1
  dispatcher_require_component platform-library "$PUBLIC_PLATFORM_LIBRARY" 644 "$EXPECTED_PLATFORM_SHA256" || return 1
  dispatcher_require_component pressure-library "$PUBLIC_PRESSURE_LIBRARY" 644 "$EXPECTED_PRESSURE_SHA256" || return 1
  dispatcher_require_component storage-library "$PUBLIC_STORAGE_LIBRARY" 644 "$EXPECTED_STORAGE_SHA256" || return 1
  dispatcher_require_component application-library "$PUBLIC_APPLICATION_LIBRARY" 644 "$EXPECTED_APPLICATION_SHA256" || return 1
  dispatcher_require_component failed-services-library "$PUBLIC_FAILED_SERVICES_LIBRARY" 644 "$EXPECTED_FAILED_SERVICES_SHA256" || return 1
  dispatcher_require_component quick-classifier-library "$PUBLIC_QUICK_CLASSIFIER_LIBRARY" 644 "$EXPECTED_QUICK_CLASSIFIER_SHA256" || return 1
}

dispatcher_validate_selected_closure() {
  case "$1" in
    audit)
      dispatcher_require_component audit-backend "$PUBLIC_AUDIT_ARTIFACT" 700 "$EXPECTED_AUDIT_SHA256"
      ;;
    quick-check)
      dispatcher_validate_quick_closure
      ;;
    last-report)
      dispatcher_require_component last-report-backend "$PUBLIC_LAST_REPORT_ARTIFACT" 700 "$EXPECTED_LAST_REPORT_SHA256"
      ;;
    verify)
      dispatcher_require_regular dispatcher "$PUBLIC_MENU_DISPATCHER" 755 || return 1
      dispatcher_require_regular launcher "$PUBLIC_MENU_LAUNCHER" 755 || return 1
      dispatcher_require_component rollback-launcher "$PUBLIC_AUDIT_ROLLBACK_LAUNCHER" 755 "$EXPECTED_AUDIT_ROLLBACK_SHA256" || return 1
      dispatcher_require_component menu-controller "$PUBLIC_MENU_CONTROLLER" 644 "$EXPECTED_MENU_CONTROLLER_SHA256" || return 1
      dispatcher_require_component sonar-library "$SONAR_PRESENTATION_LIBRARY" 644 "$EXPECTED_SONAR_SHA256" || return 1
      dispatcher_require_component audit-backend "$PUBLIC_AUDIT_ARTIFACT" 700 "$EXPECTED_AUDIT_SHA256" || return 1
      dispatcher_validate_quick_closure || return 1
      dispatcher_require_component last-report-backend "$PUBLIC_LAST_REPORT_ARTIFACT" 700 "$EXPECTED_LAST_REPORT_SHA256"
      ;;
    *) return 2 ;;
  esac
}

if (($# != 1)); then
  dispatcher_error 'dispatcher accepts exactly one literal action.' 2
  exit $?
fi
if [[ "$0" != "$PUBLIC_MENU_DISPATCHER" ||
      "${BASH_SOURCE[0]}" != "$PUBLIC_MENU_DISPATCHER" ]]; then
  dispatcher_error 'dispatcher must be invoked through its fixed installed path.'
  exit $?
fi

readonly PUBLIC_DISPATCH_ACTION="$1"
case "$PUBLIC_DISPATCH_ACTION" in
  audit|quick-check|last-report|verify) ;;
  *)
    dispatcher_error 'invalid dispatcher action.' 2
    exit $?
    ;;
esac

if ! dispatcher_validate_selected_closure "$PUBLIC_DISPATCH_ACTION"; then
  dispatcher_error 'selected public menu-v2 privileged closure failed metadata or SHA-256 validation.'
  exit $?
fi

case "$PUBLIC_DISPATCH_ACTION" in
  audit) exec "$PUBLIC_AUDIT_ARTIFACT" audit ;;
  quick-check) exec "$PUBLIC_QUICK_ARTIFACT" quick-check ;;
  last-report) exec "$PUBLIC_LAST_REPORT_ARTIFACT" last-report ;;
  verify)
    printf '%s\n' 'Public menu-v2 non-self runtime closure verification passed; launcher self-provenance requires package evidence.'
    ;;
esac
