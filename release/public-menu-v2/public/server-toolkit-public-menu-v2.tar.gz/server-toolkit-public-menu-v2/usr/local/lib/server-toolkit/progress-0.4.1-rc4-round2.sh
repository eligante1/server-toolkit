# Server Toolkit terminal progress layer.
# This file is embedded into the standalone audit-only candidate by the builder.
# shellcheck shell=bash

PROGRESS_MODE="${SERVER_TOOLKIT_PROGRESS_MODE:-auto}"
PROGRESS_WIDTH="${SERVER_TOOLKIT_PROGRESS_WIDTH:-auto}"
PROGRESS_COLUMNS=80
PROGRESS_TOTAL_SECTIONS=26
PROGRESS_TOTAL_STAGES=29
PROGRESS_COMPLETED_SECTIONS=0
PROGRESS_COMPLETED_STAGES=0
PROGRESS_PERCENT=0
PROGRESS_STAGE="Подготовка"
PROGRESS_STAGE_STARTED=0
PROGRESS_STAGE_ACTIVE=0
PROGRESS_RUNTIME_DIR=""
PROGRESS_STATE_FILE=""
PROGRESS_HEARTBEAT_PID=""
PROGRESS_HEARTBEAT_IDENTITY=""
PROGRESS_HEARTBEAT_STARTING=0
PROGRESS_HEARTBEAT_STOP_REQUESTED=0
PROGRESS_HEARTBEAT_RESOLUTION=""
PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT=""
PROGRESS_HEARTBEAT_OBSERVATION_ERROR=""
PROGRESS_HEARTBEAT_PROTOCOL=""
PROGRESS_HEARTBEAT_GENERATION=0
PROGRESS_HEARTBEAT_GENERATION_ID=""
PROGRESS_HEARTBEAT_STOP_FILE=""
PROGRESS_HEARTBEAT_DONE_FILE=""
PROGRESS_HEARTBEAT_JOBS_A_DIR=""
PROGRESS_HEARTBEAT_JOBS_B_DIR=""
PROGRESS_HEARTBEAT_JOBS_A_FILE=""
PROGRESS_HEARTBEAT_JOBS_B_FILE=""
PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
PROGRESS_HEARTBEAT_ACK_STATUS=""
PROGRESS_ACTIVE_CHILD_PID=""
PROGRESS_ACTIVE_CHILD_IDENTITY=""
PROGRESS_CHILD_GUARD_DIR=""
PROGRESS_CHILD_GUARD_READY=""
PROGRESS_CHILD_GUARD_RELEASE=""
PROGRESS_CHILD_STARTING=0
PROGRESS_CHILD_TERMINATION_IN_PROGRESS=0
PROGRESS_CLEANUP_IN_PROGRESS=0
PROGRESS_CLEANUP_DONE=0
PROGRESS_CLEANUP_STATUS=0
PROGRESS_SIGNAL_IN_PROGRESS=0
PROGRESS_SIGNAL_REPORT_PATH="недоступен"
PROGRESS_PENDING_SIGNAL=""
PROGRESS_PENDING_SIGNAL_REPORT=""
PROGRESS_ACTIVE=0
PROGRESS_INTERACTIVE=0
PROGRESS_UNICODE=0
PROGRESS_COLOR=0
PROGRESS_SOFT_SECONDS=8
PROGRESS_UTF8_LOCALE=C
PROGRESS_CURSOR_HIDDEN=0
PROGRESS_PRESENTATION_INPUT_VALIDATED=0
PROGRESS_PRESENTATION_TTY=0
PROGRESS_PRESENTATION_COLUMNS=80
PROGRESS_PRESENTATION_UNICODE=0
PROGRESS_PRESENTATION_COLOR=0
PROGRESS_PRESENTATION_FD=""
PROGRESS_FAILURE_REPORTED=0
PROGRESS_PROCESS_TREE_MAX_HOPS=256
PROGRESS_PROCESS_TREE_MAX_ROWS=4096
PROGRESS_PROCESS_TREE_MAX_TRANSITIONS=65536
# Consumed by progress_run_child's bounded callback runner. This remains
# shell-local so diagnostic children receive only the explicit environment.
CURRENT_STAGE_TIMEOUT=45

progress_terminal_columns() {
  local columns="" size=""
  if [[ -t 2 && -x /bin/stty ]]; then
    size="$(/bin/stty size <&2 2>/dev/null || true)"
    columns="${size##* }"
  elif [[ -t 2 && -x /usr/bin/stty ]]; then
    size="$(/usr/bin/stty size <&2 2>/dev/null || true)"
    columns="${size##* }"
  fi
  if ! [[ "$columns" =~ ^[0-9]+$ ]] &&
      [[ "${PROGRESS_PRESENTATION_INPUT_VALIDATED:-0}" == 1 ]]; then
    columns="${PROGRESS_PRESENTATION_COLUMNS:-}"
  fi
  [[ "$columns" =~ ^[0-9]+$ ]] || columns="${COLUMNS:-}"
  if ! [[ "$columns" =~ ^[0-9]+$ ]] && [[ -x /usr/bin/tput ]]; then
    columns="$(/usr/bin/tput cols 2>/dev/null || true)"
  fi
  [[ "$columns" =~ ^[0-9]+$ ]] || columns=80
  (( columns < 20 )) && columns=20
  (( columns > 240 )) && columns=240
  printf '%s' "$columns"
}

progress_detect_utf8_locale() {
  local candidate charmap
  for candidate in C.UTF-8 C.utf8 en_US.UTF-8; do
    charmap="$(LC_ALL="$candidate" /usr/bin/locale charmap 2>/dev/null || true)"
    [[ "$charmap" == UTF-8 ]] || continue
    if LC_ALL="$candidate" /bin/bash --noprofile --norc -p \
        -c '[[ ${#1} -eq 1 ]]' _ 'Ж' 2>/dev/null; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  printf 'C'
}

progress_locale_requests_ascii() {
  local effective_locale="${LC_ALL:-${LC_CTYPE:-${LANG:-}}}"
  case "$effective_locale" in
    C|POSIX) return 0 ;;
    *) return 1 ;;
  esac
}

progress_stderr_is_tty() {
  [[ -t 2 ]]
}

progress_capture_presentation_input() {
  # This function runs before the clean-environment reexec. Keep it strictly
  # Bash-builtin-only: inherited PATH, TERMINFO and LOCPATH must be inert.
  local columns="${COLUMNS:-80}"
  if [[ "$columns" =~ ^[0-9]{1,3}$ ]]; then
    columns=$((10#$columns))
  else
    columns=80
  fi
  (( columns < 20 )) && columns=20
  (( columns > 240 )) && columns=240
  PROGRESS_PRESENTATION_INPUT_VALIDATED=1
  PROGRESS_PRESENTATION_COLUMNS="$columns"
  PROGRESS_PRESENTATION_TTY=0
  PROGRESS_PRESENTATION_UNICODE=0
  PROGRESS_PRESENTATION_COLOR=0
  if progress_stderr_is_tty && [[ "${TERM:-dumb}" != dumb ]] &&
      (( columns >= SONAR_PRODUCTION_MIN_WIDTH )); then
    PROGRESS_PRESENTATION_TTY=1
    if ! progress_locale_requests_ascii; then
      PROGRESS_PRESENTATION_UNICODE=1
    fi
    [[ -n "${NO_COLOR:-}" ]] || PROGRESS_PRESENTATION_COLOR=1
  fi
}

progress_detect_terminal() {
  local colours=0 requested_width="$PROGRESS_WIDTH" max_width
  PROGRESS_INTERACTIVE=0
  PROGRESS_UNICODE=0
  PROGRESS_COLOR=0
  PROGRESS_COLUMNS="$(progress_terminal_columns)"
  PROGRESS_UTF8_LOCALE="$(progress_detect_utf8_locale)"
  max_width=$((PROGRESS_COLUMNS-14))
  (( max_width < 16 )) && max_width=16
  case "$PROGRESS_MODE" in
    off)
      return 1
      ;;
    plain)
      PROGRESS_INTERACTIVE=0
      ;;
    tty)
      if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
        PROGRESS_INTERACTIVE="$PROGRESS_PRESENTATION_TTY"
      else
        PROGRESS_INTERACTIVE=1
      fi
      ;;
    auto)
      if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
        PROGRESS_INTERACTIVE="$PROGRESS_PRESENTATION_TTY"
      elif progress_stderr_is_tty && [[ "${TERM:-dumb}" != dumb ]]; then
        PROGRESS_INTERACTIVE=1
      else
        PROGRESS_INTERACTIVE=0
      fi
      ;;
    *)
      printf 'Недопустимый SERVER_TOOLKIT_PROGRESS_MODE=%s; используется auto.\n' "$PROGRESS_MODE" >&2
      PROGRESS_MODE=auto
      if progress_stderr_is_tty && [[ "${TERM:-dumb}" != dumb ]]; then
        PROGRESS_INTERACTIVE=1
      else
        PROGRESS_INTERACTIVE=0
      fi
      ;;
  esac

  if [[ "$requested_width" == auto ]]; then
    PROGRESS_WIDTH=34
  elif [[ "$requested_width" =~ ^[0-9]+$ ]]; then
    PROGRESS_WIDTH="$requested_width"
  else
    printf 'Недопустимый SERVER_TOOLKIT_PROGRESS_WIDTH=%s; используется auto.\n' "$requested_width" >&2
    PROGRESS_WIDTH=34
  fi
  (( PROGRESS_WIDTH < 16 )) && PROGRESS_WIDTH=16
  (( PROGRESS_WIDTH > max_width )) && PROGRESS_WIDTH="$max_width"
  (( PROGRESS_WIDTH > 60 )) && PROGRESS_WIDTH=60

  # The active CRT row is the only mutable row. Keep it within the terminal so
  # even that one row never wraps while the spinner is being updated.
  if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" != 1 && "${TERM:-dumb}" == dumb ]]; then
    PROGRESS_INTERACTIVE=0
  fi
  if (( PROGRESS_INTERACTIVE == 1 && PROGRESS_COLUMNS < SONAR_MIN_WIDTH )); then
    PROGRESS_INTERACTIVE=0
  fi
  if (( PROGRESS_INTERACTIVE == 1 )) && [[ "$PROGRESS_UTF8_LOCALE" == C ]]; then
    PROGRESS_INTERACTIVE=0
  fi

  # The internal UTF-8 locale keeps Cyrillic geometry correct. Glyph selection
  # remains a separate caller capability, so an explicit C/POSIX locale gets
  # the ASCII symbol table without disabling the fixed-layout screen.
  if (( PROGRESS_INTERACTIVE == 1 )); then
    if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
      PROGRESS_UNICODE="$PROGRESS_PRESENTATION_UNICODE"
    elif progress_locale_requests_ascii; then
      PROGRESS_UNICODE=0
    else
      PROGRESS_UNICODE=1
    fi
  else
    PROGRESS_UNICODE=0
  fi

  if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
    PROGRESS_COLOR="$PROGRESS_PRESENTATION_COLOR"
  elif (( PROGRESS_INTERACTIVE == 1 )) && [[ -x /usr/bin/tput ]]; then
    colours="$(/usr/bin/tput colors 2>/dev/null || echo 0)"
    [[ "$colours" =~ ^[0-9]+$ ]] || colours=0
    (( colours >= 8 )) && PROGRESS_COLOR=1
  fi
  [[ -z "${NO_COLOR:-}" ]] || PROGRESS_COLOR=0
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_UTF8_LOCALE="$PROGRESS_UTF8_LOCALE"
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_UNICODE="$PROGRESS_UNICODE"
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_COLOR="$PROGRESS_COLOR"
  sonar_set_width "$PROGRESS_COLUMNS" || PROGRESS_INTERACTIVE=0
  sonar_configure_symbols
  return 0
}

progress_colour() {
  local name="$1"
  (( PROGRESS_COLOR == 1 )) || return 0
  case "$name" in
    green) sonar_colour primary ;;
    yellow) sonar_colour attention ;;
    red) sonar_colour failure ;;
    cyan) sonar_colour active ;;
    reset) printf '\033[0m' ;;
  esac
}

progress_spinner_glyph() {
  local tick="$1"
  local -a unicode_spinner=("◐" "◓" "◑" "◒")
  local -a ascii_spinner=("|" "/" "-" "\\")
  if (( PROGRESS_UNICODE == 1 )); then
    printf '%s' "${unicode_spinner[$((tick % ${#unicode_spinner[@]}))]}"
  else
    printf '%s' "${ascii_spinner[$((tick % ${#ascii_spinner[@]}))]}"
  fi
}

progress_cursor_hide() {
  if (( PROGRESS_INTERACTIVE == 1 && PROGRESS_CURSOR_HIDDEN == 0 )); then
    printf '\033[?25l' >&2
    PROGRESS_CURSOR_HIDDEN=1
  fi
}

progress_cursor_show() {
  if (( PROGRESS_CURSOR_HIDDEN == 1 )); then
    printf '\033[?25h' >&2
    PROGRESS_CURSOR_HIDDEN=0
  fi
}

progress_open_presentation_fd() {
  [[ -z "$PROGRESS_PRESENTATION_FD" ]] || return 0
  # Bash 3.2 has no dynamic {var} redirection. Use one reserved descriptor,
  # but never replace a descriptor inherited from the caller.
  if ( : >&9 ) 2>/dev/null; then
    return 1
  fi
  exec 9>&2 || return 1
  PROGRESS_PRESENTATION_FD=9
  SONAR_OUTPUT_FD=9
}

progress_close_presentation_fd() {
  [[ -n "${PROGRESS_PRESENTATION_FD:-}" ]] || {
    SONAR_OUTPUT_FD=2
    return 0
  }
  SONAR_OUTPUT_FD=2
  exec 9>&-
  PROGRESS_PRESENTATION_FD=""
}

progress_line_prefix() {
  local stage="$1" width="$PROGRESS_WIDTH" dots i
  local LC_ALL="$PROGRESS_UTF8_LOCALE"
  if (( PROGRESS_INTERACTIVE == 1 && ${#stage} > width-2 )); then
    stage="${stage:0:width-3}…"
  fi
  dots=$((width-${#stage}))
  (( dots < 2 )) && dots=2
  printf '%s' "$stage"
  for ((i=0; i<dots; i++)); do printf '.'; done
  printf ' '
}

progress_render_active_line() {
  local stage="$1" tick="${2:-0}" spinner reset elapsed
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    sonar_sync_width_from_terminal || return 0
    SONAR_LAST_TICK="$tick"
    elapsed="$(sonar_elapsed_seconds)"
    sonar_update_progress "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$elapsed"
    sonar_update_state "$SONAR_ACTIVE_GROUP" "" 1
    return 0
  fi
  spinner="$(progress_spinner_glyph "$tick")"
  reset="$(progress_colour reset)"
  printf '\r\033[2K' >&2
  progress_line_prefix "$stage" >&2
  printf '%s%s%s' "$(progress_colour cyan)" "$spinner" "$reset" >&2
}

progress_render_spinner_tick() {
  local tick="$1" slow="$2" colour=cyan spinner reset elapsed rc=0
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    sonar_render_lock_acquire || return 0
    if sonar_heartbeat_updates_disabled; then
      sonar_render_lock_release || return 2
      PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      return 0
    fi
    if ! sonar_sync_width_from_terminal; then
      sonar_disable_heartbeat_updates || rc=2
      sonar_render_lock_release || rc=2
      PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      return "$rc"
    fi
    # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
    SONAR_LAST_TICK="$tick"
    elapsed="$(sonar_elapsed_seconds)"
    sonar_update_progress "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$elapsed" || rc=2
    sonar_update_state "$SONAR_ACTIVE_GROUP" "" 1 || rc=2
    sonar_render_lock_release || rc=2
    return "$rc"
  fi
  (( slow == 1 )) && colour=yellow
  spinner="$(progress_spinner_glyph "$tick")"
  reset="$(progress_colour reset)"
  printf '\b%s%s%s' "$(progress_colour "$colour")" "$spinner" "$reset" >&2
}

progress_render_committed_line() {
  local stage="$1" outcome="$2" group elapsed
  : "$outcome"
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    group="$(sonar_group_for_stage "$stage")"
    elapsed="$(sonar_elapsed_seconds)"
    sonar_update_progress "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$elapsed"
    sonar_update_state "$group" "${SONAR_GROUP_STATES[$group]:-}" 0
    return 0
  fi
  if (( PROGRESS_INTERACTIVE == 1 )); then
    printf '\r\033[2K' >&2
  fi
  progress_line_prefix "$stage" >&2
  printf '\n' >&2
}

progress_heartbeat_platform_protocol() {
  if [[ -r "/proc/$$/stat" ]]; then
    printf 'strong'
  else
    printf 'weak'
  fi
}

progress_prepare_weak_heartbeat_coordination() {
  local generation_id prefix path created_a=0
  [[ "$PROGRESS_RUNTIME_DIR" == /* &&
     "$PROGRESS_RUNTIME_DIR" != *$'\n'* &&
     -d "$PROGRESS_RUNTIME_DIR" && ! -L "$PROGRESS_RUNTIME_DIR" ]] ||
    return 2
  PROGRESS_HEARTBEAT_GENERATION=$((PROGRESS_HEARTBEAT_GENERATION+1))
  generation_id="$$.$PROGRESS_HEARTBEAT_GENERATION"
  prefix="$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$generation_id"
  PROGRESS_HEARTBEAT_GENERATION_ID="$generation_id"
  PROGRESS_HEARTBEAT_STOP_FILE="$prefix.stop"
  PROGRESS_HEARTBEAT_DONE_FILE="$prefix.done"
  PROGRESS_HEARTBEAT_JOBS_A_DIR="$prefix.jobs-a"
  PROGRESS_HEARTBEAT_JOBS_B_DIR="$prefix.jobs-b"
  PROGRESS_HEARTBEAT_JOBS_A_FILE="$PROGRESS_HEARTBEAT_JOBS_A_DIR/snapshot"
  PROGRESS_HEARTBEAT_JOBS_B_FILE="$PROGRESS_HEARTBEAT_JOBS_B_DIR/snapshot"
  PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
  PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
  PROGRESS_HEARTBEAT_ACK_STATUS=""
  for path in \
      "$PROGRESS_HEARTBEAT_STOP_FILE" \
      "$PROGRESS_HEARTBEAT_DONE_FILE" \
      "$PROGRESS_HEARTBEAT_JOBS_A_DIR" \
      "$PROGRESS_HEARTBEAT_JOBS_B_DIR"; do
    [[ ! -e "$path" && ! -L "$path" ]] || return 2
  done
  if /bin/mkdir -m 700 -- "$PROGRESS_HEARTBEAT_JOBS_A_DIR" 2>/dev/null; then
    created_a=1
  else
    return 2
  fi
  if ! /bin/mkdir -m 700 -- "$PROGRESS_HEARTBEAT_JOBS_B_DIR" 2>/dev/null; then
    (( created_a == 0 )) ||
      /bin/rmdir -- "$PROGRESS_HEARTBEAT_JOBS_A_DIR" 2>/dev/null || true
    return 2
  fi
}

progress_heartbeat_marker_matches() {
  local path="$1" generation_id="$2" line="" extra=""
  if [[ ! -e "$path" && ! -L "$path" ]]; then
    return 1
  fi
  [[ -f "$path" && ! -L "$path" ]] || return 2
  {
    IFS= read -r line || [[ -n "$line" ]] || return 2
    if IFS= read -r extra; then
      return 2
    fi
  } <"$path"
  [[ "$line" == "$generation_id" ]]
}

progress_weak_heartbeat_write_done() {
  local done_file="$1" generation_id="$2" final_status="$3"
  [[ -n "$done_file" && -n "$generation_id" &&
     "$final_status" =~ ^(0|[1-9][0-9]{0,2})$ &&
     "$final_status" -le 255 ]] || return 2
  [[ ! -e "$done_file" && ! -L "$done_file" ]] || return 2
  (umask 077; set -o noclobber
   printf '%s|%s\n' "$generation_id" "$final_status" \
     >"$done_file") 2>/dev/null || return 2
  progress_heartbeat_ack_status "$done_file" "$generation_id" &&
    [[ "$PROGRESS_HEARTBEAT_ACK_STATUS" == "$final_status" ]]
}

progress_heartbeat_ack_status() {
  local path="$1" generation_id="$2" line="" extra="" ack_generation="" status=""
  PROGRESS_HEARTBEAT_ACK_STATUS=""
  if [[ ! -e "$path" && ! -L "$path" ]]; then
    return 1
  fi
  [[ -f "$path" && ! -L "$path" ]] || return 2
  {
    IFS= read -r line || [[ -n "$line" ]] || return 2
    # shellcheck disable=SC2034 # a second record is rejected regardless of its payload
    if IFS= read -r extra; then
      return 2
    fi
  } <"$path"
  ack_generation="${line%%|*}"
  status="${line#*|}"
  [[ "$line" == *'|'* && "$ack_generation" == "$generation_id" &&
     "$status" =~ ^(0|[1-9][0-9]{0,2})$ && "$status" -le 255 ]] || return 2
  PROGRESS_HEARTBEAT_ACK_STATUS="$status"
}

progress_weak_heartbeat_finalize() {
  local done_file="$1" generation_id="$2" final_status="$3" rc=0
  sonar_render_lock_exit_release || rc=2
  if (( rc == 0 )); then
    progress_weak_heartbeat_write_done \
      "$done_file" "$generation_id" "$final_status" || rc=2
  fi
  return "$rc"
}

progress_weak_heartbeat_exit() {
  local final_status=$? done_file="$1" generation_id="$2"
  trap - EXIT
  if ! progress_weak_heartbeat_finalize \
      "$done_file" "$generation_id" "$final_status"; then
    final_status=2
  fi
  exit "$final_status"
}

progress_weak_heartbeat_stop_requested() {
  local stop_file="$1" generation_id="$2" marker_rc=0
  progress_heartbeat_marker_matches "$stop_file" "$generation_id" ||
    marker_rc=$?
  (( marker_rc == 0 )) && return 0
  (( marker_rc == 1 )) && return 1
  return 2
}

progress_stage_heartbeat_loop() {
  local parent="$1" started="$2" soft="$3" protocol="${4:-strong}"
  local stop_file="${5:-}" done_file="${6:-}" generation_id="${7:-}"
  local tick=1 now elapsed slow loop_rc=0 marker_rc=1
  trap - ERR HUP INT TERM EXIT
  trap '' WINCH
  PROGRESS_HEARTBEAT_STOP_REQUESTED=0
  # The parent quiesces this shell before taking an identity-bearing process
  # snapshot. Once resumed, a trapped stop must exit before the remainder of
  # the loop body can spawn a helper absent from that frozen snapshot. EXIT
  # performs the owner-aware render-lock release; the parent recovers a stale
  # empty lock only after heartbeat death is proven.
  trap 'PROGRESS_HEARTBEAT_STOP_REQUESTED=1; exit 0' HUP INT TERM
  if [[ "$protocol" == weak ]]; then
    trap 'progress_weak_heartbeat_exit "$done_file" "$generation_id"' EXIT
  else
    trap 'sonar_render_lock_exit_release' EXIT
  fi
  set +e
  while (( PROGRESS_HEARTBEAT_STOP_REQUESTED == 0 )) &&
      kill -0 "$parent" 2>/dev/null; do
    if [[ "$protocol" == weak ]]; then
      marker_rc=0
      progress_weak_heartbeat_stop_requested "$stop_file" "$generation_id" ||
        marker_rc=$?
      if (( marker_rc == 0 )); then
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
      if (( marker_rc == 2 )); then
        loop_rc=2
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
    fi
    now="$(date +%s)"
    elapsed=$((now-started))
    (( elapsed < 0 )) && elapsed=0
    slow=0
    (( elapsed >= soft )) && slow=1
    if [[ "$protocol" == weak ]]; then
      marker_rc=0
      progress_weak_heartbeat_stop_requested "$stop_file" "$generation_id" ||
        marker_rc=$?
      if (( marker_rc == 0 )); then
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
      if (( marker_rc == 2 )); then
        loop_rc=2
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
    fi
    if ! progress_render_spinner_tick "$tick" "$slow"; then
      loop_rc=2
      PROGRESS_HEARTBEAT_STOP_REQUESTED=1
    fi
    if [[ "$protocol" == weak ]]; then
      marker_rc=0
      progress_weak_heartbeat_stop_requested "$stop_file" "$generation_id" ||
        marker_rc=$?
      if (( marker_rc == 0 )); then
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      elif (( marker_rc == 2 )); then
        loop_rc=2
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      fi
    fi
    tick=$((tick+1))
    (( PROGRESS_HEARTBEAT_STOP_REQUESTED == 0 )) || break
    sleep 0.15
  done
  if [[ "$protocol" == weak ]]; then
    trap - EXIT
    progress_weak_heartbeat_finalize \
      "$done_file" "$generation_id" "$loop_rc" || loop_rc=2
  else
    sonar_render_lock_exit_release
    trap - EXIT
  fi
  return "$loop_rc"
}

progress_wrap_text() {
  local text="$1" indent="${2:-  }" value_colour="${3:-reset}"
  local width paragraph line word candidate reset
  local LC_ALL="$PROGRESS_UTF8_LOCALE"
  local -a words=()
  PROGRESS_COLUMNS="$(progress_terminal_columns)"
  width=$((PROGRESS_COLUMNS-${#indent}))
  (( width < 24 )) && width=24
  (( width > 180 )) && width=180
  reset="$(progress_colour reset)"

  # A semicolon in recommendations normally separates two independent actions.
  # Turn it into a deliberate paragraph boundary before wrapping by words.
  text="${text//; /;$'\n'}"
  while IFS= read -r paragraph || [[ -n "$paragraph" ]]; do
    line=""
    words=()
    IFS=' ' read -r -a words <<<"$paragraph"
    for word in "${words[@]}"; do
      candidate="${line:+$line }$word"
      if [[ -n "$line" ]] && (( ${#candidate} > width )); then
        printf '%s%s%s%s\n' "$(progress_colour "$value_colour")" "$indent" "$line" "$reset"
        line="$word"
      else
        line="$candidate"
      fi
    done
    if [[ -n "$line" ]]; then
      printf '%s%s%s%s\n' "$(progress_colour "$value_colour")" "$indent" "$line" "$reset"
    else
      printf '\n'
    fi
  done <<<"$text"
}

progress_print_block() {
  local title="$1" text="$2" value_colour="${3:-reset}" reset
  reset="$(progress_colour reset)"
  printf '\n%s%s%s\n' "$(progress_colour cyan)" "$title" "$reset"
  progress_wrap_text "$text" "  " "$value_colour"
}

progress_write_state() {
  local percent="$1" stage="$2" started="$3" soft="$4" tmp
  PROGRESS_PERCENT="$percent"
  PROGRESS_STAGE="$stage"
  PROGRESS_SOFT_SECONDS="$soft"
  [[ -n "$PROGRESS_STATE_FILE" ]] || return 0
  tmp="${PROGRESS_STATE_FILE}.tmp.$$"
  printf '%s|%s|%s|%s\n' "$percent" "${stage//|/ }" "$started" "$soft" >"$tmp"
  mv -f "$tmp" "$PROGRESS_STATE_FILE"
}

progress_init() {
  local run_dir="$1" host="${2:-}" now
  SONAR_PRESENTATION_READY=0
  PROGRESS_RUNTIME_DIR="$run_dir"
  progress_detect_terminal || return 0
  sonar_runtime_configure "$run_dir" || PROGRESS_INTERACTIVE=0
  PROGRESS_CLEANUP_IN_PROGRESS=0
  PROGRESS_CLEANUP_DONE=0
  PROGRESS_CLEANUP_STATUS=0
  PROGRESS_FAILURE_REPORTED=0
  PROGRESS_SIGNAL_IN_PROGRESS=0
  PROGRESS_SIGNAL_REPORT_PATH="недоступен"
  PROGRESS_PENDING_SIGNAL=""
  PROGRESS_PENDING_SIGNAL_REPORT=""
  PROGRESS_HEARTBEAT_STARTING=0
  PROGRESS_HEARTBEAT_STOP_REQUESTED=0
  PROGRESS_HEARTBEAT_PROTOCOL=""
  PROGRESS_HEARTBEAT_GENERATION=0
  PROGRESS_HEARTBEAT_GENERATION_ID=""
  PROGRESS_HEARTBEAT_STOP_FILE=""
  PROGRESS_HEARTBEAT_DONE_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_DIR=""
  PROGRESS_HEARTBEAT_JOBS_B_DIR=""
  PROGRESS_HEARTBEAT_JOBS_A_FILE=""
  PROGRESS_HEARTBEAT_JOBS_B_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
  PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
  PROGRESS_HEARTBEAT_ACK_STATUS=""
  PROGRESS_STATE_FILE="$run_dir/.progress-state"
  now="$(date +%s)"
  progress_write_state 0 "Подготовка отчёта" "$now" 8
  PROGRESS_ACTIVE=1
  PROGRESS_COMPLETED_SECTIONS=0
  PROGRESS_COMPLETED_STAGES=0
  PROGRESS_STAGE_STARTED="$now"
  PROGRESS_STAGE_ACTIVE=0
  sonar_reset_audit_state
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_STARTED_AT="$now"
  if (( PROGRESS_INTERACTIVE == 1 )); then
    if ! progress_open_presentation_fd; then
      PROGRESS_INTERACTIVE=0
      printf 'SERVER TOOLKIT — АУДИТ\n\n' >&2
      return 0
    fi
    trap 'sonar_handle_winch' WINCH
    if sonar_screen_enter "$host" 0 "$PROGRESS_TOTAL_STAGES" "$now"; then
      PROGRESS_CURSOR_HIDDEN=1
    else
      SONAR_PRESENTATION_READY=0
      PROGRESS_INTERACTIVE=0
      sonar_screen_restore || true
      progress_close_presentation_fd || true
      trap - WINCH
      printf 'SERVER TOOLKIT — АУДИТ\n\n' >&2
    fi
  else
    printf 'SERVER TOOLKIT — АУДИТ\n\n' >&2
  fi
}

progress_stage_limits() {
  local title="$1"
  PROGRESS_SOFT_SECONDS=8
  # shellcheck disable=SC2034 # consumed after this module is embedded
  CURRENT_STAGE_TIMEOUT=45
  # shellcheck disable=SC2034 # branch assignments are consumed after embedding
  case "$title" in
    *"CPU SAMPLE"*) PROGRESS_SOFT_SECONDS=12; CURRENT_STAGE_TIMEOUT=20 ;;
    *"SYSTEM ERRORS"*|*"KERNEL WARNINGS"*|*"RESTARTING SERVICES"*) PROGRESS_SOFT_SECONDS=12; CURRENT_STAGE_TIMEOUT=60 ;;
    *"PUBLIC IP"*|*"DNS"*|*"LATENCY"*|*"DOWNLOAD"*) PROGRESS_SOFT_SECONDS=10; CURRENT_STAGE_TIMEOUT=45 ;;
    *"UPGRADE SIMULATION"*) PROGRESS_SOFT_SECONDS=20; CURRENT_STAGE_TIMEOUT=120 ;;
  esac
}

progress_display_stage() {
  local title="$1"
  case "$title" in
    *"SERVER IDENTITY"*) printf 'Сервер и система' ;;
    *"IDENTITY RAW"*) printf 'Подробности системы' ;;
    *"CPU SAMPLE"*) printf 'Нагрузка процессора' ;;
    *"UPTIME"*) printf 'Время работы' ;;
    *"CPU"*) printf 'Процессор' ;;
    *"MEMORY"*) printf 'Память' ;;
    *"DISK"*) printf 'Диски' ;;
    *"PUBLIC IP"*) printf 'Внешний адрес' ;;
    *"DNS"*) printf 'DNS' ;;
    *"LISTENING PORTS RAW"*) printf 'Сетевые порты' ;;
    *"PORT INVENTORY"*) printf 'Анализ портов' ;;
    *"NETWORK"*) printf 'Сетевые интерфейсы' ;;
    *"FIREWALL"*) printf 'Межсетевой экран' ;;
    *"FAILED SERVICES"*) printf 'Состояние служб' ;;
    *"RESTARTING SERVICES"*) printf 'Повторные сбои служб' ;;
    *"SECURITY BASELINE"*) printf 'Базовая безопасность' ;;
    *"VIRTUALIZATION"*) printf 'Виртуализация' ;;
    *"SYSTEM ERRORS"*) printf 'Системные ошибки' ;;
    *"KERNEL WARNINGS"*) printf 'Предупреждения ядра' ;;
    *"INTERNET NOISE"*) printf 'Внешний шум SSH' ;;
    *"PACKAGE INDEX"*) printf 'Индекс пакетов' ;;
    *"PACKAGE STATE"*) printf 'Состояние пакетов' ;;
    *"UPGRADE SIMULATION"*) printf 'Проверка обновления' ;;
    *"TIME"*) printf 'Системное время' ;;
    *"LATENCY"*) printf 'Задержка сети' ;;
    *"DOWNLOAD"*) printf 'Скорость доступа' ;;
    *) printf '%s' "$title" ;;
  esac
}

progress_begin_stage() {
  local percent="$1" stage="$2" soft="$3" now heartbeat_pid identity protocol
  (( PROGRESS_ACTIVE == 1 )) || return 0
  progress_stop_heartbeat || return $?
  now="$(date +%s)"
  PROGRESS_STAGE_STARTED="$now"
  PROGRESS_STAGE_ACTIVE=1
  sonar_begin_stage "$stage"
  progress_write_state "$percent" "$stage" "$now" "$soft"
  if (( PROGRESS_INTERACTIVE == 1 )); then
    progress_render_active_line "$stage" 0
    protocol="$(progress_heartbeat_platform_protocol)"
    [[ "$protocol" == strong || "$protocol" == weak ]] || return 2
    PROGRESS_HEARTBEAT_PROTOCOL="$protocol"
    if [[ "$protocol" == weak ]]; then
      progress_prepare_weak_heartbeat_coordination || return 2
    else
      PROGRESS_HEARTBEAT_GENERATION_ID=""
      PROGRESS_HEARTBEAT_STOP_FILE=""
      PROGRESS_HEARTBEAT_DONE_FILE=""
      PROGRESS_HEARTBEAT_JOBS_A_DIR=""
      PROGRESS_HEARTBEAT_JOBS_B_DIR=""
      PROGRESS_HEARTBEAT_JOBS_A_FILE=""
      PROGRESS_HEARTBEAT_JOBS_B_FILE=""
      PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
      PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
      PROGRESS_HEARTBEAT_ACK_STATUS=""
    fi
    PROGRESS_HEARTBEAT_STARTING=1
    progress_stage_heartbeat_loop \
      "$$" "$now" "$soft" "$protocol" \
      "$PROGRESS_HEARTBEAT_STOP_FILE" \
      "$PROGRESS_HEARTBEAT_DONE_FILE" \
      "$PROGRESS_HEARTBEAT_GENERATION_ID" &
    heartbeat_pid=$!
    PROGRESS_HEARTBEAT_PID="$heartbeat_pid"
    PROGRESS_HEARTBEAT_IDENTITY=""
    identity="$(
      progress_capture_process_identity "$heartbeat_pid" 2>/dev/null || true
    )"
  if [[ -z "$identity" ]]; then
    PROGRESS_HEARTBEAT_STARTING=0
    if [[ -n "$PROGRESS_PENDING_SIGNAL" ]]; then
      progress_dispatch_pending_signal
    elif [[ "$protocol" == weak ]]; then
      progress_stop_weak_heartbeat || true
    fi
    printf 'progress_process_tree_status=heartbeat_start_identity_unavailable pid=%s\n' \
      "$heartbeat_pid" >&2
    return 2
    fi
  if [[ "$protocol" == weak && "$identity" != ps:* ]] ||
        [[ "$protocol" == strong && "$identity" != proc:* ]]; then
    PROGRESS_HEARTBEAT_STARTING=0
    if [[ -n "$PROGRESS_PENDING_SIGNAL" ]]; then
      progress_dispatch_pending_signal
    elif [[ "$protocol" == weak ]]; then
      progress_stop_weak_heartbeat || true
    fi
    printf 'progress_process_tree_status=heartbeat_start_protocol_mismatch pid=%s protocol=%s\n' \
      "$heartbeat_pid" "$protocol" >&2
    return 2
    fi
    PROGRESS_HEARTBEAT_IDENTITY="$identity"
    PROGRESS_HEARTBEAT_STARTING=0
    progress_dispatch_pending_signal
  fi
}

progress_finish_stage() {
  local percent="$1" now elapsed outcome=ok
  (( PROGRESS_ACTIVE == 1 && PROGRESS_STAGE_ACTIVE == 1 )) || return 0
  now="$(date +%s)"
  elapsed=$((now-PROGRESS_STAGE_STARTED))
  (( elapsed < 0 )) && elapsed=0
  (( elapsed >= PROGRESS_SOFT_SECONDS )) && outcome=slow
  progress_stop_heartbeat || return $?
  sonar_finish_stage "$PROGRESS_STAGE" "$outcome"
  PROGRESS_STAGE_ACTIVE=0
  PROGRESS_COMPLETED_STAGES=$((PROGRESS_COMPLETED_STAGES+1))
  (( PROGRESS_COMPLETED_STAGES > PROGRESS_TOTAL_STAGES )) && PROGRESS_COMPLETED_STAGES="$PROGRESS_TOTAL_STAGES"
  progress_render_committed_line "$PROGRESS_STAGE" "$outcome"
  progress_write_state "$percent" "$PROGRESS_STAGE" "$now" "$PROGRESS_SOFT_SECONDS"
}

progress_section_start() {
  local title="$1" display percent
  progress_stage_limits "$title"
  display="$(progress_display_stage "$title")"
  percent=$(( PROGRESS_COMPLETED_SECTIONS * 88 / PROGRESS_TOTAL_SECTIONS ))
  progress_begin_stage "$percent" "$display" "$PROGRESS_SOFT_SECONDS"
}

progress_section_complete() {
  local title="$1" percent
  : "$title"
  PROGRESS_COMPLETED_SECTIONS=$((PROGRESS_COMPLETED_SECTIONS+1))
  (( PROGRESS_COMPLETED_SECTIONS > PROGRESS_TOTAL_SECTIONS )) && PROGRESS_COMPLETED_SECTIONS="$PROGRESS_TOTAL_SECTIONS"
  percent=$(( PROGRESS_COMPLETED_SECTIONS * 88 / PROGRESS_TOTAL_SECTIONS ))
  progress_finish_stage "$percent"
}

progress_set_absolute() {
  local percent="$1" stage="$2" soft="${3:-8}"
  progress_finish_stage "$PROGRESS_PERCENT"
  progress_begin_stage "$percent" "$stage" "$soft"
}

progress_sync_disabled_presentation() {
  local columns max_width
  sonar_heartbeat_updates_disabled || return 0
  SONAR_PRESENTATION_READY=0
  PROGRESS_INTERACTIVE=0
  columns="$(progress_terminal_columns)"
  if [[ "$columns" =~ ^[0-9]+$ ]]; then
    PROGRESS_COLUMNS="$columns"
    max_width=$((columns-14))
    (( max_width < 16 )) && max_width=16
    (( PROGRESS_WIDTH > max_width )) && PROGRESS_WIDTH="$max_width"
  fi
  sonar_screen_restore || return 2
  trap - WINCH
}

progress_process_parent_pid() {
  local pid="$1" stat_line stat_tail ppid
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  (( pid > 1 )) || return 1
  if [[ -r "/proc/$pid/stat" ]]; then
    stat_line="$(<"/proc/$pid/stat")" || return 1
    stat_tail="${stat_line##*) }"
    ppid="${stat_tail#* }"
    ppid="${ppid%% *}"
  else
    ppid="$(
      LC_ALL=C /bin/ps -o ppid= -p "$pid" 2>/dev/null |
        /usr/bin/awk 'NF { print $1; exit }'
    )"
  fi
  [[ "$ppid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  printf '%s' "$ppid"
}

progress_heartbeat_original_is_gone() {
  local pid="$1" identity="$2"
  case "$identity" in
    proc:*)
      ! kill -0 "$pid" 2>/dev/null
      ;;
    *)
      return 1
      ;;
  esac
}

progress_capture_heartbeat_jobs_snapshot() {
  local path="$1" dir="" next="" owned=0 noclobber_was_set=0 jobs_rc=0
  if [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_A_FILE" ]]; then
    dir="$PROGRESS_HEARTBEAT_JOBS_A_DIR"
    owned="$PROGRESS_HEARTBEAT_JOBS_A_OWNED"
  elif [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_B_FILE" ]]; then
    dir="$PROGRESS_HEARTBEAT_JOBS_B_DIR"
    owned="$PROGRESS_HEARTBEAT_JOBS_B_OWNED"
  else
    return 2
  fi
  [[ -n "$dir" && "$path" == "$dir/snapshot" &&
     -d "$dir" && ! -L "$dir" ]] || return 2
  next="$dir/snapshot.next"
  if (( owned == 1 )); then
    [[ -f "$path" && ! -L "$path" ]] || return 2
  else
    [[ ! -e "$path" && ! -L "$path" ]] || return 2
  fi
  [[ ! -e "$next" && ! -L "$next" ]] || return 2
  [[ "$-" == *C* ]] && noclobber_was_set=1
  set -o noclobber
  if jobs -pr >"$next" 2>/dev/null; then
    jobs_rc=0
  else
    jobs_rc=$?
  fi
  (( noclobber_was_set == 1 )) || set +o noclobber
  (( jobs_rc == 0 )) || return 2
  [[ -f "$next" && ! -L "$next" ]] || return 2
  /bin/mv -f -- "$next" "$path" 2>/dev/null || return 2
  [[ -f "$path" && ! -L "$path" ]] || return 2
  if [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_A_FILE" ]]; then
    PROGRESS_HEARTBEAT_JOBS_A_OWNED=1
  else
    PROGRESS_HEARTBEAT_JOBS_B_OWNED=1
  fi
}

progress_heartbeat_jobs_snapshot_contains() {
  local path="$1" wanted_pid="$2" job_pid
  [[ -f "$path" && ! -L "$path" ]] || return 2
  while IFS= read -r job_pid; do
    [[ "$job_pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    [[ "$job_pid" == "$wanted_pid" ]] && return 0
  done <"$path"
  return 1
}

progress_observe_weak_heartbeat_job() {
  local pid="$1" identity="$2" current="" ppid=""
  local jobs_a_rc=0 jobs_b_rc=0
  PROGRESS_HEARTBEAT_RESOLUTION=""
  PROGRESS_HEARTBEAT_OBSERVATION_ERROR=""
  [[ "$identity" == ps:* ]] || {
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=identity
    return 2
  }
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_A_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-a
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_A_FILE" "$pid" || jobs_a_rc=$?
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  ppid="$(progress_process_parent_pid "$pid" 2>/dev/null || true)"
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_B_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-b
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_B_FILE" "$pid" || jobs_b_rc=$?
  if (( jobs_b_rc == 1 )); then
    PROGRESS_HEARTBEAT_RESOLUTION=gone
    return 0
  fi
  if (( jobs_a_rc == 1 )); then
    PROGRESS_HEARTBEAT_RESOLUTION=replaced
    return 0
  fi
  if (( jobs_a_rc != 0 || jobs_b_rc != 0 )); then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-parse
    return 2
  fi
  if [[ -n "$current" && "$current" != "$identity" ]]; then
    PROGRESS_HEARTBEAT_RESOLUTION=replaced
    return 0
  fi
  if [[ -n "$ppid" && "$ppid" != "$$" ]]; then
    PROGRESS_HEARTBEAT_RESOLUTION=replaced
    return 0
  fi
  if [[ -z "$current" ]]; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=identity
    return 2
  fi
  if [[ -z "$ppid" ]]; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=ppid
    return 2
  fi
  PROGRESS_HEARTBEAT_RESOLUTION=owned
}

progress_observe_weak_heartbeat_job_absence() {
  local pid="$1" jobs_a_rc=0 jobs_b_rc=0
  PROGRESS_HEARTBEAT_RESOLUTION=""
  PROGRESS_HEARTBEAT_OBSERVATION_ERROR=""
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_A_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-a
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_A_FILE" "$pid" || jobs_a_rc=$?
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_B_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-b
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_B_FILE" "$pid" || jobs_b_rc=$?
  if (( jobs_a_rc > 1 || jobs_b_rc > 1 )); then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-parse
    return 2
  fi
  if (( jobs_b_rc == 1 )); then
    PROGRESS_HEARTBEAT_RESOLUTION=gone
  else
    # With no trusted identity, a present job is never classified as owned.
    PROGRESS_HEARTBEAT_RESOLUTION=unverified
  fi
}

progress_resolve_missing_heartbeat_identity() {
  local pid="$1" identity="$2" attempt current
  PROGRESS_HEARTBEAT_RESOLUTION=""
  [[ -n "$identity" ]] || return 2
  [[ "$identity" == proc:* ]] || return 2
  for ((attempt=0; attempt<10; attempt++)); do
    current="$(progress_process_identity "$pid" 2>/dev/null || true)"
    if [[ -n "$current" ]]; then
      if [[ "$current" == "$identity" ]]; then
        PROGRESS_HEARTBEAT_RESOLUTION=owned
      else
        PROGRESS_HEARTBEAT_RESOLUTION=gone
      fi
      return 0
    fi
    if progress_heartbeat_original_is_gone "$pid" "$identity"; then
      PROGRESS_HEARTBEAT_RESOLUTION=gone
      return 0
    fi
    sleep 0.01
  done
  return 2
}

progress_request_weak_heartbeat_stop() {
  local marker_rc=0
  progress_heartbeat_marker_matches \
    "$PROGRESS_HEARTBEAT_STOP_FILE" \
    "$PROGRESS_HEARTBEAT_GENERATION_ID" || marker_rc=$?
  (( marker_rc == 0 )) && return 0
  (( marker_rc == 1 )) || return 2
  (umask 077; set -o noclobber
   printf '%s\n' "$PROGRESS_HEARTBEAT_GENERATION_ID" \
     >"$PROGRESS_HEARTBEAT_STOP_FILE") 2>/dev/null || return 2
  progress_heartbeat_marker_matches \
    "$PROGRESS_HEARTBEAT_STOP_FILE" \
    "$PROGRESS_HEARTBEAT_GENERATION_ID"
}

progress_clear_weak_heartbeat_coordination() {
  local path dir owned unexpected
  [[ -n "$PROGRESS_HEARTBEAT_GENERATION_ID" ]] || return 2
  [[ "$PROGRESS_HEARTBEAT_STOP_FILE" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.stop" &&
     "$PROGRESS_HEARTBEAT_DONE_FILE" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.done" &&
     "$PROGRESS_HEARTBEAT_JOBS_A_DIR" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.jobs-a" &&
     "$PROGRESS_HEARTBEAT_JOBS_B_DIR" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.jobs-b" &&
     "$PROGRESS_HEARTBEAT_JOBS_A_FILE" == "$PROGRESS_HEARTBEAT_JOBS_A_DIR/snapshot" &&
     "$PROGRESS_HEARTBEAT_JOBS_B_FILE" == "$PROGRESS_HEARTBEAT_JOBS_B_DIR/snapshot" ]] ||
    return 2
  [[ -f "$PROGRESS_HEARTBEAT_STOP_FILE" &&
     ! -L "$PROGRESS_HEARTBEAT_STOP_FILE" &&
     -f "$PROGRESS_HEARTBEAT_DONE_FILE" &&
     ! -L "$PROGRESS_HEARTBEAT_DONE_FILE" ]] || return 2
  for dir in "$PROGRESS_HEARTBEAT_JOBS_A_DIR" "$PROGRESS_HEARTBEAT_JOBS_B_DIR"; do
    [[ -d "$dir" && ! -L "$dir" ]] || return 2
    [[ ! -e "$dir/snapshot.next" && ! -L "$dir/snapshot.next" ]] || return 2
    unexpected="$(/usr/bin/find "$dir" -mindepth 1 -maxdepth 1 \
      ! -name snapshot -print -quit 2>/dev/null)" || return 2
    [[ -z "$unexpected" ]] || return 2
  done
  for path in "$PROGRESS_HEARTBEAT_JOBS_A_FILE" "$PROGRESS_HEARTBEAT_JOBS_B_FILE"; do
    if [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_A_FILE" ]]; then
      owned="$PROGRESS_HEARTBEAT_JOBS_A_OWNED"
    else
      owned="$PROGRESS_HEARTBEAT_JOBS_B_OWNED"
    fi
    if (( owned == 1 )); then
      [[ -f "$path" && ! -L "$path" ]] || return 2
    else
      [[ ! -e "$path" && ! -L "$path" ]] || return 2
    fi
  done
  /bin/rm -f -- "$PROGRESS_HEARTBEAT_STOP_FILE" \
    "$PROGRESS_HEARTBEAT_DONE_FILE" 2>/dev/null || return 2
  (( PROGRESS_HEARTBEAT_JOBS_A_OWNED == 0 )) ||
    /bin/rm -f -- "$PROGRESS_HEARTBEAT_JOBS_A_FILE" 2>/dev/null || return 2
  (( PROGRESS_HEARTBEAT_JOBS_B_OWNED == 0 )) ||
    /bin/rm -f -- "$PROGRESS_HEARTBEAT_JOBS_B_FILE" 2>/dev/null || return 2
  /bin/rmdir -- "$PROGRESS_HEARTBEAT_JOBS_A_DIR" \
    "$PROGRESS_HEARTBEAT_JOBS_B_DIR" 2>/dev/null || return 2
  for path in "$PROGRESS_HEARTBEAT_STOP_FILE" \
      "$PROGRESS_HEARTBEAT_DONE_FILE" "$PROGRESS_HEARTBEAT_JOBS_A_DIR" \
      "$PROGRESS_HEARTBEAT_JOBS_B_DIR"; do
    [[ ! -e "$path" && ! -L "$path" ]] || return 2
  done
  PROGRESS_HEARTBEAT_GENERATION_ID=""
  PROGRESS_HEARTBEAT_STOP_FILE=""
  PROGRESS_HEARTBEAT_DONE_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_DIR=""
  PROGRESS_HEARTBEAT_JOBS_B_DIR=""
  PROGRESS_HEARTBEAT_JOBS_A_FILE=""
  PROGRESS_HEARTBEAT_JOBS_B_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
  PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
  PROGRESS_HEARTBEAT_ACK_STATUS=""
}

progress_stop_weak_heartbeat() {
  local pid="$PROGRESS_HEARTBEAT_PID" identity="$PROGRESS_HEARTBEAT_IDENTITY"
  local attempt observe_rc=0 resolution=""
  [[ "$PROGRESS_HEARTBEAT_PROTOCOL" == weak ]] || return 2

  # This exact-generation marker is the first cooperative stop action. All
  # PID, identity, PPID, and jobs observations below are diagnostic only.
  if ! progress_request_weak_heartbeat_stop; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_stop_marker_failed pid=%s\n' \
      "${pid:-unknown}" >&2
    return 2
  fi

  [[ "$pid" =~ ^[0-9]+$ ]] && (( pid > 1 )) || return 2
  [[ -n "$PROGRESS_HEARTBEAT_GENERATION_ID" &&
     -n "$PROGRESS_HEARTBEAT_STOP_FILE" &&
     -n "$PROGRESS_HEARTBEAT_DONE_FILE" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_A_DIR" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_B_DIR" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_A_FILE" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_B_FILE" ]] || return 2

  resolution=""
  for ((attempt=0; attempt<100; attempt++)); do
    observe_rc=0
    if [[ "$identity" == ps:* ]]; then
      progress_observe_weak_heartbeat_job "$pid" "$identity" || observe_rc=$?
    else
      progress_observe_weak_heartbeat_job_absence "$pid" || observe_rc=$?
    fi
    if (( observe_rc != 0 )); then
      if [[ "$PROGRESS_HEARTBEAT_OBSERVATION_ERROR" == jobs-* ]]; then
        SONAR_PRESENTATION_READY=0
        printf 'progress_process_tree_status=weak_heartbeat_observation_failed pid=%s reason=%s\n' \
          "$pid" "$PROGRESS_HEARTBEAT_OBSERVATION_ERROR" >&2
        return 2
      fi
    elif [[ "$PROGRESS_HEARTBEAT_RESOLUTION" == gone ]]; then
      resolution=gone
      break
    fi
    /bin/sleep 0.01
  done
  if [[ "$resolution" != gone ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_stop_unverified pid=%s reason=%s\n' \
      "$pid" "${PROGRESS_HEARTBEAT_OBSERVATION_ERROR:-job-present}" >&2
    return 2
  fi

  if ! progress_heartbeat_ack_status \
      "$PROGRESS_HEARTBEAT_DONE_FILE" \
      "$PROGRESS_HEARTBEAT_GENERATION_ID"; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_ack_invalid pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if [[ "$PROGRESS_HEARTBEAT_ACK_STATUS" != 0 ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_ack_nonzero pid=%s rc=%s\n' \
      "$pid" "$PROGRESS_HEARTBEAT_ACK_STATUS" >&2
    return 2
  fi
  if [[ -n "$SONAR_RENDER_LOCK_DIR" &&
        ( -e "$SONAR_RENDER_LOCK_DIR" || -L "$SONAR_RENDER_LOCK_DIR" ) ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_lock_unreleased pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if ! progress_sync_disabled_presentation; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=heartbeat_presentation_sync_failed\n' >&2
    return 2
  fi
  if ! progress_clear_weak_heartbeat_coordination; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_coordination_cleanup_failed pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  PROGRESS_HEARTBEAT_PID=""
  PROGRESS_HEARTBEAT_IDENTITY=""
  PROGRESS_HEARTBEAT_PROTOCOL=""
}

progress_finalize_gone_heartbeat() {
  local clear_ready="${1:-1}" rc=0
  # A different immutable identity at the recorded PID proves that the owned
  # heartbeat is gone. Never signal, stop, continue, or wait the replacement.
  (( clear_ready == 0 )) || SONAR_PRESENTATION_READY=0
  if ! sonar_recover_stale_render_lock; then
    printf 'progress_process_tree_status=heartbeat_lock_recovery_failed owned=%s\n' \
      "$SONAR_RENDER_LOCK_OWNED" >&2
    rc=2
  fi
  if ! progress_sync_disabled_presentation; then
    printf 'progress_process_tree_status=heartbeat_presentation_sync_failed\n' >&2
    rc=2
  fi
  PROGRESS_HEARTBEAT_PID=""
  PROGRESS_HEARTBEAT_IDENTITY=""
  PROGRESS_HEARTBEAT_PROTOCOL=""
  return "$rc"
}

progress_heartbeat_snapshot_has_live_members() {
  local snapshot="$1" trusted_root="$2" trusted_identity="$3"
  local pid identity current state uncertain=0
  while IFS=$'\t' read -r pid identity; do
    [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    (( pid > 1 )) || continue
    current="$(progress_process_identity "$pid" 2>/dev/null || true)"
    if [[ -n "$current" && "$current" != "$identity" ]]; then
      continue
    fi
    if [[ -z "$current" ]]; then
      if [[ "$pid" == "$trusted_root" ]] &&
          progress_heartbeat_original_is_gone "$pid" "$trusted_identity"; then
        continue
      fi
      if kill -0 "$pid" 2>/dev/null; then
        uncertain=1
      fi
      continue
    fi
    state="$(progress_process_state "$pid")"
    [[ "$state" == Z* ]] && continue
    kill -0 "$pid" 2>/dev/null && return 0
  done <<<"$snapshot"
  (( uncertain == 0 )) || return 2
  return 1
}

progress_resume_heartbeat_if_owned() {
  local pid="$1" identity="$2" current resolution=""
  [[ "$identity" == proc:* ]] || return 2
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$identity" && -n "$current" && "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_changed_before_continue pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if [[ -z "$identity" || -z "$current" ]]; then
    if [[ -n "$identity" ]] &&
        progress_resolve_missing_heartbeat_identity "$pid" "$identity"; then
      resolution="$PROGRESS_HEARTBEAT_RESOLUTION"
      if [[ "$resolution" == gone ]]; then
        return 0
      fi
      current="$identity"
    elif progress_heartbeat_original_is_gone "$pid" "$identity"; then
      return 0
    else
      printf 'progress_process_tree_status=heartbeat_identity_unavailable_before_continue pid=%s\n' \
        "$pid" >&2
      return 2
    fi
  fi
  if ! kill -CONT "$pid" 2>/dev/null; then
    if progress_resolve_missing_heartbeat_identity "$pid" "$identity" &&
        [[ "$PROGRESS_HEARTBEAT_RESOLUTION" == gone ]]; then
      return 0
    fi
    printf 'progress_process_tree_status=heartbeat_continue_failed pid=%s\n' \
      "$pid" >&2
    return 2
  fi
}

progress_capture_quiesced_heartbeat_tree() {
  local pid="$1" identity="$2" attempt state current snapshot
  local root_found=0 snapshot_pid snapshot_identity resolution=""
  PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT=""
  [[ "$identity" == proc:* ]] || return 2
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$identity" && -n "$current" && "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_changed_before_stop pid=%s\n' \
      "$pid" >&2
    return 3
  fi
  if [[ -n "$identity" && -z "$current" ]]; then
    if ! progress_resolve_missing_heartbeat_identity "$pid" "$identity"; then
      printf 'progress_process_tree_status=heartbeat_identity_unavailable_before_stop pid=%s\n' \
        "$pid" >&2
      return 2
    fi
    resolution="$PROGRESS_HEARTBEAT_RESOLUTION"
    if [[ "$resolution" == gone ]]; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      return 3
    fi
    current="$identity"
  fi
  if [[ -z "$identity" || -z "$current" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_unavailable_before_stop pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if ! kill -STOP "$pid" 2>/dev/null; then
    if progress_resolve_missing_heartbeat_identity "$pid" "$identity" &&
        [[ "$PROGRESS_HEARTBEAT_RESOLUTION" == gone ]]; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      return 3
    fi
    printf 'progress_process_tree_status=heartbeat_stop_signal_failed pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  for ((attempt=0; attempt<10; attempt++)); do
    state="$(progress_process_state "$pid")"
    [[ "$state" == T* || "$state" == t* ]] && break
    progress_process_is_running "$pid" || break
    sleep 0.01
  done
  state="$(progress_process_state "$pid")"
  if [[ "$state" != T* && "$state" != t* ]]; then
    if progress_heartbeat_original_is_gone "$pid" "$identity"; then
      printf 'progress_process_tree_status=heartbeat_gone_during_quiesce pid=%s\n' \
        "$pid" >&2
      return 3
    fi
    progress_resume_heartbeat_if_owned "$pid" "$identity" || true
    printf 'progress_process_tree_status=heartbeat_quiesce_unverified pid=%s state=%s\n' \
      "$pid" "${state:-unknown}" >&2
    return 2
  fi
  if ! snapshot="$(progress_collect_process_tree "$pid")" || [[ -z "$snapshot" ]]; then
    progress_resume_heartbeat_if_owned "$pid" "$identity" || true
    printf 'progress_process_tree_status=heartbeat_snapshot_incomplete pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -z "$current" || "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_changed_during_snapshot pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  while IFS=$'\t' read -r snapshot_pid snapshot_identity; do
    if [[ "$snapshot_pid" == "$pid" && "$snapshot_identity" == "$identity" ]]; then
      root_found=1
      break
    fi
  done <<<"$snapshot"
  if (( root_found == 0 )); then
    progress_resume_heartbeat_if_owned "$pid" "$identity" || true
    printf 'progress_process_tree_status=heartbeat_root_missing_from_snapshot pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT="$snapshot"
}

progress_stop_heartbeat() {
  local pid="$PROGRESS_HEARTBEAT_PID" identity="$PROGRESS_HEARTBEAT_IDENTITY"
  local attempt state current sync_rc=0 wait_rc=0 rc=0 live_status=1
  local snapshot="" escalation_snapshot="" capture_rc=0 resolution="" escalated=0

  # Cooperative weak shutdown must write its exact-generation marker before
  # any PID or identity handling in the generic dispatcher.
  if [[ "$PROGRESS_HEARTBEAT_PROTOCOL" == weak ]]; then
    progress_stop_weak_heartbeat
    return $?
  fi
  [[ "$pid" =~ ^[0-9]+$ ]] || {
    PROGRESS_HEARTBEAT_PID=""
    PROGRESS_HEARTBEAT_IDENTITY=""
    PROGRESS_HEARTBEAT_PROTOCOL=""
    return 0
  }
  if (( pid <= 1 )); then
    PROGRESS_HEARTBEAT_PID=""
    PROGRESS_HEARTBEAT_IDENTITY=""
    PROGRESS_HEARTBEAT_PROTOCOL=""
    printf 'progress_process_tree_status=invalid_heartbeat_pid\n' >&2
    return 2
  fi

  if [[ "$identity" == ps:* ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_protocol_unavailable pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if [[ "$identity" != proc:* ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=strong_heartbeat_identity_unavailable pid=%s\n' \
      "$pid" >&2
    return 2
  fi

  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$identity" && -z "$current" ]]; then
    if ! progress_resolve_missing_heartbeat_identity "$pid" "$identity"; then
      SONAR_PRESENTATION_READY=0
      printf 'progress_process_tree_status=heartbeat_identity_unavailable pid=%s\n' "$pid" >&2
      return 2
    fi
    resolution="$PROGRESS_HEARTBEAT_RESOLUTION"
    if [[ "$resolution" == gone ]]; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      progress_finalize_gone_heartbeat
      return $?
    fi
    current="$identity"
  fi
  if [[ -z "$identity" || -z "$current" ]]; then
    if progress_heartbeat_original_is_gone "$pid" "$identity"; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      progress_finalize_gone_heartbeat
      return $?
    fi
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=heartbeat_identity_unavailable pid=%s\n' "$pid" >&2
    return 2
  fi
  if [[ "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_replaced pid=%s\n' "$pid" >&2
    progress_finalize_gone_heartbeat
    return $?
  fi
  if progress_capture_quiesced_heartbeat_tree "$pid" "$identity"; then
    snapshot="$PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT"
  else
    capture_rc=$?
  fi
  if (( capture_rc == 3 )); then
    progress_finalize_gone_heartbeat
    return $?
  fi
  if (( capture_rc != 0 )); then
    SONAR_PRESENTATION_READY=0
    return 2
  fi
  progress_signal_process_snapshot TERM "$snapshot" "$pid" "$identity" || rc=2
  progress_resume_heartbeat_if_owned "$pid" "$identity" || rc=2
  for ((attempt=0; attempt<10; attempt++)); do
    live_status=0
    progress_heartbeat_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
      live_status=$?
    (( live_status == 1 )) && break
    sleep 0.1
  done
  live_status=0
  progress_heartbeat_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  if (( live_status == 2 )); then
    printf 'progress_process_tree_status=heartbeat_snapshot_unverified pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if (( live_status == 0 )); then
    escalated=1
    if progress_process_is_running "$pid"; then
      capture_rc=0
      if progress_capture_quiesced_heartbeat_tree "$pid" "$identity"; then
        escalation_snapshot="$PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT"
      else
        capture_rc=$?
      fi
      if (( capture_rc != 0 )); then
        return 2
      fi
    else
      escalation_snapshot="$snapshot"
    fi
    progress_signal_process_snapshot KILL "$escalation_snapshot" "$pid" "$identity" ||
      rc=2
    # Weak-identity platforms can refuse KILL. Never leave an identity-matched
    # heartbeat stopped solely because the safe escalation was unavailable.
    progress_resume_heartbeat_if_owned "$pid" "$identity" || rc=2
    for ((attempt=0; attempt<10; attempt++)); do
      live_status=0
      progress_heartbeat_snapshot_has_live_members \
        "$escalation_snapshot" "$pid" "$identity" || live_status=$?
      (( live_status == 1 )) && break
      sleep 0.1
    done
  fi
  if [[ -n "$escalation_snapshot" ]]; then
    live_status=0
    progress_heartbeat_snapshot_has_live_members \
      "$escalation_snapshot" "$pid" "$identity" || live_status=$?
    if (( live_status == 2 )); then
      printf 'progress_process_tree_status=heartbeat_escalation_unverified pid=%s\n' \
        "$pid" >&2
      return 2
    fi
    if (( live_status == 0 )); then
      printf 'progress_process_tree_status=heartbeat_escalation_incomplete pid=%s\n' \
        "$pid" >&2
      return 2
    fi
  fi
  live_status=0
  progress_heartbeat_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  if (( live_status == 2 )); then
    printf 'progress_process_tree_status=heartbeat_snapshot_unverified pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if (( live_status == 0 )); then
    printf 'progress_process_tree_status=heartbeat_cleanup_incomplete pid=%s\n' "$pid" >&2
    return 2
  fi
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$current" && "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_replaced_after_stop pid=%s\n' \
      "$pid" >&2
    progress_finalize_gone_heartbeat "$escalated"
    return $?
  fi
  if [[ -z "$current" ]] &&
      progress_heartbeat_original_is_gone "$pid" "$identity"; then
    progress_finalize_gone_heartbeat "$escalated"
    return $?
  fi
  state="$(progress_process_state "$pid")"
  if [[ "$state" == Z* ]] || ! kill -0 "$pid" 2>/dev/null; then
    wait "$pid" 2>/dev/null || wait_rc=$?
    (( wait_rc == 0 )) || SONAR_PRESENTATION_READY=0
    if ! sonar_recover_stale_render_lock; then
      printf 'progress_process_tree_status=heartbeat_lock_recovery_failed owned=%s\n' \
        "$SONAR_RENDER_LOCK_OWNED" >&2
      return 2
    fi
    if ! progress_sync_disabled_presentation; then
      printf 'progress_process_tree_status=heartbeat_presentation_sync_failed\n' >&2
      sync_rc=2
    fi
    PROGRESS_HEARTBEAT_PID=""
    PROGRESS_HEARTBEAT_IDENTITY=""
    PROGRESS_HEARTBEAT_PROTOCOL=""
    (( rc == 0 )) || return "$rc"
    return "$sync_rc"
  fi
  printf 'progress_process_tree_status=heartbeat_state_unverified pid=%s\n' "$pid" >&2
  return 2
}

progress_collect_process_tree_from_table() {
  local root="$1" expected_fields="${2:-2}"
  /usr/bin/awk -v root="$root" -v max_hops="$PROGRESS_PROCESS_TREE_MAX_HOPS" \
      -v max_rows="$PROGRESS_PROCESS_TREE_MAX_ROWS" \
      -v max_transitions="$PROGRESS_PROCESS_TREE_MAX_TRANSITIONS" \
      -v expected_fields="$expected_fields" '
    function is_pid(value) {
      return value ~ /^(0|[1-9][0-9]*)$/
    }
    function remember_status(name) {
      status[name]=1
      incomplete=1
    }
    function spend_transition() {
      transitions++
      if (transitions > max_transitions) {
        remember_status("transition_limit")
        exhausted=1
        return 0
      }
      return 1
    }
    function emit(pid, depth_value,    line) {
      line=pid
      if (identity[pid] != "") {
        line=line "\t" identity[pid]
      }
      output[pid]=line
      depth[pid]=depth_value
      if (depth_value > max_depth) {
        max_depth=depth_value
      }
    }
    NF == 0 {
      next
    }
    {
      rows++
      if (rows > max_rows) {
        remember_status("row_limit")
        fatal=1
        exit 2
      }
      if (NF != expected_fields || !is_pid($1) || !is_pid($2)) {
        remember_status("malformed")
        next
      }
      pid=$1
      ppid=$2
      row_identity=""
      if (expected_fields == 3) {
        row_identity=$3
      } else if (expected_fields == 7) {
        row_identity="ps:" $3 " " $4 " " $5 " " $6 " " $7
      }
      if (pid in parent) {
        if (parent[pid] != ppid || identity[pid] != row_identity) {
          remember_status("conflicting_duplicate")
        }
        next
      }
      parent[pid]=ppid
      identity[pid]=row_identity
    }
    END {
      if (fatal) {
        # Input processing already stopped at the hard row ceiling.
      } else if (!is_pid(root) || root <= 1 ||
                 !is_pid(max_hops) || max_hops < 1 ||
                 !is_pid(max_rows) || max_rows < 1 ||
                 !is_pid(max_transitions) || max_transitions < 1) {
        remember_status("invalid_limits")
      } else {
        generation=0
        for (pid in parent) {
          current=pid
          hops=0
          generation++
          found_root=0
          root_depth=0
          while (current in parent && current != 0 && current != 1) {
            if (!spend_transition()) {
              break
            }
            if (current == root && !found_root) {
              found_root=1
              root_depth=hops
            }
            if (seen[current] == generation) {
              remember_status("cycle")
              break
            }
            if (hops >= max_hops) {
              remember_status("hop_limit")
              break
            }
            seen[current]=generation
            next_parent=parent[current]
            if (!is_pid(next_parent)) {
              remember_status("malformed")
              break
            }
            if (next_parent == current) {
              remember_status("cycle")
              break
            }
            current=next_parent
            hops++
          }
          if (found_root && pid != root) {
            emit(pid, root_depth)
          }
          if (exhausted) {
            break
          }
        }

        # Deepest descendants are signalled first. The owned direct child is
        # always last so that it cannot orphan a still-running descendant
        # before the first signal pass has completed.
        for (wanted_depth=max_depth;
             wanted_depth>=1 && !exhausted;
             wanted_depth--) {
          while (1) {
            selected=""
            for (pid in output) {
              if (!spend_transition()) {
                break
              }
              if (depth[pid] == wanted_depth && (selected == "" || (pid + 0) < (selected + 0))) {
                selected=pid
              }
            }
            if (exhausted || selected == "") {
              break
            }
            print output[selected]
            delete output[selected]
            delete depth[selected]
          }
        }
        if (exhausted) {
          # The caller may retain identity-verified partial descendants, but
          # appends the trusted root and preserves the incomplete status.
        } else if (root in parent) {
          emit(root, 0)
          print output[root]
        } else {
          print root
          remember_status("root_missing")
        }
      }

      for (name in status) {
        print "progress_process_tree_status=" name > "/dev/stderr"
      }
      if (incomplete) {
        exit 2
      }
    }
  '
}

progress_linux_process_identity_from_stat() {
  local stat_file="$1" stat_line stat_tail
  local IFS=' '
  [[ -r "$stat_file" ]] || return 1
  stat_line="$(<"$stat_file")" || return 1
  stat_tail="${stat_line##*) }"
  set -- $stat_tail
  (($# >= 20)) || return 1
  [[ "${20}" =~ ^[0-9]+$ ]] || return 1
  printf 'proc:%s' "${20}"
}

progress_linux_process_table() {
  local stat_file pid stat_line stat_tail ppid identity
  local IFS=' '
  for stat_file in /proc/[0-9]*/stat; do
    [[ -r "$stat_file" ]] || continue
    pid="${stat_file#/proc/}"
    pid="${pid%/stat}"
    [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    stat_line="$(<"$stat_file")" || continue
    stat_tail="${stat_line##*) }"
    set -- $stat_tail
    (($# >= 20)) || continue
    ppid="$2"
    identity="${20}"
    [[ "$ppid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    [[ "$identity" =~ ^[0-9]+$ ]] || continue
    printf '%s %s proc:%s\n' "$pid" "$ppid" "$identity"
  done
}

progress_collect_process_tree() {
  local root="$1" table
  if [[ -r /proc/$$/stat ]]; then
    if ! table="$(progress_linux_process_table)"; then
      printf 'progress_process_tree_status=proc_snapshot_failed\n' >&2
      return 2
    fi
    printf '%s\n' "$table" |
      progress_collect_process_tree_from_table "$root" 3
    return
  fi
  if ! table="$(LC_ALL=C /bin/ps -eo pid=,ppid=,lstart= 2>/dev/null)"; then
    printf 'progress_process_tree_status=ps_failed\n' >&2
    return 2
  fi
  printf '%s\n' "$table" |
    progress_collect_process_tree_from_table "$root" 7
}

progress_process_identity() {
  local pid="$1" identity
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  (( pid > 1 )) || return 1
  if [[ -r "/proc/$pid/stat" ]]; then
    progress_linux_process_identity_from_stat "/proc/$pid/stat"
    return
  fi
  identity="$(
    LC_ALL=C /bin/ps -o lstart= -p "$pid" 2>/dev/null |
      /usr/bin/awk 'NF { $1=$1; print; exit }'
  )"
  [[ -n "$identity" ]] || return 1
  printf 'ps:%s' "$identity"
}

progress_capture_process_identity() {
  local pid="$1" attempt identity
  for ((attempt=0; attempt<10; attempt++)); do
    identity="$(progress_process_identity "$pid" 2>/dev/null || true)"
    if [[ -n "$identity" ]]; then
      printf '%s' "$identity"
      return 0
    fi
    progress_process_is_running "$pid" || return 1
    sleep 0.01
  done
  return 1
}

progress_process_state() {
  local pid="$1" stat_line stat_tail state
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  if [[ -r "/proc/$pid/stat" ]]; then
    stat_line="$(<"/proc/$pid/stat")" || return 1
    stat_tail="${stat_line##*) }"
    state="${stat_tail%% *}"
    [[ "$state" =~ ^[[:alpha:]]$ ]] || return 1
    printf '%s\n' "$state"
    return 0
  fi
  LC_ALL=C /bin/ps -o stat= -p "$pid" 2>/dev/null |
    /usr/bin/awk 'NF { gsub(/[[:space:]]/, ""); print; exit }'
}

progress_process_is_running() {
  local pid="$1" state
  state="$(progress_process_state "$pid")"
  [[ -n "$state" && "$state" != Z* ]]
}

progress_snapshot_has_live_members() {
  local snapshot="$1" trusted_root="$2" trusted_identity="$3"
  local pid identity current mismatch=0
  while IFS=$'\t' read -r pid identity; do
    [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    (( pid > 1 )) || continue
    if [[ "$pid" == "$trusted_root" ]]; then
      if [[ -n "$trusted_identity" ]]; then
        current="$(progress_process_identity "$pid" 2>/dev/null || true)"
        if [[ -z "$current" ]]; then
          kill -0 "$pid" 2>/dev/null && mismatch=1
          continue
        fi
        if [[ "$current" != "$trusted_identity" ]]; then
          mismatch=1
          continue
        fi
      fi
    else
      current="$(progress_process_identity "$pid" 2>/dev/null || true)"
      if [[ -z "$identity" || -z "$current" ]]; then
        kill -0 "$pid" 2>/dev/null && mismatch=1
        continue
      fi
      if [[ "$current" != "$identity" ]]; then
        mismatch=1
        continue
      fi
    fi
    kill -0 "$pid" 2>/dev/null && return 0
  done <<<"$snapshot"
  (( mismatch == 0 )) || return 2
  return 1
}

progress_signal_process_snapshot() {
  local signal="$1" snapshot="$2" trusted_root="$3" trusted_identity="$4"
  local pass pid identity current rc=0
  [[ "$signal" == TERM || "$signal" == KILL ]] || return 2

  for pass in descendants root; do
    while IFS=$'\t' read -r pid identity; do
      [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || {
        printf 'progress_process_tree_status=invalid_snapshot_pid\n' >&2
        rc=2
        continue
      }
      (( pid > 1 )) || continue
      if [[ "$pass" == descendants && "$pid" == "$trusted_root" ]]; then
        continue
      fi
      if [[ "$pass" == root && "$pid" != "$trusted_root" ]]; then
        continue
      fi

      if [[ "$pid" == "$trusted_root" ]]; then
        # Bash may reap an asynchronous child before an explicit wait, so the
        # root identity is rechecked before every signal just like descendants.
        if [[ "$signal" == KILL && "$trusted_identity" != proc:* ]]; then
          printf 'progress_process_tree_status=weak_root_identity_kill_skipped pid=%s\n' \
            "$pid" >&2
          rc=2
          continue
        fi
        current="$(progress_process_identity "$pid" 2>/dev/null || true)"
        if [[ -z "$trusted_identity" || -z "$current" ]]; then
          if progress_process_is_running "$pid"; then
            printf 'progress_process_tree_status=root_identity_unavailable pid=%s\n' "$pid" >&2
            rc=2
          fi
          continue
        fi
        if [[ "$current" != "$trusted_identity" ]]; then
          printf 'progress_process_tree_status=root_identity_changed pid=%s\n' "$pid" >&2
          rc=2
          continue
        fi
      else
        # Descendant PIDs can be reaped and reused while cleanup waits. Never
        # signal one unless its immutable start identity still matches.
        if [[ "$signal" == KILL && "$identity" != proc:* ]]; then
          printf 'progress_process_tree_status=weak_identity_kill_skipped pid=%s\n' "$pid" >&2
          rc=2
          continue
        fi
        current="$(progress_process_identity "$pid" 2>/dev/null || true)"
        if [[ -z "$identity" || -z "$current" ]]; then
          if kill -0 "$pid" 2>/dev/null; then
            printf 'progress_process_tree_status=descendant_identity_unavailable pid=%s\n' "$pid" >&2
            rc=2
          fi
          continue
        fi
        if [[ "$current" != "$identity" ]]; then
          printf 'progress_process_tree_status=descendant_identity_changed pid=%s\n' "$pid" >&2
          rc=2
          continue
        fi
      fi

      kill -s "$signal" "$pid" 2>/dev/null || true
      [[ "$pass" == root ]] && break
    done <<<"$snapshot"
  done
  return "$rc"
}

progress_terminate_active_child() {
  local pid="$PROGRESS_ACTIVE_CHILD_PID" identity="$PROGRESS_ACTIVE_CHILD_IDENTITY"
  local attempt snapshot state rc=0 live_status=1 snapshot_complete=1
  (( PROGRESS_CHILD_TERMINATION_IN_PROGRESS == 0 )) || return 0
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 0
  (( pid > 1 )) || return 0

  PROGRESS_CHILD_TERMINATION_IN_PROGRESS=1
  PROGRESS_ACTIVE_CHILD_PID=""
  PROGRESS_ACTIVE_CHILD_IDENTITY=""
  if ! snapshot="$(progress_collect_process_tree "$pid")"; then
    snapshot_complete=0
    rc=2
    printf 'progress_process_tree_status=incomplete_snapshot\n' >&2
  fi
  if (( snapshot_complete == 0 )) || [[ -z "$snapshot" ]]; then
    snapshot="${snapshot:+$snapshot$'\n'}$(printf '%s\t%s' "$pid" "$identity")"
  fi

  progress_signal_process_snapshot TERM "$snapshot" "$pid" "$identity" || rc=2
  for ((attempt=0; attempt<10; attempt++)); do
    live_status=0
    progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
      live_status=$?
    if (( live_status != 0 )); then
      (( live_status == 2 )) && rc=2
      break
    fi
    sleep 0.1
  done
  live_status=0
  progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  (( live_status == 2 )) && rc=2
  if (( live_status == 0 )); then
    # Reuse exactly the original identity-bearing snapshot. Emergency cleanup
    # must never re-enter the process-table collector.
    progress_signal_process_snapshot KILL "$snapshot" "$pid" "$identity" || rc=2
    for ((attempt=0; attempt<10; attempt++)); do
      live_status=0
      progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
        live_status=$?
      if (( live_status != 0 )); then
        (( live_status == 2 )) && rc=2
        break
      fi
      sleep 0.1
    done
  fi
  live_status=0
  progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  (( live_status == 2 )) && rc=2
  if (( live_status == 0 )); then
    printf 'progress_process_tree_status=cleanup_incomplete\n' >&2
    rc=2
  fi
  state="$(progress_process_state "$pid")"
  if [[ "$state" == Z* ]] || ! kill -0 "$pid" 2>/dev/null; then
    wait "$pid" 2>/dev/null || true
  else
    printf 'progress_process_tree_status=direct_child_not_reapable pid=%s state=%s\n' \
      "$pid" "${state:-unknown}" >&2
    rc=2
  fi
  # A portable PPID snapshot cannot prove that the command did not fork a new
  # descendant after the snapshot. The bounded cleanup is safe, but only an
  # outer owned session can certify zero leaks.
  printf 'progress_process_tree_status=single_snapshot_boundary\n' >&2
  rc=2
  PROGRESS_CHILD_TERMINATION_IN_PROGRESS=0
  return "$rc"
}

progress_queue_signal() {
  local signal="$1" report_path="${2:-недоступен}"
  if [[ -z "$PROGRESS_PENDING_SIGNAL" ]]; then
    PROGRESS_PENDING_SIGNAL="$signal"
    PROGRESS_PENDING_SIGNAL_REPORT="$report_path"
  fi
}

progress_dispatch_pending_signal() {
  local signal report_path
  [[ -n "$PROGRESS_PENDING_SIGNAL" ]] || return 0
  signal="$PROGRESS_PENDING_SIGNAL"
  report_path="${PROGRESS_PENDING_SIGNAL_REPORT:-недоступен}"
  PROGRESS_PENDING_SIGNAL=""
  PROGRESS_PENDING_SIGNAL_REPORT=""
  progress_signal "$signal" "$report_path"
}

progress_stat_uid() {
  if declare -F audit_stat_uid >/dev/null 2>&1; then
    audit_stat_uid "$1"
    return
  fi
  /usr/bin/stat -c %u -- "$1" 2>/dev/null ||
    /usr/bin/stat -f %u "$1" 2>/dev/null
}

progress_stat_mode() {
  local mode
  if declare -F audit_stat_mode >/dev/null 2>&1; then
    audit_stat_mode "$1"
    return
  fi
  if mode="$(/usr/bin/stat -c %a -- "$1" 2>/dev/null)"; then
    printf '%s\n' "$mode"
    return 0
  fi
  mode="$(/usr/bin/stat -f %Op "$1" 2>/dev/null)" || return 1
  [[ "$mode" =~ ^[0-7]+$ ]] || return 1
  (( ${#mode} <= 4 )) || mode="${mode: -4}"
  mode="${mode#0}"
  printf '%s\n' "$mode"
}

progress_runtime_dir_is_safe() {
  local runtime_dir="$1" owner mode
  case "$runtime_dir" in
    /*) ;;
    *) return 2 ;;
  esac
  case "$runtime_dir" in
    /|*/|*//*|*/./*|*/../*|*/.|*/..) return 2 ;;
  esac
  [[ -d "$runtime_dir" && ! -L "$runtime_dir" ]] || return 2
  owner="$(progress_stat_uid "$runtime_dir" 2>/dev/null || true)"
  mode="$(progress_stat_mode "$runtime_dir" 2>/dev/null || true)"
  [[ "$owner" == "$EUID" && "$mode" == 700 ]]
}

progress_child_guard_file_is_safe() {
  local path="$1" owner mode
  [[ -f "$path" && ! -L "$path" ]] || return 2
  owner="$(progress_stat_uid "$path" 2>/dev/null || true)"
  mode="$(progress_stat_mode "$path" 2>/dev/null || true)"
  [[ "$owner" == "$EUID" && "$mode" == 600 ]]
}

progress_child_guard_paths_valid() {
  local guard_dir="$1" guard_ready="$2" guard_release="$3"
  local expected_guard_dir owner mode
  progress_runtime_dir_is_safe "$PROGRESS_RUNTIME_DIR" || return 2
  expected_guard_dir="$PROGRESS_RUNTIME_DIR/.server-toolkit-child-guard"
  [[ "$guard_dir" == "$expected_guard_dir" &&
     "$guard_ready" == "$expected_guard_dir/ready" &&
     "$guard_release" == "$expected_guard_dir/release" &&
     -d "$guard_dir" &&
     ! -L "$guard_dir" ]] || return 2
  owner="$(progress_stat_uid "$guard_dir" 2>/dev/null || true)"
  mode="$(progress_stat_mode "$guard_dir" 2>/dev/null || true)"
  [[ "$owner" == "$EUID" && "$mode" == 700 ]] || return 2
  if [[ -e "$guard_ready" || -L "$guard_ready" ]]; then
    progress_child_guard_file_is_safe "$guard_ready" || return 2
  fi
  if [[ -e "$guard_release" || -L "$guard_release" ]]; then
    progress_child_guard_file_is_safe "$guard_release" || return 2
  fi
}

progress_remove_new_child_guard() {
  local guard_dir="$1" guard_ready="$2" guard_release="$3"
  local ready_created="$4" release_created="$5"
  progress_child_guard_paths_valid \
    "$guard_dir" "$guard_ready" "$guard_release" || return 2
  if (( ready_created == 1 )); then
    rm -f -- "$guard_ready" || return 2
  fi
  if (( release_created == 1 )); then
    rm -f -- "$guard_release" || return 2
  fi
  rmdir -- "$guard_dir" || return 2
}

progress_remove_child_guard() {
  local guard_dir="$PROGRESS_CHILD_GUARD_DIR"
  local guard_ready="$PROGRESS_CHILD_GUARD_READY"
  local guard_release="$PROGRESS_CHILD_GUARD_RELEASE"
  if [[ -z "$guard_dir" ]]; then
    [[ -z "$guard_ready" && -z "$guard_release" ]] || {
      printf 'progress_process_tree_status=incomplete_child_guard_paths\n' >&2
      return 2
    }
    return 0
  fi
  if ! progress_child_guard_paths_valid \
    "$guard_dir" "$guard_ready" "$guard_release"; then
    printf 'progress_process_tree_status=invalid_child_guard_paths\n' >&2
    return 2
  fi
  rm -f -- "$guard_ready" "$guard_release" || return 2
  rmdir -- "$guard_dir" || return 2
  PROGRESS_CHILD_GUARD_DIR=""
  PROGRESS_CHILD_GUARD_READY=""
  PROGRESS_CHILD_GUARD_RELEASE=""
}

progress_abort_child_guard() {
  local pid="$1" guard_ready="$2" guard_release="$3"
  local ready_attempt exit_attempt exit_started guard_status="" state="" absent_checks=0
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 2
  (( pid > 1 )) || return 2
  [[ "$guard_ready" == "$PROGRESS_CHILD_GUARD_READY" &&
     "$guard_release" == "$PROGRESS_CHILD_GUARD_RELEASE" &&
     -n "$PROGRESS_CHILD_GUARD_DIR" ]] || return 2
  printf 'abort\n' >"$guard_release" || return 2
  for ((ready_attempt=0; ready_attempt<500; ready_attempt++)); do
    if [[ -s "$guard_ready" ]]; then
      IFS= read -r guard_status <"$guard_ready" || true
      if [[ "$guard_status" == aborted ]]; then
        exit_started=$SECONDS
        for ((exit_attempt=0; exit_attempt<100; exit_attempt++)); do
          if (( SECONDS - exit_started >= 2 )); then
            break
          fi
          state="$(progress_process_state "$pid")"
          if [[ "$state" == Z* ]]; then
            wait "$pid" 2>/dev/null || true
            return 0
          fi
          if [[ -z "$state" ]] && ! kill -0 "$pid" 2>/dev/null; then
            absent_checks=$((absent_checks + 1))
            if (( absent_checks >= 2 )); then
              wait "$pid" 2>/dev/null || true
              return 0
            fi
          else
            absent_checks=0
          fi
          sleep 0.01
        done
        printf 'progress_process_tree_status=child_guard_exit_incomplete\n' >&2
        return 2
      fi
    fi
    sleep 0.01
  done
  printf 'progress_process_tree_status=child_guard_abort_incomplete\n' >&2
  return 2
}

progress_validate_stage_timeout() {
  local value="${CURRENT_STAGE_TIMEOUT-}"
  [[ "$value" =~ ^[1-9][0-9]?[0-9]?$ ]] || return 1
  (( value <= 120 )) || return 1
  printf '%s\n' "$value"
}

progress_run_child() {
  local rc=0 pid guard_status="" attempt cleanup_rc=0
  local timed_out=0 timeout_seconds timeout_ticks tick
  local guard_dir guard_ready guard_release
  local guard_ready_created=0 guard_release_created=0
  timeout_seconds="$(progress_validate_stage_timeout)" || return 125
  timeout_ticks=$((timeout_seconds * 10))
  (( PROGRESS_CLEANUP_IN_PROGRESS == 0 && PROGRESS_CLEANUP_DONE == 0 )) || return 125
  progress_runtime_dir_is_safe "$PROGRESS_RUNTIME_DIR" || return 125
  [[ -z "$PROGRESS_ACTIVE_CHILD_PID" ]] || {
    printf 'progress_process_tree_status=previous_child_cleanup_incomplete\n' >&2
    return 125
  }
  [[ -z "$PROGRESS_CHILD_GUARD_DIR" &&
     -z "$PROGRESS_CHILD_GUARD_READY" &&
     -z "$PROGRESS_CHILD_GUARD_RELEASE" ]] || {
    printf 'progress_process_tree_status=previous_child_guard_incomplete\n' >&2
    return 125
  }
  progress_dispatch_pending_signal
  PROGRESS_CHILD_STARTING=1
  # The caller creates one private, single-writer runtime directory per audit.
  # That invariant makes this fixed name unique without a global /tmp class.
  guard_dir="$PROGRESS_RUNTIME_DIR/.server-toolkit-child-guard"
  guard_ready="$guard_dir/ready"
  guard_release="$guard_dir/release"
  if ! mkdir -m 700 -- "$guard_dir" 2>/dev/null; then
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  if ! progress_child_guard_paths_valid \
    "$guard_dir" "$guard_ready" "$guard_release"; then
    # The parent was verified immediately before our atomic mkdir. If the
    # post-create metadata check fails, remove only that exact empty directory.
    rmdir -- "$guard_dir" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  if ! (umask 077; set -o noclobber; : >"$guard_ready"); then
    progress_remove_new_child_guard \
      "$guard_dir" "$guard_ready" "$guard_release" \
      "$guard_ready_created" "$guard_release_created" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  guard_ready_created=1
  if ! (umask 077; set -o noclobber; : >"$guard_release"); then
    progress_remove_new_child_guard \
      "$guard_dir" "$guard_ready" "$guard_release" \
      "$guard_ready_created" "$guard_release_created" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  guard_release_created=1
  if ! progress_child_guard_paths_valid \
       "$guard_dir" "$guard_ready" "$guard_release" ||
     ! progress_child_guard_file_is_safe "$guard_ready" ||
     ! progress_child_guard_file_is_safe "$guard_release"; then
    progress_remove_new_child_guard \
      "$guard_dir" "$guard_ready" "$guard_release" \
      "$guard_ready_created" "$guard_release_created" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  PROGRESS_CHILD_GUARD_DIR="$guard_dir"
  PROGRESS_CHILD_GUARD_READY="$guard_ready"
  PROGRESS_CHILD_GUARD_RELEASE="$guard_release"
  (
    trap - ERR HUP INT TERM EXIT
    printf 'ready\n' >"$guard_ready" || exit 125
    for ((attempt=0; attempt<500; attempt++)); do
      guard_status=""
      if [[ -s "$guard_release" ]]; then
        IFS= read -r guard_status <"$guard_release" || true
        case "$guard_status" in
          release)
            break
            ;;
          abort)
            printf 'aborted\n' >"$guard_ready" || exit 125
            exit 125
            ;;
        esac
      fi
      sleep 0.01
    done
    if [[ "$guard_status" != release ]]; then
      printf 'expired\n' >"$guard_ready" 2>/dev/null || true
      exit 125
    fi
    "$@"
  ) &
  pid=$!
  PROGRESS_ACTIVE_CHILD_PID="$pid"
  for ((attempt=0; attempt<500; attempt++)); do
    if [[ -s "$guard_ready" ]]; then
      IFS= read -r guard_status <"$guard_ready" || true
      [[ "$guard_status" == ready ]] && break
    fi
    sleep 0.01
  done
  if [[ "$guard_status" != ready ]]; then
    printf 'progress_process_tree_status=child_guard_handshake_failed\n' >&2
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    (( cleanup_rc == 0 )) || return 125
    return 125
  fi
  PROGRESS_ACTIVE_CHILD_IDENTITY="$(
    progress_capture_process_identity "$pid" 2>/dev/null || true
  )"
  if [[ -z "$PROGRESS_ACTIVE_CHILD_IDENTITY" ]]; then
    printf 'progress_process_tree_status=child_guard_identity_unavailable\n' >&2
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    (( cleanup_rc == 0 )) || return 125
    return 125
  fi
  if [[ -n "$PROGRESS_PENDING_SIGNAL" ]]; then
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  if ! printf 'release\n' >"$guard_release"; then
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  PROGRESS_CHILD_STARTING=0
  progress_dispatch_pending_signal
  for ((tick=0; tick<timeout_ticks; tick++)); do
    progress_process_is_running "$pid" || break
    sleep 0.1
  done
  if progress_process_is_running "$pid"; then
    timed_out=1
  fi
  if (( timed_out == 1 )); then
    progress_terminate_active_child || cleanup_rc=$?
    progress_remove_child_guard || cleanup_rc=2
    if (( cleanup_rc != 0 )); then
      printf 'progress_timeout_cleanup_status=unverified rc=%s\n' \
        "$cleanup_rc" >&2
    fi
    return 124
  fi
  wait "$pid" || rc=$?
  PROGRESS_ACTIVE_CHILD_PID=""
  PROGRESS_ACTIVE_CHILD_IDENTITY=""
  progress_remove_child_guard || return 125
  return "$rc"
}

progress_cleanup() {
  local rc=0 heartbeat_dead=0 presentation_contained=0
  (( PROGRESS_CLEANUP_IN_PROGRESS == 0 )) || return 0
  (( PROGRESS_CLEANUP_DONE == 0 )) || return "${PROGRESS_CLEANUP_STATUS:-0}"
  PROGRESS_CLEANUP_IN_PROGRESS=1
  progress_terminate_active_child || rc=2
  if progress_stop_heartbeat; then
    heartbeat_dead=1
  else
    rc=2
    SONAR_PRESENTATION_READY=0
  fi
  if (( heartbeat_dead == 1 )); then
    if sonar_heartbeat_updates_disabled; then
      SONAR_PRESENTATION_READY=0
      PROGRESS_INTERACTIVE=0
    fi
    sonar_screen_restore || rc=2
    trap - WINCH
    progress_cursor_show
  elif [[ -n "$SONAR_RENDER_LOCK_DIR" ]] && sonar_render_lock_acquire; then
    if sonar_disable_heartbeat_updates; then
      presentation_contained=1
      sonar_screen_restore || rc=2
      trap - WINCH
    fi
    sonar_render_lock_release || rc=2
  fi
  if [[ -n "$PROGRESS_STATE_FILE" ]]; then
    rm -f "$PROGRESS_STATE_FILE" "${PROGRESS_STATE_FILE}.tmp.$$" 2>/dev/null || true
  fi
  if declare -F audit_cleanup_private_scratch >/dev/null 2>&1; then
    audit_cleanup_private_scratch || rc=2
  fi
  if (( heartbeat_dead == 1 )); then
    sonar_runtime_cleanup || rc=2
    progress_close_presentation_fd || rc=2
  elif (( presentation_contained == 0 )); then
    # A possibly live heartbeat may still write. Leave its coordination state
    # intact and do not emit terminal restoration after this point.
    rc=2
  fi
  progress_remove_child_guard || rc=2
  PROGRESS_CLEANUP_STATUS="$rc"
  PROGRESS_CLEANUP_DONE=1
  PROGRESS_CLEANUP_IN_PROGRESS=0
  if (( PROGRESS_SIGNAL_IN_PROGRESS == 0 )); then
    progress_dispatch_pending_signal
  fi
  return "$rc"
}

progress_exit_cleanup() {
  local original_rc=$? cleanup_rc=0
  progress_cleanup || cleanup_rc=$?
  if (( cleanup_rc != 0 && original_rc == 0 )); then
    return "$cleanup_rc"
  fi
  return "$original_rc"
}

progress_complete() {
  local now reset cleanup_rc=0
  (( PROGRESS_ACTIVE == 1 )) || return 0
  progress_finish_stage 100 || cleanup_rc=2
  now="$(date +%s)"
  progress_write_state 100 "Отчёт готов" "$now" 8
  progress_cleanup || cleanup_rc=2
  if (( cleanup_rc != 0 )); then
    SONAR_PRESENTATION_READY=0
    PROGRESS_ACTIVE=0
    return "$cleanup_rc"
  fi
  reset="$(progress_colour reset)"
  printf '\n%sГотово: %s/%s%s\n' "$(progress_colour green)" "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$reset" >&2
  PROGRESS_ACTIVE=0
  return "$cleanup_rc"
}

progress_fail() {
  local reason="$1" action="$2" report_path="${3:-недоступен}" reset cleanup_rc=0
  if (( PROGRESS_FAILURE_REPORTED == 1 )); then
    PROGRESS_ACTIVE=0
    return 0
  fi
  PROGRESS_FAILURE_REPORTED=1
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_PRESENTATION_READY=0
  progress_cleanup || cleanup_rc=$?
  reset="$(progress_colour reset)"
  progress_render_committed_line "$PROGRESS_STAGE" error
  printf '\n%sОШИБКА%s\n' "$(progress_colour red)" "$reset" >&2
  printf 'Прогресс: %s%%\nЭтап: %s\nПричина: %s\nЧто делать: %s\nОтчёт: %s\n' \
    "$PROGRESS_PERCENT" "$PROGRESS_STAGE" "$reason" "$action" "$report_path" >&2
  PROGRESS_ACTIVE=0
  return "$cleanup_rc"
}

progress_signal() {
  local signal="$1" report_path="${2:-недоступен}" cleanup_rc=0
  if (( PROGRESS_CHILD_STARTING == 1 || PROGRESS_HEARTBEAT_STARTING == 1 ||
        PROGRESS_CLEANUP_IN_PROGRESS == 1 ||
        PROGRESS_SIGNAL_IN_PROGRESS == 1 )); then
    progress_queue_signal "$signal" "$report_path"
    return 0
  fi
  PROGRESS_SIGNAL_IN_PROGRESS=1
  PROGRESS_SIGNAL_REPORT_PATH="$report_path"
  trap 'progress_queue_signal HUP "$PROGRESS_SIGNAL_REPORT_PATH"' HUP
  trap 'progress_queue_signal INT "$PROGRESS_SIGNAL_REPORT_PATH"' INT
  trap 'progress_queue_signal TERM "$PROGRESS_SIGNAL_REPORT_PATH"' TERM
  progress_fail \
    "Выполнение прервано сигналом $signal" \
    "Повторить audit; если остановка повторится, прислать последний этап и отчёт" \
    "$report_path" || cleanup_rc=$?
  if (( cleanup_rc != 0 )); then
    printf 'progress_cleanup_status=incomplete rc=%s\n' "$cleanup_rc" >&2
  fi
  trap '' HUP INT TERM
  [[ "$signal" == HUP ]] && exit 129
  [[ "$signal" == INT ]] && exit 130
  exit 143
}
