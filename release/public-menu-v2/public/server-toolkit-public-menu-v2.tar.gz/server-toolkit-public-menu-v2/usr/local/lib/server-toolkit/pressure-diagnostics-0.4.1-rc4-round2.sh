#!/usr/bin/env bash
# Bounded read-only memory, swap, fault, PSI and run-queue diagnostics.

PRESSURE_SAMPLE_COUNT=5
PRESSURE_SAMPLE_INTERVAL_SECONDS=1
MEM_AVAILABLE_WARN_PCT=10.00
MEM_AVAILABLE_CRITICAL_PCT=5.00
MEMORY_PSI_SOME_WARN_PCT=10.00
MEMORY_PSI_FULL_WARN_PCT=2.00
CPU_PSI_SOME_WARN_PCT=20.00
RUN_QUEUE_PER_VCPU_WARN=2.00
MAJOR_FAULT_RATE_WARN=10.00
SWAP_IO_RATE_WARN=1.00

pressure_read_memory() {
  awk '
    $1=="MemTotal:" {total=$2}
    $1=="MemAvailable:" {available=$2}
    $1=="SwapTotal:" {swap_total=$2}
    $1=="SwapFree:" {swap_free=$2}
    END {
      if(total!~/^[0-9]+$/ || total<=0 || available!~/^[0-9]+$/ || available>total ||
         swap_total!~/^[0-9]+$/ || swap_free!~/^[0-9]+$/ || swap_free>swap_total) exit 1
      printf "%s %s %s %s\n",total,available,swap_total,swap_free
    }' /proc/meminfo 2>/dev/null
}

pressure_read_vmstat() {
  awk '
    $1=="pswpin" {swap_in=$2}
    $1=="pswpout" {swap_out=$2}
    $1=="pgmajfault" {major=$2}
    END {
      if(swap_in!~/^[0-9]+$/ || swap_out!~/^[0-9]+$/ || major!~/^[0-9]+$/) exit 1
      printf "%s %s %s\n",swap_in,swap_out,major
    }' /proc/vmstat 2>/dev/null
}

pressure_read_psi() {
  local resource="$1"
  [[ "$resource" == memory || "$resource" == cpu ]] || return 1
  [[ -r "/proc/pressure/$resource" ]] || return 1
  awk '
    $1=="some" {for(i=2;i<=NF;i++) if($i~/^avg10=/){sub(/^avg10=/,"",$i); some=$i}}
    $1=="full" {for(i=2;i<=NF;i++) if($i~/^avg10=/){sub(/^avg10=/,"",$i); full=$i}}
    END {
      if(some!~/^[0-9]+([.][0-9]+)?$/) exit 1
      if(full!~/^[0-9]+([.][0-9]+)?$/) full="unavailable"
      printf "%s %s\n",some,full
    }' "/proc/pressure/$resource" 2>/dev/null
}

pressure_read_run_queue() {
  local vcpus runnable total
  vcpus="$(cpu_read_vcpu_count 2>/dev/null || true)"
  IFS=' ' read -r runnable total < <(awk '{split($4,a,"/"); print a[1],a[2]}' /proc/loadavg 2>/dev/null) || true
  [[ "$vcpus" =~ ^[1-9][0-9]*$ && "$runnable" =~ ^[0-9]+$ && "$total" =~ ^[0-9]+$ ]] || return 1
  awk -v runnable="$runnable" -v total="$total" -v vcpus="$vcpus" 'BEGIN {
    printf "%d %d %d %.2f\n",runnable,total,vcpus,runnable/vcpus
  }'
}

pressure_wait_interval() {
  sleep "$1"
}

pressure_timestamp() {
  date -u +%Y-%m-%dT%H:%M:%SZ
}

pressure_vm_delta() {
  local before="$1" after="$2" interval="$3"
  awk -v before="$before" -v after="$after" -v interval="$interval" 'BEGIN {
    if(split(before,A," ")!=3 || split(after,B," ")!=3 || interval<=0) exit 1
    for(i=1;i<=3;i++) {
      if(A[i]!~/^[0-9]+$/ || B[i]!~/^[0-9]+$/ || B[i]<A[i]) exit 1
      D[i]=B[i]-A[i]
    }
    printf "%d %d %d %.2f %.2f %.2f\n",D[1],D[2],D[3],D[1]/interval,D[2]/interval,D[3]/interval
  }'
}

pressure_metric_stats() {
  local prefix="$1" threshold="$2" direction="$3"
  shift 3
  printf '%s\n' "$@" | awk -v prefix="$prefix" -v threshold="$threshold" -v direction="$direction" '
    function sort_values( i,j,t) {
      for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) if(v[j]<v[i]) {t=v[i];v[i]=v[j];v[j]=t}
    }
    /^[0-9]+([.][0-9]+)?$/ {
      v[++n]=$1; sum+=$1
      if((direction=="low" && $1<threshold) || (direction=="high" && $1>threshold)) exceed++
    }
    END {
      if(n==0) exit 1
      sort_values()
      if(n%2) median=v[(n+1)/2]; else median=(v[n/2]+v[n/2+1])/2
      printf "%s_min=%.2f\n",prefix,v[1]
      printf "%s_median=%.2f\n",prefix,median
      printf "%s_average=%.2f\n",prefix,sum/n
      printf "%s_max=%.2f\n",prefix,v[n]
      printf "%s_threshold=%.2f\n",prefix,threshold
      printf "%s_threshold_exceedance_count=%d\n",prefix,exceed+0
    }'
}

pressure_safe_process_inventory() {
  local order="$1"
  [[ "$order" == cpu || "$order" == memory ]] || return 1
  if [[ "$order" == cpu ]]; then
    ps -eo comm=,%cpu=,%mem= --sort=-%cpu 2>/dev/null
  else
    ps -eo comm=,%cpu=,%mem= --sort=-%mem 2>/dev/null
  fi | awk -v order="$order" 'NR<=5 && NF>=3 {
    cpu_pct=$(NF-1)
    memory_pct=$NF
    name=$1
    for(i=2;i<=NF-2;i++) name=name " " $i
    gsub(/[^A-Za-z0-9._:+@-]/,"_",name)
    if(cpu_pct !~ /^[0-9]+([.][0-9]+)?$/) cpu_pct="unavailable"
    if(memory_pct !~ /^[0-9]+([.][0-9]+)?$/) memory_pct="unavailable"
    printf "pressure_top_%s_%d_name=%s\n",order,NR,name
    printf "pressure_top_%s_%d_cpu_pct=%s\n",order,NR,cpu_pct
    printf "pressure_top_%s_%d_memory_pct=%s\n",order,NR,memory_pct
  }'
}

pressure_raw_context() {
  local oom_count=unavailable
  printf 'pressure_memory_context_status=begin\n'
  free -h 2>/dev/null || true
  if command -v journalctl >/dev/null 2>&1; then
    oom_count="$(journalctl -k --since '24 hours ago' --no-pager -o cat 2>/dev/null \
      | grep -Eic 'out of memory|oom-killer|killed process' || true)"
  fi
  [[ "$oom_count" =~ ^[0-9]+$ ]] || oom_count=unavailable
  printf 'pressure_oom_event_count_24h=%s\n' "$oom_count"
  printf 'pressure_memory_context_status=end\n'
  printf 'pressure_process_inventory_status=begin\n'
  pressure_safe_process_inventory cpu || true
  pressure_safe_process_inventory memory || true
  printf 'pressure_process_inventory_status=end\n'
}

sample_memory_cpu_pressure_metrics() {
  local requested="$PRESSURE_SAMPLE_COUNT" interval="$PRESSURE_SAMPLE_INTERVAL_SECONDS"
  local before_vm after_vm memory vm_delta memory_psi cpu_psi run_queue timestamp
  local total available swap_total swap_free available_pct swap_used swap_used_pct
  local swap_in swap_out major swap_in_rate swap_out_rate major_rate
  local mem_some mem_full cpu_some cpu_full runnable tasks vcpus run_per_vcpu
  local i memory_status cpu_status vm_status prefix critical_exceedances
  local -a available_values=() swap_used_values=() swap_in_rates=() swap_out_rates=() major_rates=()
  local -a mem_some_values=() mem_full_values=() cpu_some_values=() run_queue_values=()
  local memory_samples=0 vm_samples=0 memory_psi_samples=0 cpu_psi_samples=0 run_queue_samples=0

  printf 'pressure_sample_method=proc_meminfo_vmstat_psi_loadavg_windows\n'
  printf 'pressure_sample_count_requested=%s\n' "$requested"
  printf 'pressure_sample_interval_seconds=%s\n' "$interval"
  before_vm="$(pressure_read_vmstat || true)"

  for ((i=1; i<=requested; i++)); do
    pressure_wait_interval "$interval"
    timestamp="$(pressure_timestamp 2>/dev/null || printf unavailable)"
    memory="$(pressure_read_memory || true)"
    after_vm="$(pressure_read_vmstat || true)"
    vm_delta="$(pressure_vm_delta "$before_vm" "$after_vm" "$interval" 2>/dev/null || true)"
    before_vm="$after_vm"
    memory_psi="$(pressure_read_psi memory || true)"
    cpu_psi="$(pressure_read_psi cpu || true)"
    run_queue="$(pressure_read_run_queue || true)"
    printf 'pressure_sample_%s_timestamp_utc=%s\n' "$i" "$timestamp"

    if [[ -n "$memory" ]]; then
      IFS=' ' read -r total available swap_total swap_free <<<"$memory"
      available_pct="$(awk -v a="$available" -v t="$total" 'BEGIN{printf "%.2f",100*a/t}')"
      swap_used=$((swap_total-swap_free))
      if (( swap_total > 0 )); then
        swap_used_pct="$(awk -v u="$swap_used" -v t="$swap_total" 'BEGIN{printf "%.2f",100*u/t}')"
        swap_used_values+=("$swap_used_pct")
      else
        swap_used_pct=not_configured
      fi
      memory_samples=$((memory_samples+1))
      available_values+=("$available_pct")
      printf 'pressure_sample_%s_mem_total_kib=%s\n' "$i" "$total"
      printf 'pressure_sample_%s_mem_available_kib=%s\n' "$i" "$available"
      printf 'pressure_sample_%s_mem_available_pct=%s\n' "$i" "$available_pct"
      printf 'pressure_sample_%s_swap_total_kib=%s\n' "$i" "$swap_total"
      printf 'pressure_sample_%s_swap_used_kib=%s\n' "$i" "$swap_used"
      printf 'pressure_sample_%s_swap_used_pct=%s\n' "$i" "$swap_used_pct"
    fi

    if [[ -n "$vm_delta" ]]; then
      IFS=' ' read -r swap_in swap_out major swap_in_rate swap_out_rate major_rate <<<"$vm_delta"
      vm_samples=$((vm_samples+1))
      swap_in_rates+=("$swap_in_rate"); swap_out_rates+=("$swap_out_rate"); major_rates+=("$major_rate")
      printf 'pressure_sample_%s_swap_in_pages=%s\n' "$i" "$swap_in"
      printf 'pressure_sample_%s_swap_out_pages=%s\n' "$i" "$swap_out"
      printf 'pressure_sample_%s_major_faults=%s\n' "$i" "$major"
      printf 'pressure_sample_%s_swap_in_pages_per_second=%s\n' "$i" "$swap_in_rate"
      printf 'pressure_sample_%s_swap_out_pages_per_second=%s\n' "$i" "$swap_out_rate"
      printf 'pressure_sample_%s_major_faults_per_second=%s\n' "$i" "$major_rate"
    fi

    if [[ -n "$memory_psi" ]]; then
      IFS=' ' read -r mem_some mem_full <<<"$memory_psi"
      memory_psi_samples=$((memory_psi_samples+1)); mem_some_values+=("$mem_some")
      [[ "$mem_full" == unavailable ]] || mem_full_values+=("$mem_full")
      printf 'pressure_sample_%s_memory_psi_some_avg10_pct=%s\n' "$i" "$mem_some"
      printf 'pressure_sample_%s_memory_psi_full_avg10_pct=%s\n' "$i" "$mem_full"
    fi
    if [[ -n "$cpu_psi" ]]; then
      IFS=' ' read -r cpu_some cpu_full <<<"$cpu_psi"
      cpu_psi_samples=$((cpu_psi_samples+1)); cpu_some_values+=("$cpu_some")
      printf 'pressure_sample_%s_cpu_psi_some_avg10_pct=%s\n' "$i" "$cpu_some"
      printf 'pressure_sample_%s_cpu_psi_full_avg10_pct=%s\n' "$i" "$cpu_full"
    fi
    if [[ -n "$run_queue" ]]; then
      IFS=' ' read -r runnable tasks vcpus run_per_vcpu <<<"$run_queue"
      run_queue_samples=$((run_queue_samples+1)); run_queue_values+=("$run_per_vcpu")
      printf 'pressure_sample_%s_runnable_tasks=%s\n' "$i" "$runnable"
      printf 'pressure_sample_%s_total_tasks=%s\n' "$i" "$tasks"
      printf 'pressure_sample_%s_run_queue_per_vcpu=%s\n' "$i" "$run_per_vcpu"
    fi
  done

  if (( memory_samples == requested && vm_samples == requested && memory_psi_samples == requested )); then memory_status=ok
  elif (( memory_samples > 0 || vm_samples > 0 || memory_psi_samples > 0 )); then memory_status=partial
  else memory_status=unavailable
  fi
  if (( cpu_psi_samples == requested && run_queue_samples == requested )); then cpu_status=ok
  elif (( cpu_psi_samples > 0 || run_queue_samples > 0 )); then cpu_status=partial
  else cpu_status=unavailable
  fi
  if (( vm_samples == requested )); then vm_status=ok
  elif (( vm_samples > 0 )); then vm_status=partial
  else vm_status=unavailable
  fi

  printf 'memory_pressure_sample_status=%s\n' "$memory_status"
  printf 'cpu_pressure_sample_status=%s\n' "$cpu_status"
  printf 'vm_pressure_delta_status=%s\n' "$vm_status"
  printf 'memory_pressure_sample_count=%s\n' "$memory_samples"
  printf 'vm_pressure_delta_count=%s\n' "$vm_samples"
  printf 'memory_psi_sample_count=%s\n' "$memory_psi_samples"
  printf 'cpu_psi_sample_count=%s\n' "$cpu_psi_samples"
  printf 'run_queue_sample_count=%s\n' "$run_queue_samples"
  printf 'pressure_sample_duration_seconds=%s\n' "$((requested*interval))"

  if (( memory_samples > 0 )); then
    pressure_metric_stats mem_available_pct "$MEM_AVAILABLE_WARN_PCT" low "${available_values[@]}"
    critical_exceedances="$(printf '%s\n' "${available_values[@]}" | awk -v threshold="$MEM_AVAILABLE_CRITICAL_PCT" '$1<threshold{n++} END{print n+0}')"
    printf 'mem_available_pct_critical_threshold=%.2f\n' "$MEM_AVAILABLE_CRITICAL_PCT"
    printf 'mem_available_pct_critical_threshold_exceedance_count=%s\n' "$critical_exceedances"
    if (( ${#swap_used_values[@]} > 0 )); then
      pressure_metric_stats swap_used_pct 100.00 high "${swap_used_values[@]}"
    else
      printf 'swap_used_pct_min=not_configured\nswap_used_pct_median=not_configured\nswap_used_pct_average=not_configured\nswap_used_pct_max=not_configured\n'
    fi
  else
    printf 'mem_available_pct_min=unavailable\nmem_available_pct_median=unavailable\nmem_available_pct_average=unavailable\nmem_available_pct_max=unavailable\nmem_available_pct_threshold=%.2f\nmem_available_pct_threshold_exceedance_count=unavailable\n' "$MEM_AVAILABLE_WARN_PCT"
    printf 'mem_available_pct_critical_threshold=%.2f\nmem_available_pct_critical_threshold_exceedance_count=unavailable\n' "$MEM_AVAILABLE_CRITICAL_PCT"
    printf 'swap_used_pct_min=unavailable\nswap_used_pct_median=unavailable\nswap_used_pct_average=unavailable\nswap_used_pct_max=unavailable\n'
  fi
  if (( vm_samples > 0 )); then
    pressure_metric_stats swap_in_pages_per_second "$SWAP_IO_RATE_WARN" high "${swap_in_rates[@]}"
    pressure_metric_stats swap_out_pages_per_second "$SWAP_IO_RATE_WARN" high "${swap_out_rates[@]}"
    pressure_metric_stats major_faults_per_second "$MAJOR_FAULT_RATE_WARN" high "${major_rates[@]}"
  else
    for prefix in swap_in_pages_per_second swap_out_pages_per_second major_faults_per_second; do
      printf '%s_min=unavailable\n%s_median=unavailable\n%s_average=unavailable\n%s_max=unavailable\n%s_threshold=unavailable\n%s_threshold_exceedance_count=unavailable\n' "$prefix" "$prefix" "$prefix" "$prefix" "$prefix" "$prefix"
    done
  fi
  if (( memory_psi_samples > 0 )); then
    pressure_metric_stats memory_psi_some_avg10_pct "$MEMORY_PSI_SOME_WARN_PCT" high "${mem_some_values[@]}"
    if (( ${#mem_full_values[@]} > 0 )); then
      pressure_metric_stats memory_psi_full_avg10_pct "$MEMORY_PSI_FULL_WARN_PCT" high "${mem_full_values[@]}"
    else
      printf 'memory_psi_full_avg10_pct_min=unavailable\nmemory_psi_full_avg10_pct_median=unavailable\nmemory_psi_full_avg10_pct_average=unavailable\nmemory_psi_full_avg10_pct_max=unavailable\nmemory_psi_full_avg10_pct_threshold=%.2f\nmemory_psi_full_avg10_pct_threshold_exceedance_count=unavailable\n' "$MEMORY_PSI_FULL_WARN_PCT"
    fi
  else
    printf 'memory_psi_some_avg10_pct_max=unavailable\nmemory_psi_some_avg10_pct_threshold=%.2f\nmemory_psi_some_avg10_pct_threshold_exceedance_count=unavailable\n' "$MEMORY_PSI_SOME_WARN_PCT"
    printf 'memory_psi_full_avg10_pct_max=unavailable\nmemory_psi_full_avg10_pct_threshold=%.2f\nmemory_psi_full_avg10_pct_threshold_exceedance_count=unavailable\n' "$MEMORY_PSI_FULL_WARN_PCT"
  fi
  if (( cpu_psi_samples > 0 )); then pressure_metric_stats cpu_psi_some_avg10_pct "$CPU_PSI_SOME_WARN_PCT" high "${cpu_some_values[@]}"
  else printf 'cpu_psi_some_avg10_pct_max=unavailable\ncpu_psi_some_avg10_pct_threshold=%.2f\ncpu_psi_some_avg10_pct_threshold_exceedance_count=unavailable\n' "$CPU_PSI_SOME_WARN_PCT"
  fi
  if (( run_queue_samples > 0 )); then pressure_metric_stats run_queue_per_vcpu "$RUN_QUEUE_PER_VCPU_WARN" high "${run_queue_values[@]}"
  else printf 'run_queue_per_vcpu_max=unavailable\nrun_queue_per_vcpu_threshold=%.2f\nrun_queue_per_vcpu_threshold_exceedance_count=unavailable\n' "$RUN_QUEUE_PER_VCPU_WARN"
  fi
}

sample_memory_cpu_pressure() {
  sample_memory_cpu_pressure_metrics
  pressure_raw_context
}
