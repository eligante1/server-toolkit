#!/usr/bin/env bash
# Quick-check-only classification and diagnostic adapters.
# This module intentionally has no report, package, network or remediation path.

quick_metric_value() {
  local file="$1" key="$2"
  /usr/bin/awk -F= -v key="$key" '
    $1 == key { count++; value=substr($0,index($0,"=")+1) }
    END { if (count != 1) exit 1; print value }
  ' "$file"
}

quick_validate_metrics_file() {
  local file="$1"
  [[ -f "$file" && ! -L "$file" ]] || return 1
  /usr/bin/awk -F= '
    length($0) > 2048 { exit 1 }
    NF < 2 || $1 !~ /^[A-Za-z_][A-Za-z0-9_]*$/ { exit 1 }
    seen[$1]++ { exit 1 }
    NR > 4096 { exit 1 }
    END { if (NR == 0) exit 1 }
  ' "$file"
}

quick_number_gt() {
  [[ "$1" =~ ^[0-9]+([.][0-9]+)?$ && "$2" =~ ^[0-9]+([.][0-9]+)?$ ]] || return 1
  /usr/bin/awk -v value="$1" -v threshold="$2" 'BEGIN { exit !(value > threshold) }'
}

quick_state_max() {
  local state best=ok score=0 best_score=0
  for state in "$@"; do
    case "$state" in
      fail) score=4 ;;
      warn) score=3 ;;
      unavailable) score=2 ;;
      ok) score=1 ;;
      *) return 2 ;;
    esac
    if (( score > best_score )); then best="$state"; best_score="$score"; fi
  done
  printf '%s\n' "$best"
}

quick_count_at_least() {
  [[ "$1" =~ ^[0-9]+$ && "$2" =~ ^[0-9]+$ ]] || return 1
  (( 10#$1 >= 10#$2 ))
}

quick_system_state() {
  case "$(quick_metric_value "$1" platform_support_status 2>/dev/null || true)" in
    supported) printf 'ok\n' ;;
    compatible_unverified) printf 'warn\n' ;;
    *) printf 'unavailable\n' ;;
  esac
}

quick_memory_state() {
  local file="$1" evidence state=ok value
  evidence="$(quick_metric_value "$file" memory_pressure_sample_status 2>/dev/null || true)"
  [[ "$evidence" == ok ]] || state=unavailable

  value="$(quick_metric_value "$file" mem_available_pct_critical_threshold_exceedance_count 2>/dev/null || true)"
  if quick_count_at_least "$value" 2; then printf 'fail\n'; return 0; fi
  for value in \
    "$(quick_metric_value "$file" mem_available_pct_threshold_exceedance_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" memory_psi_full_avg10_pct_threshold_exceedance_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" memory_psi_some_avg10_pct_threshold_exceedance_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" swap_in_pages_per_second_threshold_exceedance_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" swap_out_pages_per_second_threshold_exceedance_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" major_faults_per_second_threshold_exceedance_count 2>/dev/null || true)"; do
    if quick_count_at_least "$value" 2; then printf 'warn\n'; return 0; fi
  done
  value="$(quick_metric_value "$file" kernel_oom_events 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value > 0 )); then printf 'warn\n'; return 0; fi
  printf '%s\n' "$state"
}

quick_compute_pressure_state() {
  local file="$1" evidence value
  evidence="$(quick_metric_value "$file" cpu_pressure_sample_status 2>/dev/null || true)"
  for value in \
    "$(quick_metric_value "$file" cpu_psi_some_avg10_pct_threshold_exceedance_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" run_queue_per_vcpu_threshold_exceedance_count 2>/dev/null || true)"; do
    if quick_count_at_least "$value" 2; then printf 'warn\n'; return 0; fi
  done
  [[ "$evidence" == ok ]] && printf 'ok\n' || printf 'unavailable\n'
}

quick_compute_pressure_source() {
  local file="$1" psi_count queue_count psi_warn=0 queue_warn=0
  psi_count="$(quick_metric_value "$file" cpu_psi_some_avg10_pct_threshold_exceedance_count 2>/dev/null || true)"
  queue_count="$(quick_metric_value "$file" run_queue_per_vcpu_threshold_exceedance_count 2>/dev/null || true)"
  quick_count_at_least "$psi_count" 2 && psi_warn=1
  quick_count_at_least "$queue_count" 2 && queue_warn=1
  if (( psi_warn == 1 && queue_warn == 1 )); then printf 'cpu_psi_and_run_queue\n'
  elif (( psi_warn == 1 )); then printf 'cpu_psi\n'
  elif (( queue_warn == 1 )); then printf 'run_queue\n'
  else printf 'none\n'
  fi
}

quick_storage_state() {
  local file="$1" filesystem device state=ok value
  filesystem="$(quick_metric_value "$file" storage_filesystem_status 2>/dev/null || true)"
  device="$(quick_metric_value "$file" storage_device_sample_status 2>/dev/null || true)"
  [[ "$filesystem" == ok && "$device" == ok ]] || state=unavailable

  value="$(quick_metric_value "$file" kernel_storage_errors 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value > 0 )); then printf 'fail\n'; return 0; fi
  value="$(quick_metric_value "$file" root_mount_read_only 2>/dev/null || true)"
  if [[ "$value" == yes ]]; then printf 'fail\n'; return 0; fi
  value="$(quick_metric_value "$file" root_used_pct 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value >= STORAGE_FS_CRITICAL_PCT )); then printf 'fail\n'; return 0; fi
  value="$(quick_metric_value "$file" root_inode_used_pct 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value >= STORAGE_INODE_CRITICAL_PCT )); then printf 'fail\n'; return 0; fi

  value="$(quick_metric_value "$file" root_used_pct 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value >= STORAGE_FS_WARN_PCT )); then printf 'warn\n'; return 0; fi
  value="$(quick_metric_value "$file" root_inode_used_pct 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value >= STORAGE_INODE_WARN_PCT )); then printf 'warn\n'; return 0; fi
  if [[ "$(quick_metric_value "$file" storage_latency_evidence_status 2>/dev/null || true)" == ok ]]; then
    value="$(quick_metric_value "$file" storage_await_ms_threshold_exceedance_count 2>/dev/null || true)"
    if quick_count_at_least "$value" 2; then printf 'warn\n'; return 0; fi
  fi
  for value in \
    "$(quick_metric_value "$file" storage_util_pct_threshold_exceedance_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" storage_queue_depth_threshold_exceedance_count 2>/dev/null || true)"; do
    if quick_count_at_least "$value" 2; then printf 'warn\n'; return 0; fi
  done
  printf '%s\n' "$state"
}

quick_services_state() {
  local file="$1" systemd application state=ok value threshold
  systemd="$(quick_metric_value "$file" systemd_failed_services_status 2>/dev/null || true)"
  application="$(quick_metric_value "$file" application_service_sample_status 2>/dev/null || true)"
  [[ "$systemd" == ok && "$application" == ok ]] || state=unavailable

  for value in \
    "$(quick_metric_value "$file" failed_services_critical_count 2>/dev/null || true)" \
    "$(quick_metric_value "$file" failed_services_role_count 2>/dev/null || true)"; do
    if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value > 0 )); then printf 'fail\n'; return 0; fi
  done
  value="$(quick_metric_value "$file" failed_services_unknown_count 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value > 0 )); then printf 'warn\n'; return 0; fi

  for value in \
    service_restart_count_max service_failure_events_24h application_sqlite_lock_events_24h \
    application_timeout_events_24h application_role_relevant_events_24h; do
    case "$value" in
      service_restart_count_max) threshold=service_restart_threshold ;;
      service_failure_events_24h) threshold=service_failure_event_threshold ;;
      application_sqlite_lock_events_24h) threshold=application_sqlite_lock_threshold ;;
      application_timeout_events_24h) threshold=application_timeout_threshold ;;
      *) threshold=role_service_event_threshold ;;
    esac
    if quick_count_at_least \
        "$(quick_metric_value "$file" "$value" 2>/dev/null || true)" \
        "$(quick_metric_value "$file" "$threshold" 2>/dev/null || true)"; then
      printf 'warn\n'; return 0
    fi
  done
  printf '%s\n' "$state"
}

quick_subset_status() {
  local state unavailable=0 warning=0
  for state in "$@"; do
    case "$state" in
      fail) printf 'issues_detected\n'; return 0 ;;
      warn) warning=1 ;;
      unavailable) unavailable=1 ;;
    esac
  done
  if (( warning == 1 )); then printf 'attention_required\n'
  elif (( unavailable == 1 )); then printf 'limited_unavailable_evidence\n'
  else printf 'limited_no_alerts\n'
  fi
}

quick_human_state() {
  case "$1" in
    ok) printf 'ок' ;;
    warn) printf 'внимание' ;;
    fail) printf 'СБОЙ' ;;
    *) printf 'нет данных' ;;
  esac
}

quick_display_value() {
  local file="$1" group="$2" value secondary source
  case "$group" in
    server_system)
      value="$(quick_metric_value "$file" platform_id 2>/dev/null || true)"
      secondary="$(quick_metric_value "$file" platform_version_id 2>/dev/null || true)"
      [[ -n "$value" && -n "$secondary" ]] && printf '%s %s\n' "$value" "$secondary" || printf 'недоступно\n'
      ;;
    memory)
      if [[ "$(quick_compute_pressure_state "$file")" == warn ]]; then
        source="$(quick_compute_pressure_source "$file")"
        value="$(quick_metric_value "$file" cpu_psi_some_avg10_pct_max 2>/dev/null || true)"
        secondary="$(quick_metric_value "$file" run_queue_per_vcpu_max 2>/dev/null || true)"
        case "$source" in
          cpu_psi)
            [[ "$value" =~ ^[0-9]+([.][0-9]+)?$ ]] && printf 'CPU PSI %s%%\n' "$value" || printf 'CPU PSI: нет данных\n'
            ;;
          run_queue)
            [[ "$secondary" =~ ^[0-9]+([.][0-9]+)?$ ]] && printf 'очередь CPU %s/vCPU\n' "$secondary" || printf 'очередь CPU: нет данных\n'
            ;;
          cpu_psi_and_run_queue)
            if [[ "$value" =~ ^[0-9]+([.][0-9]+)?$ && "$secondary" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
              printf 'CPU PSI %s%% · очередь %s/vCPU\n' "$value" "$secondary"
            else
              printf 'CPU PSI и очередь CPU\n'
            fi
            ;;
          *) printf 'нагрузка CPU\n' ;;
        esac
      else
        value="$(quick_metric_value "$file" mem_available_pct_min 2>/dev/null || true)"
        [[ "$value" =~ ^[0-9]+([.][0-9]+)?$ ]] && printf 'доступно %s%%\n' "$value" || printf 'недоступно\n'
      fi
      ;;
    storage)
      value="$(quick_metric_value "$file" root_used_pct 2>/dev/null || true)"
      [[ "$value" =~ ^[0-9]+$ ]] && printf 'занято %s%%\n' "$value" || printf 'недоступно\n'
      ;;
    services)
      value="$(quick_metric_value "$file" failed_services_unknown_count 2>/dev/null || true)"
      secondary="$(quick_metric_value "$file" failed_services_critical_count 2>/dev/null || true)"
      if [[ "$value" =~ ^[0-9]+$ && "$secondary" =~ ^[0-9]+$ ]]; then
        printf 'сбоев %s\n' "$((10#$value + 10#$secondary))"
      else
        printf 'недоступно\n'
      fi
      ;;
    *) return 2 ;;
  esac
}

quick_build_summary() {
  local metrics="$1" output="$2"
  local system memory compute combined_memory storage services subset
  quick_validate_metrics_file "$metrics" || return 1
  system="$(quick_system_state "$metrics")" || return 1
  memory="$(quick_memory_state "$metrics")" || return 1
  compute="$(quick_compute_pressure_state "$metrics")" || return 1
  combined_memory="$(quick_state_max "$memory" "$compute")" || return 1
  storage="$(quick_storage_state "$metrics")" || return 1
  services="$(quick_services_state "$metrics")" || return 1
  subset="$(quick_subset_status "$system" "$combined_memory" "$storage" "$services")"
  {
    printf 'scope=quick\n'
    printf 'quick_check_contract_version=2\n'
    printf 'confidence=LIMITED\n'
    printf 'executed_checks=server_system,memory_compute_pressure,storage,services\n'
    printf 'omitted_checks=cpu_full,network,packages,security,report\n'
    printf 'presentation_groups_executed=4\n'
    printf 'presentation_groups_total=9\n'
    printf 'whole_server_verdict=not_evaluated\n'
    printf 'quick_subset_status=%s\n' "$subset"
    printf 'check_server_system=%s\n' "$system"
    printf 'check_memory=%s\n' "$combined_memory"
    printf 'check_memory_evidence=%s\n' "$memory"
    printf 'check_compute_pressure=%s\n' "$compute"
    printf 'compute_pressure_source=%s\n' "$(quick_compute_pressure_source "$metrics")"
    printf 'check_storage=%s\n' "$storage"
    printf 'check_services=%s\n' "$services"
    printf 'value_server_system=%s\n' "$(quick_display_value "$metrics" server_system)"
    printf 'value_memory=%s\n' "$(quick_display_value "$metrics" memory)"
    printf 'value_storage=%s\n' "$(quick_display_value "$metrics" storage)"
    printf 'value_services=%s\n' "$(quick_display_value "$metrics" services)"
  } >"$output"
}

quick_kernel_journal_output() {
  /usr/bin/journalctl -k --since '24 hours ago' --no-pager -n 5000 -o cat
}

quick_failed_services_output() {
  /usr/bin/systemctl --failed --no-legend --plain
}

quick_collect_diagnostic_metrics() {
  local journal failed failed_names virt oom storage_errors
  local informational unknown critical role
  if command -v journalctl >/dev/null 2>&1 && journal="$(quick_kernel_journal_output 2>/dev/null)"; then
    oom="$(printf '%s\n' "$journal" | /usr/bin/grep -Eic 'out of memory|oom-killer|killed process' || true)"
    storage_errors="$(printf '%s\n' "$journal" | /usr/bin/grep -Eic 'I/O error|filesystem error|EXT4-fs error|XFS.*error|blk_update_request' || true)"
    printf 'kernel_journal_status=ok\nkernel_oom_events=%s\nkernel_storage_errors=%s\n' "$oom" "$storage_errors"
  else
    printf 'kernel_journal_status=unavailable\nkernel_oom_events=unavailable\nkernel_storage_errors=unavailable\n'
  fi
  if command -v systemctl >/dev/null 2>&1 && failed="$(quick_failed_services_output 2>/dev/null)"; then
    failed_names="$(printf '%s\n' "$failed" | /usr/bin/awk '
      NF {
        if (++count > 512) exit 2
        if ($1 !~ /^[A-Za-z0-9_.@:-]+$/) exit 2
        print $1
      }
    ')" || {
      printf '%s\n' \
        'systemd_failed_services_status=unavailable' \
        'failed_services_informational_count=unavailable' \
        'failed_services_unknown_count=unavailable' \
        'failed_services_critical_count=unavailable' \
        'failed_services_role_count=unavailable'
      return 0
    }
    if command -v systemd-detect-virt >/dev/null 2>&1; then
      virt="$(systemd-detect-virt 2>/dev/null || printf none)"
    else
      virt=none
    fi
    classify_failed_services "$failed_names" "${virt:-none}" generic
    informational="$FAILED_INFORMATIONAL_COUNT"; unknown="$FAILED_UNKNOWN_COUNT"
    critical="$FAILED_CRITICAL_COUNT"; role="$FAILED_ROLE_RELEVANT_COUNT"
    printf 'systemd_failed_services_status=ok\n'
    printf 'failed_services_informational_count=%s\n' "$informational"
    printf 'failed_services_unknown_count=%s\n' "$unknown"
    printf 'failed_services_critical_count=%s\n' "$critical"
    printf 'failed_services_role_count=%s\n' "$role"
  else
    printf '%s\n' \
      'systemd_failed_services_status=unavailable' \
      'failed_services_informational_count=unavailable' \
      'failed_services_unknown_count=unavailable' \
      'failed_services_critical_count=unavailable' \
      'failed_services_role_count=unavailable'
  fi
}

quick_collect_services_metrics() {
  sample_application_services
  quick_collect_diagnostic_metrics
}
