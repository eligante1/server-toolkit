#!/usr/bin/env bash
# Platform-family contract for the audit-only candidate.
# The builder embeds this module; its public state is consumed by the engine.
# shellcheck disable=SC2034

PLATFORM_CONTRACT_VERSION=2
PLATFORM_SUPPORTED_FAMILIES="ubuntu,debian"
PLATFORM_VALIDATED_LIST="ubuntu:24.04,ubuntu:26.04,debian:12"
# Backward-compatible alias retained for existing report consumers.
PLATFORM_SUPPORTED_LIST="ubuntu:24.04,ubuntu:26.04,debian:12"
PLATFORM_ID=unavailable
PLATFORM_VERSION_ID=unavailable
PLATFORM_SUPPORT_STATUS=unavailable
PLATFORM_SUPPORT_REASON=os_release_unavailable
PLATFORM_VALIDATION_STATUS=unavailable

platform_os_release_value() {
  local file="$1" key="$2"
  [[ -r "$file" ]] || return 1
  awk -v key="$key" '
    index($0,key "=")==1 {
      count++
      value=substr($0,length(key)+2)
      if (value ~ /^".*"$/ || value ~ /^\047.*\047$/) {
        value=substr(value,2,length(value)-2)
      }
      selected=value
    }
    END {
      if (count == 1) {
        print selected
      }
    }
  ' "$file"
}

platform_evaluate() {
  local file="${1:-/etc/os-release}" id version
  PLATFORM_ID=unavailable
  PLATFORM_VERSION_ID=unavailable
  PLATFORM_SUPPORT_STATUS=unavailable
  PLATFORM_SUPPORT_REASON=os_release_unavailable
  PLATFORM_VALIDATION_STATUS=unavailable

  [[ -r "$file" ]] || return 3
  id="$(platform_os_release_value "$file" ID 2>/dev/null || true)"
  version="$(platform_os_release_value "$file" VERSION_ID 2>/dev/null || true)"
  id="$(printf '%s' "$id" | tr '[:upper:]' '[:lower:]')"

  [[ "$id" =~ ^[a-z0-9._-]+$ ]] || id=unavailable
  [[ "$version" =~ ^[0-9]+([.][0-9]+)*$ ]] || version=unavailable
  PLATFORM_ID="$id"
  PLATFORM_VERSION_ID="$version"

  case "$id:$version" in
    ubuntu:24.04|ubuntu:26.04|debian:12)
      PLATFORM_SUPPORT_STATUS=supported
      PLATFORM_SUPPORT_REASON=matched_supported_release
      PLATFORM_VALIDATION_STATUS=validated
      return 0
      ;;
    unavailable:*)
      PLATFORM_SUPPORT_STATUS=unavailable
      PLATFORM_SUPPORT_REASON=os_identity_unavailable
      ;;
    *:unavailable)
      PLATFORM_SUPPORT_STATUS=unavailable
      PLATFORM_SUPPORT_REASON=os_version_unavailable
      ;;
    ubuntu:*|debian:*)
      PLATFORM_SUPPORT_STATUS=compatible_unverified
      PLATFORM_SUPPORT_REASON=recognized_family_unvalidated_release
      PLATFORM_VALIDATION_STATUS=unverified
      return 0
      ;;
    *)
      PLATFORM_SUPPORT_STATUS=unsupported
      PLATFORM_SUPPORT_REASON=distribution_not_in_contract
      ;;
  esac
  return 3
}

platform_assert_supported() {
  local file="${1:-/etc/os-release}" rc=0
  platform_evaluate "$file" || rc=$?
  if (( rc == 0 )); then
    return 0
  fi
  printf 'Неподдерживаемая платформа: %s %s. Запуск разрешён для выпусков Ubuntu и Debian; полностью проверены: Ubuntu 24.04, Ubuntu 26.04 и Debian 12.\n' \
    "$PLATFORM_ID" "$PLATFORM_VERSION_ID" >&2
  return 3
}
