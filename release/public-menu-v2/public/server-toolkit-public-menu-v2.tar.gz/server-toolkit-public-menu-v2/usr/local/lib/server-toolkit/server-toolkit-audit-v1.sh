#!/bin/bash -p
SERVER_TOOLKIT_IS_SOURCED=0
[[ "${BASH_SOURCE[0]}" != "$0" ]] && SERVER_TOOLKIT_IS_SOURCED=1
if [[ "$SERVER_TOOLKIT_IS_SOURCED" == 0 ]]; then
  if [[ "$-" != *p* ]]; then
    echo "Небезопасный способ запуска: запускай напрямую только предварительно проверенный абсолютный root-owned артефакт с mode 0700." >&2
    exit 126
  fi
  set -Eeuo pipefail
  IFS=$'\n\t'
fi


VERSION="0.4.1-rc4-round2-audit-only-expert-beta1"
MODE="${1-audit}"
REPORT_ROOT="${SERVER_TOOLKIT_REPORT_ROOT:-/var/server-toolkit}"
sanitize_label() {
  local value="$1" restore_nocasematch=0
  local sensitive_pattern='(authorization|bearer[[:space:]]|basic[[:space:]]|password|passwd|token|secret|api[_ -]?key|client[_ -]?secret|private[_ -]?key|subscription|(^|[^A-Za-z0-9])(vless|vmess|trojan|ss)://|[A-Za-z][A-Za-z0-9+.-]*://[^[:space:]/]+:[^[:space:]@]+@|eyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.|[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})'
  while [[ "$value" =~ [[:cntrl:]] ]]; do
    value="${value/"${BASH_REMATCH[0]}"/ }"
  done
  (( ${#value} <= 128 )) || value="${value:0:128}"
  if ! shopt -q nocasematch; then
    restore_nocasematch=1
    shopt -s nocasematch
  fi
  if [[ "$value" =~ $sensitive_pattern ]]; then
    value=REDACTED_SENSITIVE_LABEL
  fi
  (( restore_nocasematch == 0 )) || shopt -u nocasematch
  printf '%s' "$value"
}
audit_validate_metrics_file() {
  LC_ALL=C awk '
    index($0,"=") < 2 { invalid=1; next }
    {
      key=substr($0,1,index($0,"=")-1)
      value=substr($0,index($0,"=")+1)
      if(key !~ /^[a-z][a-z0-9_]*$/ || value ~ /[[:cntrl:]]/ || seen[key]++) {
        invalid=1
        next
      }
      records++
    }
    END { exit (invalid || records == 0) }
  ' "$1"
}
AUDIT_ACTIVE_SECTION_TMP=""
AUDIT_TRUSTED_METRICS_FILE=""
AUDIT_ARTIFACT_TMP_DIR=""
audit_cleanup_private_scratch() {
  [[ -z "$AUDIT_ACTIVE_SECTION_TMP" ]] || rm -f -- "$AUDIT_ACTIVE_SECTION_TMP" 2>/dev/null || true
  [[ -z "$AUDIT_TRUSTED_METRICS_FILE" ]] || rm -f -- "$AUDIT_TRUSTED_METRICS_FILE" 2>/dev/null || true
  if [[ -n "$AUDIT_ARTIFACT_TMP_DIR" ]]; then
    rm -f -- \
      "$AUDIT_ARTIFACT_TMP_DIR/technical-summary.txt.tmp" \
      "$AUDIT_ARTIFACT_TMP_DIR/result.txt.tmp" \
      "$AUDIT_ARTIFACT_TMP_DIR/readable-summary.txt.tmp" \
      "$AUDIT_ARTIFACT_TMP_DIR/metadata.env.tmp" 2>/dev/null || true
  fi
  AUDIT_ACTIVE_SECTION_TMP=""
  AUDIT_TRUSTED_METRICS_FILE=""
  AUDIT_ARTIFACT_TMP_DIR=""
}
apt_parse_full_upgrade_removals() {
  awk '
    /^[[:space:]]*[0-9]+ upgraded, [0-9]+ newly installed, [0-9]+ to remove and [0-9]+ not upgraded[.]?[[:space:]]*$/ {
      matches++
      value=$0
      sub(/^.* newly installed, /,"",value)
      sub(/ to remove.*$/,"",value)
      if(value !~ /^[0-9]+$/) exit 1
      removals=value
    }
    END {
      if(matches != 1) exit 1
      print removals
    }
  ' "$1"
}
DEFAULT_REPORT_ROOT="/var/server-toolkit"
DEFAULT_FAILED_SERVICES_ALLOWLIST_FILE="/etc/server-toolkit/failed-services.allowlist"
PROVIDER_LABEL="$(sanitize_label "${SERVER_TOOLKIT_PROVIDER:-not_supplied}")"
LOCATION_LABEL="$(sanitize_label "${SERVER_TOOLKIT_LOCATION:-not_supplied}")"
ROLE_LABEL="$(sanitize_label "${SERVER_TOOLKIT_ROLE:-generic}")"
# shellcheck disable=SC2034 # audit-only builder removes the full-engine disk branch
DISK_TEST_ENABLED=0
FAILED_SERVICES_ALLOWLIST_FILE="${SERVER_TOOLKIT_FAILED_SERVICES_ALLOWLIST_FILE:-$DEFAULT_FAILED_SERVICES_ALLOWLIST_FILE}"
APT_INDEX_FRESH_HOURS="${SERVER_TOOLKIT_APT_INDEX_FRESH_HOURS:-24}"
APT_INDEX_STALE_HOURS="${SERVER_TOOLKIT_APT_INDEX_STALE_HOURS:-72}"
PROGRESS_MODE_INPUT="${SERVER_TOOLKIT_PROGRESS_MODE:-auto}"
PROGRESS_WIDTH_INPUT="${SERVER_TOOLKIT_PROGRESS_WIDTH:-auto}"


SERVER_TOOLKIT_TRUSTED_PATH="/usr/sbin:/usr/bin:/sbin:/bin"
SERVER_TOOLKIT_SCRIPT_PATH="${BASH_SOURCE[0]}"
SERVER_TOOLKIT_PRODUCTION_MODE=0
[[ "$SERVER_TOOLKIT_IS_SOURCED" == 0 ]] && SERVER_TOOLKIT_PRODUCTION_MODE=1
SERVER_TOOLKIT_ENVIRONMENT_CLEAN=0

audit_validate_configuration() {
  local fresh="$APT_INDEX_FRESH_HOURS" stale="$APT_INDEX_STALE_HOURS"
  local progress_width="$PROGRESS_WIDTH_INPUT"
  if ! [[ "$fresh" =~ ^[0-9]{1,4}$ && "$stale" =~ ^[0-9]{1,4}$ ]]; then
    echo "SERVER_TOOLKIT_APT_INDEX_FRESH_HOURS и SERVER_TOOLKIT_APT_INDEX_STALE_HOURS должны быть десятичными часами от 0 до 8760." >&2
    return 2
  fi
  fresh=$((10#$fresh))
  stale=$((10#$stale))
  if (( fresh > 8760 || stale > 8760 || fresh > stale )); then
    echo "Пороги APT должны быть в диапазоне 0..8760 и fresh не должен превышать stale." >&2
    return 2
  fi
  case "$PROGRESS_MODE_INPUT" in
    auto|off|plain|tty) ;;
    *)
      echo "SERVER_TOOLKIT_PROGRESS_MODE должен быть auto, off, plain или tty." >&2
      return 2
      ;;
  esac
  if [[ "$progress_width" != auto ]]; then
    if ! [[ "$progress_width" =~ ^[0-9]{2}$ ]]; then
      echo "SERVER_TOOLKIT_PROGRESS_WIDTH должен быть auto или десятичным числом от 16 до 60." >&2
      return 2
    fi
    progress_width=$((10#$progress_width))
    if (( progress_width < 16 || progress_width > 60 )); then
      echo "SERVER_TOOLKIT_PROGRESS_WIDTH должен быть auto или десятичным числом от 16 до 60." >&2
      return 2
    fi
  fi
  if [[ "$SERVER_TOOLKIT_PRODUCTION_MODE" == 1 ]] &&
      [[ "$FAILED_SERVICES_ALLOWLIST_FILE" != "$DEFAULT_FAILED_SERVICES_ALLOWLIST_FILE" ]]; then
    echo "Привилегированный запуск принимает allowlist только из $DEFAULT_FAILED_SERVICES_ALLOWLIST_FILE." >&2
    return 2
  fi
  if [[ "$SERVER_TOOLKIT_PRODUCTION_MODE" == 1 ]] &&
      [[ "$REPORT_ROOT" != "$DEFAULT_REPORT_ROOT" ]]; then
    echo "Привилегированный запуск сохраняет отчёты только в $DEFAULT_REPORT_ROOT." >&2
    return 2
  fi
  if [[ "$SERVER_TOOLKIT_PRODUCTION_MODE" == 1 ]]; then
    if [[ ! "$SERVER_TOOLKIT_SCRIPT_PATH" =~ ^/[A-Za-z0-9._/-]+$ ||
          "$SERVER_TOOLKIT_SCRIPT_PATH" == */ ||
          "$SERVER_TOOLKIT_SCRIPT_PATH" == *//* ||
          "$SERVER_TOOLKIT_SCRIPT_PATH" =~ (^|/)\.\.?(/|$) ]]; then
      echo "Привилегированный запуск требует абсолютный нормализованный путь к root-owned артефакту." >&2
      return 2
    fi
  fi
  if [[ "$SERVER_TOOLKIT_PRODUCTION_MODE" == 1 ]] &&
      [[ -n "${SERVER_TOOLKIT_RCLONE_REMOTE+x}${SERVER_TOOLKIT_RCLONE_PATH+x}${SERVER_TOOLKIT_KEEP_LOCAL+x}${SERVER_TOOLKIT_DISK_TEST+x}" ||
         -n "${VPS_TOOLKIT_RCLONE_REMOTE+x}${VPS_TOOLKIT_RCLONE_PATH+x}${VPS_TOOLKIT_KEEP_LOCAL+x}" ||
         -n "${NIKOLAI_RCLONE_REMOTE+x}${NIKOLAI_RCLONE_PATH+x}${NIKOLAI_KEEP_LOCAL+x}" ]]; then
    echo "Встроенная загрузка, удаление локальной копии и disk-test отключены; переменные авторизации запрещены." >&2
    return 2
  fi
  printf -v APT_INDEX_FRESH_HOURS '%d' "$fresh"
  printf -v APT_INDEX_STALE_HOURS '%d' "$stale"
  printf -v PROGRESS_WIDTH_INPUT '%s' "$progress_width"
}

audit_reexec_clean_environment() {
  exec -c /bin/bash --noprofile --norc -p -c '
    set -Eeuo pipefail
    printf -v IFS "\n\t"
    bootstrap_stat_uid() {
      local value
      value="$(/usr/bin/stat -c %u -- "$1" 2>/dev/null)" ||
        value="$(/usr/bin/stat -f %u "$1" 2>/dev/null)" ||
        return 1
      [[ "$value" =~ ^[0-9]+$ ]] || return 1
      printf "%s\n" "$value"
    }
    bootstrap_stat_mode() {
      local value
      value="$(/usr/bin/stat -c %a -- "$1" 2>/dev/null)" ||
        value="$(/usr/bin/stat -f %Lp "$1" 2>/dev/null)" ||
        return 1
      [[ "$value" =~ ^[0-7]{3,4}$ ]] || return 1
      value="${value#0}"
      printf "%s\n" "$value"
    }
    bootstrap_directory_is_trusted() {
      local path="$1" owner mode numeric
      [[ -d "$path" && ! -L "$path" ]] || return 1
      owner="$(bootstrap_stat_uid "$path")" || return 1
      mode="$(bootstrap_stat_mode "$path")" || return 1
      [[ "$owner" == 0 ]] || return 1
      numeric=$((8#$mode))
      (( (numeric & 0022) == 0 ))
    }
    bootstrap_artifact_is_trusted() {
      local artifact="$1" parent current component owner mode
      local -a components=()
      [[ "$artifact" =~ ^/[A-Za-z0-9._/-]+$ &&
         "$artifact" != */ &&
         "$artifact" != *//* &&
         ! "$artifact" =~ (^|/)\.\.?(/|$) ]] || return 1
      parent="${artifact%/*}"
      [[ -n "$parent" ]] || parent=/
      bootstrap_directory_is_trusted / || return 1
      IFS=/ read -r -a components <<<"${parent#/}"
      current=/
      for component in "${components[@]}"; do
        [[ -n "$component" ]] || continue
        current="${current%/}/$component"
        bootstrap_directory_is_trusted "$current" || return 1
      done
      [[ -f "$artifact" && ! -L "$artifact" ]] || return 1
      owner="$(bootstrap_stat_uid "$artifact")" || return 1
      mode="$(bootstrap_stat_mode "$artifact")" || return 1
      [[ "$owner" == 0 && "$mode" == 700 ]]
    }
    artifact="$1"
    if ! bootstrap_artifact_is_trusted "$artifact"; then
      echo "Артефакт или его путь не являются root-owned trust boundary; требуется staging с mode 0700." >&2
      exit 126
    fi
    cd / || exit 126
    if ! bootstrap_artifact_is_trusted "$artifact"; then
      echo "Повторная проверка root-owned артефакта не пройдена." >&2
      exit 126
    fi
    source "$artifact" || exit 126
    expected_ifs=""
    printf -v expected_ifs "\n\t"
    if [[ "$-" != *e* || "$-" != *u* || "$-" != *E* ]]; then
      echo "Root-owned артефакт изменил обязательные strict-mode параметры clean-stage." >&2
      exit 126
    fi
    if ! shopt -qo pipefail; then
      echo "Root-owned артефакт отключил pipefail clean-stage." >&2
      exit 126
    fi
    if [[ "$IFS" != "$expected_ifs" ]]; then
      echo "Root-owned артефакт изменил доверенный IFS clean-stage." >&2
      exit 126
    fi
    SERVER_TOOLKIT_PRODUCTION_MODE=1
    SERVER_TOOLKIT_ENVIRONMENT_CLEAN=1
    MODE="$2"
    REPORT_ROOT="$3"
    PROVIDER_LABEL="$4"
    LOCATION_LABEL="$5"
    ROLE_LABEL="$6"
    APT_INDEX_FRESH_HOURS="$7"
    APT_INDEX_STALE_HOURS="$8"
    PROGRESS_MODE_INPUT="$9"
    PROGRESS_WIDTH_INPUT="${10}"
    PROGRESS_MODE="$9"
    PROGRESS_WIDTH="${10}"
    if ! [[ "${11}" =~ ^[01]$ && "${12}" =~ ^[0-9]{2,3}$ &&
            "${13}" =~ ^[01]$ && "${14}" =~ ^[01]$ ]]; then
      echo "Некорректные presentation capability scalars clean-stage." >&2
      exit 126
    fi
    presentation_columns=$((10#${12}))
    if (( presentation_columns < 20 || presentation_columns > 240 )) ||
       [[ "${11}" == 1 && presentation_columns -lt 34 ]] ||
       [[ "${11}" == 0 && ( "${13}" != 0 || "${14}" != 0 ) ]]; then
      echo "Presentation capability scalars вышли за безопасные границы." >&2
      exit 126
    fi
    PROGRESS_PRESENTATION_INPUT_VALIDATED=1
    PROGRESS_PRESENTATION_TTY="${11}"
    PROGRESS_PRESENTATION_COLUMNS="$presentation_columns"
    PROGRESS_PRESENTATION_UNICODE="${13}"
    PROGRESS_PRESENTATION_COLOR="${14}"
    unset presentation_columns
    FAILED_SERVICES_ALLOWLIST_FILE="$DEFAULT_FAILED_SERVICES_ALLOWLIST_FILE"
    DISK_TEST_ENABLED=0
    main
  ' server-toolkit-clean "$SERVER_TOOLKIT_SCRIPT_PATH" "$MODE" "$REPORT_ROOT" \
    "$PROVIDER_LABEL" "$LOCATION_LABEL" "$ROLE_LABEL" \
    "$APT_INDEX_FRESH_HOURS" "$APT_INDEX_STALE_HOURS" \
    "$PROGRESS_MODE_INPUT" "$PROGRESS_WIDTH_INPUT" \
    "${PROGRESS_PRESENTATION_TTY:-0}" "${PROGRESS_PRESENTATION_COLUMNS:-80}" \
    "${PROGRESS_PRESENTATION_UNICODE:-0}" "${PROGRESS_PRESENTATION_COLOR:-0}"
  echo "Не удалось перезапустить Toolkit с пустым окружением." >&2
  return 126
}

audit_prepare_privileged_environment() {
  local name
  [[ "$-" == *p* ]] || {
    echo "Привилегированный режим Bash обязателен." >&2
    return 126
  }
  [[ "$SERVER_TOOLKIT_ENVIRONMENT_CLEAN" == 1 ]] || {
    echo "Внутренняя clean-stage граница не подтверждена." >&2
    return 126
  }
  while IFS= read -r name; do
    [[ "$name" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || {
      echo "Некорректное имя экспортированной переменной в clean-stage." >&2
      return 126
    }
    # shellcheck disable=SC2163 # intentional name indirection for export -n
    export -n "$name" 2>/dev/null || {
      echo "Не удалось удалить экспорт переменной $name; запуск остановлен." >&2
      return 126
    }
  done < <(compgen -e)
  PATH="$SERVER_TOOLKIT_TRUSTED_PATH"
  HOME=/root
  LC_ALL=C
  LANG=C
  TERM=dumb
  TZ=UTC
  export PATH HOME LC_ALL LANG TERM TZ
  while IFS= read -r name; do
    case "$name" in
      PATH|HOME|LC_ALL|LANG|TERM|TZ) ;;
      *)
        echo "Clean-stage сохранил неожиданную экспортированную переменную $name." >&2
        return 126
        ;;
    esac
  done < <(compgen -e)
  umask 077
}

audit_run_clean_shell() {
  /usr/bin/env -i \
    PATH="$SERVER_TOOLKIT_TRUSTED_PATH" HOME=/root LC_ALL=C LANG=C TERM=dumb TZ=UTC \
    /bin/bash --noprofile --norc -p -c "$1" server-toolkit-section
}

audit_emit_server_identity() {
  local host="$1" provider="$2" location="$3" role="$4"
  local os_name kernel virtualization
  local provider_report_safe location_report_safe role_report_safe
  provider_report_safe="$(report_safe_operator_label "$provider")"
  location_report_safe="$(report_safe_operator_label "$location")"
  role_report_safe="$(report_safe_operator_label "$role")"
  os_name="$(/usr/bin/awk -F= '/^PRETTY_NAME=/{gsub(/"/,"",$2); print $2; exit}' /etc/os-release 2>/dev/null || true)"
  kernel="$(/usr/bin/uname -r 2>/dev/null || printf unknown)"
  virtualization="$(/usr/bin/systemd-detect-virt 2>/dev/null || printf unknown)"
  printf 'hostname=%s\nprovider_label=%s\nlocation_label=%s\nrole_label=%s\n' \
    "$host" "$provider_report_safe" "$location_report_safe" "$role_report_safe"
  printf 'os=%s\nkernel=%s\nvirtualization=%s\n' \
    "${os_name:-unknown}" "${kernel:-unknown}" "${virtualization:-unknown}"
}

audit_stat_uid() {
  /usr/bin/stat -c %u -- "$1" 2>/dev/null || /usr/bin/stat -f %u "$1" 2>/dev/null
}

audit_stat_mode() {
  local mode
  if mode="$(/usr/bin/stat -c %a -- "$1" 2>/dev/null)"; then
    printf '%s\n' "$mode"
    return 0
  fi
  mode="$(/usr/bin/stat -f %Op "$1" 2>/dev/null)" || return 1
  [[ "$mode" =~ ^[0-7]+$ ]] || return 1
  (( ${#mode} <= 4 )) || mode="${mode: -4}"
  mode="${mode#0}"
  printf '%s\n' "$mode"
}

audit_parent_chain_is_safe() {
  local path="${1%/*}" current component owner mode numeric
  local -a components=()
  [[ -n "$path" ]] || path=/
  IFS=/ read -r -a components <<<"${path#/}"
  current=/
  [[ -d "$current" && ! -L "$current" ]] || return 1
  owner="$(audit_stat_uid "$current" || true)"
  mode="$(audit_stat_mode "$current" || true)"
  [[ "$owner" =~ ^[0-9]+$ && "$mode" =~ ^[0-7]{3,4}$ ]] || return 1
  [[ "$owner" == 0 || "$owner" == "$EUID" ]] || return 1
  numeric=$((8#$mode))
  if (( (numeric & 0022) != 0 )); then
    (( owner == 0 && (numeric & 01000) != 0 )) || return 1
  fi
  for component in "${components[@]}"; do
    [[ -n "$component" ]] || continue
    current="${current%/}/$component"
    [[ -d "$current" && ! -L "$current" ]] || return 1
    owner="$(audit_stat_uid "$current" || true)"
    mode="$(audit_stat_mode "$current" || true)"
    [[ "$owner" =~ ^[0-9]+$ && "$mode" =~ ^[0-7]{3,4}$ ]] || return 1
    [[ "$owner" == 0 || "$owner" == "$EUID" ]] || return 1
    numeric=$((8#$mode))
    if (( (numeric & 0022) != 0 )); then
      (( owner == 0 && (numeric & 01000) != 0 )) || return 1
    fi
  done
}

audit_report_root_is_empty() {
  local root="$1" entry
  for entry in "$root"/* "$root"/.[!.]* "$root"/..?*; do
    [[ -e "$entry" || -L "$entry" ]] && return 1
  done
  return 0
}

audit_verify_report_root() {
  local root="$1" owner mode
  [[ -d "$root" && ! -L "$root" ]] || return 1
  owner="$(audit_stat_uid "$root" || true)"
  mode="$(audit_stat_mode "$root" || true)"
  [[ "$owner" == "$EUID" && "$mode" == 700 ]]
}

audit_verify_report_marker() {
  local marker="$1" owner mode value
  [[ -f "$marker" && ! -L "$marker" ]] || return 1
  owner="$(audit_stat_uid "$marker" || true)"
  mode="$(audit_stat_mode "$marker" || true)"
  value="$(<"$marker")"
  [[ "$owner" == "$EUID" && "$mode" == 600 &&
     "$value" == server-toolkit-report-root-v1 ]]
}

audit_create_report_marker() {
  local root="$1" marker="$2" temporary
  temporary="$root/.server-toolkit-report-root.tmp.$$.$RANDOM"
  (
    set -o noclobber
    umask 077
    printf 'server-toolkit-report-root-v1\n' >"$temporary"
  ) || return 1
  /bin/chmod 600 "$temporary" || {
    /bin/rm -f -- "$temporary"
    return 1
  }
  if ! audit_verify_report_marker "$temporary" ||
      ! /bin/ln "$temporary" "$marker" 2>/dev/null; then
    /bin/rm -f -- "$temporary"
    return 1
  fi
  /bin/rm -f -- "$temporary"
  audit_verify_report_marker "$marker"
}

audit_prepare_report_root() {
  local root="$1" marker created=0
  marker="$root/.server-toolkit-report-root"
  [[ "$root" =~ ^/[A-Za-z0-9._/-]+$ && "$root" != / && "$root" != */ ]] || return 1
  [[ ! "$root" =~ (^|/)\.\.?(/|$) ]] || return 1
  case "$root" in
    /bin|/bin/*|/boot|/boot/*|/dev|/dev/*|/etc|/etc/*|/home|/home/*|/lib|/lib/*|/lib32|/lib32/*|/lib64|/lib64/*|/lost+found|/lost+found/*|/media|/media/*|/mnt|/mnt/*|/opt|/opt/*|/proc|/proc/*|/root|/root/*|/run|/run/*|/sbin|/sbin/*|/srv|/srv/*|/sys|/sys/*|/usr|/usr/*|/var|/var/lib|/var/lib/*|/var/cache|/var/cache/*|/var/spool|/var/spool/*|/var/log)
      return 1
      ;;
  esac
  audit_parent_chain_is_safe "$root" || return 1
  [[ ! -L "$root" ]] || return 1
  if [[ -e "$root" ]]; then
    [[ -d "$root" ]] || return 1
  else
    /bin/mkdir -m 700 -- "$root" || return 1
    created=1
  fi
  audit_verify_report_root "$root" || return 1
  if [[ -e "$marker" || -L "$marker" ]]; then
    audit_verify_report_marker "$marker" || return 1
  else
    if (( created == 0 )) && ! audit_report_root_is_empty "$root"; then
      return 1
    fi
    audit_create_report_marker "$root" "$marker" || return 1
  fi
  audit_parent_chain_is_safe "$root" &&
    audit_verify_report_root "$root" &&
    audit_verify_report_marker "$marker"
}

audit_create_run_dir() {
  local root="$1" host="$2" stamp="$3" mode="$4" safe_host path attempt
  local owner actual_mode
  safe_host="${host//[^A-Za-z0-9._-]/_}"
  (( ${#safe_host} <= 63 )) || safe_host="${safe_host:0:63}"
  [[ -n "$safe_host" ]] || safe_host=unknown
  for ((attempt=1; attempt<=100; attempt++)); do
    path="$root/${safe_host}_${stamp}_$$_${attempt}_${mode}"
    if /bin/mkdir -m 700 -- "$path" 2>/dev/null; then
      [[ -d "$path" && ! -L "$path" ]] || return 1
      owner="$(audit_stat_uid "$path" || true)"
      actual_mode="$(audit_stat_mode "$path" || true)"
      [[ "$owner" == "$EUID" && "$actual_mode" == 700 ]] || {
        /bin/rmdir -- "$path" 2>/dev/null || true
        return 1
      }
      printf '%s\n' "$path"
      return 0
    fi
    [[ -e "$path" || -L "$path" ]] || return 1
  done
  return 1
}


#!/usr/bin/env bash
# Privacy boundary for the local-sensitive Expert Beta report.
#
# Redaction is defense in depth, not a guarantee that the full report is safe
# to share. Raw journal and firewall messages are reduced to aggregate counts
# before they reach the report stream.

report_redact_stream() {
  awk '
    /-----BEGIN ([A-Z0-9 ]+ )?PRIVATE KEY-----/ {
      private_key_block=1
      print "REDACTED_PRIVATE_KEY_BLOCK"
      next
    }
    private_key_block {
      if ($0 ~ /-----END ([A-Z0-9 ]+ )?PRIVATE KEY-----/) private_key_block=0
      next
    }
    { print }
  ' | sed -E \
    -e 's#(vless|vmess|trojan|ss)://[^[:space:]]+#REDACTED_SUBSCRIPTION#gI' \
    -e 's#([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})#REDACTED_UUID#g' \
    -e 's#((authorization|proxy-authorization)[[:space:]]*:[[:space:]]*(bearer|basic)[[:space:]]+)[^[:space:]]+#\1REDACTED#gI' \
    -e 's#(bearer[[:space:]]+)[A-Za-z0-9._~+/-]{8,}=*#\1REDACTED#gI' \
    -e 's#((private[_ -]?key|api[_ -]?key|apikey|password|passwd|token|secret|client[_ -]?secret|authorization|database[_ -]?url)[[:space:]]*[=:][[:space:]]*)"[^"]*"#\1"REDACTED"#gI' \
    -e "s#((private[_ -]?key|api[_ -]?key|apikey|password|passwd|token|secret|client[_ -]?secret|authorization|database[_ -]?url)[[:space:]]*[=:][[:space:]]*)'[^']*'#\\1'REDACTED'#gI" \
    -e 's#((private[_ -]?key|api[_ -]?key|apikey|password|passwd|token|secret|client[_ -]?secret|authorization|database[_ -]?url)[[:space:]]*[=:][[:space:]]*)[^,;[:space:]}]+#\1REDACTED#gI' \
    -e 's#("(private[_ -]?key|api[_ -]?key|apikey|password|passwd|token|secret|client[_ -]?secret|authorization|database[_ -]?url)"[[:space:]]*:[[:space:]]*)"[^"]*"#\1"REDACTED"#gI' \
    -e 's#([?&](token|key|secret|password|auth|apikey|api_key)=)[^&[:space:]]+#\1REDACTED#gI' \
    -e 's#([A-Za-z][A-Za-z0-9+.-]*://)[^/@[:space:]]+:[^/@[:space:]]+@#\1REDACTED:REDACTED@#g' \
    -e 's#(gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|xox[baprs]-[A-Za-z0-9-]{10,}|sk-[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16})#REDACTED_TOKEN#g' \
    -e 's#(^|[^A-Za-z0-9_-])([A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,})#\1REDACTED_JWT#g'
}

report_firewall_evidence() {
  local ufw_line nft_metrics
  if command -v ufw >/dev/null 2>&1; then
    ufw_line="$(ufw status 2>/dev/null | sed -n '1p' || true)"
    case "$ufw_line" in
      "Status: active") printf 'firewall_ufw_status=active\n' ;;
      "Status: inactive") printf 'firewall_ufw_status=inactive\n' ;;
      "") printf 'firewall_ufw_status=unavailable\n' ;;
      *) printf 'firewall_ufw_status=unparsed\n' ;;
    esac
  else
    printf 'firewall_ufw_status=unsupported\n'
  fi

  if command -v nft >/dev/null 2>&1 && \
     nft_metrics="$(nft list ruleset 2>/dev/null | awk '
       /^[[:space:]]*table[[:space:]]/ { tables++ }
       /^[[:space:]]*chain[[:space:]]/ { chains++ }
       /^[[:space:]]*(ip|ip6|tcp|udp|icmp|icmpv6|ct|meta|iif|oif|counter|accept|drop|reject|jump|goto)[[:space:]]/ { rules++ }
       END {
         printf "firewall_nft_table_count=%d\n", tables+0
         printf "firewall_nft_chain_count=%d\n", chains+0
         printf "firewall_nft_rule_line_count=%d\n", rules+0
       }
     ')"; then
    printf 'firewall_nft_status=available\n%s\n' "$nft_metrics"
  elif command -v nft >/dev/null 2>&1; then
    printf 'firewall_nft_status=unavailable\nfirewall_nft_table_count=unavailable\nfirewall_nft_chain_count=unavailable\nfirewall_nft_rule_line_count=unavailable\n'
  else
    printf 'firewall_nft_status=unsupported\nfirewall_nft_table_count=unavailable\nfirewall_nft_chain_count=unavailable\nfirewall_nft_rule_line_count=unavailable\n'
  fi
}

report_memory_evidence() {
  local oom_count=unavailable
  free -h 2>/dev/null || true
  if command -v journalctl >/dev/null 2>&1; then
    oom_count="$(journalctl -k --since '24 hours ago' --no-pager -o cat 2>/dev/null \
      | grep -Eic 'out of memory|oom-killer|killed process' || true)"
  fi
  [[ "$oom_count" =~ ^[0-9]+$ ]] || oom_count=unavailable
  printf 'memory_oom_event_count_24h=%s\n' "$oom_count"
}

report_restarting_service_evidence() {
  local failed_count=unavailable restart_events=unavailable
  if command -v systemctl >/dev/null 2>&1; then
    failed_count="$(systemctl list-units --type=service --state=activating,failed \
      --no-legend --plain --no-pager 2>/dev/null | awk 'NF { count++ } END { print count+0 }' || true)"
  fi
  if command -v journalctl >/dev/null 2>&1; then
    restart_events="$(journalctl --since '24 hours ago' --no-pager -o cat 2>/dev/null \
      | grep -Eic 'start request repeated too quickly|failed with result|main process exited|scheduled restart job|restart counter is at' || true)"
  fi
  [[ "$failed_count" =~ ^[0-9]+$ ]] || failed_count=unavailable
  [[ "$restart_events" =~ ^[0-9]+$ ]] || restart_events=unavailable
  printf 'restarting_service_unit_count=%s\n' "$failed_count"
  printf 'service_failure_or_restart_events_24h=%s\n' "$restart_events"
}

report_virtualization_evidence() {
  local virtualization=unavailable
  if command -v systemd-detect-virt >/dev/null 2>&1; then
    virtualization="$(systemd-detect-virt 2>/dev/null || true)"
  fi
  [[ "$virtualization" =~ ^[A-Za-z0-9._+-]+$ ]] || virtualization=unavailable
  printf 'virtualization=%s\n' "$virtualization"
}

report_system_journal_evidence() {
  local metrics
  if command -v journalctl >/dev/null 2>&1 && \
     metrics="$(journalctl -p err --since '24 hours ago' --no-pager -o cat 2>/dev/null | awk '
       NF {
         line=tolower($0)
         records++
         if (line ~ /out of memory|oom-killer|killed process/) oom++
         if (line ~ /i\/o error|filesystem error|ext4-fs error|xfs.*error|blk_update_request/) storage++
         if (line ~ /segfault|general protection fault/) crash++
         if (line ~ /start request repeated too quickly|failed with result|main process exited/) service++
       }
       END {
         printf "system_error_records_24h=%d\n", records+0
         printf "system_error_oom_events_24h=%d\n", oom+0
         printf "system_error_storage_events_24h=%d\n", storage+0
         printf "system_error_crash_events_24h=%d\n", crash+0
         printf "system_error_service_events_24h=%d\n", service+0
       }
     ')"; then
    printf 'system_error_evidence_status=available\n%s\n' "$metrics"
  else
    printf 'system_error_evidence_status=unavailable\nsystem_error_records_24h=unavailable\nsystem_error_oom_events_24h=unavailable\nsystem_error_storage_events_24h=unavailable\nsystem_error_crash_events_24h=unavailable\nsystem_error_service_events_24h=unavailable\n'
  fi
}

report_kernel_journal_evidence() {
  local metrics
  if command -v journalctl >/dev/null 2>&1 && \
     metrics="$(journalctl -k -p warning --since '24 hours ago' --no-pager -o cat 2>/dev/null | awk '
       NF {
         line=tolower($0)
         records++
         if (line ~ /out of memory|oom-killer|killed process/) oom++
         if (line ~ /i\/o error|filesystem error|ext4-fs error|xfs.*error|blk_update_request/) storage++
         if (line ~ /link is down|watchdog|netdev watchdog|transmit queue/) network++
         if (line ~ /segfault|general protection fault|kernel bug|kernel panic/) crash++
       }
       END {
         printf "kernel_warning_records_24h=%d\n", records+0
         printf "kernel_warning_oom_events_24h=%d\n", oom+0
         printf "kernel_warning_storage_events_24h=%d\n", storage+0
         printf "kernel_warning_network_events_24h=%d\n", network+0
         printf "kernel_warning_crash_events_24h=%d\n", crash+0
       }
     ')"; then
    printf 'kernel_warning_evidence_status=available\n%s\n' "$metrics"
  else
    printf 'kernel_warning_evidence_status=unavailable\nkernel_warning_records_24h=unavailable\nkernel_warning_oom_events_24h=unavailable\nkernel_warning_storage_events_24h=unavailable\nkernel_warning_network_events_24h=unavailable\nkernel_warning_crash_events_24h=unavailable\n'
  fi
}

report_security_baseline() {
  sysctl net.ipv4.ip_forward net.ipv4.conf.all.rp_filter net.ipv4.tcp_syncookies 2>/dev/null || true
  if command -v sshd >/dev/null 2>&1; then
    sshd -T 2>/dev/null | awk '
      $1=="permitrootlogin" || $1=="passwordauthentication" || $1=="pubkeyauthentication" {
        printf "ssh_%s=%s\n", $1, $2
      }
    '
  else
    printf 'ssh_effective_configuration_status=unavailable\n'
  fi
}

# Server Toolkit "Sonar" terminal presentation primitives.
# This module renders already-computed data only. It must not inspect the
# system, classify diagnostics, or alter machine-readable report contracts.
# shellcheck shell=bash

SONAR_MIN_WIDTH=34
SONAR_MAX_WIDTH=72
SONAR_LAYOUT_THRESHOLD=52
SONAR_COLUMNS=80
SONAR_WIDTH=56
SONAR_UNICODE=1
SONAR_COLOR=0
SONAR_UTF8_LOCALE=C
SONAR_SCREEN_ACTIVE=0
SONAR_PRESENTATION_READY=0
SONAR_RESTORE_IN_PROGRESS=0
SONAR_HEARTBEAT_DISABLED_FILE=""
SONAR_RENDER_LOCK_DIR=""
SONAR_RENDER_LOCK_OWNED=0
SONAR_RENDER_LOCK_DEPTH=0
SONAR_ACTIVE_GROUP=-1
SONAR_STARTED_AT=0
SONAR_LAST_TICK=0
SONAR_LAST_DONE=0
SONAR_LAST_TOTAL=29
SONAR_HOST=""

SONAR_AUDIT_ROWS=(
  "Сервер и система"
  "Процессор"
  "Память"
  "Диски"
  "Сеть и маршруты"
  "Обновления"
  "Службы"
  "Безопасность"
  "Отчёт"
)
# shellcheck disable=SC2034 # retained for the presentation group metadata contract
SONAR_GROUP_TOTALS=(3 2 1 1 9 3 4 3 3)
SONAR_GROUP_DONE=(0 0 0 0 0 0 0 0 0)
SONAR_GROUP_VALUES=("" "" "" "" "" "" "" "" "")
SONAR_GROUP_STATES=("" "" "" "" "" "" "" "" "")

sonar_repeat() {
  local glyph="$1" count="$2" result="" i
  (( count < 0 )) && count=0
  for ((i=0; i<count; i++)); do result="${result}${glyph}"; done
  printf '%s' "$result"
}

sonar_configure_symbols() {
  if (( SONAR_UNICODE == 1 )); then
    SONAR_TL='┌'; SONAR_H='─'; SONAR_TR='┐'; SONAR_V='│'
    SONAR_BL='└'; SONAR_BR='┘'; SONAR_ML='├'; SONAR_MR='┤'
    SONAR_BAR_LEFT='◄'; SONAR_BAR_RIGHT='►'
    SONAR_BAR_FULL='▓'; SONAR_BAR_EMPTY='░'
    SONAR_ELLIPSIS='…'; SONAR_POINTER='▸'
  else
    SONAR_TL='+'; SONAR_H='-'; SONAR_TR='+'; SONAR_V='|'
    SONAR_BL='+'; SONAR_BR='+'; SONAR_ML='+'; SONAR_MR='+'
    SONAR_BAR_LEFT='<'; SONAR_BAR_RIGHT='>'
    SONAR_BAR_FULL='#'; SONAR_BAR_EMPTY='.'
    SONAR_ELLIPSIS='>'; SONAR_POINTER='>'
  fi
}

sonar_runtime_configure() {
  local run_dir="$1"
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
  [[ "$run_dir" == /* && "$run_dir" != *$'\n'* &&
     -d "$run_dir" && ! -L "$run_dir" ]] || return 2
  SONAR_HEARTBEAT_DISABLED_FILE="$run_dir/.sonar-heartbeat-disabled"
  SONAR_RENDER_LOCK_DIR="$run_dir/.sonar-render-lock"
  if [[ ! -e "$SONAR_HEARTBEAT_DISABLED_FILE" &&
        ! -L "$SONAR_HEARTBEAT_DISABLED_FILE" &&
        ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]; then
    return 0
  fi
  SONAR_HEARTBEAT_DISABLED_FILE=""
  SONAR_RENDER_LOCK_DIR=""
  return 2
}

sonar_render_lock_acquire() {
  local attempt
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || return 0
  if (( SONAR_RENDER_LOCK_OWNED == 1 )); then
    SONAR_RENDER_LOCK_DEPTH=$((SONAR_RENDER_LOCK_DEPTH+1))
    return 0
  fi
  for ((attempt=0; attempt<200; attempt++)); do
    if /bin/mkdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null; then
      SONAR_RENDER_LOCK_OWNED=1
      SONAR_RENDER_LOCK_DEPTH=1
      return 0
    fi
    if [[ ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]; then
      # The current owner can release between our failed mkdir and inspection.
      # That is ordinary contention, not an unsafe path type; retry boundedly.
      /bin/sleep 0.01
      continue
    fi
    [[ -d "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]] ||
      return 2
    /bin/sleep 0.01
  done
  return 2
}

sonar_render_lock_release() {
  (( SONAR_RENDER_LOCK_OWNED == 1 )) || return 0
  if (( SONAR_RENDER_LOCK_DEPTH > 1 )); then
    SONAR_RENDER_LOCK_DEPTH=$((SONAR_RENDER_LOCK_DEPTH-1))
    return 0
  fi
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || {
    SONAR_RENDER_LOCK_OWNED=0
    SONAR_RENDER_LOCK_DEPTH=0
    return 2
  }
  /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null || return 2
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
}

sonar_render_lock_exit_release() {
  (( SONAR_RENDER_LOCK_OWNED == 1 )) || return 0
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || return 2
  /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null || return 2
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
}

sonar_recover_stale_render_lock() {
  (( SONAR_RENDER_LOCK_OWNED == 0 && SONAR_RENDER_LOCK_DEPTH == 0 )) || return 2
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || return 0
  if [[ ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]; then
    return 0
  fi
  [[ -d "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]] ||
    return 2
  # Only an empty lock directory is recoverable. This is called exclusively
  # after the heartbeat identity has been verified and its death proven. A
  # concurrent owner-aware EXIT unlock may win the rmdir race; absence is the
  # same safe end state.
  if /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null; then
    return 0
  fi
  [[ ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]
}

sonar_disable_heartbeat_updates() {
  [[ -n "$SONAR_HEARTBEAT_DISABLED_FILE" ]] || return 2
  if [[ -e "$SONAR_HEARTBEAT_DISABLED_FILE" ||
        -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]; then
    [[ -f "$SONAR_HEARTBEAT_DISABLED_FILE" &&
       ! -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]
    return
  fi
  (umask 077; set -o noclobber; : >"$SONAR_HEARTBEAT_DISABLED_FILE") \
    2>/dev/null || return 2
  [[ -f "$SONAR_HEARTBEAT_DISABLED_FILE" &&
     ! -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]
}

sonar_heartbeat_updates_disabled() {
  [[ -n "$SONAR_HEARTBEAT_DISABLED_FILE" ]] || return 1
  [[ -e "$SONAR_HEARTBEAT_DISABLED_FILE" ||
     -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]
}

sonar_runtime_cleanup() {
  local rc=0
  if (( SONAR_RENDER_LOCK_OWNED == 1 )); then
    sonar_render_lock_exit_release || rc=2
  fi
  if [[ -n "$SONAR_HEARTBEAT_DISABLED_FILE" ]]; then
    /bin/rm -f -- "$SONAR_HEARTBEAT_DISABLED_FILE" 2>/dev/null || rc=2
  fi
  if [[ -n "$SONAR_RENDER_LOCK_DIR" &&
        ( -e "$SONAR_RENDER_LOCK_DIR" || -L "$SONAR_RENDER_LOCK_DIR" ) ]]; then
    /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null || rc=2
  fi
  SONAR_HEARTBEAT_DISABLED_FILE=""
  SONAR_RENDER_LOCK_DIR=""
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
  return "$rc"
}

sonar_set_width() {
  local columns="$1"
  [[ "$columns" =~ ^[0-9]+$ ]] || columns=80
  # shellcheck disable=SC2034 # retained for the shared presentation state contract
  SONAR_COLUMNS="$columns"
  if (( columns < SONAR_MIN_WIDTH )); then
    SONAR_WIDTH="$SONAR_MIN_WIDTH"
    return 1
  fi
  SONAR_WIDTH="$columns"
  (( SONAR_WIDTH > SONAR_MAX_WIDTH )) && SONAR_WIDTH="$SONAR_MAX_WIDTH"
  return 0
}

sonar_text_length() {
  local text="$1"
  local LC_ALL="$SONAR_UTF8_LOCALE"
  printf '%s' "${#text}"
}

sonar_truncate() {
  local text="$1" width="$2" length
  local LC_ALL="$SONAR_UTF8_LOCALE"
  (( width > 0 )) || return 0
  length="${#text}"
  if (( length <= width )); then
    printf '%s' "$text"
  elif (( width == 1 )); then
    printf '%s' "$SONAR_ELLIPSIS"
  else
    printf '%s%s' "${text:0:width-1}" "$SONAR_ELLIPSIS"
  fi
}

sonar_fit() {
  local text="$1" width="$2" fitted length
  local LC_ALL="$SONAR_UTF8_LOCALE"
  fitted="$(sonar_truncate "$text" "$width")"
  length="${#fitted}"
  printf '%s' "$fitted"
  sonar_repeat ' ' $((width-length))
}

sonar_colour() {
  local role="$1"
  (( SONAR_COLOR == 1 )) || return 0
  case "$role" in
    background) printf '\033[48;2;10;14;8m' ;;
    primary) printf '\033[38;2;159;191;127m' ;;
    muted) printf '\033[38;2;74;92;54m' ;;
    active) printf '\033[38;2;232;255;192m' ;;
    attention) printf '\033[38;2;255;200;74m' ;;
    failure) printf '\033[1;38;2;255;122;82m' ;;
    reset) printf '\033[0m' ;;
  esac
}

sonar_state_role() {
  case "$1" in
    внимание) printf 'attention' ;;
    СБОЙ) printf 'failure' ;;
    ок|"нет данных"|"") printf 'muted' ;;
    *) printf 'active' ;;
  esac
}

sonar_state_is_valid() {
  case "$1" in
    ""|ок|внимание|СБОЙ|"нет данных") return 0 ;;
    *) return 1 ;;
  esac
}

sonar_spinner_glyph() {
  local tick="$1"
  local -a unicode_spinner=('/' '|' '\\' '|')
  local -a ascii_spinner=('/' '|' '\\' '|')
  if (( SONAR_UNICODE == 1 )); then
    printf '%s' "${unicode_spinner[$((tick % 4))]}"
  else
    printf '%s' "${ascii_spinner[$((tick % 4))]}"
  fi
}

sonar_frame_top() {
  local title="$1" available title_length fill
  available=$((SONAR_WIDTH-5))
  title="$(sonar_truncate "$title" "$available")"
  title_length="$(sonar_text_length "$title")"
  fill=$((SONAR_WIDTH-title_length-5))
  printf '%s%s%s%s %s %s%s%s%s\n' \
    "$(sonar_colour primary)" "$SONAR_TL" "$SONAR_H" \
    "$(sonar_colour reset)$(sonar_colour primary)" "$title" \
    "$(sonar_repeat "$SONAR_H" "$fill")" "$SONAR_TR" \
    "$(sonar_colour reset)" ""
}

sonar_frame_bottom() {
  printf '%s%s%s%s%s\n' "$(sonar_colour primary)" "$SONAR_BL" \
    "$(sonar_repeat "$SONAR_H" $((SONAR_WIDTH-2)))" "$SONAR_BR" \
    "$(sonar_colour reset)"
}

sonar_separator() {
  printf '%s%s%s%s%s\n' "$(sonar_colour primary)" "$SONAR_ML" \
    "$(sonar_repeat "$SONAR_H" $((SONAR_WIDTH-2)))" "$SONAR_MR" \
    "$(sonar_colour reset)"
}

sonar_box_text() {
  local text="$1" role="${2:-primary}" content
  content="$(sonar_fit "$text" $((SONAR_WIDTH-4)))"
  printf '%s%s%s %s%s%s %s%s%s\n' \
    "$(sonar_colour primary)" "$SONAR_V" "$(sonar_colour reset)" \
    "$(sonar_colour "$role")" "$content" "$(sonar_colour reset)" \
    "$(sonar_colour primary)" "$SONAR_V" "$(sonar_colour reset)"
}

sonar_blank() {
  sonar_box_text "" primary
}

sonar_progress_text() {
  local done="$1" total="$2" elapsed="$3" suffix bar_width filled empty
  local clock minutes seconds
  [[ "$done" =~ ^[0-9]+$ ]] || done=0
  [[ "$total" =~ ^[1-9][0-9]*$ ]] || total=1
  (( done > total )) && done="$total"
  [[ "$elapsed" =~ ^[0-9]+$ ]] || elapsed=0
  (( elapsed > 5999 )) && elapsed=5999
  minutes=$((elapsed/60)); seconds=$((elapsed%60))
  printf -v clock '%02d:%02d' "$minutes" "$seconds"
  suffix="  ${done}/${total}   ${clock}"
  bar_width=$((SONAR_WIDTH-6-${#suffix}))
  (( bar_width < 1 )) && bar_width=1
  filled=$((bar_width*done/total)); empty=$((bar_width-filled))
  printf '%s%s%s%s%s%s%s%s%s%s' \
    "$(sonar_colour primary)" "$SONAR_V " "$SONAR_BAR_LEFT" \
    "$(sonar_repeat "$SONAR_BAR_FULL" "$filled")" \
    "$(sonar_colour muted)" "$(sonar_repeat "$SONAR_BAR_EMPTY" "$empty")" \
    "$(sonar_colour primary)" "$SONAR_BAR_RIGHT" "$suffix" \
    "$(sonar_fit '' $((SONAR_WIDTH-3-bar_width-2-${#suffix})))${SONAR_V}$(sonar_colour reset)"
}

sonar_render_progress() {
  sonar_progress_text "$@"
  printf '\n'
}

sonar_name_parts() {
  local name="$1" width="$2" length dots
  local LC_ALL="$SONAR_UTF8_LOCALE"
  SONAR_NAME_LABEL=""
  SONAR_NAME_DOTS=""
  length="${#name}"
  if (( length >= width-1 )); then
    SONAR_NAME_LABEL="$(sonar_truncate "$name" "$width")"
    return 0
  fi
  dots=$((width-length-1))
  SONAR_NAME_LABEL="${name} "
  SONAR_NAME_DOTS="$(sonar_repeat '.' "$dots")"
}

sonar_render_check() {
  local name="$1" value="$2" state="$3" active="${4:-0}"
  local name_width value_field state_field state_role
  if (( active == 1 )); then
    state="$(sonar_spinner_glyph "$SONAR_LAST_TICK")"
    state_role=active
  else
    sonar_state_is_valid "$state" || return 2
    state_role="$(sonar_state_role "$state")"
  fi
  if (( SONAR_WIDTH >= SONAR_LAYOUT_THRESHOLD )); then
    name_width=$((SONAR_WIDTH-28))
  else
    name_width=$((SONAR_WIDTH-15))
  fi
  sonar_name_parts "$name" "$name_width"
  state_field="$(sonar_fit "$state" 10)"
  printf '%s%s%s %s%s%s%s%s' \
    "$(sonar_colour primary)" "$SONAR_V" "$(sonar_colour reset)" \
    "$(sonar_colour primary)" "$SONAR_NAME_LABEL" \
    "$(sonar_colour muted)" "$SONAR_NAME_DOTS" "$(sonar_colour reset)"
  if (( SONAR_WIDTH >= SONAR_LAYOUT_THRESHOLD )); then
    value_field="$(sonar_fit "$value" 12)"
    printf ' %s%s%s ' "$(sonar_colour primary)" "$value_field" "$(sonar_colour reset)"
  else
    printf ' '
  fi
  printf '%s%s%s %s%s%s\n' "$(sonar_colour "$state_role")" "$state_field" \
    "$(sonar_colour reset)" "$(sonar_colour primary)" "$SONAR_V" \
    "$(sonar_colour reset)"
}

sonar_render_footer() {
  sonar_box_text "$1" "${2:-muted}"
}

sonar_render_input() {
  sonar_box_text "$1 ${SONAR_POINTER} _" active
}

sonar_render_menu() {
  local version="${1:-v0.4.1}"
  sonar_frame_top "SERVER TOOLKIT · ${version}"
  sonar_blank
  sonar_box_text "  [1] Полный аудит"
  sonar_box_text "  [2] Быстрая проверка"
  sonar_box_text "  [3] Последний отчёт"
  sonar_blank
  sonar_box_text "  [0] Выход"
  sonar_blank
  sonar_separator
  sonar_render_input "ВЫБОР"
  sonar_frame_bottom
}

sonar_render_self_check() {
  local outcome="$1" admin_value="$2" admin_state="$3"
  local commands_value="$4" commands_state="$5"
  local space_value="$6" space_state="$7"
  local terminal_value="$8" terminal_state="$9"
  local footer1="${10}" footer2="${11:-}"
  case "$outcome" in
    ready|no-admin|missing-command) ;;
    *) return 2 ;;
  esac
  sonar_state_is_valid "$admin_state" || return 2
  sonar_state_is_valid "$commands_state" || return 2
  sonar_state_is_valid "$space_state" || return 2
  sonar_state_is_valid "$terminal_state" || return 2
  sonar_frame_top 'SERVER TOOLKIT · САМОПРОВЕРКА'
  sonar_blank
  sonar_render_check 'Права администратора' "$admin_value" "$admin_state"
  sonar_render_check 'Требуемые команды' "$commands_value" "$commands_state"
  sonar_render_check 'Место для отчёта' "$space_value" "$space_state"
  sonar_render_check 'Терминал' "$terminal_value" "$terminal_state"
  sonar_blank
  sonar_separator
  sonar_render_footer "$footer1"
  [[ -z "$footer2" ]] || sonar_render_footer "$footer2"
  sonar_frame_bottom
}

sonar_reset_audit_state() {
  SONAR_GROUP_DONE=(0 0 0 0 0 0 0 0 0)
  SONAR_GROUP_VALUES=("" "" "" "" "" "" "" "" "")
  SONAR_GROUP_STATES=("" "" "" "" "" "" "" "")
  SONAR_ACTIVE_GROUP=-1
  SONAR_LAST_TICK=0
}

sonar_group_for_stage() {
  case "$1" in
    'Сервер и система'|'Подробности системы'|'Время работы') printf '0' ;;
    'Процессор'|'Нагрузка процессора') printf '1' ;;
    'Память') printf '2' ;;
    'Диски') printf '3' ;;
    'Сетевые интерфейсы'|'Внешний адрес'|'DNS'|'Сетевые порты'|'Анализ портов'|'Межсетевой экран'|'Системное время'|'Задержка сети'|'Скорость доступа') printf '4' ;;
    'Индекс пакетов'|'Состояние пакетов'|'Проверка обновления') printf '5' ;;
    'Состояние служб'|'Повторные сбои служб'|'Системные ошибки'|'Предупреждения ядра') printf '6' ;;
    'Базовая безопасность'|'Виртуализация'|'Внешний шум SSH') printf '7' ;;
    *) printf '8' ;;
  esac
}

sonar_begin_stage() {
  SONAR_ACTIVE_GROUP="$(sonar_group_for_stage "$1")"
}

sonar_finish_stage() {
  local stage="$1" outcome="$2" group
  : "$outcome"
  group="$(sonar_group_for_stage "$stage")"
  SONAR_GROUP_DONE[$group]=$(( ${SONAR_GROUP_DONE[$group]:-0} + 1 ))
  SONAR_ACTIVE_GROUP=-1
}

sonar_render_audit() {
  local host="${1:-}" done="${2:-0}" total="${3:-29}" elapsed="${4:-0}"
  local active="${5:--1}" tick="${6:-0}" index
  SONAR_LAST_TICK="$tick"
  sonar_frame_top "SERVER TOOLKIT · АУДИТ${host:+ · $host}"
  sonar_render_progress "$done" "$total" "$elapsed"
  sonar_blank
  for ((index=0; index<${#SONAR_AUDIT_ROWS[@]}; index++)); do
    if (( index == active )); then
      sonar_render_check "${SONAR_AUDIT_ROWS[$index]}" "${SONAR_GROUP_VALUES[$index]:-}" "" 1
    else
      sonar_render_check "${SONAR_AUDIT_ROWS[$index]}" "${SONAR_GROUP_VALUES[$index]:-}" "${SONAR_GROUP_STATES[$index]:-}"
    fi
  done
  sonar_frame_bottom
}

sonar_result_collect_rows() {
  local encoded name value state target count=0
  shift 8
  SONAR_RESULT_ROWS=()
  for target in СБОЙ внимание 'нет данных'; do
    for encoded in "$@"; do
      name="${encoded%%|*}"
      value="${encoded#*|}"; value="${value%%|*}"
      state="${encoded##*|}"
      [[ "$state" == "$target" ]] || continue
      SONAR_RESULT_ROWS[$count]="${name}|${value}|${state}"
      count=$((count+1))
      (( count >= 5 )) && return 0
    done
  done
}

sonar_render_result() {
  local host="$1" done="$2" total="$3" elapsed="$4" report_path="$5"
  local failures="$6" warnings="$7" missing="$8"
  local encoded name value state
  shift 8
  sonar_result_collect_rows "$host" "$done" "$total" "$elapsed" "$report_path" "$failures" "$warnings" "$missing" "$@"
  sonar_frame_top "SERVER TOOLKIT · РЕЗУЛЬТАТ${host:+ · $host}"
  sonar_render_progress "$done" "$total" "$elapsed"
  sonar_blank
  for encoded in "${SONAR_RESULT_ROWS[@]}"; do
    name="${encoded%%|*}"
    value="${encoded#*|}"; value="${value%%|*}"
    state="${encoded##*|}"
    sonar_render_check "$name" "$value" "$state"
  done
  (( ${#SONAR_RESULT_ROWS[@]} > 0 )) || sonar_blank
  sonar_separator
  sonar_render_footer "Проверено ${done} из ${total} · сбой ${failures} · внимание ${warnings} · нет данных ${missing}"
  sonar_render_footer "Отчёт ${SONAR_POINTER} ${report_path}"
  sonar_frame_bottom
}

sonar_elapsed_seconds() {
  local now elapsed
  if ! [[ "$SONAR_STARTED_AT" =~ ^[1-9][0-9]*$ ]]; then
    printf '0'
    return 0
  fi
  now="$(date +%s)"
  elapsed=$((now-SONAR_STARTED_AT))
  (( elapsed < 0 )) && elapsed=0
  printf '%s' "$elapsed"
}

sonar_stdout_is_tty() {
  [[ -t 1 ]]
}

sonar_presentation_ready_for_result() {
  (( SONAR_PRESENTATION_READY == 1 )) || return 1
  (( PROGRESS_INTERACTIVE == 1 )) || return 1
  [[ "$SONAR_STARTED_AT" =~ ^[1-9][0-9]*$ ]] || return 1
  case "${PROGRESS_MODE:-off}" in
    off|plain) return 1 ;;
  esac
  sonar_heartbeat_updates_disabled && return 1
  sonar_stdout_is_tty
}

sonar_render_result_if_tty() {
  local columns
  sonar_presentation_ready_for_result || return 0
  if [[ "${PROGRESS_PRESENTATION_INPUT_VALIDATED:-0}" != 1 && "${TERM:-dumb}" == dumb ]]; then
    return 0
  fi
  columns="$(progress_terminal_columns)"
  sonar_set_width "$columns" || return 0
  sonar_configure_symbols
  sonar_render_result "$@"
}

sonar_summary_value_once() {
  local file="$1" key="$2"
  awk -F= -v key="$key" '
    $1==key { count++; value=substr($0,index($0,"=")+1) }
    END { if(count!=1) exit 1; print value }
  ' "$file"
}

sonar_render_summary_result_if_tty() {
  local summary="$1" host="$2" done="$3" total="$4" elapsed="$5" report_path="$6"
  local findings rank code verdict observed unit state failures=0 warnings=0 missing=0
  local -a rows=()
  sonar_presentation_ready_for_result || return 0
  findings="$(sonar_summary_value_once "$summary" findings_total)" || return 2
  [[ "$findings" =~ ^[0-9]+$ ]] || return 2
  (( findings <= 256 )) || return 2
  for ((rank=1; rank<=findings; rank++)); do
    code="$(sonar_summary_value_once "$summary" "finding_${rank}_code")" || return 2
    verdict="$(sonar_summary_value_once "$summary" "finding_${rank}_verdict")" || return 2
    observed="$(sonar_summary_value_once "$summary" "finding_${rank}_observed_value")" || return 2
    unit="$(sonar_summary_value_once "$summary" "finding_${rank}_unit")" || return 2
    case "$code" in
      *INCOMPLETE*|*UNAVAILABLE*|DIAGNOSTIC_EVIDENCE_LIMITED)
        state='нет данных'; missing=$((missing+1))
        ;;
      *)
        case "$verdict" in
          FAIL) state=СБОЙ; failures=$((failures+1)) ;;
          WARN) state=внимание; warnings=$((warnings+1)) ;;
          PASS) state=ок ;;
          *) state='нет данных'; missing=$((missing+1)) ;;
        esac
        ;;
    esac
    code="${code//|/ }"
    observed="${observed//|/ }"; unit="${unit//|/ }"
    rows[${#rows[@]}]="${code}|${observed}${unit:+ ${unit}}|${state}"
  done
  if (( ${#rows[@]} > 0 )); then
    sonar_render_result_if_tty "$host" "$done" "$total" "$elapsed" "$report_path" \
      "$failures" "$warnings" "$missing" "${rows[@]}"
  else
    sonar_render_result_if_tty "$host" "$done" "$total" "$elapsed" "$report_path" \
      "$failures" "$warnings" "$missing"
  fi
}

sonar_render_quick() {
  local done="$1" elapsed="$2" active="$3" tick="$4" footer1="$5" footer2="$6"
  local index encoded name value state
  local -a rows=()
  shift 6
  rows=("$@")
  SONAR_LAST_TICK="$tick"
  sonar_frame_top 'SERVER TOOLKIT · БЫСТРАЯ ПРОВЕРКА'
  sonar_render_progress "$done" 4 "$elapsed"
  sonar_blank
  for ((index=0; index<4; index++)); do
    encoded="${rows[$index]:-||}"
    name="${encoded%%|*}"
    value="${encoded#*|}"; value="${value%%|*}"
    state="${encoded##*|}"
    if (( index == active )); then
      sonar_render_check "$name" "$value" "" 1
    else
      sonar_render_check "$name" "$value" "$state"
    fi
  done
  sonar_blank; sonar_blank; sonar_blank; sonar_blank; sonar_blank
  sonar_separator
  sonar_render_footer "$footer1"
  sonar_render_footer "$footer2"
  sonar_frame_bottom
}

sonar_render_quick_result() {
  local done="$1" total="$2" elapsed="$3" footer1="$4" footer2="$5"
  local encoded name value state
  shift 5
  sonar_frame_top 'SERVER TOOLKIT · БЫСТРАЯ ПРОВЕРКА · ИТОГ'
  sonar_render_progress "$done" "$total" "$elapsed"
  sonar_blank
  for encoded in "$@"; do
    name="${encoded%%|*}"
    value="${encoded#*|}"; value="${value%%|*}"
    state="${encoded##*|}"
    [[ "$state" == ок ]] || sonar_render_check "$name" "$value" "$state"
  done
  sonar_blank; sonar_blank; sonar_blank; sonar_blank; sonar_blank
  sonar_separator
  sonar_render_footer "$footer1"
  sonar_render_footer "$footer2"
  sonar_frame_bottom
}

sonar_semantic_row() {
  local key="$1"
  case "$key" in
    progress) printf '2' ;;
    check:*) printf '%s' $((4+${key#check:})) ;;
    bottom) printf '%s' $((4+${#SONAR_AUDIT_ROWS[@]})) ;;
    *) return 2 ;;
  esac
}

sonar_semantic_column() {
  local key="$1" name_width
  case "$key" in
    line) printf '1' ;;
    state)
      if (( SONAR_WIDTH >= SONAR_LAYOUT_THRESHOLD )); then
        name_width=$((SONAR_WIDTH-28)); printf '%s' $((name_width+17))
      else
        name_width=$((SONAR_WIDTH-15)); printf '%s' $((name_width+4))
      fi
      ;;
    *) return 2 ;;
  esac
}

# This is the renderer's only absolute cursor-addressing primitive. Callers use
# semantic rows/columns and never perform relative cursor-up arithmetic.
sonar_put_at() {
  local row="$1" column="$2" text="$3"
  (( SONAR_SCREEN_ACTIVE == 1 )) || return 0
  printf '\033[%s;%sH%s' "$row" "$column" "$text" >&2
}

sonar_update_progress() {
  local line row column
  SONAR_LAST_DONE="$1"
  SONAR_LAST_TOTAL="$2"
  row="$(sonar_semantic_row progress)" || return 2
  column="$(sonar_semantic_column line)" || return 2
  line="$(sonar_progress_text "$1" "$2" "$3")"
  sonar_put_at "$row" "$column" "$line"
}

sonar_update_state() {
  local group="$1" state="$2" active="${3:-0}" row column role field
  row="$(sonar_semantic_row "check:${group}")" || return 2
  column="$(sonar_semantic_column state)" || return 2
  if (( active == 1 )); then
    state="$(sonar_spinner_glyph "$SONAR_LAST_TICK")"; role=active
  else
    sonar_state_is_valid "$state" || return 2
    role="$(sonar_state_role "$state")"
  fi
  field="$(sonar_fit "$state" 10)"
  sonar_put_at "$row" "$column" "$(sonar_colour "$role")${field}$(sonar_colour reset)"
}

sonar_screen_enter() {
  local host="$1" done="$2" total="$3" started="$4" now elapsed bottom rc=0
  (( SONAR_SCREEN_ACTIVE == 0 )) || return 0
  SONAR_PRESENTATION_READY=0
  [[ "$started" =~ ^[1-9][0-9]*$ ]] || return 2
  SONAR_HOST="$host"; SONAR_STARTED_AT="$started"
  SONAR_LAST_DONE="$done"; SONAR_LAST_TOTAL="$total"
  now="$(date +%s)"; elapsed=$((now-started)); (( elapsed < 0 )) && elapsed=0
  SONAR_SCREEN_ACTIVE=1
  printf '\033[?1049h\033[?25l\033[H\033[2J%s' "$(sonar_colour background)" >&2 || rc=2
  sonar_render_audit "$host" "$done" "$total" "$elapsed" "$SONAR_ACTIVE_GROUP" 0 >&2 || rc=2
  bottom="$(sonar_semantic_row bottom)" || rc=2
  if [[ -n "$bottom" ]]; then
    printf '\033[3;%sr' "$bottom" >&2 || rc=2
  fi
  if (( rc != 0 )); then
    SONAR_PRESENTATION_READY=0
    return "$rc"
  fi
  SONAR_PRESENTATION_READY=1
}

sonar_screen_redraw() {
  local now elapsed bottom
  (( SONAR_SCREEN_ACTIVE == 1 )) || return 0
  now="$(date +%s)"; elapsed=$((now-SONAR_STARTED_AT)); (( elapsed < 0 )) && elapsed=0
  printf '\033[r\033[H\033[2J%s' "$(sonar_colour background)" >&2
  sonar_render_audit "$SONAR_HOST" "$SONAR_LAST_DONE" "$SONAR_LAST_TOTAL" "$elapsed" "$SONAR_ACTIVE_GROUP" "$SONAR_LAST_TICK" >&2
  bottom="$(sonar_semantic_row bottom)" || return 2
  printf '\033[3;%sr' "$bottom" >&2
}

sonar_screen_restore() {
  local rc=0
  trap '' WINCH
  (( SONAR_RESTORE_IN_PROGRESS == 0 )) || return 0
  SONAR_RESTORE_IN_PROGRESS=1
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    printf '\033[0m\033[r\033[?25h\033[?1049l' >&2 || rc=2
  fi
  (( rc == 0 )) || SONAR_PRESENTATION_READY=0
  SONAR_SCREEN_ACTIVE=0
  PROGRESS_CURSOR_HIDDEN=0
  SONAR_RESTORE_IN_PROGRESS=0
  return "$rc"
}

sonar_sync_width_from_terminal() {
  local columns
  columns="$(progress_terminal_columns)"
  sonar_set_width "$columns" || return 1
  sonar_configure_symbols
}

sonar_handle_winch() {
  local columns rc=0 locked=0
  (( SONAR_SCREEN_ACTIVE == 1 )) || return 0
  columns="$(progress_terminal_columns)"
  if ! sonar_set_width "$columns"; then
    PROGRESS_INTERACTIVE=0
    SONAR_PRESENTATION_READY=0
    if [[ -n "$SONAR_RENDER_LOCK_DIR" ]]; then
      sonar_render_lock_acquire || {
        SONAR_PRESENTATION_READY=0
        return 2
      }
      if ! sonar_disable_heartbeat_updates; then
        sonar_render_lock_release || true
        return 2
      fi
      sonar_screen_restore || rc=2
      sonar_render_lock_release || rc=2
    else
      sonar_screen_restore || rc=2
    fi
    return "$rc"
  fi
  if [[ -n "$SONAR_RENDER_LOCK_DIR" ]]; then
    sonar_render_lock_acquire || {
      SONAR_PRESENTATION_READY=0
      return 2
    }
    locked=1
    if sonar_heartbeat_updates_disabled; then
      PROGRESS_INTERACTIVE=0
      SONAR_PRESENTATION_READY=0
      sonar_screen_restore || rc=2
      sonar_render_lock_release || rc=2
      return "$rc"
    fi
  fi
  PROGRESS_PRESENTATION_COLUMNS="$columns"
  sonar_configure_symbols
  if ! sonar_screen_redraw; then
    SONAR_PRESENTATION_READY=0
    rc=2
  fi
  if (( locked == 1 )); then
    if ! sonar_render_lock_release; then
      SONAR_PRESENTATION_READY=0
      rc=2
    fi
  fi
  return "$rc"
}

# Server Toolkit terminal progress layer.
# This file is embedded into the standalone audit-only candidate by the builder.
# shellcheck shell=bash

PROGRESS_MODE="${SERVER_TOOLKIT_PROGRESS_MODE:-auto}"
PROGRESS_WIDTH="${SERVER_TOOLKIT_PROGRESS_WIDTH:-auto}"
PROGRESS_COLUMNS=80
PROGRESS_TOTAL_SECTIONS=26
PROGRESS_TOTAL_STAGES=29
PROGRESS_COMPLETED_SECTIONS=0
PROGRESS_COMPLETED_STAGES=0
PROGRESS_PERCENT=0
PROGRESS_STAGE="Подготовка"
PROGRESS_STAGE_STARTED=0
PROGRESS_STAGE_ACTIVE=0
PROGRESS_RUNTIME_DIR=""
PROGRESS_STATE_FILE=""
PROGRESS_HEARTBEAT_PID=""
PROGRESS_HEARTBEAT_IDENTITY=""
PROGRESS_HEARTBEAT_STARTING=0
PROGRESS_HEARTBEAT_STOP_REQUESTED=0
PROGRESS_HEARTBEAT_RESOLUTION=""
PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT=""
PROGRESS_HEARTBEAT_OBSERVATION_ERROR=""
PROGRESS_HEARTBEAT_PROTOCOL=""
PROGRESS_HEARTBEAT_GENERATION=0
PROGRESS_HEARTBEAT_GENERATION_ID=""
PROGRESS_HEARTBEAT_STOP_FILE=""
PROGRESS_HEARTBEAT_DONE_FILE=""
PROGRESS_HEARTBEAT_JOBS_A_DIR=""
PROGRESS_HEARTBEAT_JOBS_B_DIR=""
PROGRESS_HEARTBEAT_JOBS_A_FILE=""
PROGRESS_HEARTBEAT_JOBS_B_FILE=""
PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
PROGRESS_HEARTBEAT_ACK_STATUS=""
PROGRESS_ACTIVE_CHILD_PID=""
PROGRESS_ACTIVE_CHILD_IDENTITY=""
PROGRESS_CHILD_GUARD_DIR=""
PROGRESS_CHILD_GUARD_READY=""
PROGRESS_CHILD_GUARD_RELEASE=""
PROGRESS_CHILD_STARTING=0
PROGRESS_CHILD_TERMINATION_IN_PROGRESS=0
PROGRESS_CLEANUP_IN_PROGRESS=0
PROGRESS_CLEANUP_DONE=0
PROGRESS_CLEANUP_STATUS=0
PROGRESS_SIGNAL_IN_PROGRESS=0
PROGRESS_SIGNAL_REPORT_PATH="недоступен"
PROGRESS_PENDING_SIGNAL=""
PROGRESS_PENDING_SIGNAL_REPORT=""
PROGRESS_ACTIVE=0
PROGRESS_INTERACTIVE=0
PROGRESS_UNICODE=0
PROGRESS_COLOR=0
PROGRESS_SOFT_SECONDS=8
PROGRESS_UTF8_LOCALE=C
PROGRESS_CURSOR_HIDDEN=0
PROGRESS_PRESENTATION_INPUT_VALIDATED=0
PROGRESS_PRESENTATION_TTY=0
PROGRESS_PRESENTATION_COLUMNS=80
PROGRESS_PRESENTATION_UNICODE=0
PROGRESS_PRESENTATION_COLOR=0
PROGRESS_PROCESS_TREE_MAX_HOPS=256
PROGRESS_PROCESS_TREE_MAX_ROWS=4096
PROGRESS_PROCESS_TREE_MAX_TRANSITIONS=65536
# Consumed by progress_run_child's bounded callback runner. This remains
# shell-local so diagnostic children receive only the explicit environment.
CURRENT_STAGE_TIMEOUT=45

progress_terminal_columns() {
  local columns="" size=""
  if [[ -t 2 && -x /bin/stty ]]; then
    size="$(/bin/stty size <&2 2>/dev/null || true)"
    columns="${size##* }"
  elif [[ -t 2 && -x /usr/bin/stty ]]; then
    size="$(/usr/bin/stty size <&2 2>/dev/null || true)"
    columns="${size##* }"
  fi
  if ! [[ "$columns" =~ ^[0-9]+$ ]] &&
      [[ "${PROGRESS_PRESENTATION_INPUT_VALIDATED:-0}" == 1 ]]; then
    columns="${PROGRESS_PRESENTATION_COLUMNS:-}"
  fi
  [[ "$columns" =~ ^[0-9]+$ ]] || columns="${COLUMNS:-}"
  if ! [[ "$columns" =~ ^[0-9]+$ ]] && [[ -x /usr/bin/tput ]]; then
    columns="$(/usr/bin/tput cols 2>/dev/null || true)"
  fi
  [[ "$columns" =~ ^[0-9]+$ ]] || columns=80
  (( columns < 20 )) && columns=20
  (( columns > 240 )) && columns=240
  printf '%s' "$columns"
}

progress_detect_utf8_locale() {
  local candidate charmap
  for candidate in C.UTF-8 C.utf8 en_US.UTF-8; do
    charmap="$(LC_ALL="$candidate" /usr/bin/locale charmap 2>/dev/null || true)"
    [[ "$charmap" == UTF-8 ]] || continue
    if LC_ALL="$candidate" /bin/bash --noprofile --norc -p \
        -c '[[ ${#1} -eq 1 ]]' _ 'Ж' 2>/dev/null; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  printf 'C'
}

progress_locale_requests_ascii() {
  local effective_locale="${LC_ALL:-${LC_CTYPE:-${LANG:-}}}"
  case "$effective_locale" in
    C|POSIX) return 0 ;;
    *) return 1 ;;
  esac
}

progress_stderr_is_tty() {
  [[ -t 2 ]]
}

progress_capture_presentation_input() {
  # This function runs before the clean-environment reexec. Keep it strictly
  # Bash-builtin-only: inherited PATH, TERMINFO and LOCPATH must be inert.
  local columns="${COLUMNS:-80}"
  if [[ "$columns" =~ ^[0-9]{1,3}$ ]]; then
    columns=$((10#$columns))
  else
    columns=80
  fi
  (( columns < 20 )) && columns=20
  (( columns > 240 )) && columns=240
  PROGRESS_PRESENTATION_INPUT_VALIDATED=1
  PROGRESS_PRESENTATION_COLUMNS="$columns"
  PROGRESS_PRESENTATION_TTY=0
  PROGRESS_PRESENTATION_UNICODE=0
  PROGRESS_PRESENTATION_COLOR=0
  if progress_stderr_is_tty && [[ "${TERM:-dumb}" != dumb ]] &&
      (( columns >= SONAR_MIN_WIDTH )); then
    PROGRESS_PRESENTATION_TTY=1
    if ! progress_locale_requests_ascii; then
      PROGRESS_PRESENTATION_UNICODE=1
    fi
    [[ -n "${NO_COLOR:-}" ]] || PROGRESS_PRESENTATION_COLOR=1
  fi
}

progress_detect_terminal() {
  local colours=0 requested_width="$PROGRESS_WIDTH" max_width
  PROGRESS_INTERACTIVE=0
  PROGRESS_UNICODE=0
  PROGRESS_COLOR=0
  PROGRESS_COLUMNS="$(progress_terminal_columns)"
  PROGRESS_UTF8_LOCALE="$(progress_detect_utf8_locale)"
  max_width=$((PROGRESS_COLUMNS-14))
  (( max_width < 16 )) && max_width=16
  case "$PROGRESS_MODE" in
    off)
      return 1
      ;;
    plain)
      PROGRESS_INTERACTIVE=0
      ;;
    tty)
      if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
        PROGRESS_INTERACTIVE="$PROGRESS_PRESENTATION_TTY"
      else
        PROGRESS_INTERACTIVE=1
      fi
      ;;
    auto)
      if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
        PROGRESS_INTERACTIVE="$PROGRESS_PRESENTATION_TTY"
      elif progress_stderr_is_tty && [[ "${TERM:-dumb}" != dumb ]]; then
        PROGRESS_INTERACTIVE=1
      else
        PROGRESS_INTERACTIVE=0
      fi
      ;;
    *)
      printf 'Недопустимый SERVER_TOOLKIT_PROGRESS_MODE=%s; используется auto.\n' "$PROGRESS_MODE" >&2
      PROGRESS_MODE=auto
      if progress_stderr_is_tty && [[ "${TERM:-dumb}" != dumb ]]; then
        PROGRESS_INTERACTIVE=1
      else
        PROGRESS_INTERACTIVE=0
      fi
      ;;
  esac

  if [[ "$requested_width" == auto ]]; then
    PROGRESS_WIDTH=34
  elif [[ "$requested_width" =~ ^[0-9]+$ ]]; then
    PROGRESS_WIDTH="$requested_width"
  else
    printf 'Недопустимый SERVER_TOOLKIT_PROGRESS_WIDTH=%s; используется auto.\n' "$requested_width" >&2
    PROGRESS_WIDTH=34
  fi
  (( PROGRESS_WIDTH < 16 )) && PROGRESS_WIDTH=16
  (( PROGRESS_WIDTH > max_width )) && PROGRESS_WIDTH="$max_width"
  (( PROGRESS_WIDTH > 60 )) && PROGRESS_WIDTH=60

  # The active CRT row is the only mutable row. Keep it within the terminal so
  # even that one row never wraps while the spinner is being updated.
  if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" != 1 && "${TERM:-dumb}" == dumb ]]; then
    PROGRESS_INTERACTIVE=0
  fi
  if (( PROGRESS_INTERACTIVE == 1 && PROGRESS_COLUMNS < SONAR_MIN_WIDTH )); then
    PROGRESS_INTERACTIVE=0
  fi
  if (( PROGRESS_INTERACTIVE == 1 )) && [[ "$PROGRESS_UTF8_LOCALE" == C ]]; then
    PROGRESS_INTERACTIVE=0
  fi

  # The internal UTF-8 locale keeps Cyrillic geometry correct. Glyph selection
  # remains a separate caller capability, so an explicit C/POSIX locale gets
  # the ASCII symbol table without disabling the fixed-layout screen.
  if (( PROGRESS_INTERACTIVE == 1 )); then
    if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
      PROGRESS_UNICODE="$PROGRESS_PRESENTATION_UNICODE"
    elif progress_locale_requests_ascii; then
      PROGRESS_UNICODE=0
    else
      PROGRESS_UNICODE=1
    fi
  else
    PROGRESS_UNICODE=0
  fi

  if [[ "$PROGRESS_PRESENTATION_INPUT_VALIDATED" == 1 ]]; then
    PROGRESS_COLOR="$PROGRESS_PRESENTATION_COLOR"
  elif (( PROGRESS_INTERACTIVE == 1 )) && [[ -x /usr/bin/tput ]]; then
    colours="$(/usr/bin/tput colors 2>/dev/null || echo 0)"
    [[ "$colours" =~ ^[0-9]+$ ]] || colours=0
    (( colours >= 8 )) && PROGRESS_COLOR=1
  fi
  [[ -z "${NO_COLOR:-}" ]] || PROGRESS_COLOR=0
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_UTF8_LOCALE="$PROGRESS_UTF8_LOCALE"
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_UNICODE="$PROGRESS_UNICODE"
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_COLOR="$PROGRESS_COLOR"
  sonar_set_width "$PROGRESS_COLUMNS" || PROGRESS_INTERACTIVE=0
  sonar_configure_symbols
  return 0
}

progress_colour() {
  local name="$1"
  (( PROGRESS_COLOR == 1 )) || return 0
  case "$name" in
    green) sonar_colour primary ;;
    yellow) sonar_colour attention ;;
    red) sonar_colour failure ;;
    cyan) sonar_colour active ;;
    reset) printf '\033[0m' ;;
  esac
}

progress_spinner_glyph() {
  local tick="$1"
  local -a unicode_spinner=("◐" "◓" "◑" "◒")
  local -a ascii_spinner=("|" "/" "-" "\\")
  if (( PROGRESS_UNICODE == 1 )); then
    printf '%s' "${unicode_spinner[$((tick % ${#unicode_spinner[@]}))]}"
  else
    printf '%s' "${ascii_spinner[$((tick % ${#ascii_spinner[@]}))]}"
  fi
}

progress_cursor_hide() {
  if (( PROGRESS_INTERACTIVE == 1 && PROGRESS_CURSOR_HIDDEN == 0 )); then
    printf '\033[?25l' >&2
    PROGRESS_CURSOR_HIDDEN=1
  fi
}

progress_cursor_show() {
  if (( PROGRESS_CURSOR_HIDDEN == 1 )); then
    printf '\033[?25h' >&2
    PROGRESS_CURSOR_HIDDEN=0
  fi
}

progress_line_prefix() {
  local stage="$1" width="$PROGRESS_WIDTH" dots i
  local LC_ALL="$PROGRESS_UTF8_LOCALE"
  if (( PROGRESS_INTERACTIVE == 1 && ${#stage} > width-2 )); then
    stage="${stage:0:width-3}…"
  fi
  dots=$((width-${#stage}))
  (( dots < 2 )) && dots=2
  printf '%s' "$stage"
  for ((i=0; i<dots; i++)); do printf '.'; done
  printf ' '
}

progress_render_active_line() {
  local stage="$1" tick="${2:-0}" spinner reset elapsed
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    sonar_sync_width_from_terminal || return 0
    SONAR_LAST_TICK="$tick"
    elapsed="$(sonar_elapsed_seconds)"
    sonar_update_progress "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$elapsed"
    sonar_update_state "$SONAR_ACTIVE_GROUP" "" 1
    return 0
  fi
  spinner="$(progress_spinner_glyph "$tick")"
  reset="$(progress_colour reset)"
  printf '\r\033[2K' >&2
  progress_line_prefix "$stage" >&2
  printf '%s%s%s' "$(progress_colour cyan)" "$spinner" "$reset" >&2
}

progress_render_spinner_tick() {
  local tick="$1" slow="$2" colour=cyan spinner reset elapsed rc=0
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    sonar_render_lock_acquire || return 0
    if sonar_heartbeat_updates_disabled; then
      sonar_render_lock_release || return 2
      PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      return 0
    fi
    if ! sonar_sync_width_from_terminal; then
      sonar_disable_heartbeat_updates || rc=2
      sonar_render_lock_release || rc=2
      PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      return "$rc"
    fi
    # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
    SONAR_LAST_TICK="$tick"
    elapsed="$(sonar_elapsed_seconds)"
    sonar_update_progress "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$elapsed" || rc=2
    sonar_update_state "$SONAR_ACTIVE_GROUP" "" 1 || rc=2
    sonar_render_lock_release || rc=2
    return "$rc"
  fi
  (( slow == 1 )) && colour=yellow
  spinner="$(progress_spinner_glyph "$tick")"
  reset="$(progress_colour reset)"
  printf '\b%s%s%s' "$(progress_colour "$colour")" "$spinner" "$reset" >&2
}

progress_render_committed_line() {
  local stage="$1" outcome="$2" group elapsed
  : "$outcome"
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    group="$(sonar_group_for_stage "$stage")"
    elapsed="$(sonar_elapsed_seconds)"
    sonar_update_progress "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$elapsed"
    sonar_update_state "$group" "${SONAR_GROUP_STATES[$group]:-}" 0
    return 0
  fi
  if (( PROGRESS_INTERACTIVE == 1 )); then
    printf '\r\033[2K' >&2
  fi
  progress_line_prefix "$stage" >&2
  printf '\n' >&2
}

progress_heartbeat_platform_protocol() {
  if [[ -r "/proc/$$/stat" ]]; then
    printf 'strong'
  else
    printf 'weak'
  fi
}

progress_prepare_weak_heartbeat_coordination() {
  local generation_id prefix path created_a=0
  [[ "$PROGRESS_RUNTIME_DIR" == /* &&
     "$PROGRESS_RUNTIME_DIR" != *$'\n'* &&
     -d "$PROGRESS_RUNTIME_DIR" && ! -L "$PROGRESS_RUNTIME_DIR" ]] ||
    return 2
  PROGRESS_HEARTBEAT_GENERATION=$((PROGRESS_HEARTBEAT_GENERATION+1))
  generation_id="$$.$PROGRESS_HEARTBEAT_GENERATION"
  prefix="$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$generation_id"
  PROGRESS_HEARTBEAT_GENERATION_ID="$generation_id"
  PROGRESS_HEARTBEAT_STOP_FILE="$prefix.stop"
  PROGRESS_HEARTBEAT_DONE_FILE="$prefix.done"
  PROGRESS_HEARTBEAT_JOBS_A_DIR="$prefix.jobs-a"
  PROGRESS_HEARTBEAT_JOBS_B_DIR="$prefix.jobs-b"
  PROGRESS_HEARTBEAT_JOBS_A_FILE="$PROGRESS_HEARTBEAT_JOBS_A_DIR/snapshot"
  PROGRESS_HEARTBEAT_JOBS_B_FILE="$PROGRESS_HEARTBEAT_JOBS_B_DIR/snapshot"
  PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
  PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
  PROGRESS_HEARTBEAT_ACK_STATUS=""
  for path in \
      "$PROGRESS_HEARTBEAT_STOP_FILE" \
      "$PROGRESS_HEARTBEAT_DONE_FILE" \
      "$PROGRESS_HEARTBEAT_JOBS_A_DIR" \
      "$PROGRESS_HEARTBEAT_JOBS_B_DIR"; do
    [[ ! -e "$path" && ! -L "$path" ]] || return 2
  done
  if /bin/mkdir -m 700 -- "$PROGRESS_HEARTBEAT_JOBS_A_DIR" 2>/dev/null; then
    created_a=1
  else
    return 2
  fi
  if ! /bin/mkdir -m 700 -- "$PROGRESS_HEARTBEAT_JOBS_B_DIR" 2>/dev/null; then
    (( created_a == 0 )) ||
      /bin/rmdir -- "$PROGRESS_HEARTBEAT_JOBS_A_DIR" 2>/dev/null || true
    return 2
  fi
}

progress_heartbeat_marker_matches() {
  local path="$1" generation_id="$2" line="" extra=""
  if [[ ! -e "$path" && ! -L "$path" ]]; then
    return 1
  fi
  [[ -f "$path" && ! -L "$path" ]] || return 2
  {
    IFS= read -r line || [[ -n "$line" ]] || return 2
    if IFS= read -r extra; then
      return 2
    fi
  } <"$path"
  [[ "$line" == "$generation_id" ]]
}

progress_weak_heartbeat_write_done() {
  local done_file="$1" generation_id="$2" final_status="$3"
  [[ -n "$done_file" && -n "$generation_id" &&
     "$final_status" =~ ^(0|[1-9][0-9]{0,2})$ &&
     "$final_status" -le 255 ]] || return 2
  [[ ! -e "$done_file" && ! -L "$done_file" ]] || return 2
  (umask 077; set -o noclobber
   printf '%s|%s\n' "$generation_id" "$final_status" \
     >"$done_file") 2>/dev/null || return 2
  progress_heartbeat_ack_status "$done_file" "$generation_id" &&
    [[ "$PROGRESS_HEARTBEAT_ACK_STATUS" == "$final_status" ]]
}

progress_heartbeat_ack_status() {
  local path="$1" generation_id="$2" line="" extra="" ack_generation="" status=""
  PROGRESS_HEARTBEAT_ACK_STATUS=""
  if [[ ! -e "$path" && ! -L "$path" ]]; then
    return 1
  fi
  [[ -f "$path" && ! -L "$path" ]] || return 2
  {
    IFS= read -r line || [[ -n "$line" ]] || return 2
    # shellcheck disable=SC2034 # a second record is rejected regardless of its payload
    if IFS= read -r extra; then
      return 2
    fi
  } <"$path"
  ack_generation="${line%%|*}"
  status="${line#*|}"
  [[ "$line" == *'|'* && "$ack_generation" == "$generation_id" &&
     "$status" =~ ^(0|[1-9][0-9]{0,2})$ && "$status" -le 255 ]] || return 2
  PROGRESS_HEARTBEAT_ACK_STATUS="$status"
}

progress_weak_heartbeat_finalize() {
  local done_file="$1" generation_id="$2" final_status="$3" rc=0
  sonar_render_lock_exit_release || rc=2
  if (( rc == 0 )); then
    progress_weak_heartbeat_write_done \
      "$done_file" "$generation_id" "$final_status" || rc=2
  fi
  return "$rc"
}

progress_weak_heartbeat_exit() {
  local final_status=$? done_file="$1" generation_id="$2"
  trap - EXIT
  if ! progress_weak_heartbeat_finalize \
      "$done_file" "$generation_id" "$final_status"; then
    final_status=2
  fi
  exit "$final_status"
}

progress_weak_heartbeat_stop_requested() {
  local stop_file="$1" generation_id="$2" marker_rc=0
  progress_heartbeat_marker_matches "$stop_file" "$generation_id" ||
    marker_rc=$?
  (( marker_rc == 0 )) && return 0
  (( marker_rc == 1 )) && return 1
  return 2
}

progress_stage_heartbeat_loop() {
  local parent="$1" started="$2" soft="$3" protocol="${4:-strong}"
  local stop_file="${5:-}" done_file="${6:-}" generation_id="${7:-}"
  local tick=1 now elapsed slow loop_rc=0 marker_rc=1
  trap - ERR HUP INT TERM EXIT
  trap '' WINCH
  PROGRESS_HEARTBEAT_STOP_REQUESTED=0
  # The parent quiesces this shell before taking an identity-bearing process
  # snapshot. Once resumed, a trapped stop must exit before the remainder of
  # the loop body can spawn a helper absent from that frozen snapshot. EXIT
  # performs the owner-aware render-lock release; the parent recovers a stale
  # empty lock only after heartbeat death is proven.
  trap 'PROGRESS_HEARTBEAT_STOP_REQUESTED=1; exit 0' HUP INT TERM
  if [[ "$protocol" == weak ]]; then
    trap 'progress_weak_heartbeat_exit "$done_file" "$generation_id"' EXIT
  else
    trap 'sonar_render_lock_exit_release' EXIT
  fi
  set +e
  while (( PROGRESS_HEARTBEAT_STOP_REQUESTED == 0 )) &&
      kill -0 "$parent" 2>/dev/null; do
    if [[ "$protocol" == weak ]]; then
      marker_rc=0
      progress_weak_heartbeat_stop_requested "$stop_file" "$generation_id" ||
        marker_rc=$?
      if (( marker_rc == 0 )); then
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
      if (( marker_rc == 2 )); then
        loop_rc=2
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
    fi
    now="$(date +%s)"
    elapsed=$((now-started))
    (( elapsed < 0 )) && elapsed=0
    slow=0
    (( elapsed >= soft )) && slow=1
    if [[ "$protocol" == weak ]]; then
      marker_rc=0
      progress_weak_heartbeat_stop_requested "$stop_file" "$generation_id" ||
        marker_rc=$?
      if (( marker_rc == 0 )); then
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
      if (( marker_rc == 2 )); then
        loop_rc=2
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
        break
      fi
    fi
    if ! progress_render_spinner_tick "$tick" "$slow"; then
      loop_rc=2
      PROGRESS_HEARTBEAT_STOP_REQUESTED=1
    fi
    if [[ "$protocol" == weak ]]; then
      marker_rc=0
      progress_weak_heartbeat_stop_requested "$stop_file" "$generation_id" ||
        marker_rc=$?
      if (( marker_rc == 0 )); then
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      elif (( marker_rc == 2 )); then
        loop_rc=2
        PROGRESS_HEARTBEAT_STOP_REQUESTED=1
      fi
    fi
    tick=$((tick+1))
    (( PROGRESS_HEARTBEAT_STOP_REQUESTED == 0 )) || break
    sleep 0.15
  done
  if [[ "$protocol" == weak ]]; then
    trap - EXIT
    progress_weak_heartbeat_finalize \
      "$done_file" "$generation_id" "$loop_rc" || loop_rc=2
  else
    sonar_render_lock_exit_release
    trap - EXIT
  fi
  return "$loop_rc"
}

progress_wrap_text() {
  local text="$1" indent="${2:-  }" value_colour="${3:-reset}"
  local width paragraph line word candidate reset
  local LC_ALL="$PROGRESS_UTF8_LOCALE"
  local -a words=()
  PROGRESS_COLUMNS="$(progress_terminal_columns)"
  width=$((PROGRESS_COLUMNS-${#indent}))
  (( width < 24 )) && width=24
  (( width > 180 )) && width=180
  reset="$(progress_colour reset)"

  # A semicolon in recommendations normally separates two independent actions.
  # Turn it into a deliberate paragraph boundary before wrapping by words.
  text="${text//; /;$'\n'}"
  while IFS= read -r paragraph || [[ -n "$paragraph" ]]; do
    line=""
    words=()
    IFS=' ' read -r -a words <<<"$paragraph"
    for word in "${words[@]}"; do
      candidate="${line:+$line }$word"
      if [[ -n "$line" ]] && (( ${#candidate} > width )); then
        printf '%s%s%s%s\n' "$(progress_colour "$value_colour")" "$indent" "$line" "$reset"
        line="$word"
      else
        line="$candidate"
      fi
    done
    if [[ -n "$line" ]]; then
      printf '%s%s%s%s\n' "$(progress_colour "$value_colour")" "$indent" "$line" "$reset"
    else
      printf '\n'
    fi
  done <<<"$text"
}

progress_print_block() {
  local title="$1" text="$2" value_colour="${3:-reset}" reset
  reset="$(progress_colour reset)"
  printf '\n%s%s%s\n' "$(progress_colour cyan)" "$title" "$reset"
  progress_wrap_text "$text" "  " "$value_colour"
}

progress_write_state() {
  local percent="$1" stage="$2" started="$3" soft="$4" tmp
  PROGRESS_PERCENT="$percent"
  PROGRESS_STAGE="$stage"
  PROGRESS_SOFT_SECONDS="$soft"
  [[ -n "$PROGRESS_STATE_FILE" ]] || return 0
  tmp="${PROGRESS_STATE_FILE}.tmp.$$"
  printf '%s|%s|%s|%s\n' "$percent" "${stage//|/ }" "$started" "$soft" >"$tmp"
  mv -f "$tmp" "$PROGRESS_STATE_FILE"
}

progress_init() {
  local run_dir="$1" host="${2:-}" now
  SONAR_PRESENTATION_READY=0
  PROGRESS_RUNTIME_DIR="$run_dir"
  progress_detect_terminal || return 0
  sonar_runtime_configure "$run_dir" || PROGRESS_INTERACTIVE=0
  PROGRESS_CLEANUP_IN_PROGRESS=0
  PROGRESS_CLEANUP_DONE=0
  PROGRESS_CLEANUP_STATUS=0
  PROGRESS_SIGNAL_IN_PROGRESS=0
  PROGRESS_SIGNAL_REPORT_PATH="недоступен"
  PROGRESS_PENDING_SIGNAL=""
  PROGRESS_PENDING_SIGNAL_REPORT=""
  PROGRESS_HEARTBEAT_STARTING=0
  PROGRESS_HEARTBEAT_STOP_REQUESTED=0
  PROGRESS_HEARTBEAT_PROTOCOL=""
  PROGRESS_HEARTBEAT_GENERATION=0
  PROGRESS_HEARTBEAT_GENERATION_ID=""
  PROGRESS_HEARTBEAT_STOP_FILE=""
  PROGRESS_HEARTBEAT_DONE_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_DIR=""
  PROGRESS_HEARTBEAT_JOBS_B_DIR=""
  PROGRESS_HEARTBEAT_JOBS_A_FILE=""
  PROGRESS_HEARTBEAT_JOBS_B_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
  PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
  PROGRESS_HEARTBEAT_ACK_STATUS=""
  PROGRESS_STATE_FILE="$run_dir/.progress-state"
  now="$(date +%s)"
  progress_write_state 0 "Подготовка отчёта" "$now" 8
  PROGRESS_ACTIVE=1
  PROGRESS_COMPLETED_SECTIONS=0
  PROGRESS_COMPLETED_STAGES=0
  PROGRESS_STAGE_STARTED="$now"
  PROGRESS_STAGE_ACTIVE=0
  sonar_reset_audit_state
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_STARTED_AT="$now"
  if (( PROGRESS_INTERACTIVE == 1 )); then
    trap 'sonar_handle_winch' WINCH
    if sonar_screen_enter "$host" 0 "$PROGRESS_TOTAL_STAGES" "$now"; then
      PROGRESS_CURSOR_HIDDEN=1
    else
      SONAR_PRESENTATION_READY=0
      PROGRESS_INTERACTIVE=0
      sonar_screen_restore || true
      trap - WINCH
      printf 'SERVER TOOLKIT — АУДИТ\n\n' >&2
    fi
  else
    printf 'SERVER TOOLKIT — АУДИТ\n\n' >&2
  fi
}

progress_stage_limits() {
  local title="$1"
  PROGRESS_SOFT_SECONDS=8
  # shellcheck disable=SC2034 # consumed after this module is embedded
  CURRENT_STAGE_TIMEOUT=45
  # shellcheck disable=SC2034 # branch assignments are consumed after embedding
  case "$title" in
    *"CPU SAMPLE"*) PROGRESS_SOFT_SECONDS=12; CURRENT_STAGE_TIMEOUT=20 ;;
    *"SYSTEM ERRORS"*|*"KERNEL WARNINGS"*|*"RESTARTING SERVICES"*) PROGRESS_SOFT_SECONDS=12; CURRENT_STAGE_TIMEOUT=60 ;;
    *"PUBLIC IP"*|*"DNS"*|*"LATENCY"*|*"DOWNLOAD"*) PROGRESS_SOFT_SECONDS=10; CURRENT_STAGE_TIMEOUT=45 ;;
    *"UPGRADE SIMULATION"*) PROGRESS_SOFT_SECONDS=20; CURRENT_STAGE_TIMEOUT=120 ;;
  esac
}

progress_display_stage() {
  local title="$1"
  case "$title" in
    *"SERVER IDENTITY"*) printf 'Сервер и система' ;;
    *"IDENTITY RAW"*) printf 'Подробности системы' ;;
    *"CPU SAMPLE"*) printf 'Нагрузка процессора' ;;
    *"UPTIME"*) printf 'Время работы' ;;
    *"CPU"*) printf 'Процессор' ;;
    *"MEMORY"*) printf 'Память' ;;
    *"DISK"*) printf 'Диски' ;;
    *"PUBLIC IP"*) printf 'Внешний адрес' ;;
    *"DNS"*) printf 'DNS' ;;
    *"LISTENING PORTS RAW"*) printf 'Сетевые порты' ;;
    *"PORT INVENTORY"*) printf 'Анализ портов' ;;
    *"NETWORK"*) printf 'Сетевые интерфейсы' ;;
    *"FIREWALL"*) printf 'Межсетевой экран' ;;
    *"FAILED SERVICES"*) printf 'Состояние служб' ;;
    *"RESTARTING SERVICES"*) printf 'Повторные сбои служб' ;;
    *"SECURITY BASELINE"*) printf 'Базовая безопасность' ;;
    *"VIRTUALIZATION"*) printf 'Виртуализация' ;;
    *"SYSTEM ERRORS"*) printf 'Системные ошибки' ;;
    *"KERNEL WARNINGS"*) printf 'Предупреждения ядра' ;;
    *"INTERNET NOISE"*) printf 'Внешний шум SSH' ;;
    *"PACKAGE INDEX"*) printf 'Индекс пакетов' ;;
    *"PACKAGE STATE"*) printf 'Состояние пакетов' ;;
    *"UPGRADE SIMULATION"*) printf 'Проверка обновления' ;;
    *"TIME"*) printf 'Системное время' ;;
    *"LATENCY"*) printf 'Задержка сети' ;;
    *"DOWNLOAD"*) printf 'Скорость доступа' ;;
    *) printf '%s' "$title" ;;
  esac
}

progress_begin_stage() {
  local percent="$1" stage="$2" soft="$3" now heartbeat_pid identity protocol
  (( PROGRESS_ACTIVE == 1 )) || return 0
  progress_stop_heartbeat || return $?
  now="$(date +%s)"
  PROGRESS_STAGE_STARTED="$now"
  PROGRESS_STAGE_ACTIVE=1
  sonar_begin_stage "$stage"
  progress_write_state "$percent" "$stage" "$now" "$soft"
  if (( PROGRESS_INTERACTIVE == 1 )); then
    progress_render_active_line "$stage" 0
    protocol="$(progress_heartbeat_platform_protocol)"
    [[ "$protocol" == strong || "$protocol" == weak ]] || return 2
    PROGRESS_HEARTBEAT_PROTOCOL="$protocol"
    if [[ "$protocol" == weak ]]; then
      progress_prepare_weak_heartbeat_coordination || return 2
    else
      PROGRESS_HEARTBEAT_GENERATION_ID=""
      PROGRESS_HEARTBEAT_STOP_FILE=""
      PROGRESS_HEARTBEAT_DONE_FILE=""
      PROGRESS_HEARTBEAT_JOBS_A_DIR=""
      PROGRESS_HEARTBEAT_JOBS_B_DIR=""
      PROGRESS_HEARTBEAT_JOBS_A_FILE=""
      PROGRESS_HEARTBEAT_JOBS_B_FILE=""
      PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
      PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
      PROGRESS_HEARTBEAT_ACK_STATUS=""
    fi
    PROGRESS_HEARTBEAT_STARTING=1
    progress_stage_heartbeat_loop \
      "$$" "$now" "$soft" "$protocol" \
      "$PROGRESS_HEARTBEAT_STOP_FILE" \
      "$PROGRESS_HEARTBEAT_DONE_FILE" \
      "$PROGRESS_HEARTBEAT_GENERATION_ID" &
    heartbeat_pid=$!
    PROGRESS_HEARTBEAT_PID="$heartbeat_pid"
    PROGRESS_HEARTBEAT_IDENTITY=""
    identity="$(
      progress_capture_process_identity "$heartbeat_pid" 2>/dev/null || true
    )"
  if [[ -z "$identity" ]]; then
    PROGRESS_HEARTBEAT_STARTING=0
    if [[ -n "$PROGRESS_PENDING_SIGNAL" ]]; then
      progress_dispatch_pending_signal
    elif [[ "$protocol" == weak ]]; then
      progress_stop_weak_heartbeat || true
    fi
    printf 'progress_process_tree_status=heartbeat_start_identity_unavailable pid=%s\n' \
      "$heartbeat_pid" >&2
    return 2
    fi
  if [[ "$protocol" == weak && "$identity" != ps:* ]] ||
        [[ "$protocol" == strong && "$identity" != proc:* ]]; then
    PROGRESS_HEARTBEAT_STARTING=0
    if [[ -n "$PROGRESS_PENDING_SIGNAL" ]]; then
      progress_dispatch_pending_signal
    elif [[ "$protocol" == weak ]]; then
      progress_stop_weak_heartbeat || true
    fi
    printf 'progress_process_tree_status=heartbeat_start_protocol_mismatch pid=%s protocol=%s\n' \
      "$heartbeat_pid" "$protocol" >&2
    return 2
    fi
    PROGRESS_HEARTBEAT_IDENTITY="$identity"
    PROGRESS_HEARTBEAT_STARTING=0
    progress_dispatch_pending_signal
  fi
}

progress_finish_stage() {
  local percent="$1" now elapsed outcome=ok
  (( PROGRESS_ACTIVE == 1 && PROGRESS_STAGE_ACTIVE == 1 )) || return 0
  now="$(date +%s)"
  elapsed=$((now-PROGRESS_STAGE_STARTED))
  (( elapsed < 0 )) && elapsed=0
  (( elapsed >= PROGRESS_SOFT_SECONDS )) && outcome=slow
  progress_stop_heartbeat || return $?
  sonar_finish_stage "$PROGRESS_STAGE" "$outcome"
  PROGRESS_STAGE_ACTIVE=0
  PROGRESS_COMPLETED_STAGES=$((PROGRESS_COMPLETED_STAGES+1))
  (( PROGRESS_COMPLETED_STAGES > PROGRESS_TOTAL_STAGES )) && PROGRESS_COMPLETED_STAGES="$PROGRESS_TOTAL_STAGES"
  progress_render_committed_line "$PROGRESS_STAGE" "$outcome"
  progress_write_state "$percent" "$PROGRESS_STAGE" "$now" "$PROGRESS_SOFT_SECONDS"
}

progress_section_start() {
  local title="$1" display percent
  progress_stage_limits "$title"
  display="$(progress_display_stage "$title")"
  percent=$(( PROGRESS_COMPLETED_SECTIONS * 88 / PROGRESS_TOTAL_SECTIONS ))
  progress_begin_stage "$percent" "$display" "$PROGRESS_SOFT_SECONDS"
}

progress_section_complete() {
  local title="$1" percent
  : "$title"
  PROGRESS_COMPLETED_SECTIONS=$((PROGRESS_COMPLETED_SECTIONS+1))
  (( PROGRESS_COMPLETED_SECTIONS > PROGRESS_TOTAL_SECTIONS )) && PROGRESS_COMPLETED_SECTIONS="$PROGRESS_TOTAL_SECTIONS"
  percent=$(( PROGRESS_COMPLETED_SECTIONS * 88 / PROGRESS_TOTAL_SECTIONS ))
  progress_finish_stage "$percent"
}

progress_set_absolute() {
  local percent="$1" stage="$2" soft="${3:-8}"
  progress_finish_stage "$PROGRESS_PERCENT"
  progress_begin_stage "$percent" "$stage" "$soft"
}

progress_sync_disabled_presentation() {
  local columns max_width
  sonar_heartbeat_updates_disabled || return 0
  SONAR_PRESENTATION_READY=0
  PROGRESS_INTERACTIVE=0
  columns="$(progress_terminal_columns)"
  if [[ "$columns" =~ ^[0-9]+$ ]]; then
    PROGRESS_COLUMNS="$columns"
    max_width=$((columns-14))
    (( max_width < 16 )) && max_width=16
    (( PROGRESS_WIDTH > max_width )) && PROGRESS_WIDTH="$max_width"
  fi
  sonar_screen_restore || return 2
  trap - WINCH
}

progress_process_parent_pid() {
  local pid="$1" stat_line stat_tail ppid
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  (( pid > 1 )) || return 1
  if [[ -r "/proc/$pid/stat" ]]; then
    stat_line="$(<"/proc/$pid/stat")" || return 1
    stat_tail="${stat_line##*) }"
    ppid="${stat_tail#* }"
    ppid="${ppid%% *}"
  else
    ppid="$(
      LC_ALL=C /bin/ps -o ppid= -p "$pid" 2>/dev/null |
        /usr/bin/awk 'NF { print $1; exit }'
    )"
  fi
  [[ "$ppid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  printf '%s' "$ppid"
}

progress_heartbeat_original_is_gone() {
  local pid="$1" identity="$2"
  case "$identity" in
    proc:*)
      ! kill -0 "$pid" 2>/dev/null
      ;;
    *)
      return 1
      ;;
  esac
}

progress_capture_heartbeat_jobs_snapshot() {
  local path="$1" dir="" next="" owned=0 noclobber_was_set=0 jobs_rc=0
  if [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_A_FILE" ]]; then
    dir="$PROGRESS_HEARTBEAT_JOBS_A_DIR"
    owned="$PROGRESS_HEARTBEAT_JOBS_A_OWNED"
  elif [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_B_FILE" ]]; then
    dir="$PROGRESS_HEARTBEAT_JOBS_B_DIR"
    owned="$PROGRESS_HEARTBEAT_JOBS_B_OWNED"
  else
    return 2
  fi
  [[ -n "$dir" && "$path" == "$dir/snapshot" &&
     -d "$dir" && ! -L "$dir" ]] || return 2
  next="$dir/snapshot.next"
  if (( owned == 1 )); then
    [[ -f "$path" && ! -L "$path" ]] || return 2
  else
    [[ ! -e "$path" && ! -L "$path" ]] || return 2
  fi
  [[ ! -e "$next" && ! -L "$next" ]] || return 2
  [[ "$-" == *C* ]] && noclobber_was_set=1
  set -o noclobber
  if jobs -pr >"$next" 2>/dev/null; then
    jobs_rc=0
  else
    jobs_rc=$?
  fi
  (( noclobber_was_set == 1 )) || set +o noclobber
  (( jobs_rc == 0 )) || return 2
  [[ -f "$next" && ! -L "$next" ]] || return 2
  /bin/mv -f -- "$next" "$path" 2>/dev/null || return 2
  [[ -f "$path" && ! -L "$path" ]] || return 2
  if [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_A_FILE" ]]; then
    PROGRESS_HEARTBEAT_JOBS_A_OWNED=1
  else
    PROGRESS_HEARTBEAT_JOBS_B_OWNED=1
  fi
}

progress_heartbeat_jobs_snapshot_contains() {
  local path="$1" wanted_pid="$2" job_pid
  [[ -f "$path" && ! -L "$path" ]] || return 2
  while IFS= read -r job_pid; do
    [[ "$job_pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    [[ "$job_pid" == "$wanted_pid" ]] && return 0
  done <"$path"
  return 1
}

progress_observe_weak_heartbeat_job() {
  local pid="$1" identity="$2" current="" ppid=""
  local jobs_a_rc=0 jobs_b_rc=0
  PROGRESS_HEARTBEAT_RESOLUTION=""
  PROGRESS_HEARTBEAT_OBSERVATION_ERROR=""
  [[ "$identity" == ps:* ]] || {
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=identity
    return 2
  }
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_A_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-a
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_A_FILE" "$pid" || jobs_a_rc=$?
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  ppid="$(progress_process_parent_pid "$pid" 2>/dev/null || true)"
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_B_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-b
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_B_FILE" "$pid" || jobs_b_rc=$?
  if (( jobs_b_rc == 1 )); then
    PROGRESS_HEARTBEAT_RESOLUTION=gone
    return 0
  fi
  if (( jobs_a_rc == 1 )); then
    PROGRESS_HEARTBEAT_RESOLUTION=replaced
    return 0
  fi
  if (( jobs_a_rc != 0 || jobs_b_rc != 0 )); then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-parse
    return 2
  fi
  if [[ -n "$current" && "$current" != "$identity" ]]; then
    PROGRESS_HEARTBEAT_RESOLUTION=replaced
    return 0
  fi
  if [[ -n "$ppid" && "$ppid" != "$$" ]]; then
    PROGRESS_HEARTBEAT_RESOLUTION=replaced
    return 0
  fi
  if [[ -z "$current" ]]; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=identity
    return 2
  fi
  if [[ -z "$ppid" ]]; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=ppid
    return 2
  fi
  PROGRESS_HEARTBEAT_RESOLUTION=owned
}

progress_observe_weak_heartbeat_job_absence() {
  local pid="$1" jobs_a_rc=0 jobs_b_rc=0
  PROGRESS_HEARTBEAT_RESOLUTION=""
  PROGRESS_HEARTBEAT_OBSERVATION_ERROR=""
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_A_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-a
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_A_FILE" "$pid" || jobs_a_rc=$?
  if ! progress_capture_heartbeat_jobs_snapshot \
      "$PROGRESS_HEARTBEAT_JOBS_B_FILE"; then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-b
    return 2
  fi
  progress_heartbeat_jobs_snapshot_contains \
    "$PROGRESS_HEARTBEAT_JOBS_B_FILE" "$pid" || jobs_b_rc=$?
  if (( jobs_a_rc > 1 || jobs_b_rc > 1 )); then
    PROGRESS_HEARTBEAT_OBSERVATION_ERROR=jobs-parse
    return 2
  fi
  if (( jobs_b_rc == 1 )); then
    PROGRESS_HEARTBEAT_RESOLUTION=gone
  else
    # With no trusted identity, a present job is never classified as owned.
    PROGRESS_HEARTBEAT_RESOLUTION=unverified
  fi
}

progress_resolve_missing_heartbeat_identity() {
  local pid="$1" identity="$2" attempt current
  PROGRESS_HEARTBEAT_RESOLUTION=""
  [[ -n "$identity" ]] || return 2
  [[ "$identity" == proc:* ]] || return 2
  for ((attempt=0; attempt<10; attempt++)); do
    current="$(progress_process_identity "$pid" 2>/dev/null || true)"
    if [[ -n "$current" ]]; then
      if [[ "$current" == "$identity" ]]; then
        PROGRESS_HEARTBEAT_RESOLUTION=owned
      else
        PROGRESS_HEARTBEAT_RESOLUTION=gone
      fi
      return 0
    fi
    if progress_heartbeat_original_is_gone "$pid" "$identity"; then
      PROGRESS_HEARTBEAT_RESOLUTION=gone
      return 0
    fi
    sleep 0.01
  done
  return 2
}

progress_request_weak_heartbeat_stop() {
  local marker_rc=0
  progress_heartbeat_marker_matches \
    "$PROGRESS_HEARTBEAT_STOP_FILE" \
    "$PROGRESS_HEARTBEAT_GENERATION_ID" || marker_rc=$?
  (( marker_rc == 0 )) && return 0
  (( marker_rc == 1 )) || return 2
  (umask 077; set -o noclobber
   printf '%s\n' "$PROGRESS_HEARTBEAT_GENERATION_ID" \
     >"$PROGRESS_HEARTBEAT_STOP_FILE") 2>/dev/null || return 2
  progress_heartbeat_marker_matches \
    "$PROGRESS_HEARTBEAT_STOP_FILE" \
    "$PROGRESS_HEARTBEAT_GENERATION_ID"
}

progress_clear_weak_heartbeat_coordination() {
  local path dir owned unexpected
  [[ -n "$PROGRESS_HEARTBEAT_GENERATION_ID" ]] || return 2
  [[ "$PROGRESS_HEARTBEAT_STOP_FILE" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.stop" &&
     "$PROGRESS_HEARTBEAT_DONE_FILE" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.done" &&
     "$PROGRESS_HEARTBEAT_JOBS_A_DIR" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.jobs-a" &&
     "$PROGRESS_HEARTBEAT_JOBS_B_DIR" == \
       "$PROGRESS_RUNTIME_DIR/.sonar-heartbeat-$PROGRESS_HEARTBEAT_GENERATION_ID.jobs-b" &&
     "$PROGRESS_HEARTBEAT_JOBS_A_FILE" == "$PROGRESS_HEARTBEAT_JOBS_A_DIR/snapshot" &&
     "$PROGRESS_HEARTBEAT_JOBS_B_FILE" == "$PROGRESS_HEARTBEAT_JOBS_B_DIR/snapshot" ]] ||
    return 2
  [[ -f "$PROGRESS_HEARTBEAT_STOP_FILE" &&
     ! -L "$PROGRESS_HEARTBEAT_STOP_FILE" &&
     -f "$PROGRESS_HEARTBEAT_DONE_FILE" &&
     ! -L "$PROGRESS_HEARTBEAT_DONE_FILE" ]] || return 2
  for dir in "$PROGRESS_HEARTBEAT_JOBS_A_DIR" "$PROGRESS_HEARTBEAT_JOBS_B_DIR"; do
    [[ -d "$dir" && ! -L "$dir" ]] || return 2
    [[ ! -e "$dir/snapshot.next" && ! -L "$dir/snapshot.next" ]] || return 2
    unexpected="$(/usr/bin/find "$dir" -mindepth 1 -maxdepth 1 \
      ! -name snapshot -print -quit 2>/dev/null)" || return 2
    [[ -z "$unexpected" ]] || return 2
  done
  for path in "$PROGRESS_HEARTBEAT_JOBS_A_FILE" "$PROGRESS_HEARTBEAT_JOBS_B_FILE"; do
    if [[ "$path" == "$PROGRESS_HEARTBEAT_JOBS_A_FILE" ]]; then
      owned="$PROGRESS_HEARTBEAT_JOBS_A_OWNED"
    else
      owned="$PROGRESS_HEARTBEAT_JOBS_B_OWNED"
    fi
    if (( owned == 1 )); then
      [[ -f "$path" && ! -L "$path" ]] || return 2
    else
      [[ ! -e "$path" && ! -L "$path" ]] || return 2
    fi
  done
  /bin/rm -f -- "$PROGRESS_HEARTBEAT_STOP_FILE" \
    "$PROGRESS_HEARTBEAT_DONE_FILE" 2>/dev/null || return 2
  (( PROGRESS_HEARTBEAT_JOBS_A_OWNED == 0 )) ||
    /bin/rm -f -- "$PROGRESS_HEARTBEAT_JOBS_A_FILE" 2>/dev/null || return 2
  (( PROGRESS_HEARTBEAT_JOBS_B_OWNED == 0 )) ||
    /bin/rm -f -- "$PROGRESS_HEARTBEAT_JOBS_B_FILE" 2>/dev/null || return 2
  /bin/rmdir -- "$PROGRESS_HEARTBEAT_JOBS_A_DIR" \
    "$PROGRESS_HEARTBEAT_JOBS_B_DIR" 2>/dev/null || return 2
  for path in "$PROGRESS_HEARTBEAT_STOP_FILE" \
      "$PROGRESS_HEARTBEAT_DONE_FILE" "$PROGRESS_HEARTBEAT_JOBS_A_DIR" \
      "$PROGRESS_HEARTBEAT_JOBS_B_DIR"; do
    [[ ! -e "$path" && ! -L "$path" ]] || return 2
  done
  PROGRESS_HEARTBEAT_GENERATION_ID=""
  PROGRESS_HEARTBEAT_STOP_FILE=""
  PROGRESS_HEARTBEAT_DONE_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_DIR=""
  PROGRESS_HEARTBEAT_JOBS_B_DIR=""
  PROGRESS_HEARTBEAT_JOBS_A_FILE=""
  PROGRESS_HEARTBEAT_JOBS_B_FILE=""
  PROGRESS_HEARTBEAT_JOBS_A_OWNED=0
  PROGRESS_HEARTBEAT_JOBS_B_OWNED=0
  PROGRESS_HEARTBEAT_ACK_STATUS=""
}

progress_stop_weak_heartbeat() {
  local pid="$PROGRESS_HEARTBEAT_PID" identity="$PROGRESS_HEARTBEAT_IDENTITY"
  local attempt observe_rc=0 resolution=""
  [[ "$PROGRESS_HEARTBEAT_PROTOCOL" == weak ]] || return 2

  # This exact-generation marker is the first cooperative stop action. All
  # PID, identity, PPID, and jobs observations below are diagnostic only.
  if ! progress_request_weak_heartbeat_stop; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_stop_marker_failed pid=%s\n' \
      "${pid:-unknown}" >&2
    return 2
  fi

  [[ "$pid" =~ ^[0-9]+$ ]] && (( pid > 1 )) || return 2
  [[ -n "$PROGRESS_HEARTBEAT_GENERATION_ID" &&
     -n "$PROGRESS_HEARTBEAT_STOP_FILE" &&
     -n "$PROGRESS_HEARTBEAT_DONE_FILE" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_A_DIR" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_B_DIR" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_A_FILE" &&
     -n "$PROGRESS_HEARTBEAT_JOBS_B_FILE" ]] || return 2

  resolution=""
  for ((attempt=0; attempt<100; attempt++)); do
    observe_rc=0
    if [[ "$identity" == ps:* ]]; then
      progress_observe_weak_heartbeat_job "$pid" "$identity" || observe_rc=$?
    else
      progress_observe_weak_heartbeat_job_absence "$pid" || observe_rc=$?
    fi
    if (( observe_rc != 0 )); then
      if [[ "$PROGRESS_HEARTBEAT_OBSERVATION_ERROR" == jobs-* ]]; then
        SONAR_PRESENTATION_READY=0
        printf 'progress_process_tree_status=weak_heartbeat_observation_failed pid=%s reason=%s\n' \
          "$pid" "$PROGRESS_HEARTBEAT_OBSERVATION_ERROR" >&2
        return 2
      fi
    elif [[ "$PROGRESS_HEARTBEAT_RESOLUTION" == gone ]]; then
      resolution=gone
      break
    fi
    /bin/sleep 0.01
  done
  if [[ "$resolution" != gone ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_stop_unverified pid=%s reason=%s\n' \
      "$pid" "${PROGRESS_HEARTBEAT_OBSERVATION_ERROR:-job-present}" >&2
    return 2
  fi

  if ! progress_heartbeat_ack_status \
      "$PROGRESS_HEARTBEAT_DONE_FILE" \
      "$PROGRESS_HEARTBEAT_GENERATION_ID"; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_ack_invalid pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if [[ "$PROGRESS_HEARTBEAT_ACK_STATUS" != 0 ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_ack_nonzero pid=%s rc=%s\n' \
      "$pid" "$PROGRESS_HEARTBEAT_ACK_STATUS" >&2
    return 2
  fi
  if [[ -n "$SONAR_RENDER_LOCK_DIR" &&
        ( -e "$SONAR_RENDER_LOCK_DIR" || -L "$SONAR_RENDER_LOCK_DIR" ) ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_lock_unreleased pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if ! progress_sync_disabled_presentation; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=heartbeat_presentation_sync_failed\n' >&2
    return 2
  fi
  if ! progress_clear_weak_heartbeat_coordination; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_coordination_cleanup_failed pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  PROGRESS_HEARTBEAT_PID=""
  PROGRESS_HEARTBEAT_IDENTITY=""
  PROGRESS_HEARTBEAT_PROTOCOL=""
}

progress_finalize_gone_heartbeat() {
  local clear_ready="${1:-1}" rc=0
  # A different immutable identity at the recorded PID proves that the owned
  # heartbeat is gone. Never signal, stop, continue, or wait the replacement.
  (( clear_ready == 0 )) || SONAR_PRESENTATION_READY=0
  if ! sonar_recover_stale_render_lock; then
    printf 'progress_process_tree_status=heartbeat_lock_recovery_failed owned=%s\n' \
      "$SONAR_RENDER_LOCK_OWNED" >&2
    rc=2
  fi
  if ! progress_sync_disabled_presentation; then
    printf 'progress_process_tree_status=heartbeat_presentation_sync_failed\n' >&2
    rc=2
  fi
  PROGRESS_HEARTBEAT_PID=""
  PROGRESS_HEARTBEAT_IDENTITY=""
  PROGRESS_HEARTBEAT_PROTOCOL=""
  return "$rc"
}

progress_heartbeat_snapshot_has_live_members() {
  local snapshot="$1" trusted_root="$2" trusted_identity="$3"
  local pid identity current state uncertain=0
  while IFS=$'\t' read -r pid identity; do
    [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    (( pid > 1 )) || continue
    current="$(progress_process_identity "$pid" 2>/dev/null || true)"
    if [[ -n "$current" && "$current" != "$identity" ]]; then
      continue
    fi
    if [[ -z "$current" ]]; then
      if [[ "$pid" == "$trusted_root" ]] &&
          progress_heartbeat_original_is_gone "$pid" "$trusted_identity"; then
        continue
      fi
      if kill -0 "$pid" 2>/dev/null; then
        uncertain=1
      fi
      continue
    fi
    state="$(progress_process_state "$pid")"
    [[ "$state" == Z* ]] && continue
    kill -0 "$pid" 2>/dev/null && return 0
  done <<<"$snapshot"
  (( uncertain == 0 )) || return 2
  return 1
}

progress_resume_heartbeat_if_owned() {
  local pid="$1" identity="$2" current resolution=""
  [[ "$identity" == proc:* ]] || return 2
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$identity" && -n "$current" && "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_changed_before_continue pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if [[ -z "$identity" || -z "$current" ]]; then
    if [[ -n "$identity" ]] &&
        progress_resolve_missing_heartbeat_identity "$pid" "$identity"; then
      resolution="$PROGRESS_HEARTBEAT_RESOLUTION"
      if [[ "$resolution" == gone ]]; then
        return 0
      fi
      current="$identity"
    elif progress_heartbeat_original_is_gone "$pid" "$identity"; then
      return 0
    else
      printf 'progress_process_tree_status=heartbeat_identity_unavailable_before_continue pid=%s\n' \
        "$pid" >&2
      return 2
    fi
  fi
  if ! kill -CONT "$pid" 2>/dev/null; then
    if progress_resolve_missing_heartbeat_identity "$pid" "$identity" &&
        [[ "$PROGRESS_HEARTBEAT_RESOLUTION" == gone ]]; then
      return 0
    fi
    printf 'progress_process_tree_status=heartbeat_continue_failed pid=%s\n' \
      "$pid" >&2
    return 2
  fi
}

progress_capture_quiesced_heartbeat_tree() {
  local pid="$1" identity="$2" attempt state current snapshot
  local root_found=0 snapshot_pid snapshot_identity resolution=""
  PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT=""
  [[ "$identity" == proc:* ]] || return 2
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$identity" && -n "$current" && "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_changed_before_stop pid=%s\n' \
      "$pid" >&2
    return 3
  fi
  if [[ -n "$identity" && -z "$current" ]]; then
    if ! progress_resolve_missing_heartbeat_identity "$pid" "$identity"; then
      printf 'progress_process_tree_status=heartbeat_identity_unavailable_before_stop pid=%s\n' \
        "$pid" >&2
      return 2
    fi
    resolution="$PROGRESS_HEARTBEAT_RESOLUTION"
    if [[ "$resolution" == gone ]]; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      return 3
    fi
    current="$identity"
  fi
  if [[ -z "$identity" || -z "$current" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_unavailable_before_stop pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if ! kill -STOP "$pid" 2>/dev/null; then
    if progress_resolve_missing_heartbeat_identity "$pid" "$identity" &&
        [[ "$PROGRESS_HEARTBEAT_RESOLUTION" == gone ]]; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      return 3
    fi
    printf 'progress_process_tree_status=heartbeat_stop_signal_failed pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  for ((attempt=0; attempt<10; attempt++)); do
    state="$(progress_process_state "$pid")"
    [[ "$state" == T* || "$state" == t* ]] && break
    progress_process_is_running "$pid" || break
    sleep 0.01
  done
  state="$(progress_process_state "$pid")"
  if [[ "$state" != T* && "$state" != t* ]]; then
    if progress_heartbeat_original_is_gone "$pid" "$identity"; then
      printf 'progress_process_tree_status=heartbeat_gone_during_quiesce pid=%s\n' \
        "$pid" >&2
      return 3
    fi
    progress_resume_heartbeat_if_owned "$pid" "$identity" || true
    printf 'progress_process_tree_status=heartbeat_quiesce_unverified pid=%s state=%s\n' \
      "$pid" "${state:-unknown}" >&2
    return 2
  fi
  if ! snapshot="$(progress_collect_process_tree "$pid")" || [[ -z "$snapshot" ]]; then
    progress_resume_heartbeat_if_owned "$pid" "$identity" || true
    printf 'progress_process_tree_status=heartbeat_snapshot_incomplete pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -z "$current" || "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_changed_during_snapshot pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  while IFS=$'\t' read -r snapshot_pid snapshot_identity; do
    if [[ "$snapshot_pid" == "$pid" && "$snapshot_identity" == "$identity" ]]; then
      root_found=1
      break
    fi
  done <<<"$snapshot"
  if (( root_found == 0 )); then
    progress_resume_heartbeat_if_owned "$pid" "$identity" || true
    printf 'progress_process_tree_status=heartbeat_root_missing_from_snapshot pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT="$snapshot"
}

progress_stop_heartbeat() {
  local pid="$PROGRESS_HEARTBEAT_PID" identity="$PROGRESS_HEARTBEAT_IDENTITY"
  local attempt state current sync_rc=0 wait_rc=0 rc=0 live_status=1
  local snapshot="" escalation_snapshot="" capture_rc=0 resolution="" escalated=0

  # Cooperative weak shutdown must write its exact-generation marker before
  # any PID or identity handling in the generic dispatcher.
  if [[ "$PROGRESS_HEARTBEAT_PROTOCOL" == weak ]]; then
    progress_stop_weak_heartbeat
    return $?
  fi
  [[ "$pid" =~ ^[0-9]+$ ]] || {
    PROGRESS_HEARTBEAT_PID=""
    PROGRESS_HEARTBEAT_IDENTITY=""
    PROGRESS_HEARTBEAT_PROTOCOL=""
    return 0
  }
  if (( pid <= 1 )); then
    PROGRESS_HEARTBEAT_PID=""
    PROGRESS_HEARTBEAT_IDENTITY=""
    PROGRESS_HEARTBEAT_PROTOCOL=""
    printf 'progress_process_tree_status=invalid_heartbeat_pid\n' >&2
    return 2
  fi

  if [[ "$identity" == ps:* ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=weak_heartbeat_protocol_unavailable pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if [[ "$identity" != proc:* ]]; then
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=strong_heartbeat_identity_unavailable pid=%s\n' \
      "$pid" >&2
    return 2
  fi

  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$identity" && -z "$current" ]]; then
    if ! progress_resolve_missing_heartbeat_identity "$pid" "$identity"; then
      SONAR_PRESENTATION_READY=0
      printf 'progress_process_tree_status=heartbeat_identity_unavailable pid=%s\n' "$pid" >&2
      return 2
    fi
    resolution="$PROGRESS_HEARTBEAT_RESOLUTION"
    if [[ "$resolution" == gone ]]; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      progress_finalize_gone_heartbeat
      return $?
    fi
    current="$identity"
  fi
  if [[ -z "$identity" || -z "$current" ]]; then
    if progress_heartbeat_original_is_gone "$pid" "$identity"; then
      printf 'progress_process_tree_status=heartbeat_gone_before_stop pid=%s\n' \
        "$pid" >&2
      progress_finalize_gone_heartbeat
      return $?
    fi
    SONAR_PRESENTATION_READY=0
    printf 'progress_process_tree_status=heartbeat_identity_unavailable pid=%s\n' "$pid" >&2
    return 2
  fi
  if [[ "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_replaced pid=%s\n' "$pid" >&2
    progress_finalize_gone_heartbeat
    return $?
  fi
  if progress_capture_quiesced_heartbeat_tree "$pid" "$identity"; then
    snapshot="$PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT"
  else
    capture_rc=$?
  fi
  if (( capture_rc == 3 )); then
    progress_finalize_gone_heartbeat
    return $?
  fi
  if (( capture_rc != 0 )); then
    SONAR_PRESENTATION_READY=0
    return 2
  fi
  progress_signal_process_snapshot TERM "$snapshot" "$pid" "$identity" || rc=2
  progress_resume_heartbeat_if_owned "$pid" "$identity" || rc=2
  for ((attempt=0; attempt<10; attempt++)); do
    live_status=0
    progress_heartbeat_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
      live_status=$?
    (( live_status == 1 )) && break
    sleep 0.1
  done
  live_status=0
  progress_heartbeat_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  if (( live_status == 2 )); then
    printf 'progress_process_tree_status=heartbeat_snapshot_unverified pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if (( live_status == 0 )); then
    escalated=1
    if progress_process_is_running "$pid"; then
      capture_rc=0
      if progress_capture_quiesced_heartbeat_tree "$pid" "$identity"; then
        escalation_snapshot="$PROGRESS_HEARTBEAT_CAPTURED_SNAPSHOT"
      else
        capture_rc=$?
      fi
      if (( capture_rc != 0 )); then
        return 2
      fi
    else
      escalation_snapshot="$snapshot"
    fi
    progress_signal_process_snapshot KILL "$escalation_snapshot" "$pid" "$identity" ||
      rc=2
    # Weak-identity platforms can refuse KILL. Never leave an identity-matched
    # heartbeat stopped solely because the safe escalation was unavailable.
    progress_resume_heartbeat_if_owned "$pid" "$identity" || rc=2
    for ((attempt=0; attempt<10; attempt++)); do
      live_status=0
      progress_heartbeat_snapshot_has_live_members \
        "$escalation_snapshot" "$pid" "$identity" || live_status=$?
      (( live_status == 1 )) && break
      sleep 0.1
    done
  fi
  if [[ -n "$escalation_snapshot" ]]; then
    live_status=0
    progress_heartbeat_snapshot_has_live_members \
      "$escalation_snapshot" "$pid" "$identity" || live_status=$?
    if (( live_status == 2 )); then
      printf 'progress_process_tree_status=heartbeat_escalation_unverified pid=%s\n' \
        "$pid" >&2
      return 2
    fi
    if (( live_status == 0 )); then
      printf 'progress_process_tree_status=heartbeat_escalation_incomplete pid=%s\n' \
        "$pid" >&2
      return 2
    fi
  fi
  live_status=0
  progress_heartbeat_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  if (( live_status == 2 )); then
    printf 'progress_process_tree_status=heartbeat_snapshot_unverified pid=%s\n' \
      "$pid" >&2
    return 2
  fi
  if (( live_status == 0 )); then
    printf 'progress_process_tree_status=heartbeat_cleanup_incomplete pid=%s\n' "$pid" >&2
    return 2
  fi
  current="$(progress_process_identity "$pid" 2>/dev/null || true)"
  if [[ -n "$current" && "$current" != "$identity" ]]; then
    printf 'progress_process_tree_status=heartbeat_identity_replaced_after_stop pid=%s\n' \
      "$pid" >&2
    progress_finalize_gone_heartbeat "$escalated"
    return $?
  fi
  if [[ -z "$current" ]] &&
      progress_heartbeat_original_is_gone "$pid" "$identity"; then
    progress_finalize_gone_heartbeat "$escalated"
    return $?
  fi
  state="$(progress_process_state "$pid")"
  if [[ "$state" == Z* ]] || ! kill -0 "$pid" 2>/dev/null; then
    wait "$pid" 2>/dev/null || wait_rc=$?
    (( wait_rc == 0 )) || SONAR_PRESENTATION_READY=0
    if ! sonar_recover_stale_render_lock; then
      printf 'progress_process_tree_status=heartbeat_lock_recovery_failed owned=%s\n' \
        "$SONAR_RENDER_LOCK_OWNED" >&2
      return 2
    fi
    if ! progress_sync_disabled_presentation; then
      printf 'progress_process_tree_status=heartbeat_presentation_sync_failed\n' >&2
      sync_rc=2
    fi
    PROGRESS_HEARTBEAT_PID=""
    PROGRESS_HEARTBEAT_IDENTITY=""
    PROGRESS_HEARTBEAT_PROTOCOL=""
    (( rc == 0 )) || return "$rc"
    return "$sync_rc"
  fi
  printf 'progress_process_tree_status=heartbeat_state_unverified pid=%s\n' "$pid" >&2
  return 2
}

progress_collect_process_tree_from_table() {
  local root="$1" expected_fields="${2:-2}"
  /usr/bin/awk -v root="$root" -v max_hops="$PROGRESS_PROCESS_TREE_MAX_HOPS" \
      -v max_rows="$PROGRESS_PROCESS_TREE_MAX_ROWS" \
      -v max_transitions="$PROGRESS_PROCESS_TREE_MAX_TRANSITIONS" \
      -v expected_fields="$expected_fields" '
    function is_pid(value) {
      return value ~ /^(0|[1-9][0-9]*)$/
    }
    function remember_status(name) {
      status[name]=1
      incomplete=1
    }
    function spend_transition() {
      transitions++
      if (transitions > max_transitions) {
        remember_status("transition_limit")
        exhausted=1
        return 0
      }
      return 1
    }
    function emit(pid, depth_value,    line) {
      line=pid
      if (identity[pid] != "") {
        line=line "\t" identity[pid]
      }
      output[pid]=line
      depth[pid]=depth_value
      if (depth_value > max_depth) {
        max_depth=depth_value
      }
    }
    NF == 0 {
      next
    }
    {
      rows++
      if (rows > max_rows) {
        remember_status("row_limit")
        fatal=1
        exit 2
      }
      if (NF != expected_fields || !is_pid($1) || !is_pid($2)) {
        remember_status("malformed")
        next
      }
      pid=$1
      ppid=$2
      row_identity=""
      if (expected_fields == 3) {
        row_identity=$3
      } else if (expected_fields == 7) {
        row_identity="ps:" $3 " " $4 " " $5 " " $6 " " $7
      }
      if (pid in parent) {
        if (parent[pid] != ppid || identity[pid] != row_identity) {
          remember_status("conflicting_duplicate")
        }
        next
      }
      parent[pid]=ppid
      identity[pid]=row_identity
    }
    END {
      if (fatal) {
        # Input processing already stopped at the hard row ceiling.
      } else if (!is_pid(root) || root <= 1 ||
                 !is_pid(max_hops) || max_hops < 1 ||
                 !is_pid(max_rows) || max_rows < 1 ||
                 !is_pid(max_transitions) || max_transitions < 1) {
        remember_status("invalid_limits")
      } else {
        generation=0
        for (pid in parent) {
          current=pid
          hops=0
          generation++
          found_root=0
          root_depth=0
          while (current in parent && current != 0 && current != 1) {
            if (!spend_transition()) {
              break
            }
            if (current == root && !found_root) {
              found_root=1
              root_depth=hops
            }
            if (seen[current] == generation) {
              remember_status("cycle")
              break
            }
            if (hops >= max_hops) {
              remember_status("hop_limit")
              break
            }
            seen[current]=generation
            next_parent=parent[current]
            if (!is_pid(next_parent)) {
              remember_status("malformed")
              break
            }
            if (next_parent == current) {
              remember_status("cycle")
              break
            }
            current=next_parent
            hops++
          }
          if (found_root && pid != root) {
            emit(pid, root_depth)
          }
          if (exhausted) {
            break
          }
        }

        # Deepest descendants are signalled first. The owned direct child is
        # always last so that it cannot orphan a still-running descendant
        # before the first signal pass has completed.
        for (wanted_depth=max_depth;
             wanted_depth>=1 && !exhausted;
             wanted_depth--) {
          while (1) {
            selected=""
            for (pid in output) {
              if (!spend_transition()) {
                break
              }
              if (depth[pid] == wanted_depth && (selected == "" || (pid + 0) < (selected + 0))) {
                selected=pid
              }
            }
            if (exhausted || selected == "") {
              break
            }
            print output[selected]
            delete output[selected]
            delete depth[selected]
          }
        }
        if (exhausted) {
          # The caller may retain identity-verified partial descendants, but
          # appends the trusted root and preserves the incomplete status.
        } else if (root in parent) {
          emit(root, 0)
          print output[root]
        } else {
          print root
          remember_status("root_missing")
        }
      }

      for (name in status) {
        print "progress_process_tree_status=" name > "/dev/stderr"
      }
      if (incomplete) {
        exit 2
      }
    }
  '
}

progress_linux_process_identity_from_stat() {
  local stat_file="$1" stat_line stat_tail
  local IFS=' '
  [[ -r "$stat_file" ]] || return 1
  stat_line="$(<"$stat_file")" || return 1
  stat_tail="${stat_line##*) }"
  set -- $stat_tail
  (($# >= 20)) || return 1
  [[ "${20}" =~ ^[0-9]+$ ]] || return 1
  printf 'proc:%s' "${20}"
}

progress_linux_process_table() {
  local stat_file pid stat_line stat_tail ppid identity
  local IFS=' '
  for stat_file in /proc/[0-9]*/stat; do
    [[ -r "$stat_file" ]] || continue
    pid="${stat_file#/proc/}"
    pid="${pid%/stat}"
    [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    stat_line="$(<"$stat_file")" || continue
    stat_tail="${stat_line##*) }"
    set -- $stat_tail
    (($# >= 20)) || continue
    ppid="$2"
    identity="${20}"
    [[ "$ppid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    [[ "$identity" =~ ^[0-9]+$ ]] || continue
    printf '%s %s proc:%s\n' "$pid" "$ppid" "$identity"
  done
}

progress_collect_process_tree() {
  local root="$1" table
  if [[ -r /proc/$$/stat ]]; then
    if ! table="$(progress_linux_process_table)"; then
      printf 'progress_process_tree_status=proc_snapshot_failed\n' >&2
      return 2
    fi
    printf '%s\n' "$table" |
      progress_collect_process_tree_from_table "$root" 3
    return
  fi
  if ! table="$(LC_ALL=C /bin/ps -eo pid=,ppid=,lstart= 2>/dev/null)"; then
    printf 'progress_process_tree_status=ps_failed\n' >&2
    return 2
  fi
  printf '%s\n' "$table" |
    progress_collect_process_tree_from_table "$root" 7
}

progress_process_identity() {
  local pid="$1" identity
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  (( pid > 1 )) || return 1
  if [[ -r "/proc/$pid/stat" ]]; then
    progress_linux_process_identity_from_stat "/proc/$pid/stat"
    return
  fi
  identity="$(
    LC_ALL=C /bin/ps -o lstart= -p "$pid" 2>/dev/null |
      /usr/bin/awk 'NF { $1=$1; print; exit }'
  )"
  [[ -n "$identity" ]] || return 1
  printf 'ps:%s' "$identity"
}

progress_capture_process_identity() {
  local pid="$1" attempt identity
  for ((attempt=0; attempt<10; attempt++)); do
    identity="$(progress_process_identity "$pid" 2>/dev/null || true)"
    if [[ -n "$identity" ]]; then
      printf '%s' "$identity"
      return 0
    fi
    progress_process_is_running "$pid" || return 1
    sleep 0.01
  done
  return 1
}

progress_process_state() {
  local pid="$1" stat_line stat_tail state
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  if [[ -r "/proc/$pid/stat" ]]; then
    stat_line="$(<"/proc/$pid/stat")" || return 1
    stat_tail="${stat_line##*) }"
    state="${stat_tail%% *}"
    [[ "$state" =~ ^[[:alpha:]]$ ]] || return 1
    printf '%s\n' "$state"
    return 0
  fi
  LC_ALL=C /bin/ps -o stat= -p "$pid" 2>/dev/null |
    /usr/bin/awk 'NF { gsub(/[[:space:]]/, ""); print; exit }'
}

progress_process_is_running() {
  local pid="$1" state
  state="$(progress_process_state "$pid")"
  [[ -n "$state" && "$state" != Z* ]]
}

progress_snapshot_has_live_members() {
  local snapshot="$1" trusted_root="$2" trusted_identity="$3"
  local pid identity current mismatch=0
  while IFS=$'\t' read -r pid identity; do
    [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || continue
    (( pid > 1 )) || continue
    if [[ "$pid" == "$trusted_root" ]]; then
      if [[ -n "$trusted_identity" ]]; then
        current="$(progress_process_identity "$pid" 2>/dev/null || true)"
        if [[ -z "$current" ]]; then
          kill -0 "$pid" 2>/dev/null && mismatch=1
          continue
        fi
        if [[ "$current" != "$trusted_identity" ]]; then
          mismatch=1
          continue
        fi
      fi
    else
      current="$(progress_process_identity "$pid" 2>/dev/null || true)"
      if [[ -z "$identity" || -z "$current" ]]; then
        kill -0 "$pid" 2>/dev/null && mismatch=1
        continue
      fi
      if [[ "$current" != "$identity" ]]; then
        mismatch=1
        continue
      fi
    fi
    kill -0 "$pid" 2>/dev/null && return 0
  done <<<"$snapshot"
  (( mismatch == 0 )) || return 2
  return 1
}

progress_signal_process_snapshot() {
  local signal="$1" snapshot="$2" trusted_root="$3" trusted_identity="$4"
  local pass pid identity current rc=0
  [[ "$signal" == TERM || "$signal" == KILL ]] || return 2

  for pass in descendants root; do
    while IFS=$'\t' read -r pid identity; do
      [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || {
        printf 'progress_process_tree_status=invalid_snapshot_pid\n' >&2
        rc=2
        continue
      }
      (( pid > 1 )) || continue
      if [[ "$pass" == descendants && "$pid" == "$trusted_root" ]]; then
        continue
      fi
      if [[ "$pass" == root && "$pid" != "$trusted_root" ]]; then
        continue
      fi

      if [[ "$pid" == "$trusted_root" ]]; then
        # Bash may reap an asynchronous child before an explicit wait, so the
        # root identity is rechecked before every signal just like descendants.
        if [[ "$signal" == KILL && "$trusted_identity" != proc:* ]]; then
          printf 'progress_process_tree_status=weak_root_identity_kill_skipped pid=%s\n' \
            "$pid" >&2
          rc=2
          continue
        fi
        current="$(progress_process_identity "$pid" 2>/dev/null || true)"
        if [[ -z "$trusted_identity" || -z "$current" ]]; then
          if progress_process_is_running "$pid"; then
            printf 'progress_process_tree_status=root_identity_unavailable pid=%s\n' "$pid" >&2
            rc=2
          fi
          continue
        fi
        if [[ "$current" != "$trusted_identity" ]]; then
          printf 'progress_process_tree_status=root_identity_changed pid=%s\n' "$pid" >&2
          rc=2
          continue
        fi
      else
        # Descendant PIDs can be reaped and reused while cleanup waits. Never
        # signal one unless its immutable start identity still matches.
        if [[ "$signal" == KILL && "$identity" != proc:* ]]; then
          printf 'progress_process_tree_status=weak_identity_kill_skipped pid=%s\n' "$pid" >&2
          rc=2
          continue
        fi
        current="$(progress_process_identity "$pid" 2>/dev/null || true)"
        if [[ -z "$identity" || -z "$current" ]]; then
          if kill -0 "$pid" 2>/dev/null; then
            printf 'progress_process_tree_status=descendant_identity_unavailable pid=%s\n' "$pid" >&2
            rc=2
          fi
          continue
        fi
        if [[ "$current" != "$identity" ]]; then
          printf 'progress_process_tree_status=descendant_identity_changed pid=%s\n' "$pid" >&2
          rc=2
          continue
        fi
      fi

      kill -s "$signal" "$pid" 2>/dev/null || true
      [[ "$pass" == root ]] && break
    done <<<"$snapshot"
  done
  return "$rc"
}

progress_terminate_active_child() {
  local pid="$PROGRESS_ACTIVE_CHILD_PID" identity="$PROGRESS_ACTIVE_CHILD_IDENTITY"
  local attempt snapshot state rc=0 live_status=1 snapshot_complete=1
  (( PROGRESS_CHILD_TERMINATION_IN_PROGRESS == 0 )) || return 0
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 0
  (( pid > 1 )) || return 0

  PROGRESS_CHILD_TERMINATION_IN_PROGRESS=1
  PROGRESS_ACTIVE_CHILD_PID=""
  PROGRESS_ACTIVE_CHILD_IDENTITY=""
  if ! snapshot="$(progress_collect_process_tree "$pid")"; then
    snapshot_complete=0
    rc=2
    printf 'progress_process_tree_status=incomplete_snapshot\n' >&2
  fi
  if (( snapshot_complete == 0 )) || [[ -z "$snapshot" ]]; then
    snapshot="${snapshot:+$snapshot$'\n'}$(printf '%s\t%s' "$pid" "$identity")"
  fi

  progress_signal_process_snapshot TERM "$snapshot" "$pid" "$identity" || rc=2
  for ((attempt=0; attempt<10; attempt++)); do
    live_status=0
    progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
      live_status=$?
    if (( live_status != 0 )); then
      (( live_status == 2 )) && rc=2
      break
    fi
    sleep 0.1
  done
  live_status=0
  progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  (( live_status == 2 )) && rc=2
  if (( live_status == 0 )); then
    # Reuse exactly the original identity-bearing snapshot. Emergency cleanup
    # must never re-enter the process-table collector.
    progress_signal_process_snapshot KILL "$snapshot" "$pid" "$identity" || rc=2
    for ((attempt=0; attempt<10; attempt++)); do
      live_status=0
      progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
        live_status=$?
      if (( live_status != 0 )); then
        (( live_status == 2 )) && rc=2
        break
      fi
      sleep 0.1
    done
  fi
  live_status=0
  progress_snapshot_has_live_members "$snapshot" "$pid" "$identity" ||
    live_status=$?
  (( live_status == 2 )) && rc=2
  if (( live_status == 0 )); then
    printf 'progress_process_tree_status=cleanup_incomplete\n' >&2
    rc=2
  fi
  state="$(progress_process_state "$pid")"
  if [[ "$state" == Z* ]] || ! kill -0 "$pid" 2>/dev/null; then
    wait "$pid" 2>/dev/null || true
  else
    printf 'progress_process_tree_status=direct_child_not_reapable pid=%s state=%s\n' \
      "$pid" "${state:-unknown}" >&2
    rc=2
  fi
  # A portable PPID snapshot cannot prove that the command did not fork a new
  # descendant after the snapshot. The bounded cleanup is safe, but only an
  # outer owned session can certify zero leaks.
  printf 'progress_process_tree_status=single_snapshot_boundary\n' >&2
  rc=2
  PROGRESS_CHILD_TERMINATION_IN_PROGRESS=0
  return "$rc"
}

progress_queue_signal() {
  local signal="$1" report_path="${2:-недоступен}"
  if [[ -z "$PROGRESS_PENDING_SIGNAL" ]]; then
    PROGRESS_PENDING_SIGNAL="$signal"
    PROGRESS_PENDING_SIGNAL_REPORT="$report_path"
  fi
}

progress_dispatch_pending_signal() {
  local signal report_path
  [[ -n "$PROGRESS_PENDING_SIGNAL" ]] || return 0
  signal="$PROGRESS_PENDING_SIGNAL"
  report_path="${PROGRESS_PENDING_SIGNAL_REPORT:-недоступен}"
  PROGRESS_PENDING_SIGNAL=""
  PROGRESS_PENDING_SIGNAL_REPORT=""
  progress_signal "$signal" "$report_path"
}

progress_stat_uid() {
  if declare -F audit_stat_uid >/dev/null 2>&1; then
    audit_stat_uid "$1"
    return
  fi
  /usr/bin/stat -c %u -- "$1" 2>/dev/null ||
    /usr/bin/stat -f %u "$1" 2>/dev/null
}

progress_stat_mode() {
  local mode
  if declare -F audit_stat_mode >/dev/null 2>&1; then
    audit_stat_mode "$1"
    return
  fi
  if mode="$(/usr/bin/stat -c %a -- "$1" 2>/dev/null)"; then
    printf '%s\n' "$mode"
    return 0
  fi
  mode="$(/usr/bin/stat -f %Op "$1" 2>/dev/null)" || return 1
  [[ "$mode" =~ ^[0-7]+$ ]] || return 1
  (( ${#mode} <= 4 )) || mode="${mode: -4}"
  mode="${mode#0}"
  printf '%s\n' "$mode"
}

progress_runtime_dir_is_safe() {
  local runtime_dir="$1" owner mode
  case "$runtime_dir" in
    /*) ;;
    *) return 2 ;;
  esac
  case "$runtime_dir" in
    /|*/|*//*|*/./*|*/../*|*/.|*/..) return 2 ;;
  esac
  [[ -d "$runtime_dir" && ! -L "$runtime_dir" ]] || return 2
  owner="$(progress_stat_uid "$runtime_dir" 2>/dev/null || true)"
  mode="$(progress_stat_mode "$runtime_dir" 2>/dev/null || true)"
  [[ "$owner" == "$EUID" && "$mode" == 700 ]]
}

progress_child_guard_file_is_safe() {
  local path="$1" owner mode
  [[ -f "$path" && ! -L "$path" ]] || return 2
  owner="$(progress_stat_uid "$path" 2>/dev/null || true)"
  mode="$(progress_stat_mode "$path" 2>/dev/null || true)"
  [[ "$owner" == "$EUID" && "$mode" == 600 ]]
}

progress_child_guard_paths_valid() {
  local guard_dir="$1" guard_ready="$2" guard_release="$3"
  local expected_guard_dir owner mode
  progress_runtime_dir_is_safe "$PROGRESS_RUNTIME_DIR" || return 2
  expected_guard_dir="$PROGRESS_RUNTIME_DIR/.server-toolkit-child-guard"
  [[ "$guard_dir" == "$expected_guard_dir" &&
     "$guard_ready" == "$expected_guard_dir/ready" &&
     "$guard_release" == "$expected_guard_dir/release" &&
     -d "$guard_dir" &&
     ! -L "$guard_dir" ]] || return 2
  owner="$(progress_stat_uid "$guard_dir" 2>/dev/null || true)"
  mode="$(progress_stat_mode "$guard_dir" 2>/dev/null || true)"
  [[ "$owner" == "$EUID" && "$mode" == 700 ]] || return 2
  if [[ -e "$guard_ready" || -L "$guard_ready" ]]; then
    progress_child_guard_file_is_safe "$guard_ready" || return 2
  fi
  if [[ -e "$guard_release" || -L "$guard_release" ]]; then
    progress_child_guard_file_is_safe "$guard_release" || return 2
  fi
}

progress_remove_new_child_guard() {
  local guard_dir="$1" guard_ready="$2" guard_release="$3"
  local ready_created="$4" release_created="$5"
  progress_child_guard_paths_valid \
    "$guard_dir" "$guard_ready" "$guard_release" || return 2
  if (( ready_created == 1 )); then
    rm -f -- "$guard_ready" || return 2
  fi
  if (( release_created == 1 )); then
    rm -f -- "$guard_release" || return 2
  fi
  rmdir -- "$guard_dir" || return 2
}

progress_remove_child_guard() {
  local guard_dir="$PROGRESS_CHILD_GUARD_DIR"
  local guard_ready="$PROGRESS_CHILD_GUARD_READY"
  local guard_release="$PROGRESS_CHILD_GUARD_RELEASE"
  if [[ -z "$guard_dir" ]]; then
    [[ -z "$guard_ready" && -z "$guard_release" ]] || {
      printf 'progress_process_tree_status=incomplete_child_guard_paths\n' >&2
      return 2
    }
    return 0
  fi
  if ! progress_child_guard_paths_valid \
    "$guard_dir" "$guard_ready" "$guard_release"; then
    printf 'progress_process_tree_status=invalid_child_guard_paths\n' >&2
    return 2
  fi
  rm -f -- "$guard_ready" "$guard_release" || return 2
  rmdir -- "$guard_dir" || return 2
  PROGRESS_CHILD_GUARD_DIR=""
  PROGRESS_CHILD_GUARD_READY=""
  PROGRESS_CHILD_GUARD_RELEASE=""
}

progress_abort_child_guard() {
  local pid="$1" guard_ready="$2" guard_release="$3"
  local ready_attempt exit_attempt exit_started guard_status="" state="" absent_checks=0
  [[ "$pid" =~ ^(0|[1-9][0-9]*)$ ]] || return 2
  (( pid > 1 )) || return 2
  [[ "$guard_ready" == "$PROGRESS_CHILD_GUARD_READY" &&
     "$guard_release" == "$PROGRESS_CHILD_GUARD_RELEASE" &&
     -n "$PROGRESS_CHILD_GUARD_DIR" ]] || return 2
  printf 'abort\n' >"$guard_release" || return 2
  for ((ready_attempt=0; ready_attempt<500; ready_attempt++)); do
    if [[ -s "$guard_ready" ]]; then
      IFS= read -r guard_status <"$guard_ready" || true
      if [[ "$guard_status" == aborted ]]; then
        exit_started=$SECONDS
        for ((exit_attempt=0; exit_attempt<100; exit_attempt++)); do
          if (( SECONDS - exit_started >= 2 )); then
            break
          fi
          state="$(progress_process_state "$pid")"
          if [[ "$state" == Z* ]]; then
            wait "$pid" 2>/dev/null || true
            return 0
          fi
          if [[ -z "$state" ]] && ! kill -0 "$pid" 2>/dev/null; then
            absent_checks=$((absent_checks + 1))
            if (( absent_checks >= 2 )); then
              wait "$pid" 2>/dev/null || true
              return 0
            fi
          else
            absent_checks=0
          fi
          sleep 0.01
        done
        printf 'progress_process_tree_status=child_guard_exit_incomplete\n' >&2
        return 2
      fi
    fi
    sleep 0.01
  done
  printf 'progress_process_tree_status=child_guard_abort_incomplete\n' >&2
  return 2
}

progress_validate_stage_timeout() {
  local value="${CURRENT_STAGE_TIMEOUT-}"
  [[ "$value" =~ ^[1-9][0-9]?[0-9]?$ ]] || return 1
  (( value <= 120 )) || return 1
  printf '%s\n' "$value"
}

progress_run_child() {
  local rc=0 pid guard_status="" attempt cleanup_rc=0
  local timed_out=0 timeout_seconds timeout_ticks tick
  local guard_dir guard_ready guard_release
  local guard_ready_created=0 guard_release_created=0
  timeout_seconds="$(progress_validate_stage_timeout)" || return 125
  timeout_ticks=$((timeout_seconds * 10))
  (( PROGRESS_CLEANUP_IN_PROGRESS == 0 && PROGRESS_CLEANUP_DONE == 0 )) || return 125
  progress_runtime_dir_is_safe "$PROGRESS_RUNTIME_DIR" || return 125
  [[ -z "$PROGRESS_ACTIVE_CHILD_PID" ]] || {
    printf 'progress_process_tree_status=previous_child_cleanup_incomplete\n' >&2
    return 125
  }
  [[ -z "$PROGRESS_CHILD_GUARD_DIR" &&
     -z "$PROGRESS_CHILD_GUARD_READY" &&
     -z "$PROGRESS_CHILD_GUARD_RELEASE" ]] || {
    printf 'progress_process_tree_status=previous_child_guard_incomplete\n' >&2
    return 125
  }
  progress_dispatch_pending_signal
  PROGRESS_CHILD_STARTING=1
  # The caller creates one private, single-writer runtime directory per audit.
  # That invariant makes this fixed name unique without a global /tmp class.
  guard_dir="$PROGRESS_RUNTIME_DIR/.server-toolkit-child-guard"
  guard_ready="$guard_dir/ready"
  guard_release="$guard_dir/release"
  if ! mkdir -m 700 -- "$guard_dir" 2>/dev/null; then
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  if ! progress_child_guard_paths_valid \
    "$guard_dir" "$guard_ready" "$guard_release"; then
    # The parent was verified immediately before our atomic mkdir. If the
    # post-create metadata check fails, remove only that exact empty directory.
    rmdir -- "$guard_dir" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  if ! (umask 077; set -o noclobber; : >"$guard_ready"); then
    progress_remove_new_child_guard \
      "$guard_dir" "$guard_ready" "$guard_release" \
      "$guard_ready_created" "$guard_release_created" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  guard_ready_created=1
  if ! (umask 077; set -o noclobber; : >"$guard_release"); then
    progress_remove_new_child_guard \
      "$guard_dir" "$guard_ready" "$guard_release" \
      "$guard_ready_created" "$guard_release_created" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  guard_release_created=1
  if ! progress_child_guard_paths_valid \
       "$guard_dir" "$guard_ready" "$guard_release" ||
     ! progress_child_guard_file_is_safe "$guard_ready" ||
     ! progress_child_guard_file_is_safe "$guard_release"; then
    progress_remove_new_child_guard \
      "$guard_dir" "$guard_ready" "$guard_release" \
      "$guard_ready_created" "$guard_release_created" 2>/dev/null || true
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  PROGRESS_CHILD_GUARD_DIR="$guard_dir"
  PROGRESS_CHILD_GUARD_READY="$guard_ready"
  PROGRESS_CHILD_GUARD_RELEASE="$guard_release"
  (
    trap - ERR HUP INT TERM EXIT
    printf 'ready\n' >"$guard_ready" || exit 125
    for ((attempt=0; attempt<500; attempt++)); do
      guard_status=""
      if [[ -s "$guard_release" ]]; then
        IFS= read -r guard_status <"$guard_release" || true
        case "$guard_status" in
          release)
            break
            ;;
          abort)
            printf 'aborted\n' >"$guard_ready" || exit 125
            exit 125
            ;;
        esac
      fi
      sleep 0.01
    done
    if [[ "$guard_status" != release ]]; then
      printf 'expired\n' >"$guard_ready" 2>/dev/null || true
      exit 125
    fi
    "$@"
  ) &
  pid=$!
  PROGRESS_ACTIVE_CHILD_PID="$pid"
  for ((attempt=0; attempt<500; attempt++)); do
    if [[ -s "$guard_ready" ]]; then
      IFS= read -r guard_status <"$guard_ready" || true
      [[ "$guard_status" == ready ]] && break
    fi
    sleep 0.01
  done
  if [[ "$guard_status" != ready ]]; then
    printf 'progress_process_tree_status=child_guard_handshake_failed\n' >&2
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    (( cleanup_rc == 0 )) || return 125
    return 125
  fi
  PROGRESS_ACTIVE_CHILD_IDENTITY="$(
    progress_capture_process_identity "$pid" 2>/dev/null || true
  )"
  if [[ -z "$PROGRESS_ACTIVE_CHILD_IDENTITY" ]]; then
    printf 'progress_process_tree_status=child_guard_identity_unavailable\n' >&2
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    (( cleanup_rc == 0 )) || return 125
    return 125
  fi
  if [[ -n "$PROGRESS_PENDING_SIGNAL" ]]; then
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  if ! printf 'release\n' >"$guard_release"; then
    progress_abort_child_guard "$pid" "$guard_ready" "$guard_release" ||
      cleanup_rc=2
    if (( cleanup_rc == 0 )); then
      PROGRESS_ACTIVE_CHILD_PID=""
      PROGRESS_ACTIVE_CHILD_IDENTITY=""
      progress_remove_child_guard || cleanup_rc=2
    fi
    PROGRESS_CHILD_STARTING=0
    progress_dispatch_pending_signal
    return 125
  fi
  PROGRESS_CHILD_STARTING=0
  progress_dispatch_pending_signal
  for ((tick=0; tick<timeout_ticks; tick++)); do
    progress_process_is_running "$pid" || break
    sleep 0.1
  done
  if progress_process_is_running "$pid"; then
    timed_out=1
  fi
  if (( timed_out == 1 )); then
    progress_terminate_active_child || cleanup_rc=$?
    progress_remove_child_guard || cleanup_rc=2
    if (( cleanup_rc != 0 )); then
      printf 'progress_timeout_cleanup_status=unverified rc=%s\n' \
        "$cleanup_rc" >&2
    fi
    return 124
  fi
  wait "$pid" || rc=$?
  PROGRESS_ACTIVE_CHILD_PID=""
  PROGRESS_ACTIVE_CHILD_IDENTITY=""
  progress_remove_child_guard || return 125
  return "$rc"
}

progress_cleanup() {
  local rc=0 heartbeat_dead=0 presentation_contained=0
  (( PROGRESS_CLEANUP_IN_PROGRESS == 0 )) || return 0
  (( PROGRESS_CLEANUP_DONE == 0 )) || return "${PROGRESS_CLEANUP_STATUS:-0}"
  PROGRESS_CLEANUP_IN_PROGRESS=1
  progress_terminate_active_child || rc=2
  if progress_stop_heartbeat; then
    heartbeat_dead=1
  else
    rc=2
    SONAR_PRESENTATION_READY=0
  fi
  if (( heartbeat_dead == 1 )); then
    if sonar_heartbeat_updates_disabled; then
      SONAR_PRESENTATION_READY=0
      PROGRESS_INTERACTIVE=0
    fi
    sonar_screen_restore || rc=2
    trap - WINCH
    progress_cursor_show
  elif [[ -n "$SONAR_RENDER_LOCK_DIR" ]] && sonar_render_lock_acquire; then
    if sonar_disable_heartbeat_updates; then
      presentation_contained=1
      sonar_screen_restore || rc=2
      trap - WINCH
    fi
    sonar_render_lock_release || rc=2
  fi
  if [[ -n "$PROGRESS_STATE_FILE" ]]; then
    rm -f "$PROGRESS_STATE_FILE" "${PROGRESS_STATE_FILE}.tmp.$$" 2>/dev/null || true
  fi
  if declare -F audit_cleanup_private_scratch >/dev/null 2>&1; then
    audit_cleanup_private_scratch || rc=2
  fi
  if (( heartbeat_dead == 1 )); then
    sonar_runtime_cleanup || rc=2
  elif (( presentation_contained == 0 )); then
    # A possibly live heartbeat may still write. Leave its coordination state
    # intact and do not emit terminal restoration after this point.
    rc=2
  fi
  progress_remove_child_guard || rc=2
  PROGRESS_CLEANUP_STATUS="$rc"
  PROGRESS_CLEANUP_DONE=1
  PROGRESS_CLEANUP_IN_PROGRESS=0
  if (( PROGRESS_SIGNAL_IN_PROGRESS == 0 )); then
    progress_dispatch_pending_signal
  fi
  return "$rc"
}

progress_exit_cleanup() {
  local original_rc=$? cleanup_rc=0
  progress_cleanup || cleanup_rc=$?
  if (( cleanup_rc != 0 && original_rc == 0 )); then
    return "$cleanup_rc"
  fi
  return "$original_rc"
}

progress_complete() {
  local now reset cleanup_rc=0
  (( PROGRESS_ACTIVE == 1 )) || return 0
  progress_finish_stage 100 || cleanup_rc=2
  now="$(date +%s)"
  progress_write_state 100 "Отчёт готов" "$now" 8
  progress_cleanup || cleanup_rc=2
  if (( cleanup_rc != 0 )); then
    SONAR_PRESENTATION_READY=0
    PROGRESS_ACTIVE=0
    return "$cleanup_rc"
  fi
  reset="$(progress_colour reset)"
  printf '\n%sГотово: %s/%s%s\n' "$(progress_colour green)" "$PROGRESS_COMPLETED_STAGES" "$PROGRESS_TOTAL_STAGES" "$reset" >&2
  PROGRESS_ACTIVE=0
  return "$cleanup_rc"
}

progress_fail() {
  local reason="$1" action="$2" report_path="${3:-недоступен}" reset cleanup_rc=0
  # shellcheck disable=SC2034 # consumed by sourced Sonar presentation helpers
  SONAR_PRESENTATION_READY=0
  progress_cleanup || cleanup_rc=$?
  reset="$(progress_colour reset)"
  progress_render_committed_line "$PROGRESS_STAGE" error
  printf '\n%sОШИБКА%s\n' "$(progress_colour red)" "$reset" >&2
  printf 'Прогресс: %s%%\nЭтап: %s\nПричина: %s\nЧто делать: %s\nОтчёт: %s\n' \
    "$PROGRESS_PERCENT" "$PROGRESS_STAGE" "$reason" "$action" "$report_path" >&2
  PROGRESS_ACTIVE=0
  return "$cleanup_rc"
}

progress_signal() {
  local signal="$1" report_path="${2:-недоступен}" cleanup_rc=0
  if (( PROGRESS_CHILD_STARTING == 1 || PROGRESS_HEARTBEAT_STARTING == 1 ||
        PROGRESS_CLEANUP_IN_PROGRESS == 1 ||
        PROGRESS_SIGNAL_IN_PROGRESS == 1 )); then
    progress_queue_signal "$signal" "$report_path"
    return 0
  fi
  PROGRESS_SIGNAL_IN_PROGRESS=1
  PROGRESS_SIGNAL_REPORT_PATH="$report_path"
  trap 'progress_queue_signal HUP "$PROGRESS_SIGNAL_REPORT_PATH"' HUP
  trap 'progress_queue_signal INT "$PROGRESS_SIGNAL_REPORT_PATH"' INT
  trap 'progress_queue_signal TERM "$PROGRESS_SIGNAL_REPORT_PATH"' TERM
  progress_fail \
    "Выполнение прервано сигналом $signal" \
    "Повторить audit; если остановка повторится, прислать последний этап и отчёт" \
    "$report_path" || cleanup_rc=$?
  if (( cleanup_rc != 0 )); then
    printf 'progress_cleanup_status=incomplete rc=%s\n' "$cleanup_rc" >&2
  fi
  trap '' HUP INT TERM
  [[ "$signal" == HUP ]] && exit 129
  [[ "$signal" == INT ]] && exit 130
  exit 143
}

#!/usr/bin/env bash
# Platform-family contract for the audit-only candidate.
# The builder embeds this module; its public state is consumed by the engine.
# shellcheck disable=SC2034

PLATFORM_CONTRACT_VERSION=2
PLATFORM_SUPPORTED_FAMILIES="ubuntu,debian"
PLATFORM_VALIDATED_LIST="ubuntu:24.04,ubuntu:26.04,debian:12"
# Backward-compatible alias retained for existing report consumers.
PLATFORM_SUPPORTED_LIST="ubuntu:24.04,ubuntu:26.04,debian:12"
PLATFORM_ID=unavailable
PLATFORM_VERSION_ID=unavailable
PLATFORM_SUPPORT_STATUS=unavailable
PLATFORM_SUPPORT_REASON=os_release_unavailable
PLATFORM_VALIDATION_STATUS=unavailable

platform_os_release_value() {
  local file="$1" key="$2"
  [[ -r "$file" ]] || return 1
  awk -v key="$key" '
    index($0,key "=")==1 {
      count++
      value=substr($0,length(key)+2)
      if (value ~ /^".*"$/ || value ~ /^\047.*\047$/) {
        value=substr(value,2,length(value)-2)
      }
      selected=value
    }
    END {
      if (count == 1) {
        print selected
      }
    }
  ' "$file"
}

platform_evaluate() {
  local file="${1:-/etc/os-release}" id version
  PLATFORM_ID=unavailable
  PLATFORM_VERSION_ID=unavailable
  PLATFORM_SUPPORT_STATUS=unavailable
  PLATFORM_SUPPORT_REASON=os_release_unavailable
  PLATFORM_VALIDATION_STATUS=unavailable

  [[ -r "$file" ]] || return 3
  id="$(platform_os_release_value "$file" ID 2>/dev/null || true)"
  version="$(platform_os_release_value "$file" VERSION_ID 2>/dev/null || true)"
  id="$(printf '%s' "$id" | tr '[:upper:]' '[:lower:]')"

  [[ "$id" =~ ^[a-z0-9._-]+$ ]] || id=unavailable
  [[ "$version" =~ ^[0-9]+([.][0-9]+)*$ ]] || version=unavailable
  PLATFORM_ID="$id"
  PLATFORM_VERSION_ID="$version"

  case "$id:$version" in
    ubuntu:24.04|ubuntu:26.04|debian:12)
      PLATFORM_SUPPORT_STATUS=supported
      PLATFORM_SUPPORT_REASON=matched_supported_release
      PLATFORM_VALIDATION_STATUS=validated
      return 0
      ;;
    unavailable:*)
      PLATFORM_SUPPORT_STATUS=unavailable
      PLATFORM_SUPPORT_REASON=os_identity_unavailable
      ;;
    *:unavailable)
      PLATFORM_SUPPORT_STATUS=unavailable
      PLATFORM_SUPPORT_REASON=os_version_unavailable
      ;;
    ubuntu:*|debian:*)
      PLATFORM_SUPPORT_STATUS=compatible_unverified
      PLATFORM_SUPPORT_REASON=recognized_family_unvalidated_release
      PLATFORM_VALIDATION_STATUS=unverified
      return 0
      ;;
    *)
      PLATFORM_SUPPORT_STATUS=unsupported
      PLATFORM_SUPPORT_REASON=distribution_not_in_contract
      ;;
  esac
  return 3
}

platform_assert_supported() {
  local file="${1:-/etc/os-release}" rc=0
  platform_evaluate "$file" || rc=$?
  if (( rc == 0 )); then
    return 0
  fi
  printf 'Неподдерживаемая платформа: %s %s. Запуск разрешён для выпусков Ubuntu и Debian; полностью проверены: Ubuntu 24.04, Ubuntu 26.04 и Debian 12.\n' \
    "$PLATFORM_ID" "$PLATFORM_VERSION_ID" >&2
  return 3
}

#!/usr/bin/env bash
# Stable command-line contract for the audit-only Expert Beta candidate.

audit_only_print_version() {
  printf 'Server Toolkit %s\n' "$VERSION"
  printf 'build=audit-only\n'
  printf 'diagnostic_schema_version=%s\n' "$DIAGNOSTIC_SCHEMA_VERSION"
  printf 'diagnostic_method_version=%s\n' "$DIAGNOSTIC_METHOD_VERSION"
  printf 'findings_schema_version=%s\n' "$FINDINGS_SCHEMA_VERSION"
  printf 'platform_contract_version=%s\n' "$PLATFORM_CONTRACT_VERSION"
  printf 'supported_platform_families=%s\n' "$PLATFORM_SUPPORTED_FAMILIES"
  printf 'validated_platforms=%s\n' "$PLATFORM_VALIDATED_LIST"
}

audit_only_print_help() {
  cat <<EOF
Server Toolkit — безопасный audit Linux VPS

Использование:
  /usr/bin/sudo -- /usr/local/lib/server-toolkit/server-toolkit-audit-v1.sh audit
  server-toolkit --help
  server-toolkit --version

Команды:
  audit       Выполнить ограниченную read-only диагностику.
  --help      Показать эту справку без запуска диагностики.
  --version   Показать версию и версии машинных контрактов.

Поддерживаемые платформы:
  Выпуски Ubuntu и Debian.
  Полностью проверены: Ubuntu 24.04, Ubuntu 26.04, Debian 12.
  На остальных выпусках audit запускается с LIMITED confidence и явной
  отметкой, что конкретный выпуск ещё не прошёл полную матрицу проверки.

Коды завершения:
  0    Команда технически завершена; итог здоровья смотри в verdict отчёта.
  1    Ошибка запуска, зависимости, сбора или формирования отчёта.
  2    Неверная команда или аргументы.
  3    Система не относится к Ubuntu/Debian или её версия не распознана.
  129  Выполнение прервано сигналом HUP (например, при разрыве терминала).
  130  Выполнение прервано сигналом INT (обычно Ctrl-C).
  143  Выполнение остановлено сигналом TERM.

Routine audit не устанавливает пакеты, не перезапускает службы,
не меняет firewall, SSH, сеть, VPN-конфигурацию и не выполняет disk benchmark.
Привилегированный audit разрешён только из предварительно проверенной,
root-owned установленной копии. Не используй sudo bash, sudo -E или curl | bash.
EOF
}

audit_only_print_usage_error() {
  printf 'Использование: server-toolkit [audit|--help|--version]\n' >&2
}

#!/usr/bin/env bash
# Bounded read-only CPU, load and I/O-pressure diagnostics.

CPU_SAMPLE_COUNT=5
CPU_SAMPLE_INTERVAL_SECONDS=2
IOWAIT_WARN_THRESHOLD=10.00
STEAL_WARN_THRESHOLD=5.00
LOAD_PER_VCPU_WARN_THRESHOLD=2.00

cpu_read_stat() {
  awk '/^cpu /{print $2,$3,$4,$5,$6,$7,$8,$9; exit}' /proc/stat 2>/dev/null
}

cpu_wait_interval() {
  sleep "$1"
}

cpu_read_loadavg() {
  awk '{print $1,$2,$3}' /proc/loadavg 2>/dev/null
}

cpu_read_vcpu_count() {
  if command -v nproc >/dev/null 2>&1; then nproc; else getconf _NPROCESSORS_ONLN 2>/dev/null; fi
}

cpu_read_io_pressure() {
  [[ -r /proc/pressure/io ]] || return 1
  awk '
    $1=="some" {for(i=2;i<=NF;i++) if($i~/^avg10=/){sub(/^avg10=/,"",$i); some=$i}}
    $1=="full" {for(i=2;i<=NF;i++) if($i~/^avg10=/){sub(/^avg10=/,"",$i); full=$i}}
    END {
      if(some=="") exit 1
      printf "%s %s\n",some,(full=="" ? "unavailable" : full)
    }' /proc/pressure/io 2>/dev/null
}

cpu_pair_percentages() {
  local before="$1" after="$2"
  awk -v before="$before" -v after="$after" 'BEGIN {
    if(split(before,A," ")!=8 || split(after,B," ")!=8) exit 1
    total=0
    for(i=1;i<=8;i++) {
      if(A[i] !~ /^[0-9]+$/ || B[i] !~ /^[0-9]+$/ || B[i]<A[i]) exit 1
      D[i]=B[i]-A[i]
      total+=D[i]
    }
    if(total<=0) exit 1
    printf "%.2f %.2f\n",100*D[5]/total,100*D[8]/total
  }'
}

cpu_metric_stats() {
  local prefix="$1" threshold="$2"
  shift 2
  printf '%s\n' "$@" | awk -v prefix="$prefix" -v threshold="$threshold" '
    function sort_values( i,j,t) {
      for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) if(v[j]<v[i]) {t=v[i];v[i]=v[j];v[j]=t}
    }
    /^[0-9]+([.][0-9]+)?$/ {
      v[++n]=$1
      sum+=$1
      if($1>threshold) exceed++
    }
    END {
      if(n==0) exit 1
      sort_values()
      if(n%2) median=v[(n+1)/2]; else median=(v[n/2]+v[n/2+1])/2
      printf "%s_min_pct=%.2f\n",prefix,v[1]
      printf "%s_median_pct=%.2f\n",prefix,median
      printf "%s_average_pct=%.2f\n",prefix,sum/n
      printf "%s_max_pct=%.2f\n",prefix,v[n]
      printf "%s_threshold_pct=%.2f\n",prefix,threshold
      printf "%s_threshold_exceedance_count=%d\n",prefix,exceed+0
    }'
}

resource_pattern() {
  local exceedances="${1:-0}" samples="${2:-0}"
  if (( samples <= 0 || exceedances <= 0 )); then printf 'not_observed'
  elif (( exceedances == 1 )); then printf 'isolated'
  elif (( exceedances < samples )); then printf 'repeated'
  else printf 'sustained'
  fi
}

resource_confidence() {
  local status="${1:-unavailable}" exceedances="${2:-0}" samples="${3:-0}"
  if [[ "$status" != ok ]]; then printf 'LOW'
  elif (( exceedances >= 3 && exceedances == samples )); then printf 'HIGH'
  elif (( exceedances >= 2 )); then printf 'MEDIUM'
  else printf 'LOW'
  fi
}

sample_cpu() {
  local requested="$CPU_SAMPLE_COUNT" interval="$CPU_SAMPLE_INTERVAL_SECONDS"
  local before after pair i iowait steal status duration loadavg vcpus pressure load_per_vcpu
  local load1 load5 load15 pressure_some pressure_full
  local -a iowaits=() steals=()

  printf 'cpu_sample_method=proc_stat_delta_windows\n'
  printf 'cpu_sample_count_requested=%s\n' "$requested"
  printf 'cpu_sample_interval_seconds=%s\n' "$interval"
  before="$(cpu_read_stat || true)"

  for ((i=1; i<=requested; i++)); do
    cpu_wait_interval "$interval"
    after="$(cpu_read_stat || true)"
    pair="$(cpu_pair_percentages "$before" "$after" 2>/dev/null || true)"
    before="$after"
    [[ -n "$pair" ]] || continue
    IFS=' ' read -r iowait steal <<<"$pair"
    iowaits+=("$iowait")
    steals+=("$steal")
    printf 'cpu_sample_%s_iowait_pct=%s\n' "${#iowaits[@]}" "$iowait"
    printf 'cpu_sample_%s_steal_pct=%s\n' "${#steals[@]}" "$steal"
  done

  duration=$(( requested * interval ))
  if (( ${#iowaits[@]} == requested )); then status=ok
  elif (( ${#iowaits[@]} > 0 )); then status=partial
  else status=unavailable
  fi
  printf 'cpu_sample_status=%s\n' "$status"
  printf 'cpu_sample_count=%s\n' "${#iowaits[@]}"
  printf 'cpu_sample_duration_seconds=%s\n' "$duration"

  if (( ${#iowaits[@]} > 0 )); then
    cpu_metric_stats iowait "$IOWAIT_WARN_THRESHOLD" "${iowaits[@]}"
    cpu_metric_stats steal "$STEAL_WARN_THRESHOLD" "${steals[@]}"
    printf 'iowait_pct=%s\n' "$(printf '%s\n' "${iowaits[@]}" | sort -n | tail -1)"
    printf 'steal_pct=%s\n' "$(printf '%s\n' "${steals[@]}" | sort -n | tail -1)"
    printf 'cpu_verdict_statistic=maximum\n'
  else
    printf 'iowait_pct=unavailable\nsteal_pct=unavailable\n'
    printf 'iowait_min_pct=unavailable\niowait_median_pct=unavailable\niowait_average_pct=unavailable\niowait_max_pct=unavailable\n'
    printf 'iowait_threshold_pct=%s\niowait_threshold_exceedance_count=unavailable\n' "$IOWAIT_WARN_THRESHOLD"
    printf 'steal_min_pct=unavailable\nsteal_median_pct=unavailable\nsteal_average_pct=unavailable\nsteal_max_pct=unavailable\n'
    printf 'steal_threshold_pct=%s\nsteal_threshold_exceedance_count=unavailable\n' "$STEAL_WARN_THRESHOLD"
    printf 'cpu_verdict_statistic=unavailable\n'
  fi

  loadavg="$(cpu_read_loadavg || true)"
  vcpus="$(cpu_read_vcpu_count || true)"
  if [[ "$loadavg" =~ ^[0-9]+([.][0-9]+)?\ [0-9]+([.][0-9]+)?\ [0-9]+([.][0-9]+)?$ && "$vcpus" =~ ^[1-9][0-9]*$ ]]; then
    IFS=' ' read -r load1 load5 load15 <<<"$loadavg"
    load_per_vcpu="$(awk -v load_value="$load1" -v cpu="$vcpus" 'BEGIN{printf "%.2f",load_value/cpu}')"
    printf 'load_sample_status=ok\nvcpu_count=%s\nload_1m=%s\nload_5m=%s\nload_15m=%s\nload_1m_per_vcpu=%s\nload_1m_per_vcpu_threshold=%s\n' \
      "$vcpus" "$load1" "$load5" "$load15" "$load_per_vcpu" "$LOAD_PER_VCPU_WARN_THRESHOLD"
  else
    printf 'load_sample_status=unavailable\nvcpu_count=unavailable\nload_1m=unavailable\nload_5m=unavailable\nload_15m=unavailable\nload_1m_per_vcpu=unavailable\nload_1m_per_vcpu_threshold=%s\n' \
      "$LOAD_PER_VCPU_WARN_THRESHOLD"
  fi

  pressure="$(cpu_read_io_pressure || true)"
  if [[ -n "$pressure" ]]; then
    IFS=' ' read -r pressure_some pressure_full <<<"$pressure"
    printf 'io_pressure_status=ok\nio_pressure_some_avg10_pct=%s\nio_pressure_full_avg10_pct=%s\n' "$pressure_some" "$pressure_full"
  else
    printf 'io_pressure_status=unavailable\nio_pressure_some_avg10_pct=unavailable\nio_pressure_full_avg10_pct=unavailable\n'
  fi
}

#!/usr/bin/env bash
# Bounded read-only root-filesystem and backing-device diagnostics.

# The builder embeds this module; the summary module consumes these public thresholds.
# shellcheck disable=SC2034
STORAGE_SAMPLE_COUNT=5
STORAGE_SAMPLE_INTERVAL_SECONDS=1
STORAGE_COMMAND_TIMEOUT_SECONDS=5
STORAGE_MIN_OPS_PER_WINDOW=5
STORAGE_AWAIT_WARN_MS=50.00
STORAGE_UTIL_WARN_PCT=90.00
STORAGE_QUEUE_WARN=2.00
STORAGE_FS_WARN_PCT=90
STORAGE_FS_CRITICAL_PCT=95
STORAGE_INODE_WARN_PCT=90
STORAGE_INODE_CRITICAL_PCT=95

storage_run_bounded() {
  command -v timeout >/dev/null 2>&1 || return 127
  timeout --signal=TERM --kill-after=2s "${STORAGE_COMMAND_TIMEOUT_SECONDS}s" "$@"
}

storage_read_root_mount() {
  if command -v findmnt >/dev/null 2>&1; then
    storage_run_bounded findmnt -n -o SOURCE,FSTYPE,OPTIONS,TARGET / 2>/dev/null
    return
  fi
  awk '$2=="/" {print $1, $3, $4, $2; exit}' /proc/mounts 2>/dev/null
}

storage_read_root_space() {
  storage_run_bounded df -Pk / 2>/dev/null | awk 'NR==2 {
    used=$3+0; total=$2+0; available=$4+0
    pct=$5; gsub(/%/,"",pct)
    if(pct !~ /^[0-9]+$/) exit 1
    printf "%d %d %d %d\n",total,used,available,pct
  }'
}

storage_read_root_inodes() {
  storage_run_bounded df -Pi / 2>/dev/null | awk 'NR==2 {
    total=$2+0; used=$3+0; available=$4+0
    pct=$5; gsub(/%/,"",pct)
    if(pct !~ /^[0-9]+$/) exit 1
    printf "%d %d %d %d\n",total,used,available,pct
  }'
}

storage_resolve_device() {
  local source="$1" kname=""
  [[ "$source" == /dev/* ]] || return 1
  if command -v lsblk >/dev/null 2>&1; then
    kname="$(storage_run_bounded lsblk -ndo KNAME "$source" 2>/dev/null | head -1 || true)"
  fi
  if [[ -z "$kname" ]]; then
    kname="$(basename "$(readlink -f "$source" 2>/dev/null || printf '%s' "$source")")"
  fi
  [[ -n "$kname" && -r "/sys/class/block/$kname/stat" ]] || return 1
  printf '%s\n' "$kname"
}

storage_read_device_stat() {
  local device="$1"
  [[ "$device" =~ ^[A-Za-z0-9._!+-]+$ ]] || return 1
  awk '{for(i=1;i<=11;i++){if($i !~ /^[0-9]+$/) exit 1; printf "%s%s",$i,(i==11?ORS:OFS)}}' \
    "/sys/class/block/$device/stat" 2>/dev/null
}

storage_wait_interval() {
  sleep "$1"
}

storage_pair_metrics() {
  local before="$1" after="$2" interval_ms="$3" minimum_ops="$4"
  awk -v before="$before" -v after="$after" -v interval_ms="$interval_ms" -v minimum_ops="$minimum_ops" 'BEGIN {
    if(split(before,A," ")<11 || split(after,B," ")<11) exit 1
    for(i=1;i<=11;i++) {
      if(A[i] !~ /^[0-9]+$/ || B[i] !~ /^[0-9]+$/) exit 1
      if(i!=9 && B[i]<A[i]) exit 1
      D[i]=B[i]-A[i]
    }
    if(interval_ms<=0) exit 1
    operations=D[1]+D[5]
    await_value=(operations>=minimum_ops ? sprintf("%.2f",(D[4]+D[8])/operations) : "unavailable")
    read_await=(D[1]>=minimum_ops ? sprintf("%.2f",D[4]/D[1]) : "unavailable")
    write_await=(D[5]>=minimum_ops ? sprintf("%.2f",D[8]/D[5]) : "unavailable")
    utilization=100*D[10]/interval_ms
    if(utilization>100) utilization=100
    queue=D[11]/interval_ms
    printf "%d %d %d %s %.2f %.2f %d %s %s\n",operations,D[1],D[5],await_value,utilization,queue,B[9],read_await,write_await
  }'
}

storage_metric_stats() {
  local prefix="$1" threshold="$2"
  shift 2
  printf '%s\n' "$@" | awk -v prefix="$prefix" -v threshold="$threshold" '
    function sort_values( i,j,t) {
      for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) if(v[j]<v[i]) {t=v[i];v[i]=v[j];v[j]=t}
    }
    /^[0-9]+([.][0-9]+)?$/ {
      v[++n]=$1
      sum+=$1
      if($1>threshold) exceed++
    }
    END {
      if(n==0) exit 1
      sort_values()
      if(n%2) median=v[(n+1)/2]; else median=(v[n/2]+v[n/2+1])/2
      printf "%s_min=%.2f\n",prefix,v[1]
      printf "%s_median=%.2f\n",prefix,median
      printf "%s_average=%.2f\n",prefix,sum/n
      printf "%s_max=%.2f\n",prefix,v[n]
      printf "%s_threshold=%.2f\n",prefix,threshold
      printf "%s_threshold_exceedance_count=%d\n",prefix,exceed+0
    }'
}

storage_raw_inventory() {
  printf 'storage_raw_inventory_status=begin\n'
  if command -v df >/dev/null 2>&1; then
    storage_run_bounded df -hT 2>/dev/null || true
    storage_run_bounded df -ih 2>/dev/null || true
  fi
  if command -v lsblk >/dev/null 2>&1; then
    storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL,TRAN 2>/dev/null || \
      storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL 2>/dev/null || \
      storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINT,MODEL,TRAN 2>/dev/null || \
      storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINT,MODEL 2>/dev/null || true
  fi
  printf 'storage_raw_inventory_status=end\n'
}

sample_storage_metrics() {
  local mount_data source filesystem options target root_read_only filesystem_status
  local space_data inode_data total used available used_pct inode_total inode_used inode_available inode_used_pct
  local device before after pair i interval_ms status latency_status
  local operations read_ops write_ops await_value utilization queue inflight read_await write_await
  local -a awaits=() read_awaits=() write_awaits=() utilizations=() queues=()
  local completed=0 activity_windows=0 latency_windows=0 total_operations=0

  printf 'storage_sample_method=sysfs_block_stat_delta_windows\n'
  printf 'storage_sample_count_requested=%s\n' "$STORAGE_SAMPLE_COUNT"
  printf 'storage_sample_interval_seconds=%s\n' "$STORAGE_SAMPLE_INTERVAL_SECONDS"
  printf 'storage_min_ops_per_window=%s\n' "$STORAGE_MIN_OPS_PER_WINDOW"

  mount_data="$(storage_read_root_mount || true)"
  space_data="$(storage_read_root_space || true)"
  inode_data="$(storage_read_root_inodes || true)"
  if [[ -n "$mount_data" && -n "$space_data" && -n "$inode_data" ]]; then
    IFS=' ' read -r source filesystem options target <<<"$mount_data"
    IFS=' ' read -r total used available used_pct <<<"$space_data"
    IFS=' ' read -r inode_total inode_used inode_available inode_used_pct <<<"$inode_data"
    if [[ -n "$source" && -n "$filesystem" && "$total" =~ ^[0-9]+$ && "$used_pct" =~ ^[0-9]+$ && "$inode_used_pct" =~ ^[0-9]+$ ]]; then
      filesystem_status=ok
    else
      filesystem_status=unavailable
    fi
  else
    source=unavailable; filesystem=unavailable; options=unavailable; target=/
    total=unavailable; used=unavailable; available=unavailable; used_pct=unavailable
    inode_total=unavailable; inode_used=unavailable; inode_available=unavailable; inode_used_pct=unavailable
    filesystem_status=unavailable
  fi
  case ",${options}," in
    *,ro,*) root_read_only=yes ;;
    *,rw,*) root_read_only=no ;;
    *) root_read_only=unknown ;;
  esac
  printf 'storage_filesystem_status=%s\n' "$filesystem_status"
  printf 'root_source=%s\nroot_filesystem=%s\nroot_mountpoint=%s\nroot_mount_read_only=%s\n' \
    "$source" "$filesystem" "${target:-/}" "$root_read_only"
  printf 'root_total_kib=%s\nroot_used_kib=%s\nroot_available_kib=%s\nroot_used_pct=%s\n' \
    "$total" "$used" "$available" "$used_pct"
  printf 'root_inode_total=%s\nroot_inode_used=%s\nroot_inode_available=%s\nroot_inode_used_pct=%s\n' \
    "$inode_total" "$inode_used" "$inode_available" "$inode_used_pct"

  device="$(storage_resolve_device "$source" || true)"
  if [[ -z "$device" ]]; then
    printf 'storage_device_status=unsupported\nstorage_device=%s\n' "${source:-unavailable}"
    printf 'storage_device_sample_status=unavailable\nstorage_device_sample_count=0\nstorage_device_activity_windows=0\nstorage_device_latency_windows=0\nstorage_device_operations=unavailable\n'
    printf 'storage_await_ms_min=unavailable\nstorage_await_ms_median=unavailable\nstorage_await_ms_average=unavailable\nstorage_await_ms_max=unavailable\nstorage_await_ms_threshold=%.2f\nstorage_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
    printf 'storage_read_await_ms_min=unavailable\nstorage_read_await_ms_median=unavailable\nstorage_read_await_ms_average=unavailable\nstorage_read_await_ms_max=unavailable\nstorage_read_await_ms_threshold=%.2f\nstorage_read_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
    printf 'storage_write_await_ms_min=unavailable\nstorage_write_await_ms_median=unavailable\nstorage_write_await_ms_average=unavailable\nstorage_write_await_ms_max=unavailable\nstorage_write_await_ms_threshold=%.2f\nstorage_write_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
    printf 'storage_util_pct_min=unavailable\nstorage_util_pct_median=unavailable\nstorage_util_pct_average=unavailable\nstorage_util_pct_max=unavailable\nstorage_util_pct_threshold=%.2f\nstorage_util_pct_threshold_exceedance_count=unavailable\n' "$STORAGE_UTIL_WARN_PCT"
    printf 'storage_queue_depth_min=unavailable\nstorage_queue_depth_median=unavailable\nstorage_queue_depth_average=unavailable\nstorage_queue_depth_max=unavailable\nstorage_queue_depth_threshold=%.2f\nstorage_queue_depth_threshold_exceedance_count=unavailable\n' "$STORAGE_QUEUE_WARN"
    printf 'storage_latency_evidence_status=unavailable\nstorage_device_inflight=unavailable\n'
    return 0
  fi

  printf 'storage_device_status=ok\nstorage_device=%s\n' "$device"
  interval_ms=$((STORAGE_SAMPLE_INTERVAL_SECONDS * 1000))
  before="$(storage_read_device_stat "$device" || true)"
  for ((i=1; i<=STORAGE_SAMPLE_COUNT; i++)); do
    storage_wait_interval "$STORAGE_SAMPLE_INTERVAL_SECONDS"
    after="$(storage_read_device_stat "$device" || true)"
    pair="$(storage_pair_metrics "$before" "$after" "$interval_ms" "$STORAGE_MIN_OPS_PER_WINDOW" 2>/dev/null || true)"
    before="$after"
    [[ -n "$pair" ]] || continue
    IFS=' ' read -r operations read_ops write_ops await_value utilization queue inflight read_await write_await <<<"$pair"
    completed=$((completed+1))
    total_operations=$((total_operations+operations))
    utilizations+=("$utilization")
    queues+=("$queue")
    if (( operations > 0 )); then activity_windows=$((activity_windows+1)); fi
    if [[ "$await_value" != unavailable ]]; then
      awaits+=("$await_value")
      latency_windows=$((latency_windows+1))
    fi
    [[ "$read_await" == unavailable ]] || read_awaits+=("$read_await")
    [[ "$write_await" == unavailable ]] || write_awaits+=("$write_await")
    printf 'storage_sample_%s_operations=%s\n' "$completed" "$operations"
    printf 'storage_sample_%s_read_operations=%s\n' "$completed" "$read_ops"
    printf 'storage_sample_%s_write_operations=%s\n' "$completed" "$write_ops"
    printf 'storage_sample_%s_await_ms=%s\n' "$completed" "$await_value"
    printf 'storage_sample_%s_read_await_ms=%s\n' "$completed" "$read_await"
    printf 'storage_sample_%s_write_await_ms=%s\n' "$completed" "$write_await"
    printf 'storage_sample_%s_util_pct=%s\n' "$completed" "$utilization"
    printf 'storage_sample_%s_queue_depth=%s\n' "$completed" "$queue"
    printf 'storage_sample_%s_inflight=%s\n' "$completed" "$inflight"
  done

  if (( completed == STORAGE_SAMPLE_COUNT )); then status=ok
  elif (( completed > 0 )); then status=partial
  else status=unavailable
  fi
  if (( latency_windows >= 2 )); then latency_status=ok
  elif (( latency_windows == 1 )); then latency_status=limited
  elif (( activity_windows > 0 )); then latency_status=insufficient_activity
  else latency_status=idle
  fi
  printf 'storage_device_sample_status=%s\n' "$status"
  printf 'storage_device_sample_count=%s\nstorage_device_activity_windows=%s\nstorage_device_latency_windows=%s\nstorage_device_operations=%s\n' \
    "$completed" "$activity_windows" "$latency_windows" "$total_operations"
  printf 'storage_latency_evidence_status=%s\n' "$latency_status"
  printf 'storage_device_inflight=%s\n' "${inflight:-unavailable}"

  if (( ${#awaits[@]} > 0 )); then
    storage_metric_stats storage_await_ms "$STORAGE_AWAIT_WARN_MS" "${awaits[@]}"
  else
    printf 'storage_await_ms_min=unavailable\nstorage_await_ms_median=unavailable\nstorage_await_ms_average=unavailable\nstorage_await_ms_max=unavailable\nstorage_await_ms_threshold=%.2f\nstorage_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
  fi
  if (( ${#read_awaits[@]} > 0 )); then
    storage_metric_stats storage_read_await_ms "$STORAGE_AWAIT_WARN_MS" "${read_awaits[@]}"
  else
    printf 'storage_read_await_ms_min=unavailable\nstorage_read_await_ms_median=unavailable\nstorage_read_await_ms_average=unavailable\nstorage_read_await_ms_max=unavailable\nstorage_read_await_ms_threshold=%.2f\nstorage_read_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
  fi
  if (( ${#write_awaits[@]} > 0 )); then
    storage_metric_stats storage_write_await_ms "$STORAGE_AWAIT_WARN_MS" "${write_awaits[@]}"
  else
    printf 'storage_write_await_ms_min=unavailable\nstorage_write_await_ms_median=unavailable\nstorage_write_await_ms_average=unavailable\nstorage_write_await_ms_max=unavailable\nstorage_write_await_ms_threshold=%.2f\nstorage_write_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
  fi
  if (( ${#utilizations[@]} > 0 )); then
    storage_metric_stats storage_util_pct "$STORAGE_UTIL_WARN_PCT" "${utilizations[@]}"
    storage_metric_stats storage_queue_depth "$STORAGE_QUEUE_WARN" "${queues[@]}"
  else
    printf 'storage_util_pct_min=unavailable\nstorage_util_pct_median=unavailable\nstorage_util_pct_average=unavailable\nstorage_util_pct_max=unavailable\nstorage_util_pct_threshold=%.2f\nstorage_util_pct_threshold_exceedance_count=unavailable\n' "$STORAGE_UTIL_WARN_PCT"
    printf 'storage_queue_depth_min=unavailable\nstorage_queue_depth_median=unavailable\nstorage_queue_depth_average=unavailable\nstorage_queue_depth_max=unavailable\nstorage_queue_depth_threshold=%.2f\nstorage_queue_depth_threshold_exceedance_count=unavailable\n' "$STORAGE_QUEUE_WARN"
  fi
}

sample_storage() {
  sample_storage_metrics
  storage_raw_inventory
}

#!/usr/bin/env bash
# Bounded read-only memory, swap, fault, PSI and run-queue diagnostics.

PRESSURE_SAMPLE_COUNT=5
PRESSURE_SAMPLE_INTERVAL_SECONDS=1
MEM_AVAILABLE_WARN_PCT=10.00
MEM_AVAILABLE_CRITICAL_PCT=5.00
MEMORY_PSI_SOME_WARN_PCT=10.00
MEMORY_PSI_FULL_WARN_PCT=2.00
CPU_PSI_SOME_WARN_PCT=20.00
RUN_QUEUE_PER_VCPU_WARN=2.00
MAJOR_FAULT_RATE_WARN=10.00
SWAP_IO_RATE_WARN=1.00

pressure_read_memory() {
  awk '
    $1=="MemTotal:" {total=$2}
    $1=="MemAvailable:" {available=$2}
    $1=="SwapTotal:" {swap_total=$2}
    $1=="SwapFree:" {swap_free=$2}
    END {
      if(total!~/^[0-9]+$/ || total<=0 || available!~/^[0-9]+$/ || available>total ||
         swap_total!~/^[0-9]+$/ || swap_free!~/^[0-9]+$/ || swap_free>swap_total) exit 1
      printf "%s %s %s %s\n",total,available,swap_total,swap_free
    }' /proc/meminfo 2>/dev/null
}

pressure_read_vmstat() {
  awk '
    $1=="pswpin" {swap_in=$2}
    $1=="pswpout" {swap_out=$2}
    $1=="pgmajfault" {major=$2}
    END {
      if(swap_in!~/^[0-9]+$/ || swap_out!~/^[0-9]+$/ || major!~/^[0-9]+$/) exit 1
      printf "%s %s %s\n",swap_in,swap_out,major
    }' /proc/vmstat 2>/dev/null
}

pressure_read_psi() {
  local resource="$1"
  [[ "$resource" == memory || "$resource" == cpu ]] || return 1
  [[ -r "/proc/pressure/$resource" ]] || return 1
  awk '
    $1=="some" {for(i=2;i<=NF;i++) if($i~/^avg10=/){sub(/^avg10=/,"",$i); some=$i}}
    $1=="full" {for(i=2;i<=NF;i++) if($i~/^avg10=/){sub(/^avg10=/,"",$i); full=$i}}
    END {
      if(some!~/^[0-9]+([.][0-9]+)?$/) exit 1
      if(full!~/^[0-9]+([.][0-9]+)?$/) full="unavailable"
      printf "%s %s\n",some,full
    }' "/proc/pressure/$resource" 2>/dev/null
}

pressure_read_run_queue() {
  local vcpus runnable total
  vcpus="$(cpu_read_vcpu_count 2>/dev/null || true)"
  IFS=' ' read -r runnable total < <(awk '{split($4,a,"/"); print a[1],a[2]}' /proc/loadavg 2>/dev/null) || true
  [[ "$vcpus" =~ ^[1-9][0-9]*$ && "$runnable" =~ ^[0-9]+$ && "$total" =~ ^[0-9]+$ ]] || return 1
  awk -v runnable="$runnable" -v total="$total" -v vcpus="$vcpus" 'BEGIN {
    printf "%d %d %d %.2f\n",runnable,total,vcpus,runnable/vcpus
  }'
}

pressure_wait_interval() {
  sleep "$1"
}

pressure_timestamp() {
  date -u +%Y-%m-%dT%H:%M:%SZ
}

pressure_vm_delta() {
  local before="$1" after="$2" interval="$3"
  awk -v before="$before" -v after="$after" -v interval="$interval" 'BEGIN {
    if(split(before,A," ")!=3 || split(after,B," ")!=3 || interval<=0) exit 1
    for(i=1;i<=3;i++) {
      if(A[i]!~/^[0-9]+$/ || B[i]!~/^[0-9]+$/ || B[i]<A[i]) exit 1
      D[i]=B[i]-A[i]
    }
    printf "%d %d %d %.2f %.2f %.2f\n",D[1],D[2],D[3],D[1]/interval,D[2]/interval,D[3]/interval
  }'
}

pressure_metric_stats() {
  local prefix="$1" threshold="$2" direction="$3"
  shift 3
  printf '%s\n' "$@" | awk -v prefix="$prefix" -v threshold="$threshold" -v direction="$direction" '
    function sort_values( i,j,t) {
      for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) if(v[j]<v[i]) {t=v[i];v[i]=v[j];v[j]=t}
    }
    /^[0-9]+([.][0-9]+)?$/ {
      v[++n]=$1; sum+=$1
      if((direction=="low" && $1<threshold) || (direction=="high" && $1>threshold)) exceed++
    }
    END {
      if(n==0) exit 1
      sort_values()
      if(n%2) median=v[(n+1)/2]; else median=(v[n/2]+v[n/2+1])/2
      printf "%s_min=%.2f\n",prefix,v[1]
      printf "%s_median=%.2f\n",prefix,median
      printf "%s_average=%.2f\n",prefix,sum/n
      printf "%s_max=%.2f\n",prefix,v[n]
      printf "%s_threshold=%.2f\n",prefix,threshold
      printf "%s_threshold_exceedance_count=%d\n",prefix,exceed+0
    }'
}

pressure_safe_process_inventory() {
  local order="$1"
  [[ "$order" == cpu || "$order" == memory ]] || return 1
  if [[ "$order" == cpu ]]; then
    ps -eo comm=,%cpu=,%mem= --sort=-%cpu 2>/dev/null
  else
    ps -eo comm=,%cpu=,%mem= --sort=-%mem 2>/dev/null
  fi | awk -v order="$order" 'NR<=5 && NF>=3 {
    cpu_pct=$(NF-1)
    memory_pct=$NF
    name=$1
    for(i=2;i<=NF-2;i++) name=name " " $i
    gsub(/[^A-Za-z0-9._:+@-]/,"_",name)
    if(cpu_pct !~ /^[0-9]+([.][0-9]+)?$/) cpu_pct="unavailable"
    if(memory_pct !~ /^[0-9]+([.][0-9]+)?$/) memory_pct="unavailable"
    printf "pressure_top_%s_%d_name=%s\n",order,NR,name
    printf "pressure_top_%s_%d_cpu_pct=%s\n",order,NR,cpu_pct
    printf "pressure_top_%s_%d_memory_pct=%s\n",order,NR,memory_pct
  }'
}

pressure_raw_context() {
  local oom_count=unavailable
  printf 'pressure_memory_context_status=begin\n'
  free -h 2>/dev/null || true
  if command -v journalctl >/dev/null 2>&1; then
    oom_count="$(journalctl -k --since '24 hours ago' --no-pager -o cat 2>/dev/null \
      | grep -Eic 'out of memory|oom-killer|killed process' || true)"
  fi
  [[ "$oom_count" =~ ^[0-9]+$ ]] || oom_count=unavailable
  printf 'pressure_oom_event_count_24h=%s\n' "$oom_count"
  printf 'pressure_memory_context_status=end\n'
  printf 'pressure_process_inventory_status=begin\n'
  pressure_safe_process_inventory cpu || true
  pressure_safe_process_inventory memory || true
  printf 'pressure_process_inventory_status=end\n'
}

sample_memory_cpu_pressure_metrics() {
  local requested="$PRESSURE_SAMPLE_COUNT" interval="$PRESSURE_SAMPLE_INTERVAL_SECONDS"
  local before_vm after_vm memory vm_delta memory_psi cpu_psi run_queue timestamp
  local total available swap_total swap_free available_pct swap_used swap_used_pct
  local swap_in swap_out major swap_in_rate swap_out_rate major_rate
  local mem_some mem_full cpu_some cpu_full runnable tasks vcpus run_per_vcpu
  local i memory_status cpu_status vm_status prefix critical_exceedances
  local -a available_values=() swap_used_values=() swap_in_rates=() swap_out_rates=() major_rates=()
  local -a mem_some_values=() mem_full_values=() cpu_some_values=() run_queue_values=()
  local memory_samples=0 vm_samples=0 memory_psi_samples=0 cpu_psi_samples=0 run_queue_samples=0

  printf 'pressure_sample_method=proc_meminfo_vmstat_psi_loadavg_windows\n'
  printf 'pressure_sample_count_requested=%s\n' "$requested"
  printf 'pressure_sample_interval_seconds=%s\n' "$interval"
  before_vm="$(pressure_read_vmstat || true)"

  for ((i=1; i<=requested; i++)); do
    pressure_wait_interval "$interval"
    timestamp="$(pressure_timestamp 2>/dev/null || printf unavailable)"
    memory="$(pressure_read_memory || true)"
    after_vm="$(pressure_read_vmstat || true)"
    vm_delta="$(pressure_vm_delta "$before_vm" "$after_vm" "$interval" 2>/dev/null || true)"
    before_vm="$after_vm"
    memory_psi="$(pressure_read_psi memory || true)"
    cpu_psi="$(pressure_read_psi cpu || true)"
    run_queue="$(pressure_read_run_queue || true)"
    printf 'pressure_sample_%s_timestamp_utc=%s\n' "$i" "$timestamp"

    if [[ -n "$memory" ]]; then
      IFS=' ' read -r total available swap_total swap_free <<<"$memory"
      available_pct="$(awk -v a="$available" -v t="$total" 'BEGIN{printf "%.2f",100*a/t}')"
      swap_used=$((swap_total-swap_free))
      if (( swap_total > 0 )); then
        swap_used_pct="$(awk -v u="$swap_used" -v t="$swap_total" 'BEGIN{printf "%.2f",100*u/t}')"
        swap_used_values+=("$swap_used_pct")
      else
        swap_used_pct=not_configured
      fi
      memory_samples=$((memory_samples+1))
      available_values+=("$available_pct")
      printf 'pressure_sample_%s_mem_total_kib=%s\n' "$i" "$total"
      printf 'pressure_sample_%s_mem_available_kib=%s\n' "$i" "$available"
      printf 'pressure_sample_%s_mem_available_pct=%s\n' "$i" "$available_pct"
      printf 'pressure_sample_%s_swap_total_kib=%s\n' "$i" "$swap_total"
      printf 'pressure_sample_%s_swap_used_kib=%s\n' "$i" "$swap_used"
      printf 'pressure_sample_%s_swap_used_pct=%s\n' "$i" "$swap_used_pct"
    fi

    if [[ -n "$vm_delta" ]]; then
      IFS=' ' read -r swap_in swap_out major swap_in_rate swap_out_rate major_rate <<<"$vm_delta"
      vm_samples=$((vm_samples+1))
      swap_in_rates+=("$swap_in_rate"); swap_out_rates+=("$swap_out_rate"); major_rates+=("$major_rate")
      printf 'pressure_sample_%s_swap_in_pages=%s\n' "$i" "$swap_in"
      printf 'pressure_sample_%s_swap_out_pages=%s\n' "$i" "$swap_out"
      printf 'pressure_sample_%s_major_faults=%s\n' "$i" "$major"
      printf 'pressure_sample_%s_swap_in_pages_per_second=%s\n' "$i" "$swap_in_rate"
      printf 'pressure_sample_%s_swap_out_pages_per_second=%s\n' "$i" "$swap_out_rate"
      printf 'pressure_sample_%s_major_faults_per_second=%s\n' "$i" "$major_rate"
    fi

    if [[ -n "$memory_psi" ]]; then
      IFS=' ' read -r mem_some mem_full <<<"$memory_psi"
      memory_psi_samples=$((memory_psi_samples+1)); mem_some_values+=("$mem_some")
      [[ "$mem_full" == unavailable ]] || mem_full_values+=("$mem_full")
      printf 'pressure_sample_%s_memory_psi_some_avg10_pct=%s\n' "$i" "$mem_some"
      printf 'pressure_sample_%s_memory_psi_full_avg10_pct=%s\n' "$i" "$mem_full"
    fi
    if [[ -n "$cpu_psi" ]]; then
      IFS=' ' read -r cpu_some cpu_full <<<"$cpu_psi"
      cpu_psi_samples=$((cpu_psi_samples+1)); cpu_some_values+=("$cpu_some")
      printf 'pressure_sample_%s_cpu_psi_some_avg10_pct=%s\n' "$i" "$cpu_some"
      printf 'pressure_sample_%s_cpu_psi_full_avg10_pct=%s\n' "$i" "$cpu_full"
    fi
    if [[ -n "$run_queue" ]]; then
      IFS=' ' read -r runnable tasks vcpus run_per_vcpu <<<"$run_queue"
      run_queue_samples=$((run_queue_samples+1)); run_queue_values+=("$run_per_vcpu")
      printf 'pressure_sample_%s_runnable_tasks=%s\n' "$i" "$runnable"
      printf 'pressure_sample_%s_total_tasks=%s\n' "$i" "$tasks"
      printf 'pressure_sample_%s_run_queue_per_vcpu=%s\n' "$i" "$run_per_vcpu"
    fi
  done

  if (( memory_samples == requested && vm_samples == requested && memory_psi_samples == requested )); then memory_status=ok
  elif (( memory_samples > 0 || vm_samples > 0 || memory_psi_samples > 0 )); then memory_status=partial
  else memory_status=unavailable
  fi
  if (( cpu_psi_samples == requested && run_queue_samples == requested )); then cpu_status=ok
  elif (( cpu_psi_samples > 0 || run_queue_samples > 0 )); then cpu_status=partial
  else cpu_status=unavailable
  fi
  if (( vm_samples == requested )); then vm_status=ok
  elif (( vm_samples > 0 )); then vm_status=partial
  else vm_status=unavailable
  fi

  printf 'memory_pressure_sample_status=%s\n' "$memory_status"
  printf 'cpu_pressure_sample_status=%s\n' "$cpu_status"
  printf 'vm_pressure_delta_status=%s\n' "$vm_status"
  printf 'memory_pressure_sample_count=%s\n' "$memory_samples"
  printf 'vm_pressure_delta_count=%s\n' "$vm_samples"
  printf 'memory_psi_sample_count=%s\n' "$memory_psi_samples"
  printf 'cpu_psi_sample_count=%s\n' "$cpu_psi_samples"
  printf 'run_queue_sample_count=%s\n' "$run_queue_samples"
  printf 'pressure_sample_duration_seconds=%s\n' "$((requested*interval))"

  if (( memory_samples > 0 )); then
    pressure_metric_stats mem_available_pct "$MEM_AVAILABLE_WARN_PCT" low "${available_values[@]}"
    critical_exceedances="$(printf '%s\n' "${available_values[@]}" | awk -v threshold="$MEM_AVAILABLE_CRITICAL_PCT" '$1<threshold{n++} END{print n+0}')"
    printf 'mem_available_pct_critical_threshold=%.2f\n' "$MEM_AVAILABLE_CRITICAL_PCT"
    printf 'mem_available_pct_critical_threshold_exceedance_count=%s\n' "$critical_exceedances"
    if (( ${#swap_used_values[@]} > 0 )); then
      pressure_metric_stats swap_used_pct 100.00 high "${swap_used_values[@]}"
    else
      printf 'swap_used_pct_min=not_configured\nswap_used_pct_median=not_configured\nswap_used_pct_average=not_configured\nswap_used_pct_max=not_configured\n'
    fi
  else
    printf 'mem_available_pct_min=unavailable\nmem_available_pct_median=unavailable\nmem_available_pct_average=unavailable\nmem_available_pct_max=unavailable\nmem_available_pct_threshold=%.2f\nmem_available_pct_threshold_exceedance_count=unavailable\n' "$MEM_AVAILABLE_WARN_PCT"
    printf 'mem_available_pct_critical_threshold=%.2f\nmem_available_pct_critical_threshold_exceedance_count=unavailable\n' "$MEM_AVAILABLE_CRITICAL_PCT"
    printf 'swap_used_pct_min=unavailable\nswap_used_pct_median=unavailable\nswap_used_pct_average=unavailable\nswap_used_pct_max=unavailable\n'
  fi
  if (( vm_samples > 0 )); then
    pressure_metric_stats swap_in_pages_per_second "$SWAP_IO_RATE_WARN" high "${swap_in_rates[@]}"
    pressure_metric_stats swap_out_pages_per_second "$SWAP_IO_RATE_WARN" high "${swap_out_rates[@]}"
    pressure_metric_stats major_faults_per_second "$MAJOR_FAULT_RATE_WARN" high "${major_rates[@]}"
  else
    for prefix in swap_in_pages_per_second swap_out_pages_per_second major_faults_per_second; do
      printf '%s_min=unavailable\n%s_median=unavailable\n%s_average=unavailable\n%s_max=unavailable\n%s_threshold=unavailable\n%s_threshold_exceedance_count=unavailable\n' "$prefix" "$prefix" "$prefix" "$prefix" "$prefix" "$prefix"
    done
  fi
  if (( memory_psi_samples > 0 )); then
    pressure_metric_stats memory_psi_some_avg10_pct "$MEMORY_PSI_SOME_WARN_PCT" high "${mem_some_values[@]}"
    if (( ${#mem_full_values[@]} > 0 )); then
      pressure_metric_stats memory_psi_full_avg10_pct "$MEMORY_PSI_FULL_WARN_PCT" high "${mem_full_values[@]}"
    else
      printf 'memory_psi_full_avg10_pct_min=unavailable\nmemory_psi_full_avg10_pct_median=unavailable\nmemory_psi_full_avg10_pct_average=unavailable\nmemory_psi_full_avg10_pct_max=unavailable\nmemory_psi_full_avg10_pct_threshold=%.2f\nmemory_psi_full_avg10_pct_threshold_exceedance_count=unavailable\n' "$MEMORY_PSI_FULL_WARN_PCT"
    fi
  else
    printf 'memory_psi_some_avg10_pct_max=unavailable\nmemory_psi_some_avg10_pct_threshold=%.2f\nmemory_psi_some_avg10_pct_threshold_exceedance_count=unavailable\n' "$MEMORY_PSI_SOME_WARN_PCT"
    printf 'memory_psi_full_avg10_pct_max=unavailable\nmemory_psi_full_avg10_pct_threshold=%.2f\nmemory_psi_full_avg10_pct_threshold_exceedance_count=unavailable\n' "$MEMORY_PSI_FULL_WARN_PCT"
  fi
  if (( cpu_psi_samples > 0 )); then pressure_metric_stats cpu_psi_some_avg10_pct "$CPU_PSI_SOME_WARN_PCT" high "${cpu_some_values[@]}"
  else printf 'cpu_psi_some_avg10_pct_max=unavailable\ncpu_psi_some_avg10_pct_threshold=%.2f\ncpu_psi_some_avg10_pct_threshold_exceedance_count=unavailable\n' "$CPU_PSI_SOME_WARN_PCT"
  fi
  if (( run_queue_samples > 0 )); then pressure_metric_stats run_queue_per_vcpu "$RUN_QUEUE_PER_VCPU_WARN" high "${run_queue_values[@]}"
  else printf 'run_queue_per_vcpu_max=unavailable\nrun_queue_per_vcpu_threshold=%.2f\nrun_queue_per_vcpu_threshold_exceedance_count=unavailable\n' "$RUN_QUEUE_PER_VCPU_WARN"
  fi
}

sample_memory_cpu_pressure() {
  sample_memory_cpu_pressure_metrics
  pressure_raw_context
}

#!/usr/bin/env bash
# Bounded read-only Linux TCP and primary-interface counter diagnostics.

NETWORK_SAMPLE_COUNT=5
NETWORK_SAMPLE_INTERVAL_SECONDS=1
NETWORK_RETRANS_RATIO_MIN_OUT_SEGMENTS=20
NETWORK_RETRANS_RATIO_WARN_PCT=5.00
NETWORK_EVENT_RATE_WARN=0.00
NETWORK_ROUTE_FILE="/proc/net/route"
NETWORK_SYS_CLASS_NET_ROOT="/sys/class/net"

network_timestamp() {
  date -u -Is
}

network_wait_interval() {
  sleep "$1"
}

network_default_interface() {
  local interface=""
  interface="$(awk '$2=="00000000" && $1!="lo" {print $1; exit}' "$NETWORK_ROUTE_FILE" 2>/dev/null || true)"
  if [[ -z "$interface" ]] && command -v ip >/dev/null 2>&1; then
    interface="$(ip -4 route show default 2>/dev/null | awk '$1=="default" {for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}' || true)"
  fi
  [[ "$interface" =~ ^[A-Za-z0-9_.:@-]+$ && -d "$NETWORK_SYS_CLASS_NET_ROOT/$interface/statistics" ]] || return 1
  printf '%s\n' "$interface"
}

network_read_counter_file() {
  local path="$1" value
  [[ -r "$path" ]] || return 1
  IFS= read -r value <"$path" || return 1
  [[ "$value" =~ ^[0-9]+$ ]] || return 1
  printf '%s\n' "$value"
}

network_read_interface_counters() {
  local interface="$1"
  local base="$NETWORK_SYS_CLASS_NET_ROOT/$interface/statistics"
  local rx_packets tx_packets rx_errors tx_errors rx_dropped tx_dropped
  [[ "$interface" =~ ^[A-Za-z0-9_.:@-]+$ ]] || return 1
  rx_packets="$(network_read_counter_file "$base/rx_packets")" || return 1
  tx_packets="$(network_read_counter_file "$base/tx_packets")" || return 1
  rx_errors="$(network_read_counter_file "$base/rx_errors")" || return 1
  tx_errors="$(network_read_counter_file "$base/tx_errors")" || return 1
  rx_dropped="$(network_read_counter_file "$base/rx_dropped")" || return 1
  tx_dropped="$(network_read_counter_file "$base/tx_dropped")" || return 1
  printf '%s %s %s %s %s %s\n' \
    "$rx_packets" "$tx_packets" "$rx_errors" "$tx_errors" "$rx_dropped" "$tx_dropped"
}

network_read_tcp_counters_from_files() {
  local snmp_file="$1" netstat_file="$2"
  awk '
    $1=="Tcp:" && $2=="RtoAlgorithm" {
      for(i=2;i<=NF;i++) tcp_field[$i]=i
      next
    }
    $1=="Tcp:" && $2 ~ /^[0-9]+$/ && ("OutSegs" in tcp_field) {
      out_segments=$(tcp_field["OutSegs"])
      retrans_segments=$(tcp_field["RetransSegs"])
      next
    }
    $1=="TcpExt:" && $2 !~ /^[0-9]+$/ {
      for(i=2;i<=NF;i++) ext_field[$i]=i
      next
    }
    $1=="TcpExt:" && $2 ~ /^[0-9]+$/ && ("TCPTimeouts" in ext_field) {
      tcp_timeouts=$(ext_field["TCPTimeouts"])
      syn_retrans=$(ext_field["TCPSynRetrans"])
      listen_drops=$(ext_field["ListenDrops"])
      listen_overflows=$(ext_field["ListenOverflows"])
      abort_timeout=$(ext_field["TCPAbortOnTimeout"])
    }
    END {
      values[1]=out_segments; values[2]=retrans_segments; values[3]=tcp_timeouts
      values[4]=syn_retrans; values[5]=listen_drops; values[6]=listen_overflows; values[7]=abort_timeout
      for(i=1;i<=7;i++) if(values[i] !~ /^[0-9]+$/) exit 1
      printf "%s %s %s %s %s %s %s\n",values[1],values[2],values[3],values[4],values[5],values[6],values[7]
    }
  ' "$snmp_file" "$netstat_file" 2>/dev/null
}

network_read_tcp_counters() {
  network_read_tcp_counters_from_files /proc/net/snmp /proc/net/netstat
}

network_read_snapshot() {
  local interface="$1" tcp interface_counters
  tcp="$(network_read_tcp_counters)" || return 1
  interface_counters="$(network_read_interface_counters "$interface")" || return 1
  printf '%s %s\n' "$tcp" "$interface_counters"
}

network_pair_metrics() {
  local before="$1" after="$2" interval="$3"
  awk -v before="$before" -v after="$after" -v interval="$interval" \
      -v minimum_out="$NETWORK_RETRANS_RATIO_MIN_OUT_SEGMENTS" 'BEGIN {
    if(split(before,A," ")!=13 || split(after,B," ")!=13 || interval<=0) exit 1
    for(i=1;i<=13;i++) {
      if(A[i] !~ /^[0-9]+$/ || B[i] !~ /^[0-9]+$/) exit 1
      if(B[i]<A[i]) exit 2
      D[i]=B[i]-A[i]
    }
    ratio=(D[1]>=minimum_out ? sprintf("%.2f",100*D[2]/D[1]) : "unavailable")
    activity=((D[1]+D[8]+D[9])>0 ? 1 : 0)
    printf "%.2f %.2f %s %.2f %.2f %.2f %.2f %.2f %.2f %.2f %d\n", \
      D[1]/interval,D[2]/interval,ratio,D[3]/interval,D[4]/interval,D[5]/interval, \
      D[6]/interval,D[7]/interval,(D[10]+D[11])/interval,(D[12]+D[13])/interval,activity
  }'
}

network_metric_stats() {
  local prefix="$1" threshold="$2"
  shift 2
  printf '%s\n' "$@" | awk -v prefix="$prefix" -v threshold="$threshold" '
    function sort_values( i,j,t) {
      for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) if(v[j]<v[i]) {t=v[i];v[i]=v[j];v[j]=t}
    }
    /^[0-9]+([.][0-9]+)?$/ {
      v[++n]=$1; sum+=$1
      if($1>threshold) exceed++
    }
    END {
      if(n==0) exit 1
      sort_values()
      if(n%2) median=v[(n+1)/2]; else median=(v[n/2]+v[n/2+1])/2
      printf "%s_min=%.2f\n",prefix,v[1]
      printf "%s_median=%.2f\n",prefix,median
      printf "%s_average=%.2f\n",prefix,sum/n
      printf "%s_max=%.2f\n",prefix,v[n]
      printf "%s_threshold=%.2f\n",prefix,threshold
      printf "%s_threshold_exceedance_count=%d\n",prefix,exceed+0
    }'
}

network_unavailable_stats() {
  local prefix="$1" threshold="$2"
  printf '%s_min=unavailable\n%s_median=unavailable\n%s_average=unavailable\n%s_max=unavailable\n' \
    "$prefix" "$prefix" "$prefix" "$prefix"
  printf '%s_threshold=%.2f\n%s_threshold_exceedance_count=unavailable\n' "$prefix" "$threshold" "$prefix"
}

network_emit_stats() {
  local prefix="$1" threshold="$2"
  shift 2
  if ! network_metric_stats "$prefix" "$threshold" "$@"; then
    network_unavailable_stats "$prefix" "$threshold"
  fi
}

network_raw_context() {
  printf 'network_raw_context_status=begin\n'
  if command -v ip >/dev/null 2>&1; then
    ip -br addr 2>/dev/null || true
    ip route 2>/dev/null || true
    ip -6 route 2>/dev/null || true
  fi
  if command -v ss >/dev/null 2>&1; then ss -s 2>/dev/null || true; fi
  printf 'network_raw_context_status=end\n'
}

sample_server_network_metrics() {
  local requested="$NETWORK_SAMPLE_COUNT" interval="$NETWORK_SAMPLE_INTERVAL_SECONDS"
  local interface before after pair timestamp rc i status
  local out_rate retrans_rate retrans_ratio timeout_rate syn_rate listen_drop_rate listen_overflow_rate abort_rate error_rate drop_rate activity
  local completed=0 activity_windows=0 reset_windows=0
  local -a out_rates=() retrans_rates=() retrans_ratios=() timeout_rates=() syn_rates=()
  local -a listen_drop_rates=() listen_overflow_rates=() abort_rates=() error_rates=() drop_rates=()

  printf 'network_counter_sample_method=proc_net_sysfs_delta_windows\n'
  printf 'network_counter_sample_count_requested=%s\n' "$requested"
  printf 'network_counter_sample_interval_seconds=%s\n' "$interval"
  printf 'network_retrans_ratio_min_out_segments=%s\n' "$NETWORK_RETRANS_RATIO_MIN_OUT_SEGMENTS"

  interface="$(network_default_interface || true)"
  if [[ -z "$interface" ]]; then
    printf 'network_counter_sample_status=unavailable\nnetwork_primary_interface=unavailable\n'
    printf 'network_counter_sample_count=0\nnetwork_counter_activity_windows=0\nnetwork_counter_reset_windows=0\n'
    network_emit_stats network_tcp_out_segments_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_tcp_retrans_segments_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_tcp_retrans_ratio_pct "$NETWORK_RETRANS_RATIO_WARN_PCT"
    network_emit_stats network_tcp_timeout_events_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_tcp_syn_retrans_events_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_listen_drop_events_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_listen_overflow_events_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_tcp_abort_timeout_events_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_interface_error_events_per_second "$NETWORK_EVENT_RATE_WARN"
    network_emit_stats network_interface_drop_events_per_second "$NETWORK_EVENT_RATE_WARN"
    return 0
  fi
  printf 'network_primary_interface=%s\n' "$interface"

  before="$(network_read_snapshot "$interface" || true)"
  for ((i=1;i<=requested;i++)); do
    network_wait_interval "$interval"
    timestamp="$(network_timestamp)"
    printf 'network_sample_%s_timestamp_utc=%s\n' "$i" "$timestamp"
    after="$(network_read_snapshot "$interface" || true)"
    if [[ -z "$before" || -z "$after" ]]; then
      before="$after"
      continue
    fi
    set +e
    pair="$(network_pair_metrics "$before" "$after" "$interval")"
    rc=$?
    set -e
    before="$after"
    if (( rc != 0 )); then
      (( rc == 2 )) && reset_windows=$((reset_windows+1))
      continue
    fi
    IFS=' ' read -r out_rate retrans_rate retrans_ratio timeout_rate syn_rate listen_drop_rate \
      listen_overflow_rate abort_rate error_rate drop_rate activity <<<"$pair"
    completed=$((completed+1))
    activity_windows=$((activity_windows+activity))
    out_rates+=("$out_rate"); retrans_rates+=("$retrans_rate")
    [[ "$retrans_ratio" != unavailable ]] && retrans_ratios+=("$retrans_ratio")
    timeout_rates+=("$timeout_rate"); syn_rates+=("$syn_rate")
    listen_drop_rates+=("$listen_drop_rate"); listen_overflow_rates+=("$listen_overflow_rate")
    abort_rates+=("$abort_rate"); error_rates+=("$error_rate"); drop_rates+=("$drop_rate")
  done

  if (( completed == requested )); then status=ok
  elif (( completed >= 2 )); then status=limited
  else status=unavailable
  fi
  printf 'network_counter_sample_status=%s\n' "$status"
  printf 'network_counter_sample_count=%s\nnetwork_counter_activity_windows=%s\nnetwork_counter_reset_windows=%s\n' \
    "$completed" "$activity_windows" "$reset_windows"
  network_emit_stats network_tcp_out_segments_per_second "$NETWORK_EVENT_RATE_WARN" "${out_rates[@]}"
  network_emit_stats network_tcp_retrans_segments_per_second "$NETWORK_EVENT_RATE_WARN" "${retrans_rates[@]}"
  network_emit_stats network_tcp_retrans_ratio_pct "$NETWORK_RETRANS_RATIO_WARN_PCT" "${retrans_ratios[@]}"
  network_emit_stats network_tcp_timeout_events_per_second "$NETWORK_EVENT_RATE_WARN" "${timeout_rates[@]}"
  network_emit_stats network_tcp_syn_retrans_events_per_second "$NETWORK_EVENT_RATE_WARN" "${syn_rates[@]}"
  network_emit_stats network_listen_drop_events_per_second "$NETWORK_EVENT_RATE_WARN" "${listen_drop_rates[@]}"
  network_emit_stats network_listen_overflow_events_per_second "$NETWORK_EVENT_RATE_WARN" "${listen_overflow_rates[@]}"
  network_emit_stats network_tcp_abort_timeout_events_per_second "$NETWORK_EVENT_RATE_WARN" "${abort_rates[@]}"
  network_emit_stats network_interface_error_events_per_second "$NETWORK_EVENT_RATE_WARN" "${error_rates[@]}"
  network_emit_stats network_interface_drop_events_per_second "$NETWORK_EVENT_RATE_WARN" "${drop_rates[@]}"
}

sample_server_network() {
  sample_server_network_metrics
  network_raw_context
}

#!/usr/bin/env bash
# Bounded read-only application and systemd service evidence.

APPLICATION_JOURNAL_WINDOW="24 hours ago"
APPLICATION_JOURNAL_MAX_RECORDS=5000
APPLICATION_SQLITE_LOCK_WARN_COUNT=2
APPLICATION_TIMEOUT_WARN_COUNT=5
SERVICE_FAILURE_WARN_COUNT=3
SERVICE_RESTART_WARN_COUNT=3
ROLE_SERVICE_EVENT_WARN_COUNT=3

application_parse_systemctl_show() {
  awk -F= '
    function flush_unit() {
      if (id == "") return
      units++
      if (restarts ~ /^[0-9]+$/) {
        total += restarts
        if (restarts > 0) affected++
        if (restarts > maximum) maximum = restarts
      } else {
        invalid++
      }
      id=""; restarts=""
    }
    /^$/ { flush_unit(); next }
    $1=="Id" { if (id != "") flush_unit(); id=$2; next }
    $1=="NRestarts" { restarts=$2; next }
    END {
      flush_unit()
      printf "service_units_observed=%d\n", units+0
      printf "service_units_with_restarts=%d\n", affected+0
      printf "service_restart_count_total=%d\n", total+0
      printf "service_restart_count_max=%d\n", maximum+0
      printf "service_restart_counter_invalid_units=%d\n", invalid+0
    }
  '
}

application_systemctl_show() {
  systemctl show --type=service --all --property=Id --property=NRestarts --no-pager
}

application_journal_output() {
  journalctl --since "$APPLICATION_JOURNAL_WINDOW" --no-pager \
    -n "$APPLICATION_JOURNAL_MAX_RECORDS" -o json --output-fields=MESSAGE
}

application_role_journal_output() {
  journalctl -u x-ui.service -u xray.service --since "$APPLICATION_JOURNAL_WINDOW" \
    --no-pager -n "$APPLICATION_JOURNAL_MAX_RECORDS" -o json --output-fields=MESSAGE
}

application_count_lines() {
  awk 'NF {count++} END {print count+0}'
}

application_count_pattern() {
  local pattern="$1"
  grep -Eic "$pattern" || true
}

application_emit_unavailable_restart_counters() {
  printf '%s\n' \
    'service_restart_counter_status=unavailable' \
    'service_restart_counter_scope=systemd_manager_lifetime' \
    'service_units_observed=unavailable' \
    'service_units_with_restarts=unavailable' \
    'service_restart_count_total=unavailable' \
    'service_restart_count_max=unavailable' \
    'service_restart_counter_invalid_units=unavailable'
}

application_emit_unavailable_journal_counters() {
  printf '%s\n' \
    'application_journal_status=unavailable' \
    "application_journal_window=$APPLICATION_JOURNAL_WINDOW" \
    "application_journal_max_records=$APPLICATION_JOURNAL_MAX_RECORDS" \
    'application_journal_records_scanned=unavailable' \
    'application_journal_truncated=unavailable' \
    'application_sqlite_lock_events_24h=unavailable' \
    'application_timeout_events_24h=unavailable' \
    'service_failure_events_24h=unavailable' \
    'service_restart_events_24h=unavailable'
}

sample_application_services() {
  local systemctl_output restart_metrics restart_invalid restart_status
  local journal_output journal_status journal_records journal_truncated
  local sqlite_locks timeouts service_failures service_restarts
  local role_output role_status role_records role_truncated role_events
  local sample_status=unavailable available_sources=0

  printf 'application_service_sample_method=systemd_restart_counters_and_bounded_journal_patterns\n'
  printf 'application_sqlite_lock_threshold=%s\n' "$APPLICATION_SQLITE_LOCK_WARN_COUNT"
  printf 'application_timeout_threshold=%s\n' "$APPLICATION_TIMEOUT_WARN_COUNT"
  printf 'service_failure_event_threshold=%s\n' "$SERVICE_FAILURE_WARN_COUNT"
  printf 'service_restart_threshold=%s\n' "$SERVICE_RESTART_WARN_COUNT"
  printf 'role_service_event_threshold=%s\n' "$ROLE_SERVICE_EVENT_WARN_COUNT"

  if command -v systemctl >/dev/null 2>&1 && \
     systemctl_output="$(application_systemctl_show 2>/dev/null)" && \
     restart_metrics="$(printf '%s\n' "$systemctl_output" | application_parse_systemctl_show)"; then
    restart_invalid="$(printf '%s\n' "$restart_metrics" | awk -F= '$1=="service_restart_counter_invalid_units"{print $2}')"
    if [[ "$restart_invalid" =~ ^[0-9]+$ ]] && (( restart_invalid == 0 )); then restart_status=ok
    else restart_status=limited
    fi
    printf 'service_restart_counter_status=%s\n' "$restart_status"
    printf 'service_restart_counter_scope=systemd_manager_lifetime\n'
    printf '%s\n' "$restart_metrics"
    available_sources=$((available_sources+1))
  else
    application_emit_unavailable_restart_counters
  fi

  if command -v journalctl >/dev/null 2>&1 && \
     journal_output="$(application_journal_output 2>/dev/null)"; then
    journal_records="$(printf '%s\n' "$journal_output" | application_count_lines)"
    if [[ "$journal_records" =~ ^[0-9]+$ ]] && (( journal_records >= APPLICATION_JOURNAL_MAX_RECORDS )); then
      journal_status=limited; journal_truncated=yes
    else
      journal_status=ok; journal_truncated=no
    fi
    sqlite_locks="$(printf '%s\n' "$journal_output" | application_count_pattern 'database is locked')"
    timeouts="$(printf '%s\n' "$journal_output" | application_count_pattern 'context deadline exceeded|i/o timeout|connection timed out|request timed out|operation timed out')"
    service_failures="$(printf '%s\n' "$journal_output" | application_count_pattern 'start request repeated too quickly|failed with result|main process exited')"
    service_restarts="$(printf '%s\n' "$journal_output" | application_count_pattern 'scheduled restart job|restart counter is at')"
    printf 'application_journal_status=%s\n' "$journal_status"
    printf 'application_journal_window=%s\n' "$APPLICATION_JOURNAL_WINDOW"
    printf 'application_journal_max_records=%s\n' "$APPLICATION_JOURNAL_MAX_RECORDS"
    printf 'application_journal_records_scanned=%s\n' "$journal_records"
    printf 'application_journal_truncated=%s\n' "$journal_truncated"
    printf 'application_sqlite_lock_events_24h=%s\n' "$sqlite_locks"
    printf 'application_timeout_events_24h=%s\n' "$timeouts"
    printf 'service_failure_events_24h=%s\n' "$service_failures"
    printf 'service_restart_events_24h=%s\n' "$service_restarts"
    available_sources=$((available_sources+1))
  else
    application_emit_unavailable_journal_counters
  fi

  case "${ROLE_LABEL:-generic}" in
    vpn|proxy|xray|hub|streaming-test)
      if command -v journalctl >/dev/null 2>&1 && \
         role_output="$(application_role_journal_output 2>/dev/null)"; then
        role_records="$(printf '%s\n' "$role_output" | application_count_lines)"
        if [[ "$role_records" =~ ^[0-9]+$ ]] && (( role_records >= APPLICATION_JOURNAL_MAX_RECORDS )); then
          role_status=limited; role_truncated=yes
        else
          role_status=ok; role_truncated=no
        fi
        role_events="$(printf '%s\n' "$role_output" | application_count_pattern 'database is locked|context deadline exceeded|i/o timeout|connection timed out|request timed out|operation timed out|start request repeated too quickly|failed with result|main process exited|scheduled restart job|restart counter is at')"
      else
        role_status=unavailable; role_records=unavailable; role_truncated=unavailable; role_events=unavailable
      fi
      ;;
    *) role_status=not_applicable; role_records=0; role_truncated=no; role_events=0 ;;
  esac
  printf 'application_role_scope_status=%s\n' "$role_status"
  printf 'application_role_journal_records_scanned=%s\n' "$role_records"
  printf 'application_role_journal_truncated=%s\n' "$role_truncated"
  printf 'application_role_relevant_events_24h=%s\n' "$role_events"

  if (( available_sources == 2 )); then
    if [[ "$restart_status" == ok && "$journal_status" == ok && \
          ( "$role_status" == ok || "$role_status" == not_applicable ) ]]; then sample_status=ok
    else sample_status=limited
    fi
  elif (( available_sources == 1 )); then
    sample_status=limited
  fi
  printf 'application_service_sample_status=%s\n' "$sample_status"
}

#!/usr/bin/env bash
# Integrity-checked comparison with one compatible local audit report.

HISTORICAL_COMPARISON_METHOD_VERSION="historical-comparison-v1"
HISTORICAL_REPORT_SCAN_LIMIT=50

history_machine_value() {
  local file="$1" key="$2"
  awk -F= -v key="$key" '$1==key{sub(/^[^=]*=/,""); value=$0} END{print value}' "$file" 2>/dev/null
}

history_metadata_value() {
  history_machine_value "$1" "$2"
}

history_is_safe_token() {
  [[ "${1:-}" =~ ^[A-Za-z0-9._:+@/-]+$ ]]
}

history_is_nonnegative_number() {
  [[ "${1:-}" =~ ^[0-9]+([.][0-9]+)?$ ]]
}

history_report_is_trusted() {
  local report_dir="$1" expected_server="$2" expected_uid="${3:-0}"
  local summary="$report_dir/technical-summary.txt" metadata="$report_dir/metadata.env"
  local actual_uid mode group_digit other_digit stored_hash actual_hash file
  local metadata_server metadata_mode metadata_policy

  [[ -d "$report_dir" && ! -L "$report_dir" ]] || return 1
  [[ -f "$summary" && ! -L "$summary" && -f "$metadata" && ! -L "$metadata" ]] || {
    return 1
  }

  [[ "$expected_uid" =~ ^[0-9]+$ ]] || expected_uid=0
  for file in "$report_dir" "$summary" "$metadata"; do
    actual_uid="$(stat -c %u "$file" 2>/dev/null || stat -f %u "$file" 2>/dev/null || true)"
    [[ "$actual_uid" =~ ^[0-9]+$ && "$actual_uid" == "$expected_uid" ]] || {
      return 1
    }
    mode="$(stat -c %a "$file" 2>/dev/null || stat -f %Lp "$file" 2>/dev/null || true)"
    [[ "$mode" =~ ^[0-7]{3,4}$ ]] || return 1
    group_digit="${mode: -2:1}"
    other_digit="${mode: -1}"
    if (( (group_digit & 2) != 0 || (other_digit & 2) != 0 )); then
      return 1
    fi
  done

  metadata_server="$(history_metadata_value "$metadata" server)"
  metadata_mode="$(history_metadata_value "$metadata" mode)"
  metadata_policy="$(history_metadata_value "$metadata" audit_policy)"
  [[ "$metadata_server" == "$expected_server" && "$metadata_mode" == audit && "$metadata_policy" == read_only ]] || {
    return 1
  }

  stored_hash="$(history_metadata_value "$metadata" summary_sha256)"
  [[ "$stored_hash" =~ ^[0-9a-fA-F]{64}$ ]] || return 1
  actual_hash="$(sha256sum "$summary" 2>/dev/null | awk '{print $1}')"
  [[ "$actual_hash" == "$stored_hash" ]] || return 1

  return 0
}

history_cpu_signature() {
  local summary="$1" method count duration
  method="$(history_machine_value "$summary" cpu_sample_method)"
  count="$(history_machine_value "$summary" cpu_sample_count)"
  duration="$(history_machine_value "$summary" cpu_sample_duration_seconds)"
  if ! history_is_safe_token "$method" || [[ ! "$count" =~ ^[1-9][0-9]*$ ]] || [[ ! "$duration" =~ ^[1-9][0-9]*$ ]]; then
    printf 'unavailable'
    return 1
  fi
  printf '%s|%s|%s' "$method" "$count" "$duration"
}

history_signed_delta() {
  awk -v previous="$1" -v current="$2" 'BEGIN { printf "%+.2f", current-previous }'
}

history_relative_change() {
  awk -v previous="$1" -v current="$2" 'BEGIN {
    if (previous==0) { print "unavailable_zero_baseline"; exit }
    printf "%+.2f", ((current-previous)/previous)*100
  }'
}

history_ratio() {
  awk -v previous="$1" -v current="$2" 'BEGIN {
    if (previous==0) { print "unavailable_zero_baseline"; exit }
    printf "%.2f", current/previous
  }'
}

history_format_metric() {
  local label="$1" previous="$2" current="$3" delta="$4" relative="$5" ratio="$6"
  if ! history_is_nonnegative_number "$previous" || ! history_is_nonnegative_number "$current"; then
    printf '%s: недостаточно совместимых числовых данных.' "$label"
  elif [[ "$relative" == unavailable_zero_baseline || "$ratio" == unavailable_zero_baseline ]]; then
    printf '%s: %s%% → %s%%; изменение %s п.п.; относительное изменение не рассчитывается при нулевом предыдущем значении.' \
      "$label" "$previous" "$current" "${delta:-unavailable}"
  else
    printf '%s: %s%% → %s%%; изменение %s п.п., %s%%, коэффициент %sx.' \
      "$label" "$previous" "$current" "${delta:-unavailable}" "${relative:-unavailable}" "${ratio:-unavailable}"
  fi
}

history_emit_common() {
  local status="$1" observations=0 limitations
  if [[ "$status" == compatible ]]; then
    observations=2
    limitations="Two compatible observations show a difference, not a trend or root cause"
  elif [[ "$status" == incompatible ]]; then
    limitations="A prior report exists, but incompatible methods prohibit a numeric comparison"
  elif [[ "$status" == no_trusted_prior_report ]]; then
    limitations="Prior local evidence was not trusted, so no baseline was used"
  else
    limitations="No compatible prior local audit was available"
  fi
  printf 'historical_comparison_status=%s\n' "$status"
  printf 'historical_comparison_method_version=%s\n' "$HISTORICAL_COMPARISON_METHOD_VERSION"
  printf 'historical_comparison_policy=informational_only_no_verdict_override\n'
  printf 'historical_observation_count=%s\n' "$observations"
  printf 'historical_trend_status=not_inferred\n'
  printf 'historical_limitations=%s\n' "$limitations"
}

append_historical_comparison() {
  local report_root="$1" current_run_dir="$2" current_summary="$3" expected_server="$4"
  local expected_uid="${5:-0}"
  local current_signature candidate_signature candidate_dir candidate_summary candidate_metadata candidate_diagnostic_method
  local current_method current_count current_duration current_verdict current_risk current_schema current_diagnostic_method
  local previous_method previous_count previous_duration previous_verdict previous_risk previous_schema previous_diagnostic_method previous_utc previous_version
  local previous_iowait current_iowait previous_steal current_steal previous_basename
  local compatible_dir="" latest_incompatible_dir="" latest_incompatible_reason=none
  local trusted_candidates=0 untrusted_candidates=0 incompatible_candidates=0 scanned=0
  local output

  [[ -f "$current_summary" && ! -L "$current_summary" ]] || return 1
  current_signature="$(history_cpu_signature "$current_summary" 2>/dev/null || true)"
  IFS='|' read -r current_method current_count current_duration <<<"$current_signature"
  current_verdict="$(history_machine_value "$current_summary" verdict)"
  current_risk="$(history_machine_value "$current_summary" risk_score)"
  current_schema="$(history_machine_value "$current_summary" diagnostic_schema_version)"
  current_diagnostic_method="$(history_machine_value "$current_summary" diagnostic_method_version)"

  while IFS= read -r -d '' candidate_dir; do
    [[ "$candidate_dir" != "$current_run_dir" ]] || continue
    (( scanned < HISTORICAL_REPORT_SCAN_LIMIT )) || break
    scanned=$((scanned+1))
    if ! history_report_is_trusted "$candidate_dir" "$expected_server" "$expected_uid"; then
      untrusted_candidates=$((untrusted_candidates+1))
      continue
    fi
    trusted_candidates=$((trusted_candidates+1))
    candidate_summary="$candidate_dir/technical-summary.txt"
    candidate_signature="$(history_cpu_signature "$candidate_summary" 2>/dev/null || true)"
    candidate_diagnostic_method="$(history_machine_value "$candidate_summary" diagnostic_method_version)"
    if history_is_safe_token "$current_diagnostic_method" && [[ "$candidate_diagnostic_method" == "$current_diagnostic_method" ]] && \
      [[ "$current_signature" != unavailable && "$candidate_signature" == "$current_signature" ]]; then
      compatible_dir="$candidate_dir"
      break
    fi
    incompatible_candidates=$((incompatible_candidates+1))
    if [[ -z "$latest_incompatible_dir" ]]; then
      latest_incompatible_dir="$candidate_dir"
      if ! history_is_safe_token "$current_diagnostic_method"; then
        latest_incompatible_reason=current_diagnostic_method_unavailable
      elif ! history_is_safe_token "$candidate_diagnostic_method"; then
        latest_incompatible_reason=previous_diagnostic_method_unavailable
      elif [[ "$candidate_diagnostic_method" != "$current_diagnostic_method" ]]; then
        latest_incompatible_reason=diagnostic_method_version_mismatch
      elif [[ "$current_signature" == unavailable ]]; then
        latest_incompatible_reason=current_cpu_signature_unavailable
      elif [[ "$candidate_signature" == unavailable ]]; then
        latest_incompatible_reason=previous_cpu_signature_unavailable
      else
        latest_incompatible_reason=cpu_sample_signature_mismatch
      fi
    fi
  done < <(find "$report_root" -mindepth 1 -maxdepth 1 -type d -name "${expected_server}_*_audit" -print0 2>/dev/null | sort -zr)

  if [[ -n "$compatible_dir" ]]; then
    candidate_summary="$compatible_dir/technical-summary.txt"
    candidate_metadata="$compatible_dir/metadata.env"
    previous_basename="$(basename "$compatible_dir")"
    previous_method="$(history_machine_value "$candidate_summary" cpu_sample_method)"
    previous_count="$(history_machine_value "$candidate_summary" cpu_sample_count)"
    previous_duration="$(history_machine_value "$candidate_summary" cpu_sample_duration_seconds)"
    previous_verdict="$(history_machine_value "$candidate_summary" verdict)"
    previous_risk="$(history_machine_value "$candidate_summary" risk_score)"
    previous_schema="$(history_machine_value "$candidate_summary" diagnostic_schema_version)"
    previous_diagnostic_method="$(history_machine_value "$candidate_summary" diagnostic_method_version)"
    previous_utc="$(history_machine_value "$candidate_summary" utc)"
    previous_version="$(history_metadata_value "$candidate_metadata" version)"
    previous_iowait="$(history_machine_value "$candidate_summary" iowait_max_pct)"
    current_iowait="$(history_machine_value "$current_summary" iowait_max_pct)"
    previous_steal="$(history_machine_value "$candidate_summary" steal_max_pct)"
    current_steal="$(history_machine_value "$current_summary" steal_max_pct)"

    history_is_safe_token "$previous_basename" || previous_basename=unavailable
    history_is_safe_token "$previous_utc" || previous_utc=unavailable
    history_is_safe_token "$previous_version" || previous_version=unavailable
    history_is_safe_token "$previous_schema" || previous_schema=unavailable
    history_is_safe_token "$current_schema" || current_schema=unavailable
    history_is_safe_token "$previous_diagnostic_method" || previous_diagnostic_method=unavailable
    history_is_safe_token "$current_diagnostic_method" || current_diagnostic_method=unavailable
    [[ "$previous_verdict" =~ ^(PASS|WARN|FAIL)$ ]] || previous_verdict=unavailable
    [[ "$current_verdict" =~ ^(PASS|WARN|FAIL)$ ]] || current_verdict=unavailable
    [[ "$previous_risk" =~ ^[0-9]+$ ]] || previous_risk=unavailable
    [[ "$current_risk" =~ ^[0-9]+$ ]] || current_risk=unavailable

    output="$(history_emit_common compatible)"
    output+=$'\n'"historical_previous_report=$previous_basename"
    output+=$'\n'"historical_previous_utc=$previous_utc"
    output+=$'\n'"historical_previous_version=$previous_version"
    output+=$'\n'"historical_previous_diagnostic_schema_version=${previous_schema:-unavailable}"
    output+=$'\n'"historical_current_diagnostic_schema_version=${current_schema:-unavailable}"
    output+=$'\n'"historical_previous_diagnostic_method_version=${previous_diagnostic_method:-unavailable}"
    output+=$'\n'"historical_current_diagnostic_method_version=${current_diagnostic_method:-unavailable}"
    output+=$'\n'"historical_previous_verdict=$previous_verdict"
    output+=$'\n'"historical_current_verdict=$current_verdict"
    output+=$'\n'"historical_previous_risk_score=$previous_risk"
    output+=$'\n'"historical_current_risk_score=$current_risk"
    output+=$'\n'"historical_cpu_metric_compatibility=compatible"
    output+=$'\n'"historical_cpu_sample_method_previous=$previous_method"
    output+=$'\n'"historical_cpu_sample_method_current=$current_method"
    output+=$'\n'"historical_cpu_sample_count_previous=$previous_count"
    output+=$'\n'"historical_cpu_sample_count_current=$current_count"
    output+=$'\n'"historical_cpu_sample_duration_seconds_previous=$previous_duration"
    output+=$'\n'"historical_cpu_sample_duration_seconds_current=$current_duration"

    if history_is_nonnegative_number "$previous_iowait" && history_is_nonnegative_number "$current_iowait"; then
      output+=$'\n'"historical_iowait_max_pct_previous=$previous_iowait"
      output+=$'\n'"historical_iowait_max_pct_current=$current_iowait"
      output+=$'\n'"historical_iowait_delta_percentage_points=$(history_signed_delta "$previous_iowait" "$current_iowait")"
      output+=$'\n'"historical_iowait_relative_change_pct=$(history_relative_change "$previous_iowait" "$current_iowait")"
      output+=$'\n'"historical_iowait_ratio=$(history_ratio "$previous_iowait" "$current_iowait")"
    else
      output+=$'\n'historical_iowait_metric_status=unavailable
    fi

    if history_is_nonnegative_number "$previous_steal" && history_is_nonnegative_number "$current_steal"; then
      output+=$'\n'"historical_steal_max_pct_previous=$previous_steal"
      output+=$'\n'"historical_steal_max_pct_current=$current_steal"
      output+=$'\n'"historical_steal_delta_percentage_points=$(history_signed_delta "$previous_steal" "$current_steal")"
      output+=$'\n'"historical_steal_relative_change_pct=$(history_relative_change "$previous_steal" "$current_steal")"
      output+=$'\n'"historical_steal_ratio=$(history_ratio "$previous_steal" "$current_steal")"
    else
      output+=$'\n'historical_steal_metric_status=unavailable
    fi
  elif [[ -n "$latest_incompatible_dir" ]]; then
    candidate_summary="$latest_incompatible_dir/technical-summary.txt"
    previous_basename="$(basename "$latest_incompatible_dir")"
    history_is_safe_token "$previous_basename" || previous_basename=unavailable
    candidate_signature="$(history_cpu_signature "$candidate_summary" 2>/dev/null || true)"
    IFS='|' read -r previous_method previous_count previous_duration <<<"$candidate_signature"
    previous_diagnostic_method="$(history_machine_value "$candidate_summary" diagnostic_method_version)"
    history_is_safe_token "$previous_diagnostic_method" || previous_diagnostic_method=unavailable
    history_is_safe_token "$current_diagnostic_method" || current_diagnostic_method=unavailable
    output="$(history_emit_common incompatible)"
    output+=$'\n'"historical_previous_report=$previous_basename"
    output+=$'\n'"historical_incompatibility_reason=$latest_incompatible_reason"
    output+=$'\n'"historical_previous_diagnostic_method_version=$previous_diagnostic_method"
    output+=$'\n'"historical_current_diagnostic_method_version=$current_diagnostic_method"
    output+=$'\n'"historical_cpu_sample_method_previous=${previous_method:-unavailable}"
    output+=$'\n'"historical_cpu_sample_method_current=${current_method:-unavailable}"
    output+=$'\n'"historical_cpu_sample_count_previous=${previous_count:-unavailable}"
    output+=$'\n'"historical_cpu_sample_count_current=${current_count:-unavailable}"
    output+=$'\n'"historical_cpu_sample_duration_seconds_previous=${previous_duration:-unavailable}"
    output+=$'\n'"historical_cpu_sample_duration_seconds_current=${current_duration:-unavailable}"
  elif (( untrusted_candidates > 0 )); then
    output="$(history_emit_common no_trusted_prior_report)"
  else
    output="$(history_emit_common no_prior_report)"
  fi

  output+=$'\n'"historical_reports_scanned=$scanned"
  output+=$'\n'"historical_trusted_candidates=$trusted_candidates"
  output+=$'\n'"historical_untrusted_candidates=$untrusted_candidates"
  output+=$'\n'"historical_incompatible_candidates=$incompatible_candidates"
  printf '%s\n' "$output" >>"$current_summary"
}

history_format_summary() {
  local summary="$1" status reason previous_verdict current_verdict previous_iowait current_iowait iowait_delta iowait_relative iowait_ratio
  local previous_steal current_steal steal_delta steal_relative steal_ratio previous_method current_method iowait_text steal_text
  status="$(history_machine_value "$summary" historical_comparison_status)"
  case "$status" in
    compatible)
      previous_verdict="$(history_machine_value "$summary" historical_previous_verdict)"
      current_verdict="$(history_machine_value "$summary" historical_current_verdict)"
      previous_iowait="$(history_machine_value "$summary" historical_iowait_max_pct_previous)"
      current_iowait="$(history_machine_value "$summary" historical_iowait_max_pct_current)"
      iowait_delta="$(history_machine_value "$summary" historical_iowait_delta_percentage_points)"
      iowait_relative="$(history_machine_value "$summary" historical_iowait_relative_change_pct)"
      iowait_ratio="$(history_machine_value "$summary" historical_iowait_ratio)"
      previous_steal="$(history_machine_value "$summary" historical_steal_max_pct_previous)"
      current_steal="$(history_machine_value "$summary" historical_steal_max_pct_current)"
      steal_delta="$(history_machine_value "$summary" historical_steal_delta_percentage_points)"
      steal_relative="$(history_machine_value "$summary" historical_steal_relative_change_pct)"
      steal_ratio="$(history_machine_value "$summary" historical_steal_ratio)"
      iowait_text="$(history_format_metric 'I/O wait max' "$previous_iowait" "$current_iowait" "$iowait_delta" "$iowait_relative" "$iowait_ratio")"
      steal_text="$(history_format_metric 'CPU steal max' "$previous_steal" "$current_steal" "$steal_delta" "$steal_relative" "$steal_ratio")"
      printf 'Предыдущий результат: %s; текущий: %s. %s %s Методика совместима. Это сравнение двух наблюдений, а не доказательство тенденции или причины.' \
        "${previous_verdict:-unavailable}" "${current_verdict:-unavailable}" "$iowait_text" "$steal_text"
      ;;
    incompatible)
      reason="$(history_machine_value "$summary" historical_incompatibility_reason)"
      if [[ "$reason" == diagnostic_method_version_mismatch || "$reason" == current_diagnostic_method_unavailable || "$reason" == previous_diagnostic_method_unavailable ]]; then
        previous_method="$(history_machine_value "$summary" historical_previous_diagnostic_method_version)"
        current_method="$(history_machine_value "$summary" historical_current_diagnostic_method_version)"
      else
        previous_method="$(history_machine_value "$summary" historical_cpu_sample_method_previous)"
        current_method="$(history_machine_value "$summary" historical_cpu_sample_method_current)"
      fi
      printf 'Найден предыдущий локальный отчёт, но методика несовместима (%s → %s; причина %s). Числовая разница намеренно не рассчитывается.' \
        "${previous_method:-unavailable}" "${current_method:-unavailable}" "${reason:-unavailable}"
      ;;
    no_trusted_prior_report)
      printf 'Локальные предыдущие отчёты найдены, но их целостность или права доступа не подтверждены. Сравнение не выполнено.'
      ;;
    *)
      printf 'Совместимый предыдущий локальный audit не найден. Текущий результат показан без вывода о динамике.'
      ;;
  esac
}

#!/usr/bin/env bash
# Read-only access and first-audit readiness evidence for Ubuntu/Debian hosts.
#
# This layer correlates local effective configuration only. It never claims
# that a locally listening socket is externally reachable.

ACCESS_READINESS_SCHEMA_VERSION=1
ACCESS_READINESS_NOT_CHECKED_FAMILIES="users,persistence,image_provenance,containers,integrity,backup_restore"

access_readiness_value() {
  local text="$1" key="$2"
  printf '%s\n' "$text" | awk -F= -v key="$key" '
    $1==key { count++; value=substr($0,index($0,"=")+1) }
    END { if(count != 1) exit 1; print value }
  '
}

access_parse_ssh_effective_output() {
  local context_status="$1"
  awk -v context_status="$context_status" '
    function mark_scope(value, lower) {
      lower=tolower(value)
      if (lower ~ /(^|\[)(::|0:0:0:0:0:0:0:0)(\]|:|$)/ ||
          lower ~ /(^|[^0-9])0[.]0[.]0[.]0(:|$)/ || lower == "*") wildcard=1
      else if (lower ~ /(^|\[)::1(\]|:|$)/ || lower ~ /^127[.]/) loopback=1
      else specific=1
    }
    function csv_add(value, kind, i) {
      if (kind == "port") {
        if (!(value in ports)) { ports[value]=1; port_order[++port_count]=value }
      }
    }
    $1=="permitrootlogin" && NF==2 { root=$2; root_seen++ }
    $1=="passwordauthentication" && NF==2 { password=$2; password_seen++ }
    $1=="kbdinteractiveauthentication" && NF==2 { keyboard=$2; keyboard_seen++ }
    $1=="pubkeyauthentication" && NF==2 { pubkey=$2; pubkey_seen++ }
    $1=="authenticationmethods" {
      auth_seen++
      auth=""
      for (i=2;i<=NF;i++) {
        auth=auth (i==2?"":"|") $i
        if ($i !~ /^[A-Za-z0-9@._+-]+(,[A-Za-z0-9@._+-]+)*$/) auth_invalid=1
      }
      if (NF<2) auth_invalid=1
    }
    $1=="port" && NF==2 && $2 ~ /^[0-9]+$/ { csv_add($2,"port"); port_seen++ }
    $1=="listenaddress" && NF==2 { mark_scope($2); listen_seen++ }
    $1=="allowusers" { allow_users_seen++; allow_users_count += NF-1 }
    $1=="allowgroups" { allow_groups_seen++; allow_groups_count += NF-1 }
    END {
      status=(root_seen==1 && password_seen==1 && keyboard_seen==1 && pubkey_seen==1 &&
              auth_seen==1 && auth_invalid==0 && port_seen>0 && listen_seen>0 ? "ok" : "unparsed")
      printf "ssh_effective_status=%s\n",status
      printf "ssh_effective_permit_root_login=%s\n",(root_seen==1?root:"unavailable")
      printf "ssh_effective_password_authentication=%s\n",(password_seen==1?password:"unavailable")
      printf "ssh_effective_kbd_interactive_authentication=%s\n",(keyboard_seen==1?keyboard:"unavailable")
      printf "ssh_effective_pubkey_authentication=%s\n",(pubkey_seen==1?pubkey:"unavailable")
      printf "ssh_effective_authentication_methods=%s\n",(auth_seen==1 && auth_invalid==0?auth:"unavailable")
      printf "ssh_effective_context_status=%s\n",context_status
      if (port_count == 0) printf "ssh_effective_port_set=unavailable\n"
      else {
        printf "ssh_effective_port_set="
        for(i=1;i<=port_count;i++) printf "%s%s",(i==1?"":","),port_order[i]
        printf "\n"
      }
      scope_count=wildcard+loopback+specific
      if (scope_count==0) scope="unavailable"
      else if (scope_count>1) scope="mixed"
      else if (wildcard) scope="wildcard"
      else if (loopback) scope="loopback"
      else scope="specific_non_loopback"
      printf "ssh_effective_listen_address_scope=%s\n",scope
      printf "ssh_effective_allow_users_status=%s\n",(allow_users_seen?"configured":"not_configured")
      printf "ssh_effective_allow_users_count=%d\n",allow_users_count+0
      printf "ssh_effective_allow_groups_status=%s\n",(allow_groups_seen?"configured":"not_configured")
      printf "ssh_effective_allow_groups_count=%d\n",allow_groups_count+0
    }
  '
}

access_collect_ssh_effective() {
  local output context_output context_status=unavailable parsed status
  if ! command -v sshd >/dev/null 2>&1; then
    printf '%s\n' \
      'ssh_effective_status=unsupported' \
      'ssh_effective_permit_root_login=unavailable' \
      'ssh_effective_password_authentication=unavailable' \
      'ssh_effective_kbd_interactive_authentication=unavailable' \
      'ssh_effective_pubkey_authentication=unavailable' \
      'ssh_effective_authentication_methods=unavailable' \
      'ssh_effective_context_status=unavailable' \
      'ssh_effective_port_set=unavailable' \
      'ssh_effective_listen_address_scope=unavailable' \
      'ssh_effective_allow_users_status=unavailable' \
      'ssh_effective_allow_users_count=unavailable' \
      'ssh_effective_allow_groups_status=unavailable' \
      'ssh_effective_allow_groups_count=unavailable'
    return 0
  fi
  if ! output="$(sshd -T 2>/dev/null)"; then
    printf '%s\n' \
      'ssh_effective_status=unavailable' \
      'ssh_effective_permit_root_login=unavailable' \
      'ssh_effective_password_authentication=unavailable' \
      'ssh_effective_kbd_interactive_authentication=unavailable' \
      'ssh_effective_pubkey_authentication=unavailable' \
      'ssh_effective_authentication_methods=unavailable' \
      'ssh_effective_context_status=unavailable' \
      'ssh_effective_port_set=unavailable' \
      'ssh_effective_listen_address_scope=unavailable' \
      'ssh_effective_allow_users_status=unavailable' \
      'ssh_effective_allow_users_count=unavailable' \
      'ssh_effective_allow_groups_status=unavailable' \
      'ssh_effective_allow_groups_count=unavailable'
    return 0
  fi
  if context_output="$(sshd -T -C user=root,host=localhost,addr=127.0.0.1 2>/dev/null)"; then
    if [[ "$context_output" == "$output" ]]; then context_status=sample_matches_default
    else context_status=sample_differs_from_default
    fi
  fi
  parsed="$(printf '%s\n' "$output" | access_parse_ssh_effective_output "$context_status")"
  status="$(access_readiness_value "$parsed" ssh_effective_status 2>/dev/null || true)"
  if [[ "$status" != ok && "$status" != unparsed ]]; then
    return 1
  fi
  printf '%s\n' "$parsed"
}

access_collect_tcp_listeners() {
  local ssh_ports="$1" output
  if ! command -v ss >/dev/null 2>&1; then
    printf '%s\n' \
      'tcp_listener_evidence_status=unsupported' \
      'tcp_listener_total=unavailable' \
      'tcp_listener_loopback_count=unavailable' \
      'tcp_listener_wildcard_count=unavailable' \
      'tcp_listener_specific_non_loopback_count=unavailable' \
      'ssh_listener_correlation_status=unavailable' \
      'ssh_listener_scope=unavailable'
    return 0
  fi
  if ! output="$(ss -H -lntup 2>/dev/null)"; then
    printf '%s\n' \
      'tcp_listener_evidence_status=unavailable' \
      'tcp_listener_total=unavailable' \
      'tcp_listener_loopback_count=unavailable' \
      'tcp_listener_wildcard_count=unavailable' \
      'tcp_listener_specific_non_loopback_count=unavailable' \
      'ssh_listener_correlation_status=unavailable' \
      'ssh_listener_scope=unavailable'
    return 0
  fi
  printf '%s\n' "$output" | awk -v ssh_ports="$ssh_ports" '
    BEGIN {
      ports_known=(ssh_ports ~ /^[0-9]+(,[0-9]+)*$/)
      if (ports_known) {
        n=split(ssh_ports,p,",")
        for(i=1;i<=n;i++) ssh_port[p[i]]=1
      }
    }
    $1 ~ /^tcp/ {
      local_addr=$5
      if (local_addr == "") next
      address=local_addr
      port=""
      if (local_addr ~ /^\[/) {
        port=local_addr
        sub(/^.*\]:/,"",port)
        sub(/^\[/,"",address)
        sub(/\]:[^:]+$/,"",address)
      } else {
        port=local_addr
        sub(/^.*:/,"",port)
        sub(/:[^:]+$/,"",address)
      }
      total++
      scope="specific_non_loopback"
      if (address=="0.0.0.0" || address=="*" || address=="::" || address=="[::]") scope="wildcard"
      else if (address=="::1" || address ~ /^127[.]/) scope="loopback"
      if (scope=="wildcard") wildcard++
      else if (scope=="loopback") loopback++
      else specific++
      if (ports_known && (port in ssh_port)) {
        matched++
        if (scope=="wildcard") ssh_wildcard=1
        else if (scope=="loopback") ssh_loopback=1
        else ssh_specific=1
      }
    }
    END {
      printf "tcp_listener_evidence_status=ok\n"
      printf "tcp_listener_total=%d\n",total+0
      printf "tcp_listener_loopback_count=%d\n",loopback+0
      printf "tcp_listener_wildcard_count=%d\n",wildcard+0
      printf "tcp_listener_specific_non_loopback_count=%d\n",specific+0
      if (!ports_known) {
        printf "ssh_listener_correlation_status=unavailable\nssh_listener_scope=unavailable\n"
      } else if (matched==0) {
        printf "ssh_listener_correlation_status=not_observed\nssh_listener_scope=not_observed\n"
      } else {
        scope_count=ssh_wildcard+ssh_loopback+ssh_specific
        if (scope_count>1) scope="mixed"
        else if (ssh_wildcard) scope="wildcard"
        else if (ssh_loopback) scope="loopback"
        else scope="specific_non_loopback"
        printf "ssh_listener_correlation_status=matched\nssh_listener_scope=%s\n",scope
      }
    }
  '
}

access_collect_ufw() {
  local output first
  if ! command -v ufw >/dev/null 2>&1; then
    printf 'firewall_ufw_status=unsupported\n'
    return 0
  fi
  if ! output="$(ufw status 2>/dev/null)"; then
    printf 'firewall_ufw_status=unavailable\n'
    return 0
  fi
  first="$(printf '%s\n' "$output" | sed -n '1p')"
  case "$first" in
    'Status: active') printf 'firewall_ufw_status=active\n' ;;
    'Status: inactive') printf 'firewall_ufw_status=inactive\n' ;;
    '') printf 'firewall_ufw_status=unavailable\n' ;;
    *) printf 'firewall_ufw_status=unparsed\n' ;;
  esac
}

access_collect_nft() {
  local output
  if ! command -v nft >/dev/null 2>&1; then
    printf '%s\n' \
      'firewall_nft_status=unsupported' \
      'firewall_nft_input_policy=unavailable' \
      'firewall_nft_input_hook_count=unavailable' \
      'firewall_nft_rule_line_count=unavailable'
    return 0
  fi
  if ! output="$(nft list ruleset 2>/dev/null)"; then
    printf '%s\n' \
      'firewall_nft_status=unavailable' \
      'firewall_nft_input_policy=unavailable' \
      'firewall_nft_input_hook_count=unavailable' \
      'firewall_nft_rule_line_count=unavailable'
    return 0
  fi
  printf '%s\n' "$output" | awk '
    {
      line=tolower($0)
      if (line ~ /^[[:space:]]*table[[:space:]]/) tables++
      if (line ~ /^[[:space:]]*chain[[:space:]]/) chains++
      if (line ~ /hook[[:space:]]+input([[:space:]]|;)/) {
        hooks++
        if (line ~ /policy[[:space:]]+(drop|reject)([[:space:]]|;)/) deny++
        else if (line ~ /policy[[:space:]]+accept([[:space:]]|;)/) accept++
        else unknown_policy++
        in_input=1
        next
      }
      if (in_input && line ~ /^[[:space:]]*}/) in_input=0
      else if (in_input && line !~ /^[[:space:]]*$/) input_rules++
      if (line ~ /^[[:space:]]*(ip|ip6|tcp|udp|icmp|icmpv6|ct|meta|iif|oif|counter|accept|drop|reject|jump|goto)[[:space:]]/) rules++
    }
    END {
      if (hooks==0) policy="none"
      else if (deny>0 && accept==0 && unknown_policy==0) policy="default_deny"
      else if (accept>0 && deny==0 && unknown_policy==0) policy="accept"
      else policy="mixed_or_unparsed"
      printf "firewall_nft_status=available\n"
      printf "firewall_nft_input_policy=%s\n",policy
      printf "firewall_nft_input_hook_count=%d\n",hooks+0
      printf "firewall_nft_rule_line_count=%d\n",rules+0
    }
  '
}

access_collect_iptables_family() {
  local command_name="$1" prefix="$2" output
  if ! command -v "$command_name" >/dev/null 2>&1; then
    printf '%s_status=unsupported\n%s_input_policy=unavailable\n%s_input_rule_count=unavailable\n' \
      "$prefix" "$prefix" "$prefix"
    return 0
  fi
  if ! output="$("$command_name" -S INPUT 2>/dev/null)"; then
    printf '%s_status=unavailable\n%s_input_policy=unavailable\n%s_input_rule_count=unavailable\n' \
      "$prefix" "$prefix" "$prefix"
    return 0
  fi
  printf '%s\n' "$output" | awk -v prefix="$prefix" '
    $1=="-P" && $2=="INPUT" && NF==3 { policy=tolower($3); policy_seen++ }
    $1=="-A" && $2=="INPUT" { rules++ }
    END {
      status=(policy_seen==1?"available":"unparsed")
      printf "%s_status=%s\n",prefix,status
      printf "%s_input_policy=%s\n",prefix,(policy_seen==1?policy:"unavailable")
      printf "%s_input_rule_count=%d\n",prefix,rules+0
    }
  '
}

access_local_firewall_derive() {
  local ufw="$1" nft_status="$2" nft_policy="$3" ipt4_status="$4" ipt4_policy="$5" ipt6_status="$6" ipt6_policy="$7"
  local status=UNKNOWN confidence=LIMITED sources=none enforcing=0 known=0 incomplete=0 conflict=0
  local nft_deny=0 nft_accept=0 ipt4_deny=0 ipt4_accept=0 ipt6_deny=0 ipt6_accept=0
  [[ "$ufw" =~ ^(active|inactive)$ ]] && known=1
  [[ "$ufw" =~ ^(unsupported|unavailable|unparsed)$ ]] && incomplete=1
  if [[ "$nft_status" == available ]]; then
    known=1
    [[ "$nft_policy" == default_deny ]] && nft_deny=1
    [[ "$nft_policy" == accept ]] && nft_accept=1
    [[ "$nft_policy" =~ ^(none|mixed_or_unparsed|unavailable)$ ]] && incomplete=1
  elif [[ "$nft_status" =~ ^(unsupported|unavailable|unparsed)$ ]]; then incomplete=1
  fi
  if [[ "$ipt4_status" == available ]]; then
    known=1
    [[ "$ipt4_policy" =~ ^(drop|reject)$ ]] && ipt4_deny=1
    [[ "$ipt4_policy" == accept ]] && ipt4_accept=1
    [[ ! "$ipt4_policy" =~ ^(drop|reject|accept)$ ]] && incomplete=1
  elif [[ "$ipt4_status" =~ ^(unsupported|unavailable|unparsed)$ ]]; then incomplete=1
  fi
  if [[ "$ipt6_status" == available ]]; then
    known=1
    [[ "$ipt6_policy" =~ ^(drop|reject)$ ]] && ipt6_deny=1
    [[ "$ipt6_policy" == accept ]] && ipt6_accept=1
    [[ ! "$ipt6_policy" =~ ^(drop|reject|accept)$ ]] && incomplete=1
  elif [[ "$ipt6_status" =~ ^(unsupported|unavailable|unparsed)$ ]]; then incomplete=1
  fi
  if (( nft_deny == 1 )); then
    enforcing=1
    sources=nft
  fi
  if (( ipt4_deny == 1 && ipt6_deny == 1 )); then
    enforcing=1
    [[ "$sources" == none ]] && sources=iptables || sources="${sources},iptables"
  fi
  if (( (nft_deny == 1 && (ipt4_accept == 1 || ipt6_accept == 1)) ||
        (nft_accept == 1 && (ipt4_deny == 1 || ipt6_deny == 1)) ||
        (ipt4_deny == 1 && ipt6_accept == 1) ||
        (ipt4_accept == 1 && ipt6_deny == 1) )); then
    conflict=1
  fi
  if (( conflict == 1 )); then
    status=REVIEW
    confidence=MEDIUM
  elif (( enforcing == 1 )); then
    status=ENFORCING
    confidence=HIGH
    (( incomplete == 0 )) || confidence=MEDIUM
  elif (( incomplete == 1 || known == 0 )); then
    status=UNKNOWN
    confidence=LIMITED
  else
    status=REVIEW
    confidence=MEDIUM
  fi
  printf '%s\n' \
    "local_firewall_status=$status" \
    "local_firewall_confidence=$confidence" \
    "local_firewall_enforcement_sources=$sources"
}

access_readiness_evaluate() {
  local ssh_status="$1" root_login="$2" password_auth="$3" keyboard_auth="$4" pubkey_auth="$5"
  local authentication_methods="$6" ssh_context_status="$7" ssh_config_scope="$8" allow_users="$9"
  shift 9
  local allow_groups="$1" listener_status="$2" ssh_listener_scope="$3" firewall_status="$4" firewall_confidence="$5"
  local apt_index="$6" package_evidence="$7" apt_simulation="$8"
  local ssh_access_status=UNKNOWN package_status=UNKNOWN overall=UNKNOWN confidence=LIMITED
  local correlation='evidence_incomplete_no_healthy_inference'
  local limitation='local_read_only_evidence_only;external_reachability_not_tested;ssh_match_contexts_not_exhaustively_evaluated'

  if [[ "$ssh_status" == ok && "$ssh_context_status" =~ ^sample_(matches|differs_from)_default$ &&
        "$authentication_methods" != unavailable && "$listener_status" == ok &&
        "$ssh_listener_scope" =~ ^(wildcard|specific_non_loopback|mixed|loopback|not_observed)$ ]]; then
    if [[ "$root_login" == yes && ( "$password_auth" == yes || "$keyboard_auth" == yes ) &&
          "$ssh_listener_scope" =~ ^(wildcard|specific_non_loopback|mixed)$ ]]; then
      ssh_access_status=PASSWORD_CAPABLE_REVIEW
      correlation='root_and_password_capable_auth_with_non_loopback_or_wildcard_ssh_bind_requires_review'
    elif [[ "$password_auth" == no && "$keyboard_auth" == no && "$pubkey_auth" == yes &&
            "$root_login" =~ ^(no|prohibit-password|without-password|forced-commands-only)$ &&
            "$ssh_listener_scope" != not_observed ]]; then
      ssh_access_status=KEY_ORIENTED_REVIEW
      correlation='default_context_is_key_oriented_but_match_contexts_are_not_exhaustively_evaluated'
    else
      ssh_access_status=CONFIGURATION_REVIEW
      correlation='effective_ssh_configuration_or_local_bind_requires_owner_review'
    fi
    if [[ "$ssh_context_status" == sample_differs_from_default ]]; then
      ssh_access_status=CONDITIONAL_CONTEXT_REVIEW
      correlation='sampled_ssh_context_differs_from_default_and_other_match_contexts_remain_unchecked'
    fi
  fi

  if [[ "$apt_index" == fresh && "$package_evidence" == available && "$apt_simulation" == ok ]]; then
    package_status=READY
  fi

  if [[ "$ssh_access_status" == PASSWORD_CAPABLE_REVIEW &&
        "$root_login" == yes && ( "$password_auth" == yes || "$keyboard_auth" == yes ) &&
        "$ssh_listener_scope" =~ ^(wildcard|specific_non_loopback|mixed)$ ]]; then
    overall=REVIEW
    confidence=MEDIUM
    if [[ "$firewall_status" == UNKNOWN || "$package_status" == UNKNOWN ]]; then
      confidence=LIMITED
    fi
  elif [[ "$ssh_access_status" == UNKNOWN || "$firewall_status" == UNKNOWN || "$package_status" == UNKNOWN ]]; then
    overall=UNKNOWN
    confidence=LIMITED
  else
    overall=REVIEW
    confidence=MEDIUM
    [[ "$firewall_confidence" == LIMITED ]] && confidence=LIMITED
    if [[ "$firewall_status" == REVIEW ]]; then
      correlation='local_firewall_status_or_backend_policy_requires_review'
    fi
  fi

  if [[ "$apt_index" != fresh || "$package_evidence" != available || "$apt_simulation" != ok ]]; then
    limitation="${limitation};package_evidence_unknown_or_limited"
  fi
  if [[ "$ssh_status" != ok || "$listener_status" != ok ||
        ! "$ssh_context_status" =~ ^sample_(matches|differs_from)_default$ ]]; then
    limitation="${limitation};ssh_or_listener_evidence_unknown"
  fi
  if [[ "$ssh_context_status" == sample_differs_from_default ]]; then
    limitation="${limitation};sampled_ssh_context_differs_from_default"
  fi
  if [[ "$firewall_status" == UNKNOWN ]]; then
    limitation="${limitation};local_firewall_evidence_unknown"
  elif [[ "$firewall_status" == REVIEW ]]; then
    limitation="${limitation};local_firewall_policy_requires_review"
  fi

  printf '%s\n' \
    "access_readiness_schema_version=$ACCESS_READINESS_SCHEMA_VERSION" \
    "access_readiness_status=$overall" \
    "access_readiness_confidence=$confidence" \
    "ssh_access_status=$ssh_access_status" \
    "firewall_readiness_status=$firewall_status" \
    "package_readiness_status=$package_status" \
    "access_readiness_fact_ssh=effective_status:${ssh_status};root_login:${root_login};password_auth:${password_auth};keyboard_interactive:${keyboard_auth};pubkey_auth:${pubkey_auth};authentication_methods:${authentication_methods};context:${ssh_context_status};configured_bind:${ssh_config_scope};allow_users:${allow_users};allow_groups:${allow_groups}" \
    "access_readiness_fact_listener=local_tcp_status:${listener_status};ssh_bind:${ssh_listener_scope};external_reachability:NOT_CHECKED" \
    "access_readiness_fact_firewall=local_status:${firewall_status};confidence:${firewall_confidence}" \
    "access_readiness_fact_packages=apt_index:${apt_index};package_list:${package_evidence};simulation:${apt_simulation}" \
    "access_readiness_correlation=$correlation" \
    "access_readiness_limitations=$limitation" \
    'access_readiness_checked_scope=ssh_effective_configuration,tcp_listener_bind,local_firewall,apt_package_evidence' \
    'access_readiness_not_checked_status=NOT CHECKED' \
    "access_readiness_not_checked_families=$ACCESS_READINESS_NOT_CHECKED_FAMILIES"
}

sample_access_readiness_metrics() {
  local ssh_metrics listener_metrics ufw_metrics nft_metrics ipt4_metrics ipt6_metrics firewall_metrics
  local ssh_ports ufw nft_status nft_policy ipt4_status ipt4_policy ipt6_status ipt6_policy
  ssh_metrics="$(access_collect_ssh_effective)" || return 1
  ssh_ports="$(access_readiness_value "$ssh_metrics" ssh_effective_port_set)" || return 1
  listener_metrics="$(access_collect_tcp_listeners "$ssh_ports")" || return 1
  ufw_metrics="$(access_collect_ufw)" || return 1
  nft_metrics="$(access_collect_nft)" || return 1
  ipt4_metrics="$(access_collect_iptables_family iptables firewall_iptables)" || return 1
  ipt6_metrics="$(access_collect_iptables_family ip6tables firewall_ip6tables)" || return 1
  ufw="$(access_readiness_value "$ufw_metrics" firewall_ufw_status)" || return 1
  nft_status="$(access_readiness_value "$nft_metrics" firewall_nft_status)" || return 1
  nft_policy="$(access_readiness_value "$nft_metrics" firewall_nft_input_policy)" || return 1
  ipt4_status="$(access_readiness_value "$ipt4_metrics" firewall_iptables_status)" || return 1
  ipt4_policy="$(access_readiness_value "$ipt4_metrics" firewall_iptables_input_policy)" || return 1
  ipt6_status="$(access_readiness_value "$ipt6_metrics" firewall_ip6tables_status)" || return 1
  ipt6_policy="$(access_readiness_value "$ipt6_metrics" firewall_ip6tables_input_policy)" || return 1
  firewall_metrics="$(access_local_firewall_derive \
    "$ufw" "$nft_status" "$nft_policy" \
    "$ipt4_status" "$ipt4_policy" "$ipt6_status" "$ipt6_policy")" || return 1
  printf 'access_evidence_schema_version=%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n' \
    "$ACCESS_READINESS_SCHEMA_VERSION" \
    "$ssh_metrics" "$listener_metrics" "$ufw_metrics" "$nft_metrics" \
    "$ipt4_metrics" "$ipt6_metrics" "$firewall_metrics"
}

#!/usr/bin/env bash
# Bounded read-only network and time readiness for Ubuntu/Debian audit-only.

NETWORK_TIME_READINESS_SCHEMA_VERSION=1
NETWORK_TIME_FRESH_BOOT_SECONDS=900
NETWORK_TIME_RESOLV_CONF="${NETWORK_TIME_RESOLV_CONF:-/etc/resolv.conf}"
NETWORK_TIME_ROUTE4_FILE="${NETWORK_TIME_ROUTE4_FILE:-/proc/net/route}"
NETWORK_TIME_ROUTE6_FILE="${NETWORK_TIME_ROUTE6_FILE:-/proc/net/ipv6_route}"
NETWORK_TIME_UPTIME_FILE="${NETWORK_TIME_UPTIME_FILE:-/proc/uptime}"
NETWORK_TIME_SYS_CLASS_NET_ROOT="${NETWORK_TIME_SYS_CLASS_NET_ROOT:-/sys/class/net}"

network_time_value() {
  local text="$1" key="$2"
  printf '%s\n' "$text" | awk -F= -v key="$key" '
    $1==key { count++; value=substr($0,index($0,"=")+1) }
    END { if(count != 1) exit 1; print value }
  '
}

network_time_safe_interface() {
  [[ "$1" =~ ^[A-Za-z0-9_.:@-]+$ && "$1" != unavailable ]]
}

network_time_route_metrics_from_values() {
  local ipv4_status="$1" ipv4_interface="$2" ipv6_status="$3" ipv6_interface="$4" mtu_raw="$5"
  local primary=unavailable mtu=unavailable mtu_status=UNKNOWN mtu_profile=UNKNOWN
  [[ "$ipv4_status" =~ ^(PRESENT|ABSENT|UNKNOWN)$ ]] || return 1
  [[ "$ipv6_status" =~ ^(PRESENT|ABSENT|UNKNOWN)$ ]] || return 1
  if [[ "$ipv4_status" == PRESENT ]]; then
    network_time_safe_interface "$ipv4_interface" || return 1
    primary="$ipv4_interface"
  else
    ipv4_interface=unavailable
  fi
  if [[ "$ipv6_status" == PRESENT ]]; then
    network_time_safe_interface "$ipv6_interface" || return 1
    [[ "$primary" != unavailable ]] || primary="$ipv6_interface"
  else
    ipv6_interface=unavailable
  fi
  if [[ "$primary" != unavailable && "$mtu_raw" =~ ^[0-9]+$ ]] &&
     (( mtu_raw >= 68 && mtu_raw <= 65535 )); then
    mtu="$mtu_raw"
    mtu_status=OBSERVED
    if (( mtu_raw < 1500 )); then mtu_profile=BELOW_1500
    elif (( mtu_raw == 1500 )); then mtu_profile=STANDARD_1500
    else mtu_profile=ABOVE_1500
    fi
  elif [[ "$ipv4_status" == ABSENT && "$ipv6_status" == ABSENT ]]; then
    mtu_status=NOT_APPLICABLE
    mtu_profile=NOT_APPLICABLE
  fi
  printf '%s\n' \
    "network_ipv4_default_route_status=$ipv4_status" \
    "network_ipv4_default_interface=$ipv4_interface" \
    "network_ipv6_default_route_status=$ipv6_status" \
    "network_ipv6_default_interface=$ipv6_interface" \
    "network_readiness_primary_interface=$primary" \
    "network_primary_interface_mtu=$mtu" \
    "network_mtu_status=$mtu_status" \
    "network_mtu_profile=$mtu_profile"
}

network_time_parse_route4_file() {
  local file="$1"
  if [[ ! -r "$file" ]]; then
    printf '%s\n' \
      'network_ipv4_default_route_status=UNKNOWN' \
      'network_ipv4_default_interface=unavailable'
    return 0
  fi
  awk '
    function safe_interface(value) {
      return value != "lo" && value ~ /^[A-Za-z0-9_.:@-]+$/
    }
    function hex8(value) {
      return length(value) == 8 && value ~ /^[0-9A-Fa-f]+$/
    }
    function flags_up(value, last) {
      if(value !~ /^[0-9A-Fa-f]+$/ || length(value) > 8) return 0
      last=substr(value,length(value),1)
      return last ~ /^[13579bBdDfF]$/
    }
    NR==1 {
      if(NF < 11 || $1!="Iface" || $2!="Destination" || $3!="Gateway" ||
         $4!="Flags" || $5!="RefCnt" || $6!="Use" || $7!="Metric" ||
         $8!="Mask" || $9!="MTU" || $10!="Window" || $11!="IRTT") invalid=1
      else header=1
      next
    }
    /^[[:space:]]*$/ { next }
    {
      rows++
      if(NF < 11 || $1 !~ /^[A-Za-z0-9_.:@-]+$/ || !hex8($2) || !hex8($3) ||
         $4 !~ /^[0-9A-Fa-f]+$/ || length($4) > 8 ||
         $5 !~ /^[0-9]+$/ || $6 !~ /^[0-9]+$/ || $7 !~ /^[0-9]+$/ ||
         !hex8($8) || $9 !~ /^[0-9]+$/ || $10 !~ /^[0-9]+$/ ||
         $11 !~ /^[0-9]+$/) {
        invalid=1
        next
      }
      if(toupper($2)=="00000000" && toupper($8)=="00000000" &&
         safe_interface($1) && flags_up($4)) {
        metric=$7+0
        if(!found || metric < best_metric) {
          found=1
          best_metric=metric
          best_interface=$1
        }
      }
    }
    END {
      if(!header || invalid || rows == 0) {
        print "network_ipv4_default_route_status=UNKNOWN"
        print "network_ipv4_default_interface=unavailable"
      } else if(found) {
        print "network_ipv4_default_route_status=PRESENT"
        print "network_ipv4_default_interface=" best_interface
      } else {
        print "network_ipv4_default_route_status=ABSENT"
        print "network_ipv4_default_interface=unavailable"
      }
    }
  ' "$file" 2>/dev/null || printf '%s\n' \
    'network_ipv4_default_route_status=UNKNOWN' \
    'network_ipv4_default_interface=unavailable'
}

network_time_parse_route6_file() {
  local file="$1" parsed
  if [[ ! -r "$file" ]]; then
    printf '%s\n' \
      'network_ipv6_default_route_status=UNKNOWN' \
      'network_ipv6_default_interface=unavailable'
    return 0
  fi
  if ! parsed="$(LC_ALL=C awk '
    function interface_shape(value) {
      return value ~ /^[A-Za-z0-9_.:@-]+$/
    }
    function hex_width(value, width) {
      return length(value) == width && value ~ /^[0-9A-Fa-f]+$/
    }
    function prefix_shape(value) {
      return length(value) == 2 && value ~ /^[0-9A-Fa-f]+$/
    }
    function zero_prefix(value) {
      return value == "00"
    }
    function flags_up(value, last) {
      if(!hex_width(value,8)) return 0
      last=substr(value,8,1)
      return last ~ /^[13579bBdDfF]$/
    }
    function hex_value(value, result, digits, i, digit) {
      result=0
      digits="0123456789abcdef"
      value=tolower(value)
      for(i=1;i<=length(value);i++) {
        digit=index(digits,substr(value,i,1))-1
        if(digit < 0) return -1
        result=result*16+digit
      }
      return result
    }
    /^[[:space:]]*$/ { next }
    {
      rows++
      if(NF != 10 || !hex_width($1,32) || !prefix_shape($2) ||
         !hex_width($3,32) || !prefix_shape($4) || !hex_width($5,32) ||
         !hex_width($6,8) || !hex_width($7,8) || !hex_width($8,8) ||
         !hex_width($9,8) || !interface_shape($10)) {
        invalid=1
        next
      }
      if(toupper($1)=="00000000000000000000000000000000" &&
         zero_prefix($2) && $10!="lo" && flags_up($9)) {
        metric=hex_value($6)
        if(metric < 0) {
          invalid=1
          next
        }
        if(!found || metric < best_metric ||
           (metric == best_metric && $10 < best_interface)) {
          found=1
          best_metric=metric
          best_interface=$10
        }
      }
    }
    END {
      if(invalid || rows == 0) {
        print "network_ipv6_default_route_status=UNKNOWN"
        print "network_ipv6_default_interface=unavailable"
      } else if(found) {
        print "network_ipv6_default_route_status=PRESENT"
        print "network_ipv6_default_interface=" best_interface
      } else {
        print "network_ipv6_default_route_status=ABSENT"
        print "network_ipv6_default_interface=unavailable"
      }
    }
  ' "$file" 2>/dev/null)"; then
    printf '%s\n' \
      'network_ipv6_default_route_status=UNKNOWN' \
      'network_ipv6_default_interface=unavailable'
    return 0
  fi
  if [[ -z "$parsed" ]]; then
    printf '%s\n' \
      'network_ipv6_default_route_status=UNKNOWN' \
      'network_ipv6_default_interface=unavailable'
  else
    printf '%s\n' "$parsed"
  fi
}

network_time_collect_route_metrics() {
  local ipv4_metrics ipv6_metrics ipv4_status=UNKNOWN ipv4_interface=unavailable
  local ipv6_status=UNKNOWN ipv6_interface=unavailable primary mtu_raw=unavailable
  ipv4_metrics="$(network_time_parse_route4_file "$NETWORK_TIME_ROUTE4_FILE")"
  ipv4_status="$(network_time_value "$ipv4_metrics" network_ipv4_default_route_status)" || ipv4_status=UNKNOWN
  ipv4_interface="$(network_time_value "$ipv4_metrics" network_ipv4_default_interface)" || ipv4_interface=unavailable
  ipv6_metrics="$(network_time_parse_route6_file "$NETWORK_TIME_ROUTE6_FILE")"
  ipv6_status="$(network_time_value "$ipv6_metrics" network_ipv6_default_route_status)" || ipv6_status=UNKNOWN
  ipv6_interface="$(network_time_value "$ipv6_metrics" network_ipv6_default_interface)" || ipv6_interface=unavailable
  if [[ "$ipv4_status" == PRESENT ]]; then primary="$ipv4_interface"
  elif [[ "$ipv6_status" == PRESENT ]]; then primary="$ipv6_interface"
  else primary=unavailable
  fi
  if [[ "$primary" != unavailable && -r "$NETWORK_TIME_SYS_CLASS_NET_ROOT/$primary/mtu" ]]; then
    IFS= read -r mtu_raw <"$NETWORK_TIME_SYS_CLASS_NET_ROOT/$primary/mtu" || mtu_raw=unavailable
  fi
  network_time_route_metrics_from_values \
    "$ipv4_status" "$ipv4_interface" "$ipv6_status" "$ipv6_interface" "$mtu_raw"
}

network_time_name_service_metrics_from_values() {
  local resolver_status="$1" resolver_count="$2" resolution_status="$3" requested="$4" succeeded="$5"
  [[ "$resolver_status" =~ ^(CONFIGURED|MISSING|UNKNOWN)$ ]] || return 1
  [[ "$resolution_status" =~ ^(RESOLVED|PARTIAL|NO_SUCCESS|UNKNOWN)$ ]] || return 1
  [[ "$resolver_count" =~ ^[0-9]+$ || "$resolver_count" == unavailable ]] || return 1
  [[ "$requested" =~ ^[0-9]+$ || "$requested" == unavailable ]] || return 1
  [[ "$succeeded" =~ ^[0-9]+$ || "$succeeded" == unavailable ]] || return 1
  printf '%s\n' \
    "network_resolver_configuration_status=$resolver_status" \
    "network_resolver_nameserver_count=$resolver_count" \
    "network_name_service_resolution_status=$resolution_status" \
    "network_name_service_resolution_requested_count=$requested" \
    "network_name_service_resolution_success_count=$succeeded"
}

network_time_collect_name_service_metrics() {
  local resolver_status=UNKNOWN resolver_count=unavailable resolution_status=UNKNOWN
  local resolver_scan declarations valid invalid requested=unavailable succeeded=unavailable host
  if [[ -r "$NETWORK_TIME_RESOLV_CONF" ]]; then
    resolver_scan="$(awk '
      function valid_ipv4(value, part, count, i) {
        count=split(value,part,".")
        if(count != 4) return 0
        for(i=1;i<=4;i++) {
          if(part[i] !~ /^[0-9]+$/ || part[i]+0 > 255) return 0
        }
        return 1
      }
      function valid_ipv6(value, zone_parts, zone_count, address, compressed,
                          hextet, count, i) {
        zone_count=split(value,zone_parts,"%")
        if(zone_count > 2 || (zone_count == 2 && zone_parts[2] !~ /^[A-Za-z0-9_.-]+$/)) return 0
        address=zone_parts[1]
        if(address !~ /^[0-9A-Fa-f:]+$/ || index(address,":") == 0 || address ~ /:::/) return 0
        compressed=(index(address,"::") > 0)
        if(compressed) {
          hextet_address=address
          sub(/::/,"",hextet_address)
          if(index(hextet_address,"::") > 0) return 0
        }
        count=split(address,hextet,":")
        if(count > 8 || (!compressed && count != 8)) return 0
        for(i=1;i<=count;i++) {
          if(hextet[i] != "" && (length(hextet[i]) > 4 || hextet[i] !~ /^[0-9A-Fa-f]+$/)) return 0
        }
        return 1
      }
      function valid_nameserver(value) {
        return valid_ipv4(value) || valid_ipv6(value)
      }
      {
        line=$0
        sub(/^[[:space:]]+/,"",line)
        if(line=="" || line ~ /^#/) next
        count=split(line,field,/[[:space:]]+/)
        if(field[1] != "nameserver") next
        declarations++
        if(count >= 2 && valid_nameserver(field[2]) &&
           (count == 2 || field[3] ~ /^#/)) valid++
        else invalid++
      }
      END { print declarations+0, valid+0, invalid+0 }
    ' "$NETWORK_TIME_RESOLV_CONF" 2>/dev/null || true)"
    if [[ "$resolver_scan" =~ ^[0-9]+[[:space:]][0-9]+[[:space:]][0-9]+$ ]]; then
      IFS=' ' read -r declarations valid invalid <<<"$resolver_scan"
      if (( invalid > 0 )); then
        resolver_status=UNKNOWN
      elif (( valid > 0 )); then
        resolver_status=CONFIGURED
        resolver_count="$valid"
      elif (( declarations == 0 )); then
        resolver_status=MISSING
        resolver_count=0
      fi
    fi
  fi
  if command -v getent >/dev/null 2>&1; then
    requested=2
    succeeded=0
    for host in github.com archive.ubuntu.com; do
      if getent ahosts "$host" >/dev/null 2>&1; then
        succeeded=$((succeeded+1))
      fi
    done
    if (( succeeded == requested )); then resolution_status=RESOLVED
    elif (( succeeded > 0 )); then resolution_status=PARTIAL
    else resolution_status=NO_SUCCESS
    fi
  fi
  network_time_name_service_metrics_from_values \
    "$resolver_status" "$resolver_count" "$resolution_status" "$requested" "$succeeded"
}

network_time_time_metrics_from_values() {
  local evidence_status="$1" synchronized="$2" ntp_enabled="$3" can_ntp="$4" timezone="$5" uptime="$6"
  [[ "$evidence_status" =~ ^(ok|unavailable|malformed)$ ]] || return 1
  [[ "$synchronized" =~ ^(yes|no|unavailable)$ ]] || return 1
  [[ "$ntp_enabled" =~ ^(yes|no|unavailable)$ ]] || return 1
  [[ "$can_ntp" =~ ^(yes|no|unavailable)$ ]] || return 1
  [[ "$timezone" =~ ^[A-Za-z0-9_+./-]+$ ]] || timezone=unavailable
  [[ "$uptime" =~ ^[0-9]+$ ]] || uptime=unavailable
  printf '%s\n' \
    "network_time_evidence_status=$evidence_status" \
    "network_time_ntp_synchronized=$synchronized" \
    "network_time_ntp_enabled=$ntp_enabled" \
    "network_time_can_ntp=$can_ntp" \
    "network_time_timezone=$timezone" \
    "network_time_uptime_seconds=$uptime"
}

network_time_collect_time_metrics() {
  local output evidence_status=unavailable synchronized=unavailable ntp_enabled=unavailable
  local can_ntp=unavailable timezone=unavailable uptime=unavailable raw_uptime
  if command -v timedatectl >/dev/null 2>&1 && output="$(timedatectl show 2>/dev/null)"; then
    synchronized="$(printf '%s\n' "$output" | awk -F= '$1=="NTPSynchronized"{count++; value=$2} END{if(count==1) print value; else print "unavailable"}')"
    ntp_enabled="$(printf '%s\n' "$output" | awk -F= '$1=="NTP"{count++; value=$2} END{if(count==1) print value; else print "unavailable"}')"
    can_ntp="$(printf '%s\n' "$output" | awk -F= '$1=="CanNTP"{count++; value=$2} END{if(count==1) print value; else print "unavailable"}')"
    timezone="$(printf '%s\n' "$output" | awk -F= '$1=="Timezone"{count++; value=$2} END{if(count==1) print value; else print "unavailable"}')"
    if [[ "$synchronized" =~ ^(yes|no)$ ]]; then evidence_status=ok
    else evidence_status=malformed; synchronized=unavailable
    fi
    [[ "$ntp_enabled" =~ ^(yes|no)$ ]] || ntp_enabled=unavailable
    [[ "$can_ntp" =~ ^(yes|no)$ ]] || can_ntp=unavailable
  fi
  if [[ -r "$NETWORK_TIME_UPTIME_FILE" ]]; then
    IFS=' ' read -r raw_uptime _ <"$NETWORK_TIME_UPTIME_FILE" || raw_uptime=unavailable
    if [[ "$raw_uptime" =~ ^[0-9]+([.][0-9]+)?$ ]]; then uptime="${raw_uptime%%.*}"; fi
  fi
  network_time_time_metrics_from_values \
    "$evidence_status" "$synchronized" "$ntp_enabled" "$can_ntp" "$timezone" "$uptime"
}

network_time_readiness_evaluate() {
  local route="$1" dns="$2" time="$3"
  local ipv4 ipv4_interface ipv6 ipv6_interface primary mtu mtu_status mtu_profile
  local resolver resolver_count resolution_status resolution_requested resolution_success
  local time_evidence synchronized ntp_enabled can_ntp timezone uptime time_status=UNKNOWN
  local status=READY confidence=MEDIUM coverage_status=complete limitation
  ipv4="$(network_time_value "$route" network_ipv4_default_route_status)" || return 1
  ipv4_interface="$(network_time_value "$route" network_ipv4_default_interface)" || return 1
  ipv6="$(network_time_value "$route" network_ipv6_default_route_status)" || return 1
  ipv6_interface="$(network_time_value "$route" network_ipv6_default_interface)" || return 1
  primary="$(network_time_value "$route" network_readiness_primary_interface)" || return 1
  mtu="$(network_time_value "$route" network_primary_interface_mtu)" || return 1
  mtu_status="$(network_time_value "$route" network_mtu_status)" || return 1
  mtu_profile="$(network_time_value "$route" network_mtu_profile)" || return 1
  resolver="$(network_time_value "$dns" network_resolver_configuration_status)" || return 1
  resolver_count="$(network_time_value "$dns" network_resolver_nameserver_count)" || return 1
  resolution_status="$(network_time_value "$dns" network_name_service_resolution_status)" || return 1
  resolution_requested="$(network_time_value "$dns" network_name_service_resolution_requested_count)" || return 1
  resolution_success="$(network_time_value "$dns" network_name_service_resolution_success_count)" || return 1
  time_evidence="$(network_time_value "$time" network_time_evidence_status)" || return 1
  synchronized="$(network_time_value "$time" network_time_ntp_synchronized)" || return 1
  ntp_enabled="$(network_time_value "$time" network_time_ntp_enabled)" || return 1
  can_ntp="$(network_time_value "$time" network_time_can_ntp)" || return 1
  timezone="$(network_time_value "$time" network_time_timezone)" || return 1
  uptime="$(network_time_value "$time" network_time_uptime_seconds)" || return 1

  if [[ ! "$uptime" =~ ^[0-9]+$ ]]; then
    time_status=UNKNOWN
  elif [[ "$time_evidence" == ok && "$synchronized" == yes ]]; then
    time_status=SYNCED
  elif [[ "$time_evidence" == ok && "$synchronized" == no && "$uptime" =~ ^[0-9]+$ ]] &&
       (( uptime < NETWORK_TIME_FRESH_BOOT_SECONDS )) && [[ "$ntp_enabled" != no && "$can_ntp" != no ]]; then
    time_status=PENDING_RECHECK
  elif [[ "$time_evidence" == ok && "$synchronized" == no ]]; then
    time_status=UNSYNCED_REVIEW
  fi

  limitation='local_read_only_evidence_only;external_reachability_not_checked;name_service_success_may_come_from_hosts_or_other_nss_sources;name_service_success_does_not_prove_dns_or_all_networking;mtu_path_compatibility_not_tested;clock_correctness_not_certified_from_self_report;domain_tls_not_checked_without_endpoint_context'
  if [[ "$ipv4" == UNKNOWN || "$ipv6" == UNKNOWN || "$mtu_status" == UNKNOWN ||
        "$resolver" == UNKNOWN || "$resolution_status" == UNKNOWN || "$time_status" == UNKNOWN ]]; then
    status=UNKNOWN
    confidence=LIMITED
    coverage_status=limited
    limitation="${limitation};one_or_more_sources_unknown_or_unparseable"
  elif [[ "$ipv4" == ABSENT && "$ipv6" == ABSENT ]]; then
    status=REVIEW
    limitation="${limitation};no_default_route_observed_for_either_family"
  elif [[ "$resolver" == MISSING || "$resolution_status" =~ ^(PARTIAL|NO_SUCCESS)$ ||
          "$time_status" == UNSYNCED_REVIEW ]]; then
    status=REVIEW
    limitation="${limitation};resolver_dns_or_established_time_state_requires_review"
  elif [[ "$time_status" == PENDING_RECHECK ]]; then
    status=PENDING_RECHECK
    confidence=LIMITED
    limitation="${limitation};fresh_boot_time_sync_requires_recheck"
  fi

  printf '%s\n' \
    "network_time_evidence_schema_version=$NETWORK_TIME_READINESS_SCHEMA_VERSION" \
    "network_time_readiness_schema_version=$NETWORK_TIME_READINESS_SCHEMA_VERSION" \
    "network_time_readiness_status=$status" \
    "network_time_readiness_confidence=$confidence" \
    "network_time_readiness_coverage_status=$coverage_status" \
    "$route" "$dns" "$time" \
    "network_time_sync_status=$time_status" \
    "network_time_external_reachability_status=NOT_CHECKED" \
    "network_time_domain_tls_status=NOT_CHECKED" \
    'network_time_readiness_checked_scope=default_routes,primary_interface_mtu,resolver_configuration,bounded_name_service_resolution,native_time_sync_state' \
    'network_time_readiness_not_checked_status=NOT CHECKED' \
    'network_time_readiness_not_checked_families=external_reachability,path_mtu,remote_clock_reference,domain_tls' \
    "network_time_readiness_limitations=$limitation" \
    "network_time_readiness_fact_routes=ipv4:${ipv4}/${ipv4_interface};ipv6:${ipv6}/${ipv6_interface};primary:${primary};mtu:${mtu}/${mtu_status}/${mtu_profile}" \
    "network_time_readiness_fact_name_service=resolver:${resolver}/${resolver_count};bounded_nss_lookup:${resolution_status}/${resolution_success}_of_${resolution_requested}" \
    "network_time_readiness_fact_time=sync:${time_status};native:${synchronized};ntp:${ntp_enabled};can_ntp:${can_ntp};timezone:${timezone};uptime_seconds:${uptime}"
}

sample_network_time_readiness_metrics() {
  local route dns time
  route="$(network_time_collect_route_metrics)" || return 1
  dns="$(network_time_collect_name_service_metrics)" || return 1
  time="$(network_time_collect_time_metrics)" || return 1
  network_time_readiness_evaluate "$route" "$dns" "$time"
}

#!/usr/bin/env bash
# Evidence-based summary policy for the audit-only diagnostic candidate.

DIAGNOSTIC_SCHEMA_VERSION=10
DIAGNOSTIC_METHOD_VERSION="diagnostic-app-service-v2"
FINDINGS_SCHEMA_VERSION=1
FINDINGS_READABLE_LIMIT=5

report_safe_operator_label() {
  local value="$1"
  case "$value" in
    *"-----BEGIN "*"PRIVATE KEY-----"*)
      printf 'REDACTED_PRIVATE_KEY\n'
      ;;
    *)
      printf '%s\n' "$value" | redact
      ;;
  esac
}

ranked_findings_readable_text() {
  local summary_file="$1" limit="${2:-$FINDINGS_READABLE_LIMIT}"
  awk -F= -v limit="$limit" '
    function value(line) { sub(/^[^=]*=/,"",line); return line }
    $1=="findings_total" { total=$2+0; next }
    $1 ~ /^finding_[0-9]+_/ {
      key=$1
      sub(/^finding_/,"",key)
      rank=key
      sub(/_.*/,"",rank)
      field=key
      sub(/^[0-9]+_/,"",field)
      data[rank SUBSEP field]=value($0)
    }
    END {
      if (total==0) {
        print "Существенных находок нет."
        exit
      }
      shown=(total<limit?total:limit)
      printf "Показано %d из %d.\n",shown,total
      for(i=1;i<=shown;i++) {
        printf "%d. [%s; риск %s] %s:\n",i,data[i SUBSEP "confidence"],data[i SUBSEP "severity_score"],data[i SUBSEP "code"]
        printf "   Измерено: %s %s; порог %s.\n",data[i SUBSEP "observed_value"],data[i SUBSEP "unit"],data[i SUBSEP "threshold"]
        printf "   Подтверждено: %s\n",data[i SUBSEP "confirmed"]
        printf "   Интерпретация: %s\n",data[i SUBSEP "interpretation"]
        printf "   Ограничение: %s\n",data[i SUBSEP "limitations"]
        printf "   Действие: %s\n",data[i SUBSEP "next_action"]
      }
    }
  ' "$summary_file"
}

platform_release_notice_text() {
  local summary_file="$1" support_status validation_status platform_id platform_version validated_list
  support_status="$(awk -F= '$1=="platform_support_status"{print $2}' "$summary_file")"
  [[ "$support_status" == compatible_unverified ]] || return 0
  validation_status="$(awk -F= '$1=="platform_validation_status"{print $2}' "$summary_file")"
  platform_id="$(awk -F= '$1=="platform_id"{print $2}' "$summary_file")"
  platform_version="$(awk -F= '$1=="platform_version_id"{print $2}' "$summary_file")"
  validated_list="$(awk -F= '$1=="platform_validated_list"{print $2}' "$summary_file")"
  printf '%s\n' \
    "PLATFORM_RELEASE_UNVALIDATED: ${platform_id:-unavailable}:${platform_version:-unavailable}." \
    "Статус: ${support_status}/${validation_status:-unavailable}. Выпуск распознан, но ещё не прошёл полную матрицу проверки Server Toolkit." \
    "Полностью проверенные выпуски: ${validated_list:-unavailable}." \
    "Ограничение: общий confidence не может быть выше LIMITED; отдельная находка с LOW confidence сохраняет LOW." \
    "Действие: проверить coverage и недоступные показатели; для полной гарантии нужен отдельный CI/live gate этого выпуска."
}

diagnostic_probe_kernel_journal() {
  local output
  KERNEL_JOURNAL_STATUS=unavailable
  KERNEL_OOM_EVENTS=unavailable
  KERNEL_STORAGE_ERRORS=unavailable
  command -v journalctl >/dev/null 2>&1 || return 0
  if ! output="$(journalctl -k --since '24 hours ago' --no-pager 2>/dev/null)"; then
    return 0
  fi
  KERNEL_JOURNAL_STATUS=ok
  KERNEL_OOM_EVENTS="$(printf '%s\n' "$output" | grep -Eic 'out of memory|oom-killer|killed process' || true)"
  KERNEL_STORAGE_ERRORS="$(printf '%s\n' "$output" | grep -Eic 'I/O error|filesystem error|EXT4-fs error|XFS.*error|blk_update_request' || true)"
}

diagnostic_probe_failed_services() {
  local output
  SYSTEMD_FAILED_SERVICES_STATUS=unavailable
  DIAGNOSTIC_FAILED_NAMES=""
  command -v systemctl >/dev/null 2>&1 || return 0
  if ! output="$(systemctl --failed --no-legend --plain 2>/dev/null)"; then
    return 0
  fi
  SYSTEMD_FAILED_SERVICES_STATUS=ok
  DIAGNOSTIC_FAILED_NAMES="$(printf '%s\n' "$output" | awk '{print $1}' | sed '/^$/d' || true)"
}

diagnostic_reboot_required() {
  [[ -f /var/run/reboot-required ]]
}

# Embedded summary code intentionally consumes state populated by sibling modules
# and caller-local report paths.
# shellcheck disable=SC2154
make_summary() {
  local phase="$1" out="$2" max_severity=0 finding_count=0 verdict reboot oom fs_errors
  local apt_refresh_status apt_simulation_status failed_names virt informational unknown critical role_relevant reason action os_name
  local apt_index_status apt_index_coverage_status network_check_status network_rc diagnostic_confidence kernel_journal_status systemd_failed_services_status
  local package_update_evidence_status updates_total_report kernel_updates_report phased_updates_report normal_updates_report
  local coverage_status coverage_required=0 coverage_completed=0 coverage_missing=none coverage_limited=none
  local cpu_sample_status cpu_sample_count cpu_sample_duration cpu_sample_method
  local iowait iowait_min iowait_median iowait_average iowait_threshold iowait_exceedances iowait_pattern iowait_confidence
  local steal steal_min steal_median steal_average steal_threshold steal_exceedances steal_pattern steal_confidence
  local load_status load_1m load_5m load_15m load_per_vcpu load_threshold vcpu_count
  local io_pressure_status io_pressure_some io_pressure_full
  local storage_filesystem_status storage_device_status storage_device_sample_status storage_latency_status storage_device
  local storage_sample_method storage_sample_count storage_sample_interval storage_sample_duration
  local root_source root_filesystem root_read_only root_total root_used root_available root_used_pct root_inode_used_pct
  local storage_operations storage_activity_windows storage_latency_windows storage_inflight
  local storage_await_min storage_await_median storage_await_average storage_await_max storage_await_threshold storage_await_exceedances
  local storage_read_await_max storage_write_await_max
  local storage_util_min storage_util_median storage_util_average storage_util_max storage_util_threshold storage_util_exceedances
  local storage_queue_min storage_queue_median storage_queue_average storage_queue_max storage_queue_threshold storage_queue_exceedances
  local memory_pressure_status cpu_pressure_status pressure_sample_count pressure_sample_duration
  local mem_available_min mem_available_median mem_available_average mem_available_max mem_available_threshold mem_available_exceedances
  local mem_available_critical_threshold mem_available_critical_exceedances swap_used_max
  local swap_in_max swap_in_threshold swap_in_exceedances swap_out_max swap_out_threshold swap_out_exceedances
  local major_fault_max major_fault_threshold major_fault_exceedances
  local memory_psi_some_max memory_psi_some_threshold memory_psi_some_exceedances
  local memory_psi_full_max memory_psi_full_threshold memory_psi_full_exceedances
  local cpu_psi_some_max cpu_psi_some_threshold cpu_psi_some_exceedances
  local run_queue_max run_queue_threshold run_queue_exceedances pressure_pattern pressure_confidence
  local network_counter_status network_interface network_sample_count network_activity_windows network_reset_windows
  local network_sample_method network_sample_interval network_sample_duration
  local network_retrans_ratio_max network_retrans_ratio_threshold network_retrans_ratio_exceedances
  local network_timeout_max network_timeout_exceedances network_syn_max network_syn_exceedances
  local network_listen_drop_max network_listen_drop_exceedances network_listen_overflow_max network_listen_overflow_exceedances
  local network_abort_max network_abort_exceedances network_error_max network_error_exceedances network_drop_max network_drop_exceedances
  local application_service_status application_service_method application_journal_status application_journal_window application_journal_max application_journal_records application_journal_truncated
  local service_restart_counter_status service_restart_counter_scope service_units_observed service_units_with_restarts service_restart_total service_restart_max service_restart_invalid
  local application_sqlite_locks application_timeouts service_failure_events service_restart_events
  local application_role_scope_status application_role_records application_role_truncated application_role_events application_sqlite_threshold application_timeout_threshold
  local service_failure_threshold service_restart_threshold role_service_threshold
  local provider_label_report_safe location_label_report_safe role_label_report_safe
  local access_evidence_schema_version ssh_effective_status ssh_effective_root ssh_effective_password ssh_effective_keyboard ssh_effective_pubkey
  local ssh_effective_authentication_methods ssh_effective_context_status
  local ssh_effective_ports ssh_effective_config_scope ssh_allow_users_status ssh_allow_users_count ssh_allow_groups_status ssh_allow_groups_count
  local tcp_listener_status tcp_listener_total tcp_listener_loopback tcp_listener_wildcard tcp_listener_specific
  local ssh_listener_correlation ssh_listener_scope firewall_ufw_status firewall_nft_status firewall_nft_policy
  local firewall_nft_hooks firewall_nft_rules firewall_iptables_status firewall_iptables_policy firewall_iptables_rules
  local firewall_ip6tables_status firewall_ip6tables_policy firewall_ip6tables_rules local_firewall_status local_firewall_confidence local_firewall_sources
  local access_metrics access_readiness_status access_readiness_confidence ssh_access_status firewall_readiness_status package_readiness_status
  local access_fact_ssh access_fact_listener access_fact_firewall access_fact_packages access_correlation access_limitations access_checked_scope access_not_checked_status access_not_checked_families
  local network_time_evidence_schema_version network_time_readiness_schema_version network_time_readiness_status network_time_readiness_confidence network_time_readiness_coverage_status
  local network_ipv4_default_route_status network_ipv4_default_interface network_ipv6_default_route_status network_ipv6_default_interface
  local network_readiness_primary_interface network_primary_interface_mtu network_mtu_status network_mtu_profile
  local network_resolver_configuration_status network_resolver_nameserver_count network_name_service_resolution_status
  local network_name_service_resolution_requested_count network_name_service_resolution_success_count network_time_evidence_status
  local network_time_ntp_synchronized network_time_ntp_enabled network_time_can_ntp network_time_timezone network_time_uptime_seconds network_time_sync_status
  local network_time_external_reachability_status network_time_domain_tls_status network_time_checked_scope
  local network_time_not_checked_status network_time_not_checked_families network_time_limitations
  local network_time_fact_routes network_time_fact_name_service network_time_fact_time
  local package_finding_confidence=LIMITED
  local primary_code=none primary_category=none primary_confidence=HIGH primary_observed=none primary_unit=none primary_threshold=none
  local primary_confirmed="Существенных проблем не найдено" primary_interpretation="Измеренные показатели не пересекли настроенные пороги"
  local primary_limitation="Аудит ограничен указанными методами и временным окном"
  local -a findings_severity findings_code findings_category findings_confidence findings_observed findings_unit findings_threshold
  local -a findings_reason findings_action findings_confirmed findings_interpretation findings_limitation findings_order

  reboot=no
  diagnostic_reboot_required && reboot=yes
  cpu_sample_status="$(last_metric cpu_sample_status)"; cpu_sample_status="${cpu_sample_status:-unavailable}"
  cpu_sample_count="$(last_metric cpu_sample_count)"; cpu_sample_count="${cpu_sample_count:-unavailable}"
  cpu_sample_duration="$(last_metric cpu_sample_duration_seconds)"; cpu_sample_duration="${cpu_sample_duration:-unavailable}"
  cpu_sample_method="$(last_metric cpu_sample_method)"; cpu_sample_method="${cpu_sample_method:-unavailable}"
  iowait="$(last_metric iowait_max_pct)"; iowait="${iowait:-unavailable}"
  iowait_min="$(last_metric iowait_min_pct)"; iowait_min="${iowait_min:-unavailable}"
  iowait_median="$(last_metric iowait_median_pct)"; iowait_median="${iowait_median:-unavailable}"
  iowait_average="$(last_metric iowait_average_pct)"; iowait_average="${iowait_average:-unavailable}"
  iowait_threshold="$(last_metric iowait_threshold_pct)"; iowait_threshold="${iowait_threshold:-$IOWAIT_WARN_THRESHOLD}"
  iowait_exceedances="$(last_metric iowait_threshold_exceedance_count)"; iowait_exceedances="${iowait_exceedances:-unavailable}"
  steal="$(last_metric steal_max_pct)"; steal="${steal:-unavailable}"
  steal_min="$(last_metric steal_min_pct)"; steal_min="${steal_min:-unavailable}"
  steal_median="$(last_metric steal_median_pct)"; steal_median="${steal_median:-unavailable}"
  steal_average="$(last_metric steal_average_pct)"; steal_average="${steal_average:-unavailable}"
  steal_threshold="$(last_metric steal_threshold_pct)"; steal_threshold="${steal_threshold:-$STEAL_WARN_THRESHOLD}"
  steal_exceedances="$(last_metric steal_threshold_exceedance_count)"; steal_exceedances="${steal_exceedances:-unavailable}"
  load_status="$(last_metric load_sample_status)"; load_status="${load_status:-unavailable}"
  vcpu_count="$(last_metric vcpu_count)"; vcpu_count="${vcpu_count:-unavailable}"
  load_1m="$(last_metric load_1m)"; load_1m="${load_1m:-unavailable}"
  load_5m="$(last_metric load_5m)"; load_5m="${load_5m:-unavailable}"
  load_15m="$(last_metric load_15m)"; load_15m="${load_15m:-unavailable}"
  load_per_vcpu="$(last_metric load_1m_per_vcpu)"; load_per_vcpu="${load_per_vcpu:-unavailable}"
  load_threshold="$(last_metric load_1m_per_vcpu_threshold)"; load_threshold="${load_threshold:-$LOAD_PER_VCPU_WARN_THRESHOLD}"
  io_pressure_status="$(last_metric io_pressure_status)"; io_pressure_status="${io_pressure_status:-unavailable}"
  io_pressure_some="$(last_metric io_pressure_some_avg10_pct)"; io_pressure_some="${io_pressure_some:-unavailable}"
  io_pressure_full="$(last_metric io_pressure_full_avg10_pct)"; io_pressure_full="${io_pressure_full:-unavailable}"
  storage_filesystem_status="$(last_metric storage_filesystem_status)"; storage_filesystem_status="${storage_filesystem_status:-unavailable}"
  storage_device_status="$(last_metric storage_device_status)"; storage_device_status="${storage_device_status:-unavailable}"
  storage_device_sample_status="$(last_metric storage_device_sample_status)"; storage_device_sample_status="${storage_device_sample_status:-unavailable}"
  storage_latency_status="$(last_metric storage_latency_evidence_status)"; storage_latency_status="${storage_latency_status:-unavailable}"
  storage_device="$(last_metric storage_device)"; storage_device="${storage_device:-unavailable}"
  storage_sample_method="$(last_metric storage_sample_method)"; storage_sample_method="${storage_sample_method:-unavailable}"
  storage_sample_count="$(last_metric storage_device_sample_count)"; storage_sample_count="${storage_sample_count:-unavailable}"
  storage_sample_interval="$(last_metric storage_sample_interval_seconds)"; storage_sample_interval="${storage_sample_interval:-unavailable}"
  storage_sample_duration=unavailable
  if [[ "$storage_sample_count" =~ ^[0-9]+$ && "$storage_sample_interval" =~ ^[0-9]+$ ]]; then
    storage_sample_duration=$((storage_sample_count * storage_sample_interval))
  fi
  root_source="$(last_metric root_source)"; root_source="${root_source:-unavailable}"
  root_filesystem="$(last_metric root_filesystem)"; root_filesystem="${root_filesystem:-unavailable}"
  root_read_only="$(last_metric root_mount_read_only)"; root_read_only="${root_read_only:-unknown}"
  root_total="$(last_metric root_total_kib)"; root_total="${root_total:-unavailable}"
  root_used="$(last_metric root_used_kib)"; root_used="${root_used:-unavailable}"
  root_available="$(last_metric root_available_kib)"; root_available="${root_available:-unavailable}"
  root_used_pct="$(last_metric root_used_pct)"; root_used_pct="${root_used_pct:-unavailable}"
  root_inode_used_pct="$(last_metric root_inode_used_pct)"; root_inode_used_pct="${root_inode_used_pct:-unavailable}"
  storage_operations="$(last_metric storage_device_operations)"; storage_operations="${storage_operations:-unavailable}"
  storage_activity_windows="$(last_metric storage_device_activity_windows)"; storage_activity_windows="${storage_activity_windows:-unavailable}"
  storage_latency_windows="$(last_metric storage_device_latency_windows)"; storage_latency_windows="${storage_latency_windows:-unavailable}"
  storage_inflight="$(last_metric storage_device_inflight)"; storage_inflight="${storage_inflight:-unavailable}"
  storage_await_min="$(last_metric storage_await_ms_min)"; storage_await_min="${storage_await_min:-unavailable}"
  storage_await_median="$(last_metric storage_await_ms_median)"; storage_await_median="${storage_await_median:-unavailable}"
  storage_await_average="$(last_metric storage_await_ms_average)"; storage_await_average="${storage_await_average:-unavailable}"
  storage_await_max="$(last_metric storage_await_ms_max)"; storage_await_max="${storage_await_max:-unavailable}"
  storage_await_threshold="$(last_metric storage_await_ms_threshold)"; storage_await_threshold="${storage_await_threshold:-$STORAGE_AWAIT_WARN_MS}"
  storage_await_exceedances="$(last_metric storage_await_ms_threshold_exceedance_count)"; storage_await_exceedances="${storage_await_exceedances:-unavailable}"
  storage_read_await_max="$(last_metric storage_read_await_ms_max)"; storage_read_await_max="${storage_read_await_max:-unavailable}"
  storage_write_await_max="$(last_metric storage_write_await_ms_max)"; storage_write_await_max="${storage_write_await_max:-unavailable}"
  storage_util_min="$(last_metric storage_util_pct_min)"; storage_util_min="${storage_util_min:-unavailable}"
  storage_util_median="$(last_metric storage_util_pct_median)"; storage_util_median="${storage_util_median:-unavailable}"
  storage_util_average="$(last_metric storage_util_pct_average)"; storage_util_average="${storage_util_average:-unavailable}"
  storage_util_max="$(last_metric storage_util_pct_max)"; storage_util_max="${storage_util_max:-unavailable}"
  storage_util_threshold="$(last_metric storage_util_pct_threshold)"; storage_util_threshold="${storage_util_threshold:-$STORAGE_UTIL_WARN_PCT}"
  storage_util_exceedances="$(last_metric storage_util_pct_threshold_exceedance_count)"; storage_util_exceedances="${storage_util_exceedances:-unavailable}"
  storage_queue_min="$(last_metric storage_queue_depth_min)"; storage_queue_min="${storage_queue_min:-unavailable}"
  storage_queue_median="$(last_metric storage_queue_depth_median)"; storage_queue_median="${storage_queue_median:-unavailable}"
  storage_queue_average="$(last_metric storage_queue_depth_average)"; storage_queue_average="${storage_queue_average:-unavailable}"
  storage_queue_max="$(last_metric storage_queue_depth_max)"; storage_queue_max="${storage_queue_max:-unavailable}"
  storage_queue_threshold="$(last_metric storage_queue_depth_threshold)"; storage_queue_threshold="${storage_queue_threshold:-$STORAGE_QUEUE_WARN}"
  storage_queue_exceedances="$(last_metric storage_queue_depth_threshold_exceedance_count)"; storage_queue_exceedances="${storage_queue_exceedances:-unavailable}"
  memory_pressure_status="$(last_metric memory_pressure_sample_status)"; memory_pressure_status="${memory_pressure_status:-unavailable}"
  cpu_pressure_status="$(last_metric cpu_pressure_sample_status)"; cpu_pressure_status="${cpu_pressure_status:-unavailable}"
  pressure_sample_count="$(last_metric pressure_sample_count_requested)"; pressure_sample_count="${pressure_sample_count:-unavailable}"
  pressure_sample_duration="$(last_metric pressure_sample_duration_seconds)"; pressure_sample_duration="${pressure_sample_duration:-unavailable}"
  mem_available_min="$(last_metric mem_available_pct_min)"; mem_available_min="${mem_available_min:-unavailable}"
  mem_available_median="$(last_metric mem_available_pct_median)"; mem_available_median="${mem_available_median:-unavailable}"
  mem_available_average="$(last_metric mem_available_pct_average)"; mem_available_average="${mem_available_average:-unavailable}"
  mem_available_max="$(last_metric mem_available_pct_max)"; mem_available_max="${mem_available_max:-unavailable}"
  mem_available_threshold="$(last_metric mem_available_pct_threshold)"; mem_available_threshold="${mem_available_threshold:-$MEM_AVAILABLE_WARN_PCT}"
  mem_available_exceedances="$(last_metric mem_available_pct_threshold_exceedance_count)"; mem_available_exceedances="${mem_available_exceedances:-unavailable}"
  mem_available_critical_threshold="$(last_metric mem_available_pct_critical_threshold)"; mem_available_critical_threshold="${mem_available_critical_threshold:-$MEM_AVAILABLE_CRITICAL_PCT}"
  mem_available_critical_exceedances="$(last_metric mem_available_pct_critical_threshold_exceedance_count)"; mem_available_critical_exceedances="${mem_available_critical_exceedances:-unavailable}"
  swap_used_max="$(last_metric swap_used_pct_max)"; swap_used_max="${swap_used_max:-unavailable}"
  swap_in_max="$(last_metric swap_in_pages_per_second_max)"; swap_in_max="${swap_in_max:-unavailable}"
  swap_in_threshold="$(last_metric swap_in_pages_per_second_threshold)"; swap_in_threshold="${swap_in_threshold:-$SWAP_IO_RATE_WARN}"
  swap_in_exceedances="$(last_metric swap_in_pages_per_second_threshold_exceedance_count)"; swap_in_exceedances="${swap_in_exceedances:-unavailable}"
  swap_out_max="$(last_metric swap_out_pages_per_second_max)"; swap_out_max="${swap_out_max:-unavailable}"
  swap_out_threshold="$(last_metric swap_out_pages_per_second_threshold)"; swap_out_threshold="${swap_out_threshold:-$SWAP_IO_RATE_WARN}"
  swap_out_exceedances="$(last_metric swap_out_pages_per_second_threshold_exceedance_count)"; swap_out_exceedances="${swap_out_exceedances:-unavailable}"
  major_fault_max="$(last_metric major_faults_per_second_max)"; major_fault_max="${major_fault_max:-unavailable}"
  major_fault_threshold="$(last_metric major_faults_per_second_threshold)"; major_fault_threshold="${major_fault_threshold:-$MAJOR_FAULT_RATE_WARN}"
  major_fault_exceedances="$(last_metric major_faults_per_second_threshold_exceedance_count)"; major_fault_exceedances="${major_fault_exceedances:-unavailable}"
  memory_psi_some_max="$(last_metric memory_psi_some_avg10_pct_max)"; memory_psi_some_max="${memory_psi_some_max:-unavailable}"
  memory_psi_some_threshold="$(last_metric memory_psi_some_avg10_pct_threshold)"; memory_psi_some_threshold="${memory_psi_some_threshold:-$MEMORY_PSI_SOME_WARN_PCT}"
  memory_psi_some_exceedances="$(last_metric memory_psi_some_avg10_pct_threshold_exceedance_count)"; memory_psi_some_exceedances="${memory_psi_some_exceedances:-unavailable}"
  memory_psi_full_max="$(last_metric memory_psi_full_avg10_pct_max)"; memory_psi_full_max="${memory_psi_full_max:-unavailable}"
  memory_psi_full_threshold="$(last_metric memory_psi_full_avg10_pct_threshold)"; memory_psi_full_threshold="${memory_psi_full_threshold:-$MEMORY_PSI_FULL_WARN_PCT}"
  memory_psi_full_exceedances="$(last_metric memory_psi_full_avg10_pct_threshold_exceedance_count)"; memory_psi_full_exceedances="${memory_psi_full_exceedances:-unavailable}"
  cpu_psi_some_max="$(last_metric cpu_psi_some_avg10_pct_max)"; cpu_psi_some_max="${cpu_psi_some_max:-unavailable}"
  cpu_psi_some_threshold="$(last_metric cpu_psi_some_avg10_pct_threshold)"; cpu_psi_some_threshold="${cpu_psi_some_threshold:-$CPU_PSI_SOME_WARN_PCT}"
  cpu_psi_some_exceedances="$(last_metric cpu_psi_some_avg10_pct_threshold_exceedance_count)"; cpu_psi_some_exceedances="${cpu_psi_some_exceedances:-unavailable}"
  run_queue_max="$(last_metric run_queue_per_vcpu_max)"; run_queue_max="${run_queue_max:-unavailable}"
  run_queue_threshold="$(last_metric run_queue_per_vcpu_threshold)"; run_queue_threshold="${run_queue_threshold:-$RUN_QUEUE_PER_VCPU_WARN}"
  run_queue_exceedances="$(last_metric run_queue_per_vcpu_threshold_exceedance_count)"; run_queue_exceedances="${run_queue_exceedances:-unavailable}"
  network_counter_status="$(last_metric network_counter_sample_status)"; network_counter_status="${network_counter_status:-unavailable}"
  network_interface="$(last_metric network_primary_interface)"; network_interface="${network_interface:-unavailable}"
  network_sample_count="$(last_metric network_counter_sample_count)"; network_sample_count="${network_sample_count:-unavailable}"
  network_sample_method="$(last_metric network_counter_sample_method)"; network_sample_method="${network_sample_method:-unavailable}"
  network_sample_interval="$(last_metric network_counter_sample_interval_seconds)"; network_sample_interval="${network_sample_interval:-unavailable}"
  network_sample_duration=unavailable
  if [[ "$network_sample_count" =~ ^[0-9]+$ && "$network_sample_interval" =~ ^[0-9]+$ ]]; then
    network_sample_duration=$((network_sample_count * network_sample_interval))
  fi
  network_activity_windows="$(last_metric network_counter_activity_windows)"; network_activity_windows="${network_activity_windows:-unavailable}"
  network_reset_windows="$(last_metric network_counter_reset_windows)"; network_reset_windows="${network_reset_windows:-unavailable}"
  network_retrans_ratio_max="$(last_metric network_tcp_retrans_ratio_pct_max)"; network_retrans_ratio_max="${network_retrans_ratio_max:-unavailable}"
  network_retrans_ratio_threshold="$(last_metric network_tcp_retrans_ratio_pct_threshold)"; network_retrans_ratio_threshold="${network_retrans_ratio_threshold:-$NETWORK_RETRANS_RATIO_WARN_PCT}"
  network_retrans_ratio_exceedances="$(last_metric network_tcp_retrans_ratio_pct_threshold_exceedance_count)"; network_retrans_ratio_exceedances="${network_retrans_ratio_exceedances:-unavailable}"
  network_timeout_max="$(last_metric network_tcp_timeout_events_per_second_max)"; network_timeout_max="${network_timeout_max:-unavailable}"
  network_timeout_exceedances="$(last_metric network_tcp_timeout_events_per_second_threshold_exceedance_count)"; network_timeout_exceedances="${network_timeout_exceedances:-unavailable}"
  network_syn_max="$(last_metric network_tcp_syn_retrans_events_per_second_max)"; network_syn_max="${network_syn_max:-unavailable}"
  network_syn_exceedances="$(last_metric network_tcp_syn_retrans_events_per_second_threshold_exceedance_count)"; network_syn_exceedances="${network_syn_exceedances:-unavailable}"
  network_listen_drop_max="$(last_metric network_listen_drop_events_per_second_max)"; network_listen_drop_max="${network_listen_drop_max:-unavailable}"
  network_listen_drop_exceedances="$(last_metric network_listen_drop_events_per_second_threshold_exceedance_count)"; network_listen_drop_exceedances="${network_listen_drop_exceedances:-unavailable}"
  network_listen_overflow_max="$(last_metric network_listen_overflow_events_per_second_max)"; network_listen_overflow_max="${network_listen_overflow_max:-unavailable}"
  network_listen_overflow_exceedances="$(last_metric network_listen_overflow_events_per_second_threshold_exceedance_count)"; network_listen_overflow_exceedances="${network_listen_overflow_exceedances:-unavailable}"
  network_abort_max="$(last_metric network_tcp_abort_timeout_events_per_second_max)"; network_abort_max="${network_abort_max:-unavailable}"
  network_abort_exceedances="$(last_metric network_tcp_abort_timeout_events_per_second_threshold_exceedance_count)"; network_abort_exceedances="${network_abort_exceedances:-unavailable}"
  network_error_max="$(last_metric network_interface_error_events_per_second_max)"; network_error_max="${network_error_max:-unavailable}"
  network_error_exceedances="$(last_metric network_interface_error_events_per_second_threshold_exceedance_count)"; network_error_exceedances="${network_error_exceedances:-unavailable}"
  network_drop_max="$(last_metric network_interface_drop_events_per_second_max)"; network_drop_max="${network_drop_max:-unavailable}"
  network_drop_exceedances="$(last_metric network_interface_drop_events_per_second_threshold_exceedance_count)"; network_drop_exceedances="${network_drop_exceedances:-unavailable}"
  application_service_status="$(last_metric application_service_sample_status)"; application_service_status="${application_service_status:-unavailable}"
  application_service_method="$(last_metric application_service_sample_method)"; application_service_method="${application_service_method:-unavailable}"
  application_sqlite_threshold="$(last_metric application_sqlite_lock_threshold)"; application_sqlite_threshold="${application_sqlite_threshold:-$APPLICATION_SQLITE_LOCK_WARN_COUNT}"
  application_timeout_threshold="$(last_metric application_timeout_threshold)"; application_timeout_threshold="${application_timeout_threshold:-$APPLICATION_TIMEOUT_WARN_COUNT}"
  service_failure_threshold="$(last_metric service_failure_event_threshold)"; service_failure_threshold="${service_failure_threshold:-$SERVICE_FAILURE_WARN_COUNT}"
  service_restart_threshold="$(last_metric service_restart_threshold)"; service_restart_threshold="${service_restart_threshold:-$SERVICE_RESTART_WARN_COUNT}"
  role_service_threshold="$(last_metric role_service_event_threshold)"; role_service_threshold="${role_service_threshold:-$ROLE_SERVICE_EVENT_WARN_COUNT}"
  application_journal_status="$(last_metric application_journal_status)"; application_journal_status="${application_journal_status:-unavailable}"
  application_journal_window="$(last_metric application_journal_window)"; application_journal_window="${application_journal_window:-unavailable}"
  application_journal_max="$(last_metric application_journal_max_records)"; application_journal_max="${application_journal_max:-unavailable}"
  application_journal_records="$(last_metric application_journal_records_scanned)"; application_journal_records="${application_journal_records:-unavailable}"
  application_journal_truncated="$(last_metric application_journal_truncated)"; application_journal_truncated="${application_journal_truncated:-unavailable}"
  service_restart_counter_status="$(last_metric service_restart_counter_status)"; service_restart_counter_status="${service_restart_counter_status:-unavailable}"
  service_restart_counter_scope="$(last_metric service_restart_counter_scope)"; service_restart_counter_scope="${service_restart_counter_scope:-unavailable}"
  service_units_observed="$(last_metric service_units_observed)"; service_units_observed="${service_units_observed:-unavailable}"
  service_units_with_restarts="$(last_metric service_units_with_restarts)"; service_units_with_restarts="${service_units_with_restarts:-unavailable}"
  service_restart_total="$(last_metric service_restart_count_total)"; service_restart_total="${service_restart_total:-unavailable}"
  service_restart_max="$(last_metric service_restart_count_max)"; service_restart_max="${service_restart_max:-unavailable}"
  service_restart_invalid="$(last_metric service_restart_counter_invalid_units)"; service_restart_invalid="${service_restart_invalid:-unavailable}"
  application_sqlite_locks="$(last_metric application_sqlite_lock_events_24h)"; application_sqlite_locks="${application_sqlite_locks:-unavailable}"
  application_timeouts="$(last_metric application_timeout_events_24h)"; application_timeouts="${application_timeouts:-unavailable}"
  service_failure_events="$(last_metric service_failure_events_24h)"; service_failure_events="${service_failure_events:-unavailable}"
  service_restart_events="$(last_metric service_restart_events_24h)"; service_restart_events="${service_restart_events:-unavailable}"
  application_role_scope_status="$(last_metric application_role_scope_status)"; application_role_scope_status="${application_role_scope_status:-unavailable}"
  application_role_records="$(last_metric application_role_journal_records_scanned)"; application_role_records="${application_role_records:-unavailable}"
  application_role_truncated="$(last_metric application_role_journal_truncated)"; application_role_truncated="${application_role_truncated:-unavailable}"
  application_role_events="$(last_metric application_role_relevant_events_24h)"; application_role_events="${application_role_events:-unavailable}"
  apt_refresh_status="$(last_metric apt_refresh_status)"; apt_refresh_status="${apt_refresh_status:-unknown}"
  apt_index_status="$(last_metric apt_index_status)"; apt_index_status="${apt_index_status:-unknown}"
  apt_simulation_status="$(last_metric apt_simulation_status)"; apt_simulation_status="${apt_simulation_status:-unknown}"
  access_evidence_schema_version="$(last_metric access_evidence_schema_version)"; access_evidence_schema_version="${access_evidence_schema_version:-unavailable}"
  ssh_effective_status="$(last_metric ssh_effective_status)"; ssh_effective_status="${ssh_effective_status:-unavailable}"
  ssh_effective_root="$(last_metric ssh_effective_permit_root_login)"; ssh_effective_root="${ssh_effective_root:-unavailable}"
  ssh_effective_password="$(last_metric ssh_effective_password_authentication)"; ssh_effective_password="${ssh_effective_password:-unavailable}"
  ssh_effective_keyboard="$(last_metric ssh_effective_kbd_interactive_authentication)"; ssh_effective_keyboard="${ssh_effective_keyboard:-unavailable}"
  ssh_effective_pubkey="$(last_metric ssh_effective_pubkey_authentication)"; ssh_effective_pubkey="${ssh_effective_pubkey:-unavailable}"
  ssh_effective_authentication_methods="$(last_metric ssh_effective_authentication_methods)"; ssh_effective_authentication_methods="${ssh_effective_authentication_methods:-unavailable}"
  ssh_effective_context_status="$(last_metric ssh_effective_context_status)"; ssh_effective_context_status="${ssh_effective_context_status:-unavailable}"
  ssh_effective_ports="$(last_metric ssh_effective_port_set)"; ssh_effective_ports="${ssh_effective_ports:-unavailable}"
  ssh_effective_config_scope="$(last_metric ssh_effective_listen_address_scope)"; ssh_effective_config_scope="${ssh_effective_config_scope:-unavailable}"
  ssh_allow_users_status="$(last_metric ssh_effective_allow_users_status)"; ssh_allow_users_status="${ssh_allow_users_status:-unavailable}"
  ssh_allow_users_count="$(last_metric ssh_effective_allow_users_count)"; ssh_allow_users_count="${ssh_allow_users_count:-unavailable}"
  ssh_allow_groups_status="$(last_metric ssh_effective_allow_groups_status)"; ssh_allow_groups_status="${ssh_allow_groups_status:-unavailable}"
  ssh_allow_groups_count="$(last_metric ssh_effective_allow_groups_count)"; ssh_allow_groups_count="${ssh_allow_groups_count:-unavailable}"
  tcp_listener_status="$(last_metric tcp_listener_evidence_status)"; tcp_listener_status="${tcp_listener_status:-unavailable}"
  tcp_listener_total="$(last_metric tcp_listener_total)"; tcp_listener_total="${tcp_listener_total:-unavailable}"
  tcp_listener_loopback="$(last_metric tcp_listener_loopback_count)"; tcp_listener_loopback="${tcp_listener_loopback:-unavailable}"
  tcp_listener_wildcard="$(last_metric tcp_listener_wildcard_count)"; tcp_listener_wildcard="${tcp_listener_wildcard:-unavailable}"
  tcp_listener_specific="$(last_metric tcp_listener_specific_non_loopback_count)"; tcp_listener_specific="${tcp_listener_specific:-unavailable}"
  ssh_listener_correlation="$(last_metric ssh_listener_correlation_status)"; ssh_listener_correlation="${ssh_listener_correlation:-unavailable}"
  ssh_listener_scope="$(last_metric ssh_listener_scope)"; ssh_listener_scope="${ssh_listener_scope:-unavailable}"
  firewall_ufw_status="$(last_metric firewall_ufw_status)"; firewall_ufw_status="${firewall_ufw_status:-unavailable}"
  firewall_nft_status="$(last_metric firewall_nft_status)"; firewall_nft_status="${firewall_nft_status:-unavailable}"
  firewall_nft_policy="$(last_metric firewall_nft_input_policy)"; firewall_nft_policy="${firewall_nft_policy:-unavailable}"
  firewall_nft_hooks="$(last_metric firewall_nft_input_hook_count)"; firewall_nft_hooks="${firewall_nft_hooks:-unavailable}"
  firewall_nft_rules="$(last_metric firewall_nft_rule_line_count)"; firewall_nft_rules="${firewall_nft_rules:-unavailable}"
  firewall_iptables_status="$(last_metric firewall_iptables_status)"; firewall_iptables_status="${firewall_iptables_status:-unavailable}"
  firewall_iptables_policy="$(last_metric firewall_iptables_input_policy)"; firewall_iptables_policy="${firewall_iptables_policy:-unavailable}"
  firewall_iptables_rules="$(last_metric firewall_iptables_input_rule_count)"; firewall_iptables_rules="${firewall_iptables_rules:-unavailable}"
  firewall_ip6tables_status="$(last_metric firewall_ip6tables_status)"; firewall_ip6tables_status="${firewall_ip6tables_status:-unavailable}"
  firewall_ip6tables_policy="$(last_metric firewall_ip6tables_input_policy)"; firewall_ip6tables_policy="${firewall_ip6tables_policy:-unavailable}"
  firewall_ip6tables_rules="$(last_metric firewall_ip6tables_input_rule_count)"; firewall_ip6tables_rules="${firewall_ip6tables_rules:-unavailable}"
  local_firewall_status="$(last_metric local_firewall_status)"; local_firewall_status="${local_firewall_status:-UNKNOWN}"
  local_firewall_confidence="$(last_metric local_firewall_confidence)"; local_firewall_confidence="${local_firewall_confidence:-LIMITED}"
  local_firewall_sources="$(last_metric local_firewall_enforcement_sources)"; local_firewall_sources="${local_firewall_sources:-none}"
  network_time_evidence_schema_version="$(last_metric network_time_evidence_schema_version)"; network_time_evidence_schema_version="${network_time_evidence_schema_version:-unavailable}"
  network_time_readiness_schema_version="$NETWORK_TIME_READINESS_SCHEMA_VERSION"
  network_time_readiness_status="$(last_metric network_time_readiness_status)"; network_time_readiness_status="${network_time_readiness_status:-UNKNOWN}"
  network_time_readiness_confidence="$(last_metric network_time_readiness_confidence)"; network_time_readiness_confidence="${network_time_readiness_confidence:-LIMITED}"
  network_time_readiness_coverage_status="$(last_metric network_time_readiness_coverage_status)"; network_time_readiness_coverage_status="${network_time_readiness_coverage_status:-limited}"
  network_ipv4_default_route_status="$(last_metric network_ipv4_default_route_status)"; network_ipv4_default_route_status="${network_ipv4_default_route_status:-UNKNOWN}"
  network_ipv4_default_interface="$(last_metric network_ipv4_default_interface)"; network_ipv4_default_interface="${network_ipv4_default_interface:-unavailable}"
  network_ipv6_default_route_status="$(last_metric network_ipv6_default_route_status)"; network_ipv6_default_route_status="${network_ipv6_default_route_status:-UNKNOWN}"
  network_ipv6_default_interface="$(last_metric network_ipv6_default_interface)"; network_ipv6_default_interface="${network_ipv6_default_interface:-unavailable}"
  network_readiness_primary_interface="$(last_metric network_readiness_primary_interface)"; network_readiness_primary_interface="${network_readiness_primary_interface:-unavailable}"
  network_primary_interface_mtu="$(last_metric network_primary_interface_mtu)"; network_primary_interface_mtu="${network_primary_interface_mtu:-unavailable}"
  network_mtu_status="$(last_metric network_mtu_status)"; network_mtu_status="${network_mtu_status:-UNKNOWN}"
  network_mtu_profile="$(last_metric network_mtu_profile)"; network_mtu_profile="${network_mtu_profile:-UNKNOWN}"
  network_resolver_configuration_status="$(last_metric network_resolver_configuration_status)"; network_resolver_configuration_status="${network_resolver_configuration_status:-UNKNOWN}"
  network_resolver_nameserver_count="$(last_metric network_resolver_nameserver_count)"; network_resolver_nameserver_count="${network_resolver_nameserver_count:-unavailable}"
  network_name_service_resolution_status="$(last_metric network_name_service_resolution_status)"; network_name_service_resolution_status="${network_name_service_resolution_status:-UNKNOWN}"
  network_name_service_resolution_requested_count="$(last_metric network_name_service_resolution_requested_count)"; network_name_service_resolution_requested_count="${network_name_service_resolution_requested_count:-unavailable}"
  network_name_service_resolution_success_count="$(last_metric network_name_service_resolution_success_count)"; network_name_service_resolution_success_count="${network_name_service_resolution_success_count:-unavailable}"
  network_time_evidence_status="$(last_metric network_time_evidence_status)"; network_time_evidence_status="${network_time_evidence_status:-unavailable}"
  network_time_ntp_synchronized="$(last_metric network_time_ntp_synchronized)"; network_time_ntp_synchronized="${network_time_ntp_synchronized:-unavailable}"
  network_time_ntp_enabled="$(last_metric network_time_ntp_enabled)"; network_time_ntp_enabled="${network_time_ntp_enabled:-unavailable}"
  network_time_can_ntp="$(last_metric network_time_can_ntp)"; network_time_can_ntp="${network_time_can_ntp:-unavailable}"
  network_time_timezone="$(last_metric network_time_timezone)"; network_time_timezone="${network_time_timezone:-unavailable}"
  network_time_uptime_seconds="$(last_metric network_time_uptime_seconds)"; network_time_uptime_seconds="${network_time_uptime_seconds:-unavailable}"
  network_time_sync_status="$(last_metric network_time_sync_status)"; network_time_sync_status="${network_time_sync_status:-UNKNOWN}"
  network_time_external_reachability_status="$(last_metric network_time_external_reachability_status)"; network_time_external_reachability_status="${network_time_external_reachability_status:-NOT_CHECKED}"
  network_time_domain_tls_status="$(last_metric network_time_domain_tls_status)"; network_time_domain_tls_status="${network_time_domain_tls_status:-NOT_CHECKED}"
  network_time_checked_scope="$(last_metric network_time_readiness_checked_scope)"; network_time_checked_scope="${network_time_checked_scope:-unavailable}"
  network_time_not_checked_status="$(last_metric network_time_readiness_not_checked_status)"; network_time_not_checked_status="${network_time_not_checked_status:-NOT CHECKED}"
  network_time_not_checked_families="$(last_metric network_time_readiness_not_checked_families)"; network_time_not_checked_families="${network_time_not_checked_families:-external_reachability,path_mtu,remote_clock_reference,domain_tls}"
  network_time_limitations="$(last_metric network_time_readiness_limitations)"; network_time_limitations="${network_time_limitations:-local_read_only_evidence_only}"
  network_time_fact_routes="$(last_metric network_time_readiness_fact_routes)"; network_time_fact_routes="${network_time_fact_routes:-unavailable}"
  network_time_fact_name_service="$(last_metric network_time_readiness_fact_name_service)"; network_time_fact_name_service="${network_time_fact_name_service:-unavailable}"
  network_time_fact_time="$(last_metric network_time_readiness_fact_time)"; network_time_fact_time="${network_time_fact_time:-unavailable}"
  diagnostic_probe_kernel_journal
  kernel_journal_status="$KERNEL_JOURNAL_STATUS"
  oom="$KERNEL_OOM_EVENTS"
  fs_errors="$KERNEL_STORAGE_ERRORS"
  PACKAGE_UPDATE_EVIDENCE_STATUS=unavailable
  classify_updates
  package_update_evidence_status="${PACKAGE_UPDATE_EVIDENCE_STATUS:-unavailable}"
  updates_total_report="$updates_total"
  kernel_updates_report="$kernel_updates"
  phased_updates_report="$phased_updates"
  normal_updates_report="$normal_updates"
  if [[ "$package_update_evidence_status" != available ]]; then
    updates_total_report=unavailable
    kernel_updates_report=unavailable
    phased_updates_report=unavailable
    normal_updates_report=unavailable
  fi
  access_metrics="$(access_readiness_evaluate \
    "$ssh_effective_status" "$ssh_effective_root" "$ssh_effective_password" "$ssh_effective_keyboard" \
    "$ssh_effective_pubkey" "$ssh_effective_authentication_methods" "$ssh_effective_context_status" \
    "$ssh_effective_config_scope" "$ssh_allow_users_status" "$ssh_allow_groups_status" \
    "$tcp_listener_status" "$ssh_listener_scope" \
    "$local_firewall_status" "$local_firewall_confidence" \
    "$apt_index_status" "$package_update_evidence_status" "$apt_simulation_status")" || return 1
  access_readiness_status="$(access_readiness_value "$access_metrics" access_readiness_status)" || return 1
  access_readiness_confidence="$(access_readiness_value "$access_metrics" access_readiness_confidence)" || return 1
  ssh_access_status="$(access_readiness_value "$access_metrics" ssh_access_status)" || return 1
  firewall_readiness_status="$(access_readiness_value "$access_metrics" firewall_readiness_status)" || return 1
  package_readiness_status="$(access_readiness_value "$access_metrics" package_readiness_status)" || return 1
  access_fact_ssh="$(access_readiness_value "$access_metrics" access_readiness_fact_ssh)" || return 1
  access_fact_listener="$(access_readiness_value "$access_metrics" access_readiness_fact_listener)" || return 1
  access_fact_firewall="$(access_readiness_value "$access_metrics" access_readiness_fact_firewall)" || return 1
  access_fact_packages="$(access_readiness_value "$access_metrics" access_readiness_fact_packages)" || return 1
  access_correlation="$(access_readiness_value "$access_metrics" access_readiness_correlation)" || return 1
  access_limitations="$(access_readiness_value "$access_metrics" access_readiness_limitations)" || return 1
  access_checked_scope="$(access_readiness_value "$access_metrics" access_readiness_checked_scope)" || return 1
  access_not_checked_status="$(access_readiness_value "$access_metrics" access_readiness_not_checked_status)" || return 1
  access_not_checked_families="$(access_readiness_value "$access_metrics" access_readiness_not_checked_families)" || return 1
  [[ "$apt_index_status" == fresh ]] && package_finding_confidence=HIGH
  diagnostic_probe_failed_services
  systemd_failed_services_status="$SYSTEMD_FAILED_SERVICES_STATUS"
  failed_names="$DIAGNOSTIC_FAILED_NAMES"
  virt="$(systemd-detect-virt 2>/dev/null || true)"; virt="${virt:-none}"
  if [[ "$systemd_failed_services_status" == ok ]]; then
    classify_failed_services "$failed_names" "$virt" "$ROLE_LABEL"
    informational="$FAILED_INFORMATIONAL_COUNT"
    unknown="$FAILED_UNKNOWN_COUNT"
    critical="$FAILED_CRITICAL_COUNT"
    role_relevant="$FAILED_ROLE_RELEVANT_COUNT"
  else
    informational=unavailable
    unknown=unavailable
    critical=unavailable
    role_relevant=unavailable
  fi
  update_message "$kernel_updates" "$phased_updates"
  reason="$UPDATE_REASON"
  action="$UPDATE_ACTION"

  add_finding() {
    local severity="$1" code="$2" category="$3" confidence="$4" observed="$5" unit="$6" threshold="$7" finding_reason="$8" finding_action="$9"
    shift 9
    local confirmed="${1:-$finding_reason}" interpretation="${2:-$finding_reason}" limitation="${3:-Требуется сверка с полным техническим отчётом}"
    finding_count=$((finding_count+1))
    findings_severity[$finding_count]="$severity"
    findings_code[$finding_count]="$code"
    findings_category[$finding_count]="$category"
    findings_confidence[$finding_count]="$confidence"
    findings_observed[$finding_count]="$observed"
    findings_unit[$finding_count]="$unit"
    findings_threshold[$finding_count]="$threshold"
    findings_reason[$finding_count]="$finding_reason"
    findings_action[$finding_count]="$finding_action"
    findings_confirmed[$finding_count]="$confirmed"
    findings_interpretation[$finding_count]="$interpretation"
    findings_limitation[$finding_count]="$limitation"
    if (( severity > max_severity )); then
      max_severity="$severity"
      reason="$finding_reason"
      action="$finding_action"
      primary_code="$code"
      primary_category="$category"
      primary_confidence="$confidence"
      primary_observed="$observed"
      primary_unit="$unit"
      primary_threshold="$threshold"
      primary_confirmed="$confirmed"
      primary_interpretation="$interpretation"
      primary_limitation="$limitation"
    fi
  }

  finding_safe_value() {
    local value="${1:-unavailable}"
    value="${value//$'\r'/ }"
    value="${value//$'\n'/ }"
    value="${value//$'\t'/ }"
    [[ -n "$value" ]] || value=unavailable
    printf '%s' "$value"
  }

  finding_put() {
    local key="$1" value
    value="$(finding_safe_value "$2")"
    if ! printf '%s=%s\n' "$key" "$value" >>"$out"; then
      FINDING_WRITE_FAILED=1
      return 1
    fi
  }

  emit_ranked_findings() {
    local i j tmp rank idx code category method duration count minimum median average maximum exceedances required_exceedances evidence evidence_model baseline hypothesis impact
    local FINDING_WRITE_FAILED=0
    if ! printf 'findings_schema_version=%s\nfindings_order=severity_score_desc_registration_order\nfindings_total=%s\n' \
      "$FINDINGS_SCHEMA_VERSION" "$finding_count" >>"$out"; then
      return 1
    fi
    for ((i=1; i<=finding_count; i++)); do
      findings_order[$i]="$i"
      j="$i"
      while (( j > 1 )) && (( findings_severity[${findings_order[$j]}] > findings_severity[${findings_order[$((j-1))]}] )); do
        tmp="${findings_order[$j]}"
        findings_order[$j]="${findings_order[$((j-1))]}"
        findings_order[$((j-1))]="$tmp"
        j=$((j-1))
      done
    done
    for ((rank=1; rank<=finding_count; rank++)); do
      idx="${findings_order[$rank]}"
      code="${findings_code[$idx]}"
      category="${findings_category[$idx]}"
      method=unavailable duration=unavailable count=unavailable minimum=unavailable median=unavailable average=unavailable maximum="${findings_observed[$idx]}" exceedances=unavailable required_exceedances=unavailable evidence=unavailable evidence_model=unavailable
      baseline="threshold:${findings_threshold[$idx]} ${findings_unit[$idx]}"
      hypothesis="Возможная первопричина требует отдельной проверки; текущий аудит её не доказывает"
      impact="${findings_reason[$idx]}"
      case "$category" in
        packages) method=apt_index_and_full_upgrade_simulation; count=1; evidence=apt_index_and_simulation; evidence_model=snapshot ;;
        applications) method="$application_service_method"; duration=86400; count="$application_journal_records"; evidence=bounded_systemd_journal_patterns; evidence_model=event_count ;;
        services) method=systemd_failed_units_restart_counters_and_bounded_journal; count="$service_units_observed"; evidence=systemd_and_bounded_journal; evidence_model=snapshot ;;
        diagnostics) method=required_check_coverage_matrix; count="$coverage_required"; evidence=diagnostic_source_statuses; evidence_model=coverage ;;
        network) method="$network_sample_method"; duration="$network_sample_duration"; count="$network_sample_count"; evidence=proc_net_snmp_netstat_and_sysfs; evidence_model=windowed ;;
        memory) method=proc_meminfo_vmstat_psi_loadavg_windows; duration="$pressure_sample_duration"; count="$pressure_sample_count"; evidence=proc_meminfo_vmstat_and_psi; evidence_model=windowed ;;
        compute) method="$cpu_sample_method"; duration="$cpu_sample_duration"; count="$cpu_sample_count"; evidence=proc_stat_and_loadavg; evidence_model=windowed ;;
        storage) method="$storage_sample_method"; duration="$storage_sample_duration"; count="$storage_sample_count"; evidence=sysfs_block_stat_and_filesystem_snapshot; evidence_model=windowed ;;
        system) method=system_state_snapshot; count=1; evidence=local_system_markers; evidence_model=snapshot ;;
      esac
      case "$code" in
        PLATFORM_RELEASE_UNVALIDATED) method=os_release_family_compatibility_gate; count=1; evidence=/etc/os-release; evidence_model=snapshot ;;
        NETWORK_TIME_READINESS_REVIEW|NETWORK_TIME_READINESS_EVIDENCE_LIMITED|NETWORK_TIME_SYNC_PENDING_RECHECK)
          method=proc_routes_sysfs_resolv_conf_getent_timedatectl_and_proc_uptime
          count=1
          evidence=local_network_and_native_time_sources
          evidence_model=bounded_snapshot
          ;;
        CPU_STEAL_HIGH)
          method="$cpu_sample_method"; duration="$cpu_sample_duration"; count="$cpu_sample_count"
          minimum="$steal_min"; median="$steal_median"; average="$steal_average"; maximum="$steal"; exceedances="$steal_exceedances"; evidence=/proc/stat
          ;;
        DISK_IOWAIT_HIGH)
          method="$cpu_sample_method"; duration="$cpu_sample_duration"; count="$cpu_sample_count"
          minimum="$iowait_min"; median="$iowait_median"; average="$iowait_average"; maximum="$iowait"; exceedances="$iowait_exceedances"; evidence=/proc/stat
          ;;
        CPU_SAMPLE_INCOMPLETE)
          method="$cpu_sample_method"; duration="$cpu_sample_duration"; count="$cpu_sample_count"; maximum=unavailable; evidence=/proc/stat
          ;;
        LOAD_PER_VCPU_HIGH)
          method=proc_loadavg_snapshot; duration=unavailable; count=1; maximum="$load_per_vcpu"; evidence=/proc/loadavg; evidence_model=snapshot
          ;;
        MEMORY_AVAILABLE_CRITICAL)
          minimum="$mem_available_min"; median="$mem_available_median"; average="$mem_available_average"; maximum="$mem_available_max"; exceedances="$mem_available_critical_exceedances"
          required_exceedances=2
          ;;
        MEMORY_AVAILABLE_LOW)
          minimum="$mem_available_min"; median="$mem_available_median"; average="$mem_available_average"; maximum="$mem_available_max"; exceedances="$mem_available_exceedances"
          required_exceedances=2
          ;;
        MEMORY_PSI_FULL_HIGH) maximum="$memory_psi_full_max"; exceedances="$memory_psi_full_exceedances"; required_exceedances=2 ;;
        MEMORY_PSI_SOME_HIGH) maximum="$memory_psi_some_max"; exceedances="$memory_psi_some_exceedances"; required_exceedances=2 ;;
        CPU_PSI_HIGH) maximum="$cpu_psi_some_max"; exceedances="$cpu_psi_some_exceedances"; required_exceedances=2 ;;
        RUN_QUEUE_HIGH) maximum="$run_queue_max"; exceedances="$run_queue_exceedances"; required_exceedances=2 ;;
        SWAP_IO_REPEATED) maximum="${swap_in_max}/${swap_out_max}"; exceedances="${swap_in_exceedances}/${swap_out_exceedances}"; required_exceedances=2 ;;
        MAJOR_FAULTS_REPEATED) maximum="$major_fault_max"; exceedances="$major_fault_exceedances"; required_exceedances=2 ;;
        STORAGE_DEVICE_LATENCY_HIGH)
          minimum="$storage_await_min"; median="$storage_await_median"; average="$storage_await_average"; maximum="$storage_await_max"; exceedances="$storage_await_exceedances"; required_exceedances=2
          ;;
        STORAGE_DEVICE_BUSY)
          minimum="$storage_util_min"; median="$storage_util_median"; average="$storage_util_average"; maximum="$storage_util_max"; exceedances="$storage_util_exceedances"; required_exceedances=2
          ;;
        STORAGE_QUEUE_HIGH)
          minimum="$storage_queue_min"; median="$storage_queue_median"; average="$storage_queue_average"; maximum="$storage_queue_max"; exceedances="$storage_queue_exceedances"; required_exceedances=2
          ;;
        NETWORK_RETRANSMISSION_RATIO_HIGH) maximum="$network_retrans_ratio_max"; exceedances="$network_retrans_ratio_exceedances"; required_exceedances=2 ;;
        NETWORK_TCP_TIMEOUTS_REPEATED) maximum="$network_timeout_max"; exceedances="$network_timeout_exceedances"; required_exceedances=2 ;;
        NETWORK_TCP_ABORT_TIMEOUT_REPEATED) maximum="$network_abort_max"; exceedances="$network_abort_exceedances"; required_exceedances=2 ;;
        NETWORK_INTERFACE_ERRORS_REPEATED) maximum="$network_error_max"; exceedances="$network_error_exceedances"; required_exceedances=2 ;;
        NETWORK_INTERFACE_DROPS_REPEATED) maximum="$network_drop_max"; exceedances="$network_drop_exceedances"; required_exceedances=2 ;;
        NETWORK_SYN_RETRANSMITS_REPEATED) maximum="$network_syn_max"; exceedances="$network_syn_exceedances"; required_exceedances=2 ;;
        APPLICATION_SQLITE_LOCKS_REPEATED|APPLICATION_STORAGE_SYMPTOMS_CORRELATED) exceedances="$application_sqlite_locks" ;;
        APPLICATION_TIMEOUTS_REPEATED|APPLICATION_NETWORK_SYMPTOMS_CORRELATED) exceedances="$application_timeouts" ;;
        SERVICE_FAILURE_EVENTS_REPEATED) exceedances="$service_failure_events"; evidence_model=event_count ;;
        SERVICE_RESTARTS_REPEATED) duration=unavailable; count="$service_units_observed"; exceedances="$service_restart_max"; evidence_model=lifetime_counter ;;
        ROLE_SERVICE_EVENTS_REPEATED) exceedances="$application_role_events"; evidence_model=event_count ;;
        REBOOT_REQUIRED) method=reboot_required_marker_snapshot; count=1; evidence=/var/run/reboot-required; evidence_model=snapshot ;;
        MEMORY_OOM|STORAGE_KERNEL_ERRORS) method=bounded_kernel_journal_24h; duration=86400; count=1; evidence=kernel_journal; evidence_model=event_count ;;
        ROOT_FILESYSTEM_*|ROOT_INODES_*) method=filesystem_capacity_snapshot; duration=unavailable; count=1; evidence=df_and_mountinfo; evidence_model=snapshot ;;
        DIAGNOSTIC_COVERAGE_INCOMPLETE|DIAGNOSTIC_EVIDENCE_LIMITED) maximum="$coverage_completed"; exceedances=unavailable; evidence_model=coverage ;;
      esac
      finding_put "finding_${rank}_rank" "$rank"
      finding_put "finding_${rank}_code" "$code"
      finding_put "finding_${rank}_category" "$category"
      finding_put "finding_${rank}_severity_score" "${findings_severity[$idx]}"
      finding_put "finding_${rank}_verdict" "$(severity_to_verdict "${findings_severity[$idx]}")"
      finding_put "finding_${rank}_confidence" "${findings_confidence[$idx]}"
      finding_put "finding_${rank}_observed_value" "${findings_observed[$idx]}"
      finding_put "finding_${rank}_unit" "${findings_unit[$idx]}"
      finding_put "finding_${rank}_threshold" "${findings_threshold[$idx]}"
      finding_put "finding_${rank}_comparison_baseline" "$baseline"
      finding_put "finding_${rank}_sample_method" "$method"
      finding_put "finding_${rank}_sample_duration_seconds" "$duration"
      finding_put "finding_${rank}_sample_count" "$count"
      finding_put "finding_${rank}_minimum" "$minimum"
      finding_put "finding_${rank}_median" "$median"
      finding_put "finding_${rank}_average" "$average"
      finding_put "finding_${rank}_maximum" "$maximum"
      finding_put "finding_${rank}_threshold_exceedance_count" "$exceedances"
      finding_put "finding_${rank}_required_exceedance_count" "$required_exceedances"
      finding_put "finding_${rank}_evidence_model" "$evidence_model"
      finding_put "finding_${rank}_evidence_source" "$evidence"
      finding_put "finding_${rank}_confirmed" "${findings_confirmed[$idx]}"
      finding_put "finding_${rank}_interpretation" "${findings_interpretation[$idx]}"
      finding_put "finding_${rank}_hypothesis" "$hypothesis"
      finding_put "finding_${rank}_impact_hint" "$impact"
      finding_put "finding_${rank}_limitations" "${findings_limitation[$idx]}"
      finding_put "finding_${rank}_next_action" "${findings_action[$idx]}"
    done
    (( FINDING_WRITE_FAILED == 0 ))
  }

  coverage_require() {
    local check="$1" status="$2"
    coverage_required=$((coverage_required+1))
    case "$status" in
      ok|fresh|stale|very_stale)
        coverage_completed=$((coverage_completed+1))
        ;;
      limited)
        if [[ "$coverage_limited" == none ]]; then coverage_limited="$check"
        else coverage_limited="${coverage_limited},${check}"
        fi
        ;;
      *)
        if [[ "$coverage_missing" == none ]]; then coverage_missing="$check"
        else coverage_missing="${coverage_missing},${check}"
        fi
        ;;
    esac
  }

  if [[ "$access_evidence_schema_version" == "$ACCESS_READINESS_SCHEMA_VERSION" ]]; then
    if [[ "$ssh_effective_root" == yes &&
          ( "$ssh_effective_password" == yes || "$ssh_effective_keyboard" == yes ) &&
          "$ssh_listener_scope" =~ ^(wildcard|specific_non_loopback|mixed)$ ]]; then
      add_finding 20 SSH_ROOT_PASSWORD_CAPABLE_BIND_REVIEW access MEDIUM \
        "${ssh_effective_root}/${ssh_effective_password}/${ssh_effective_keyboard}/${ssh_listener_scope}" configuration_correlation owner_reviewed \
        "Effective SSH permits root and a password-capable authentication path while a matching local SSH listener is bound beyond loopback" \
        "Review the exact owner access path before separately authorized SSH or firewall changes" \
        "sshd -T and local ss evidence confirm the configuration and bind correlation" \
        "This increases access risk and requires review; it does not prove external reachability or compromise" \
        "Local listeners and firewall evidence cannot establish provider-edge or Internet reachability"
    elif [[ "$access_readiness_status" == UNKNOWN ]]; then
      add_finding 10 ACCESS_READINESS_EVIDENCE_LIMITED access LIMITED UNKNOWN status owner_reviewed \
        "Access/readiness evidence is incomplete or package evidence is stale" \
        "Review unavailable readiness sources; do not infer a healthy zero" \
        "The readiness classifier preserved UNKNOWN instead of replacing unavailable evidence with zero" \
        "The separate 13-check system-health coverage remains unchanged" \
        "$access_limitations"
    elif [[ "$access_readiness_status" == REVIEW ]]; then
      add_finding 10 ACCESS_READINESS_REVIEW access MEDIUM REVIEW status owner_reviewed \
        "Access/readiness evidence requires owner review" \
        "Review the exact SSH context and local firewall facts before any separately authorized change" \
        "The bounded local evidence does not prove all SSH Match contexts or a consistent default-deny firewall" \
        "No external reachability or compromise is inferred" \
      "$access_limitations"
    fi
  fi
  case "$network_time_readiness_status" in
    REVIEW)
      add_finding 15 NETWORK_TIME_READINESS_REVIEW network MEDIUM REVIEW status owner_reviewed \
        "Network/time readiness requires review" \
        "Review the exact route, name-service and time-sync facts before any separately authorized change" \
        "Bounded local evidence found a route, name-service or established time-sync state requiring review" \
        "The readiness result is WARN, not proof of provider failure or external unreachability" \
        "$network_time_limitations"
      ;;
    UNKNOWN)
      add_finding 15 NETWORK_TIME_READINESS_EVIDENCE_LIMITED network LIMITED UNKNOWN status owner_reviewed \
        "Network/time readiness evidence is incomplete or unparseable" \
        "Restore the unavailable local evidence source and repeat the audit; do not infer healthy networking or time" \
        "The classifier preserved material UNKNOWN evidence instead of replacing it with a healthy value" \
        "The historical 13-check health coverage is unchanged; this separate readiness coverage is limited" \
        "$network_time_limitations"
      ;;
    PENDING_RECHECK)
      add_finding 10 NETWORK_TIME_SYNC_PENDING_RECHECK network LIMITED PENDING_RECHECK status recheck \
        "Time synchronization is pending recheck after a fresh boot" \
        "Repeat the read-only time check after the server has had time to synchronize" \
        "Native time synchronization is not yet reported while uptime is below the fresh-boot threshold" \
        "This is a bounded recheck state, not an automatic serious finding" \
        "$network_time_limitations"
      ;;
    READY)
      ;;
    *)
      add_finding 15 NETWORK_TIME_READINESS_EVIDENCE_LIMITED network LIMITED UNKNOWN status owner_reviewed \
        "Network/time readiness evidence has an unsupported status" \
        "Repeat the audit with the current audit-only collector; do not infer healthy networking or time" \
        "The readiness status could not be interpreted by the technical summary" \
        "The historical 13-check health coverage is unchanged; this separate readiness result is limited" \
        "$network_time_limitations"
      ;;
  esac
  ((normal_updates>0)) && add_finding 15 OS_UPDATES_AVAILABLE packages "$package_finding_confidence" "$normal_updates" packages 0 "Доступны обычные обновления ОС: $normal_updates" "Просмотреть отчёт и при необходимости выполнить обновление отдельно штатными средствами ОС"
  if [[ "$held_packages" =~ ^[0-9]+$ ]] && (( held_packages > 0 )); then
    add_finding 20 HELD_PACKAGES packages MEDIUM "$held_packages" packages 0 "Обнаружены удерживаемые пакеты: $held_packages" "Проверить причины удержания пакетов до обновления"
  fi
  if [[ "$broken_package_state" =~ ^[0-9]+$ ]] && (( broken_package_state > 0 )); then
    add_finding 40 PACKAGE_STATE_BROKEN packages HIGH "$broken_package_state" boolean 0 "Нарушено состояние пакетной системы" "Не продолжать обновление до восстановления пакетной системы"
  fi
  if [[ "$full_upgrade_removals" =~ ^[0-9]+$ ]] && (( full_upgrade_removals > 0 )); then
    add_finding 40 UPGRADE_REMOVALS packages HIGH "$full_upgrade_removals" packages 0 "Обновление планирует удаление пакетов: $full_upgrade_removals" "Не выполнять обновление автоматически"
  fi
  [[ "$reboot" == yes ]] && add_finding 10 REBOOT_REQUIRED system HIGH yes boolean no "Для применения уже установленных обновлений требуется перезагрузка" "Проверить сервисы и выполнить контролируемую перезагрузку"
  if [[ "$PLATFORM_SUPPORT_STATUS" == compatible_unverified ]]; then
    add_finding 10 PLATFORM_RELEASE_UNVALIDATED diagnostics MEDIUM "$PLATFORM_ID:$PLATFORM_VERSION_ID" release "$PLATFORM_VALIDATED_LIST" \
      "Выпуск ОС распознан и допускает read-only audit, но ещё не прошёл полную матрицу проверки Server Toolkit" \
      "Учитывать LIMITED confidence и проверить недоступные показатели; для полной гарантии нужен отдельный CI/live gate этого выпуска" \
      "Подтверждены семейство и версия ОС из /etc/os-release" \
      "Базовая совместимость разрешена, но эквивалентность всех диагностических методов не доказана" \
      "Этот выпуск отсутствует в списке полностью проверенных платформ"
  fi
  if [[ "$unknown" =~ ^[0-9]+$ ]] && (( unknown > 0 )); then
    add_finding 20 FAILED_SERVICES_UNKNOWN services MEDIUM "$unknown" services 0 "Есть неизвестные неработающие службы: $unknown" "Проверить перечисленные службы до следующего изменения"
  fi
  if [[ "$role_relevant" =~ ^[0-9]+$ ]] && (( role_relevant > 0 )); then
    add_finding 40 FAILED_SERVICES_ROLE services HIGH "$role_relevant" services 0 "Есть неработающие службы, критичные для заявленной роли: $role_relevant" "Не использовать сервер по заявленной роли до восстановления служб"
  fi
  if [[ "$critical" =~ ^[0-9]+$ ]] && (( critical > 0 )); then
    add_finding 40 FAILED_SERVICES_CRITICAL services HIGH "$critical" services 0 "Есть критичные системные службы: $critical" "Не продолжать изменения до восстановления служб"
  fi
  if [[ "$service_restart_max" =~ ^[0-9]+$ ]] && [[ "$service_restart_threshold" =~ ^[0-9]+$ ]] && (( service_restart_max >= service_restart_threshold )); then
    add_finding 30 SERVICE_RESTARTS_REPEATED services MEDIUM "$service_restart_max" restarts "$service_restart_threshold" \
      "Одна из служб автоматически перезапускалась не менее ${service_restart_max} раз" \
      "Проверить агрегированные события службы и сопоставить их с ресурсными метриками" \
      "Systemd сообщает повышенный restart counter минимум для одной службы" \
      "Служба могла завершаться аварийно или перезапускаться по своей restart policy" \
      "NRestarts относится к времени жизни systemd manager, а имя службы намеренно не выводится в summary"
  fi
  if [[ "$service_failure_events" =~ ^[0-9]+$ ]] && [[ "$service_failure_threshold" =~ ^[0-9]+$ ]] && (( service_failure_events >= service_failure_threshold )); then
    add_finding 30 SERVICE_FAILURE_EVENTS_REPEATED services MEDIUM "$service_failure_events" events_24h "$service_failure_threshold" \
      "В журнале повторялись события сбоев служб: ${service_failure_events} за окно" \
      "Проверить полный локальный отчёт и сопоставить время с CPU, памятью, storage и сетью" \
      "В bounded-выборке журнала найдены повторные systemd failure markers" \
      "Одна или несколько служб сообщали о сбоях запуска или завершения" \
      "Агрегированный счётчик не определяет конкретную службу или первопричину"
  fi
  if [[ "$application_sqlite_locks" =~ ^[0-9]+$ ]] && [[ "$application_sqlite_threshold" =~ ^[0-9]+$ ]] && (( application_sqlite_locks >= application_sqlite_threshold )); then
    add_finding 30 APPLICATION_SQLITE_LOCKS_REPEATED applications MEDIUM "$application_sqlite_locks" events_24h "$application_sqlite_threshold" \
      "SQLite lock-события повторялись: ${application_sqlite_locks} за окно" \
      "Проверить конкурирующие записи приложения и сопоставить с storage latency, iowait и свободным местом" \
      "В bounded-выборке журнала повторялось сообщение database is locked" \
      "Приложение сталкивалось с блокировкой SQLite во время операций с базой" \
      "Причина блокировки, конкретная база и виновный процесс не определяются агрегированным счётчиком"
  fi
  if [[ "$application_timeouts" =~ ^[0-9]+$ ]] && [[ "$application_timeout_threshold" =~ ^[0-9]+$ ]] && (( application_timeouts >= application_timeout_threshold )); then
    add_finding 25 APPLICATION_TIMEOUTS_REPEATED applications MEDIUM "$application_timeouts" events_24h "$application_timeout_threshold" \
      "Таймауты приложений повторялись: ${application_timeouts} за окно" \
      "Сопоставить время событий с TCP counters, нагрузкой служб и удалёнными зависимостями" \
      "В bounded-выборке журнала повторялись явные timeout markers" \
      "Операции приложений не завершались в ожидаемое время" \
      "Маршрут, удалённая сторона, локальный ресурс и конкретное приложение не назначаются причиной"
  fi
  if [[ "$application_role_events" =~ ^[0-9]+$ ]] && [[ "$role_service_threshold" =~ ^[0-9]+$ ]] && (( application_role_events >= role_service_threshold )); then
    add_finding 35 ROLE_SERVICE_EVENTS_REPEATED services MEDIUM "$application_role_events" events_24h "$role_service_threshold" \
      "Для служб заявленной роли повторялись ошибки или таймауты: ${application_role_events} за окно" \
      "Проверить работоспособность роли и сопоставить события с ресурсными и сетевыми метриками" \
      "Role-scoped journal query вернул повторные application/service markers" \
      "Службы заявленной роли испытывали повторяющиеся сбои или задержки" \
      "Summary не раскрывает имена служб и не доказывает инфраструктурную первопричину"
  fi
  if [[ "$application_sqlite_locks" =~ ^[0-9]+$ ]] && [[ "$application_sqlite_threshold" =~ ^[0-9]+$ ]] && (( application_sqlite_locks >= application_sqlite_threshold )) && \
     { { [[ "$iowait_exceedances" =~ ^[0-9]+$ ]] && (( iowait_exceedances >= 2 )); } || \
       { [[ "$storage_await_exceedances" =~ ^[0-9]+$ ]] && (( storage_await_exceedances >= 2 )); }; }; then
    add_finding 35 APPLICATION_STORAGE_SYMPTOMS_CORRELATED applications MEDIUM "$application_sqlite_locks" sqlite_lock_events_24h "$application_sqlite_threshold" \
      "SQLite lock-события совпали в одном аудите с повышенными storage-показателями" \
      "Сопоставить точные timestamps приложения и storage; не назначать disk fault без временного совпадения" \
      "В одном аудите присутствуют повторные SQLite locks и повторное превышение iowait или await" \
      "Storage-задержка может усиливать application lock symptoms" \
      "Журнал за 24 часа не синхронизирован по времени с короткими resource samples; причинность не доказана"
  fi
  if [[ "$application_timeouts" =~ ^[0-9]+$ ]] && [[ "$application_timeout_threshold" =~ ^[0-9]+$ ]] && (( application_timeouts >= application_timeout_threshold )) && \
     { { [[ "$network_timeout_exceedances" =~ ^[0-9]+$ ]] && (( network_timeout_exceedances >= 2 )); } || \
       { [[ "$network_retrans_ratio_exceedances" =~ ^[0-9]+$ ]] && (( network_retrans_ratio_exceedances >= 2 )); } || \
       { [[ "$network_abort_exceedances" =~ ^[0-9]+$ ]] && (( network_abort_exceedances >= 2 )); }; }; then
    add_finding 35 APPLICATION_NETWORK_SYMPTOMS_CORRELATED applications MEDIUM "$application_timeouts" application_timeout_events_24h "$application_timeout_threshold" \
      "Таймауты приложений совпали в одном аудите с повторными TCP-симптомами" \
      "Сопоставить точные timestamps приложения, маршрута и удалённой стороны" \
      "В одном аудите присутствуют повторные application timeouts и повторные kernel TCP symptoms" \
      "Сетевые задержки могут участвовать в наблюдаемых application timeouts" \
      "Журнал за 24 часа не синхронизирован по времени с пятисекундным TCP sample; причинность не доказана"
  fi
  [[ "$apt_simulation_status" != ok ]] && add_finding 20 APT_SIMULATION_INCOMPLETE packages MEDIUM "$apt_simulation_status" status ok "Не удалось выполнить безопасную симуляцию обновления" "Не выполнять обновление до успешной симуляции"

  if [[ "$cpu_sample_status" != ok ]]; then
    add_finding 20 CPU_SAMPLE_INCOMPLETE resources LOW "$cpu_sample_status" status ok \
      "Диагностика CPU/I/O неполна: $cpu_sample_status" \
      "Повторить audit; отсутствующие показатели нельзя считать нулевыми" \
      "Получено ${cpu_sample_count} из ${CPU_SAMPLE_COUNT} запланированных интервалов" \
      "Надёжность заключения по CPU/I/O ограничена" \
      "Часть или все дельты /proc/stat недоступны"
  fi
  if [[ "$steal" =~ ^[0-9]+([.][0-9]+)?$ ]] && awk -v x="$steal" -v t="$steal_threshold" 'BEGIN{exit !(x>t)}'; then
    steal_pattern="$(resource_pattern "$steal_exceedances" "$cpu_sample_count")"
    steal_confidence="$(resource_confidence "$cpu_sample_status" "$steal_exceedances" "$cpu_sample_count")"
    add_finding 30 CPU_STEAL_HIGH compute "$steal_confidence" "$steal" percent "$steal_threshold" \
      "CPU steal достиг ${steal}%: превышений ${steal_exceedances}/${cpu_sample_count}" \
      "Повторить ограниченный замер и обратиться к провайдеру при подтверждении" \
      "Зафиксировано превышение CPU steal в $steal_pattern режиме" \
      "Гипервизор задерживал выполнение виртуального CPU во время измерений" \
      "Причина на стороне конкретного физического узла не доказана"
  fi
  if [[ "$iowait" =~ ^[0-9]+([.][0-9]+)?$ ]] && awk -v x="$iowait" -v t="$iowait_threshold" 'BEGIN{exit !(x>t)}'; then
    iowait_pattern="$(resource_pattern "$iowait_exceedances" "$cpu_sample_count")"
    iowait_confidence="$(resource_confidence "$cpu_sample_status" "$iowait_exceedances" "$cpu_sample_count")"
    add_finding 25 DISK_IOWAIT_HIGH storage "$iowait_confidence" "$iowait" percent "$iowait_threshold" \
      "I/O wait достиг ${iowait}%: превышений ${iowait_exceedances}/${cpu_sample_count}" \
      "Повторить ограниченный многократный замер и сопоставить с PSI, await, очередью и журналами приложений" \
      "Измерено повышенное ожидание I/O в $iowait_pattern режиме" \
      "Во время измерений CPU ожидал завершения операций ввода-вывода" \
      "Физическая неисправность диска и точный компонент задержки не доказаны"
  fi
  if [[ "$load_per_vcpu" =~ ^[0-9]+([.][0-9]+)?$ ]] && awk -v x="$load_per_vcpu" -v t="$load_threshold" 'BEGIN{exit !(x>t)}'; then
    add_finding 20 LOAD_PER_VCPU_HIGH compute MEDIUM "$load_per_vcpu" ratio "$load_threshold" \
      "Высокая минутная нагрузка: ${load_per_vcpu} на vCPU" \
      "Проверить процессы и повторить замер под контролируемой нагрузкой" \
      "Load average за 1 минуту превышает порог на vCPU" \
      "Очередь выполняемых или ожидающих задач повышена" \
      "Load average сам по себе не определяет виновный процесс или ресурс"
  fi
  if [[ "$oom" =~ ^[0-9]+$ ]] && (( oom > 0 )); then
    add_finding 35 MEMORY_OOM memory HIGH "$oom" events 0 "Зафиксирована нехватка памяти" "Разобрать причину до продолжения"
  fi
  if [[ "$mem_available_critical_exceedances" =~ ^[0-9]+$ ]] && (( mem_available_critical_exceedances >= 2 )); then
    pressure_pattern="$(resource_pattern "$mem_available_critical_exceedances" "$pressure_sample_count")"
    pressure_confidence="$(resource_confidence "$memory_pressure_status" "$mem_available_critical_exceedances" "$pressure_sample_count")"
    add_finding 40 MEMORY_AVAILABLE_CRITICAL memory "$pressure_confidence" "$mem_available_min" percent "$mem_available_critical_threshold" \
      "Доступная память снижалась до ${mem_available_min}%: критических окон ${mem_available_critical_exceedances}/${pressure_sample_count}" \
      "Не продолжать нагрузочные изменения; определить потребителей памяти и проверить OOM/PSI" \
      "Критически низкая доступная память повторилась в $pressure_pattern режиме" \
      "Сервер испытывал выраженное ограничение доступной памяти во время измерений" \
      "Конкретный процесс и причина роста памяти не назначаются без дополнительной корреляции"
  elif [[ "$mem_available_exceedances" =~ ^[0-9]+$ ]] && (( mem_available_exceedances >= 2 )); then
    pressure_pattern="$(resource_pattern "$mem_available_exceedances" "$pressure_sample_count")"
    pressure_confidence="$(resource_confidence "$memory_pressure_status" "$mem_available_exceedances" "$pressure_sample_count")"
    add_finding 30 MEMORY_AVAILABLE_LOW memory "$pressure_confidence" "$mem_available_min" percent "$mem_available_threshold" \
      "Доступная память снижалась до ${mem_available_min}%: превышений ${mem_available_exceedances}/${pressure_sample_count}" \
      "Проверить процессы по памяти и сопоставить с swap, major faults, PSI и OOM" \
      "Низкая доступная память повторилась в $pressure_pattern режиме" \
      "Запас памяти был ниже консервативного порога в нескольких окнах" \
      "Высокое использование памяти само по себе не доказывает утечку"
  fi
  if [[ "$memory_psi_full_exceedances" =~ ^[0-9]+$ ]] && (( memory_psi_full_exceedances >= 2 )); then
    add_finding 35 MEMORY_PSI_FULL_HIGH memory MEDIUM "$memory_psi_full_max" percent "$memory_psi_full_threshold" \
      "Полная PSI-задержка памяти достигла ${memory_psi_full_max}%: превышений ${memory_psi_full_exceedances}" \
      "Сопоставить давление памяти с доступной памятью, swap, major faults и процессами" \
      "Повторно измерены интервалы, когда все рабочие задачи ожидали память" \
      "Во время нескольких окон наблюдалось системное memory pressure" \
      "PSI не определяет конкретный виновный процесс"
  elif [[ "$memory_psi_some_exceedances" =~ ^[0-9]+$ ]] && (( memory_psi_some_exceedances >= 2 )); then
    add_finding 30 MEMORY_PSI_SOME_HIGH memory MEDIUM "$memory_psi_some_max" percent "$memory_psi_some_threshold" \
      "PSI-задержка памяти достигла ${memory_psi_some_max}%: превышений ${memory_psi_some_exceedances}" \
      "Сопоставить давление памяти с доступной памятью, swap, major faults и процессами"
  fi
  if { [[ "$swap_in_exceedances" =~ ^[0-9]+$ ]] && (( swap_in_exceedances >= 2 )); } || \
     { [[ "$swap_out_exceedances" =~ ^[0-9]+$ ]] && (( swap_out_exceedances >= 2 )); }; then
    add_finding 20 SWAP_IO_REPEATED memory MEDIUM "${swap_in_max}/${swap_out_max}" pages_per_second_in_out "$SWAP_IO_RATE_WARN" \
      "Повторно наблюдался обмен со swap: in max ${swap_in_max}, out max ${swap_out_max} страниц/с" \
      "Сопоставить swap-активность с доступной памятью, PSI и задержками приложений" \
      "Swap I/O наблюдался более чем в одном временном окне" \
      "Активный swap может увеличивать задержки при memory pressure" \
      "Само наличие занятого swap без текущего I/O не считается проблемой"
  fi
  if [[ "$major_fault_exceedances" =~ ^[0-9]+$ ]] && (( major_fault_exceedances >= 2 )); then
    add_finding 20 MAJOR_FAULTS_REPEATED memory MEDIUM "$major_fault_max" faults_per_second "$major_fault_threshold" \
      "Major page faults достигли ${major_fault_max}/с: превышений ${major_fault_exceedances}" \
      "Сопоставить faults с процессами, storage latency, swap и PSI"
  fi
  if [[ "$cpu_psi_some_exceedances" =~ ^[0-9]+$ ]] && (( cpu_psi_some_exceedances >= 2 )); then
    add_finding 25 CPU_PSI_HIGH compute MEDIUM "$cpu_psi_some_max" percent "$cpu_psi_some_threshold" \
      "PSI-задержка CPU достигла ${cpu_psi_some_max}%: превышений ${cpu_psi_some_exceedances}" \
      "Проверить процессы по CPU и повторить bounded замер"
  elif [[ "$run_queue_exceedances" =~ ^[0-9]+$ ]] && (( run_queue_exceedances >= 2 )); then
    add_finding 20 RUN_QUEUE_HIGH compute MEDIUM "$run_queue_max" runnable_per_vcpu "$run_queue_threshold" \
      "Очередь выполняемых задач достигла ${run_queue_max} на vCPU: превышений ${run_queue_exceedances}" \
      "Проверить процессы по CPU и сопоставить с load average и PSI"
  fi
  if [[ "$fs_errors" =~ ^[0-9]+$ ]] && (( fs_errors > 0 )); then
    add_finding 40 STORAGE_KERNEL_ERRORS storage HIGH "$fs_errors" events 0 "Найдены ошибки диска или файловой системы" "Остановить развёртывание и проверить хранилище"
  fi
  if [[ "$root_used_pct" =~ ^[0-9]+$ ]] && (( root_used_pct >= STORAGE_FS_CRITICAL_PCT )); then
    add_finding 40 ROOT_FILESYSTEM_CRITICAL storage HIGH "$root_used_pct" percent "$STORAGE_FS_CRITICAL_PCT" \
      "Корневая файловая система заполнена на ${root_used_pct}%" \
      "Безопасно освободить место после проверки крупнейших каталогов и журналов" \
      "Измерено критическое заполнение корневой файловой системы" \
      "Недостаток свободного места может нарушать запись журналов, баз данных и обновлений" \
      "Причина заполнения не определяется без анализа содержимого"
  elif [[ "$root_used_pct" =~ ^[0-9]+$ ]] && (( root_used_pct >= STORAGE_FS_WARN_PCT )); then
    add_finding 20 ROOT_FILESYSTEM_HIGH storage HIGH "$root_used_pct" percent "$STORAGE_FS_WARN_PCT" \
      "Корневая файловая система заполнена на ${root_used_pct}%" \
      "Просмотреть крупнейшие каталоги и запланировать безопасное освобождение места"
  fi
  if [[ "$root_inode_used_pct" =~ ^[0-9]+$ ]] && (( root_inode_used_pct >= STORAGE_INODE_CRITICAL_PCT )); then
    add_finding 40 ROOT_INODES_CRITICAL storage HIGH "$root_inode_used_pct" percent "$STORAGE_INODE_CRITICAL_PCT" \
      "Inode корневой файловой системы использованы на ${root_inode_used_pct}%" \
      "Найти каталоги с большим количеством мелких файлов до исчерпания inode"
  elif [[ "$root_inode_used_pct" =~ ^[0-9]+$ ]] && (( root_inode_used_pct >= STORAGE_INODE_WARN_PCT )); then
    add_finding 20 ROOT_INODES_HIGH storage HIGH "$root_inode_used_pct" percent "$STORAGE_INODE_WARN_PCT" \
      "Inode корневой файловой системы использованы на ${root_inode_used_pct}%" \
      "Проверить каталоги с большим количеством мелких файлов"
  fi
  if [[ "$root_read_only" == yes ]]; then
    add_finding 40 ROOT_FILESYSTEM_READ_ONLY storage HIGH yes boolean no \
      "Корневая файловая система смонтирована только для чтения" \
      "Не выполнять изменения; проверить журнал ядра и состояние файловой системы"
  fi
  if [[ "$storage_latency_status" == ok && "$storage_await_exceedances" =~ ^[0-9]+$ ]] && (( storage_await_exceedances >= 2 )); then
    add_finding 30 STORAGE_DEVICE_LATENCY_HIGH storage MEDIUM "$storage_await_max" milliseconds "$storage_await_threshold" \
      "Задержка устройства достигла ${storage_await_max} ms: превышений ${storage_await_exceedances}/${storage_latency_windows}" \
      "Повторить read-only замер под контролируемой нагрузкой и сопоставить с PSI, очередью и журналами приложений" \
      "Повторно измерена повышенная средняя задержка завершённых операций устройства $storage_device" \
      "Storage path отвечал медленнее консервативного порога во время нескольких активных окон" \
      "Физическая неисправность диска, конкретный слой хранилища и причина задержки не доказаны"
  fi
  if [[ "$storage_util_exceedances" =~ ^[0-9]+$ ]] && (( storage_util_exceedances >= 2 )); then
    add_finding 25 STORAGE_DEVICE_BUSY storage MEDIUM "$storage_util_max" percent "$storage_util_threshold" \
      "Устройство было занято до ${storage_util_max}%: превышений ${storage_util_exceedances}" \
      "Сопоставить занятость устройства с await, очередью, PSI и активными процессами"
  fi
  if [[ "$storage_queue_exceedances" =~ ^[0-9]+$ ]] && (( storage_queue_exceedances >= 2 )); then
    add_finding 25 STORAGE_QUEUE_HIGH storage MEDIUM "$storage_queue_max" requests "$storage_queue_threshold" \
      "Средняя очередь устройства достигла ${storage_queue_max}: превышений ${storage_queue_exceedances}" \
      "Повторить замер и сопоставить очередь с задержкой и workload"
  fi

  if [[ "$network_listen_drop_exceedances" =~ ^[0-9]+$ && "$network_listen_overflow_exceedances" =~ ^[0-9]+$ ]] && \
     (( network_listen_drop_exceedances >= 2 || network_listen_overflow_exceedances >= 2 )); then
    add_finding 35 NETWORK_LISTEN_DROPS_REPEATED network MEDIUM "${network_listen_drop_max}/${network_listen_overflow_max}" events_per_second_drop_overflow 0 \
      "Повторно росли TCP listen drops/overflows: max ${network_listen_drop_max}/${network_listen_overflow_max} событий/с" \
      "Проверить backlog, нагрузку принимающего сервиса и коррелирующие CPU/network counters" \
      "Kernel TCP counters росли минимум в двух окнах" \
      "Сервер не успевал принять часть входящих соединений во время измерений" \
      "Конкретный сервис и первопричина не определяются только по глобальным kernel counters"
  fi
  if [[ "$network_timeout_exceedances" =~ ^[0-9]+$ ]] && (( network_timeout_exceedances >= 2 )); then
    add_finding 30 NETWORK_TCP_TIMEOUTS_REPEATED network MEDIUM "$network_timeout_max" events_per_second 0 \
      "TCP timeouts повторялись: max ${network_timeout_max} событий/с, окон ${network_timeout_exceedances}/${network_sample_count}" \
      "Сопоставить время события с маршрутом, retransmissions, firewall и логами приложения" \
      "Глобальный TCPTimeouts рос минимум в двух временных окнах" \
      "На сервере повторялись TCP-таймауты во время bounded-замера" \
      "Удалённая сторона, маршрут, firewall, приложение или провайдерская причина не определены"
  fi
  if [[ "$network_abort_exceedances" =~ ^[0-9]+$ ]] && (( network_abort_exceedances >= 2 )); then
    add_finding 30 NETWORK_TCP_ABORT_TIMEOUT_REPEATED network MEDIUM "$network_abort_max" events_per_second 0 \
      "TCP-соединения повторно завершались по timeout: max ${network_abort_max} событий/с" \
      "Сопоставить aborts с retransmissions, очередями сокетов и логами приложения"
  fi
  if [[ "$network_retrans_ratio_exceedances" =~ ^[0-9]+$ ]] && (( network_retrans_ratio_exceedances >= 2 )); then
    add_finding 30 NETWORK_RETRANSMISSION_RATIO_HIGH network MEDIUM "$network_retrans_ratio_max" percent "$network_retrans_ratio_threshold" \
      "Доля TCP retransmissions достигла ${network_retrans_ratio_max}%: превышений ${network_retrans_ratio_exceedances}" \
      "Повторить замер и сопоставить с TCP timeouts, маршрутом и удалённой точкой" \
      "Повышенная доля retransmissions повторилась при достаточном числе исходящих TCP-сегментов" \
      "Часть TCP-сегментов требовала повторной передачи" \
      "Глобальный counter не определяет конкретное соединение, участок маршрута или виновную сторону"
  fi
  if [[ "$network_error_exceedances" =~ ^[0-9]+$ ]] && (( network_error_exceedances >= 2 )); then
    add_finding 30 NETWORK_INTERFACE_ERRORS_REPEATED network MEDIUM "$network_error_max" events_per_second 0 \
      "Ошибки интерфейса $network_interface повторялись: max ${network_error_max} событий/с" \
      "Проверить kernel log, virtual NIC и состояние сети у провайдера"
  fi
  if [[ "$network_drop_exceedances" =~ ^[0-9]+$ ]] && (( network_drop_exceedances >= 2 )); then
    add_finding 25 NETWORK_INTERFACE_DROPS_REPEATED network MEDIUM "$network_drop_max" events_per_second 0 \
      "Дропы интерфейса $network_interface повторялись: max ${network_drop_max} событий/с" \
      "Сопоставить дропы с нагрузкой, очередями, kernel log и provider network"
  fi
  if [[ "$network_syn_exceedances" =~ ^[0-9]+$ ]] && (( network_syn_exceedances >= 2 )); then
    add_finding 25 NETWORK_SYN_RETRANSMITS_REPEATED network MEDIUM "$network_syn_max" events_per_second 0 \
      "Повторные SYN наблюдались минимум в двух окнах: max ${network_syn_max} событий/с" \
      "Сопоставить с доступностью удалённых точек, firewall и маршрутом"
  fi

  if network_status; then
    network_check_status=ok
  else
    network_rc=$?
    if (( network_rc == 2 )); then
      network_check_status=unsupported
      add_finding 20 NETWORK_CHECK_UNSUPPORTED network MEDIUM unsupported status ok "Сетевая проверка неполна: отсутствует curl или getent" "Установить недостающий диагностический инструмент и повторить audit"
    else
      network_check_status=failed
      add_finding 30 NETWORK_HTTPS_FAILED network MEDIUM failed status ok "Не подтверждён доступ в интернет по HTTPS" "Повторить сетевую проверку"
    fi
  fi

  coverage_require cpu_sample "$cpu_sample_status"
  coverage_require load_sample "$load_status"
  coverage_require kernel_journal "$kernel_journal_status"
  coverage_require systemd_failed_services "$systemd_failed_services_status"
  apt_index_coverage_status="$apt_index_status"
  [[ "$package_update_evidence_status" == available ]] || apt_index_coverage_status=unavailable
  coverage_require apt_index "$apt_index_coverage_status"
  coverage_require apt_simulation "$apt_simulation_status"
  coverage_require network_check "$network_check_status"
  coverage_require storage_filesystem "$storage_filesystem_status"
  coverage_require storage_device_io "$storage_device_sample_status"
  coverage_require memory_pressure "$memory_pressure_status"
  coverage_require cpu_pressure "$cpu_pressure_status"
  coverage_require network_counters "$network_counter_status"
  coverage_require application_service_events "$application_service_status"
  if (( coverage_completed == coverage_required )); then
    coverage_status=complete
  elif [[ "$coverage_missing" != none ]]; then
    coverage_status=partial
    add_finding 20 DIAGNOSTIC_COVERAGE_INCOMPLETE diagnostics HIGH "$coverage_completed" checks "$coverage_required" \
      "Диагностика выполнена не полностью: ${coverage_completed}/${coverage_required} обязательных проверок" \
      "Повторить audit после восстановления недоступных источников: $coverage_missing" \
      "Подтверждено отсутствие части обязательных диагностических данных" \
      "Общий вывод ограничен неполным покрытием проверок" \
      "Отсутствующие проверки: $coverage_missing"
  else
    coverage_status=limited
    add_finding 10 DIAGNOSTIC_EVIDENCE_LIMITED diagnostics MEDIUM "$coverage_completed" checks "$coverage_required" \
      "Часть диагностических данных ограничена: ${coverage_completed}/${coverage_required} проверок полные" \
      "Учитывать ограничение выборки; при необходимости выполнить отдельную углублённую проверку: $coverage_limited" \
      "Источники доступны, но часть доказательств ограничена безопасным лимитом выборки" \
      "Общий вывод сохраняется, но уверенность снижена для ограниченных проверок" \
      "Ограниченные проверки: $coverage_limited"
  fi

  if [[ "$primary_code" != none ]]; then
    diagnostic_confidence="$primary_confidence"
  elif [[ "$cpu_sample_status" == ok && "$network_check_status" == ok && "$apt_index_status" == fresh ]]; then
    diagnostic_confidence=HIGH
  else
    diagnostic_confidence=LIMITED
  fi
  if [[ "$coverage_status" != complete ]]; then diagnostic_confidence=LIMITED
  elif [[ "$storage_latency_status" != ok ]]; then diagnostic_confidence=LIMITED
  elif [[ "$network_counter_status" != ok ]]; then diagnostic_confidence=LIMITED
  elif [[ "$application_service_status" != ok ]]; then diagnostic_confidence=LIMITED
  elif [[ "$access_evidence_schema_version" == "$ACCESS_READINESS_SCHEMA_VERSION" && "$access_readiness_confidence" == LIMITED ]]; then diagnostic_confidence=LIMITED
  elif [[ "$network_time_evidence_schema_version" == "$NETWORK_TIME_READINESS_SCHEMA_VERSION" && "$network_time_readiness_confidence" == LIMITED ]]; then diagnostic_confidence=LIMITED
  elif [[ "$access_evidence_schema_version" == "$ACCESS_READINESS_SCHEMA_VERSION" && "$access_readiness_confidence" == MEDIUM && "$diagnostic_confidence" == HIGH ]]; then diagnostic_confidence=MEDIUM
  elif [[ "$network_time_evidence_schema_version" == "$NETWORK_TIME_READINESS_SCHEMA_VERSION" && "$network_time_readiness_confidence" == MEDIUM && "$diagnostic_confidence" == HIGH ]]; then diagnostic_confidence=MEDIUM
  fi
  if [[ "$PLATFORM_SUPPORT_STATUS" != supported ]]; then
    case "$diagnostic_confidence" in
      HIGH|MEDIUM) diagnostic_confidence=LIMITED ;;
    esac
  fi
  verdict="$(severity_to_verdict "$max_severity")"
  os_name="$(awk -F= '/^PRETTY_NAME=/{gsub(/"/,"",$2); print $2}' /etc/os-release 2>/dev/null || true)"
  provider_label_report_safe="$(report_safe_operator_label "$PROVIDER_LABEL")"
  location_label_report_safe="$(report_safe_operator_label "$LOCATION_LABEL")"
  role_label_report_safe="$(report_safe_operator_label "$ROLE_LABEL")"

  if ! cat >"$out" <<EOT
Server Toolkit v$VERSION
server=$host
utc=$(date -u -Is)
mode=audit
audit_policy=read_only
platform_contract_version=$PLATFORM_CONTRACT_VERSION
platform_support_status=$PLATFORM_SUPPORT_STATUS
platform_support_reason=$PLATFORM_SUPPORT_REASON
platform_validation_status=$PLATFORM_VALIDATION_STATUS
platform_supported_families=$PLATFORM_SUPPORTED_FAMILIES
platform_validated_list=$PLATFORM_VALIDATED_LIST
platform_supported_list=$PLATFORM_SUPPORTED_LIST
platform_id=$PLATFORM_ID
platform_version_id=$PLATFORM_VERSION_ID
phase=$phase
verdict=$verdict
risk_score=$max_severity
finding_count=$finding_count
diagnostic_confidence=$diagnostic_confidence
diagnostic_schema_version=$DIAGNOSTIC_SCHEMA_VERSION
diagnostic_method_version=$DIAGNOSTIC_METHOD_VERSION
diagnostic_coverage_status=$coverage_status
diagnostic_required_checks=$coverage_required
diagnostic_completed_checks=$coverage_completed
diagnostic_missing_checks=$coverage_missing
diagnostic_limited_checks=$coverage_limited
primary_finding_code=$primary_code
primary_finding_category=$primary_category
primary_finding_confidence=$primary_confidence
primary_finding_observed_value=$primary_observed
primary_finding_unit=$primary_unit
primary_finding_threshold=$primary_threshold
primary_finding_confirmed=$primary_confirmed
primary_finding_interpretation=$primary_interpretation
primary_finding_hypothesis=Причина не назначается без дополнительных доказательств
primary_finding_limitations=$primary_limitation
primary_finding_next_action=$action
provider_label=$provider_label_report_safe
location_label=$location_label_report_safe
role_label=$role_label_report_safe
access_evidence_schema_version=$access_evidence_schema_version
access_readiness_schema_version=$ACCESS_READINESS_SCHEMA_VERSION
access_readiness_status=$access_readiness_status
access_readiness_confidence=$access_readiness_confidence
ssh_access_status=$ssh_access_status
firewall_readiness_status=$firewall_readiness_status
package_readiness_status=$package_readiness_status
ssh_effective_status=$ssh_effective_status
ssh_effective_permit_root_login=$ssh_effective_root
ssh_effective_password_authentication=$ssh_effective_password
ssh_effective_kbd_interactive_authentication=$ssh_effective_keyboard
ssh_effective_pubkey_authentication=$ssh_effective_pubkey
ssh_effective_authentication_methods=$ssh_effective_authentication_methods
ssh_effective_context_status=$ssh_effective_context_status
ssh_effective_port_set=$ssh_effective_ports
ssh_effective_listen_address_scope=$ssh_effective_config_scope
ssh_effective_allow_users_status=$ssh_allow_users_status
ssh_effective_allow_users_count=$ssh_allow_users_count
ssh_effective_allow_groups_status=$ssh_allow_groups_status
ssh_effective_allow_groups_count=$ssh_allow_groups_count
tcp_listener_evidence_status=$tcp_listener_status
tcp_listener_total=$tcp_listener_total
tcp_listener_loopback_count=$tcp_listener_loopback
tcp_listener_wildcard_count=$tcp_listener_wildcard
tcp_listener_specific_non_loopback_count=$tcp_listener_specific
ssh_listener_correlation_status=$ssh_listener_correlation
ssh_listener_scope=$ssh_listener_scope
firewall_ufw_status=$firewall_ufw_status
firewall_nft_status=$firewall_nft_status
firewall_nft_input_policy=$firewall_nft_policy
firewall_nft_input_hook_count=$firewall_nft_hooks
firewall_nft_rule_line_count=$firewall_nft_rules
firewall_iptables_status=$firewall_iptables_status
firewall_iptables_input_policy=$firewall_iptables_policy
firewall_iptables_input_rule_count=$firewall_iptables_rules
firewall_ip6tables_status=$firewall_ip6tables_status
firewall_ip6tables_input_policy=$firewall_ip6tables_policy
firewall_ip6tables_input_rule_count=$firewall_ip6tables_rules
local_firewall_status=$local_firewall_status
local_firewall_confidence=$local_firewall_confidence
local_firewall_enforcement_sources=$local_firewall_sources
access_readiness_fact_ssh=$access_fact_ssh
access_readiness_fact_listener=$access_fact_listener
access_readiness_fact_firewall=$access_fact_firewall
access_readiness_fact_packages=$access_fact_packages
access_readiness_correlation=$access_correlation
access_readiness_limitations=$access_limitations
access_readiness_checked_scope=$access_checked_scope
access_readiness_not_checked_status=$access_not_checked_status
access_readiness_not_checked_families=$access_not_checked_families
network_time_evidence_schema_version=$network_time_evidence_schema_version
network_time_readiness_schema_version=$network_time_readiness_schema_version
network_time_readiness_status=$network_time_readiness_status
network_time_readiness_confidence=$network_time_readiness_confidence
network_time_readiness_coverage_status=$network_time_readiness_coverage_status
network_ipv4_default_route_status=$network_ipv4_default_route_status
network_ipv4_default_interface=$network_ipv4_default_interface
network_ipv6_default_route_status=$network_ipv6_default_route_status
network_ipv6_default_interface=$network_ipv6_default_interface
network_readiness_primary_interface=$network_readiness_primary_interface
network_primary_interface_mtu=$network_primary_interface_mtu
network_mtu_status=$network_mtu_status
network_mtu_profile=$network_mtu_profile
network_resolver_configuration_status=$network_resolver_configuration_status
network_resolver_nameserver_count=$network_resolver_nameserver_count
network_name_service_resolution_status=$network_name_service_resolution_status
network_name_service_resolution_requested_count=$network_name_service_resolution_requested_count
network_name_service_resolution_success_count=$network_name_service_resolution_success_count
network_time_evidence_status=$network_time_evidence_status
network_time_ntp_synchronized=$network_time_ntp_synchronized
network_time_ntp_enabled=$network_time_ntp_enabled
network_time_can_ntp=$network_time_can_ntp
network_time_timezone=$network_time_timezone
network_time_uptime_seconds=$network_time_uptime_seconds
network_time_sync_status=$network_time_sync_status
network_time_external_reachability_status=$network_time_external_reachability_status
network_time_domain_tls_status=$network_time_domain_tls_status
network_time_readiness_checked_scope=$network_time_checked_scope
network_time_readiness_not_checked_status=$network_time_not_checked_status
network_time_readiness_not_checked_families=$network_time_not_checked_families
network_time_readiness_limitations=$network_time_limitations
network_time_readiness_fact_routes=$network_time_fact_routes
network_time_readiness_fact_name_service=$network_time_fact_name_service
network_time_readiness_fact_time=$network_time_fact_time
network_check_status=$network_check_status
network_counter_sample_status=$network_counter_status
network_primary_interface=$network_interface
network_counter_sample_count=$network_sample_count
network_counter_activity_windows=$network_activity_windows
network_counter_reset_windows=$network_reset_windows
network_tcp_retrans_ratio_pct_max=$network_retrans_ratio_max
network_tcp_retrans_ratio_pct_threshold=$network_retrans_ratio_threshold
network_tcp_retrans_ratio_pct_threshold_exceedance_count=$network_retrans_ratio_exceedances
network_tcp_timeout_events_per_second_max=$network_timeout_max
network_tcp_timeout_events_per_second_threshold_exceedance_count=$network_timeout_exceedances
network_tcp_syn_retrans_events_per_second_max=$network_syn_max
network_tcp_syn_retrans_events_per_second_threshold_exceedance_count=$network_syn_exceedances
network_listen_drop_events_per_second_max=$network_listen_drop_max
network_listen_drop_events_per_second_threshold_exceedance_count=$network_listen_drop_exceedances
network_listen_overflow_events_per_second_max=$network_listen_overflow_max
network_listen_overflow_events_per_second_threshold_exceedance_count=$network_listen_overflow_exceedances
network_tcp_abort_timeout_events_per_second_max=$network_abort_max
network_tcp_abort_timeout_events_per_second_threshold_exceedance_count=$network_abort_exceedances
network_interface_error_events_per_second_max=$network_error_max
network_interface_error_events_per_second_threshold_exceedance_count=$network_error_exceedances
network_interface_drop_events_per_second_max=$network_drop_max
network_interface_drop_events_per_second_threshold_exceedance_count=$network_drop_exceedances
application_service_sample_status=$application_service_status
application_service_sample_method=$application_service_method
application_sqlite_lock_threshold=$application_sqlite_threshold
application_timeout_threshold=$application_timeout_threshold
service_failure_event_threshold=$service_failure_threshold
service_restart_threshold=$service_restart_threshold
role_service_event_threshold=$role_service_threshold
application_journal_status=$application_journal_status
application_journal_window=$application_journal_window
application_journal_max_records=$application_journal_max
application_journal_records_scanned=$application_journal_records
application_journal_truncated=$application_journal_truncated
service_restart_counter_status=$service_restart_counter_status
service_restart_counter_scope=$service_restart_counter_scope
service_units_observed=$service_units_observed
service_units_with_restarts=$service_units_with_restarts
service_restart_count_total=$service_restart_total
service_restart_count_max=$service_restart_max
service_restart_counter_invalid_units=$service_restart_invalid
application_sqlite_lock_events_24h=$application_sqlite_locks
application_timeout_events_24h=$application_timeouts
service_failure_events_24h=$service_failure_events
service_restart_events_24h=$service_restart_events
application_role_scope_status=$application_role_scope_status
application_role_journal_records_scanned=$application_role_records
application_role_journal_truncated=$application_role_truncated
application_role_relevant_events_24h=$application_role_events
kernel_journal_status=$kernel_journal_status
kernel_oom_events=$oom
kernel_storage_error_events=$fs_errors
systemd_failed_services_status=$systemd_failed_services_status
storage_filesystem_status=$storage_filesystem_status
storage_device_status=$storage_device_status
storage_device_sample_status=$storage_device_sample_status
storage_latency_evidence_status=$storage_latency_status
root_source=$root_source
root_filesystem=$root_filesystem
root_mount_read_only=$root_read_only
root_total_kib=$root_total
root_used_kib=$root_used
root_available_kib=$root_available
root_used_pct=$root_used_pct
root_inode_used_pct=$root_inode_used_pct
storage_device=$storage_device
storage_device_operations=$storage_operations
storage_device_activity_windows=$storage_activity_windows
storage_device_latency_windows=$storage_latency_windows
storage_device_inflight=$storage_inflight
storage_await_ms_min=$storage_await_min
storage_await_ms_median=$storage_await_median
storage_await_ms_average=$storage_await_average
storage_await_ms_max=$storage_await_max
storage_await_ms_threshold=$storage_await_threshold
storage_await_ms_threshold_exceedance_count=$storage_await_exceedances
storage_read_await_ms_max=$storage_read_await_max
storage_write_await_ms_max=$storage_write_await_max
storage_util_pct_min=$storage_util_min
storage_util_pct_median=$storage_util_median
storage_util_pct_average=$storage_util_average
storage_util_pct_max=$storage_util_max
storage_util_pct_threshold=$storage_util_threshold
storage_util_pct_threshold_exceedance_count=$storage_util_exceedances
storage_queue_depth_min=$storage_queue_min
storage_queue_depth_median=$storage_queue_median
storage_queue_depth_average=$storage_queue_average
storage_queue_depth_max=$storage_queue_max
storage_queue_depth_threshold=$storage_queue_threshold
storage_queue_depth_threshold_exceedance_count=$storage_queue_exceedances
memory_pressure_sample_status=$memory_pressure_status
cpu_pressure_sample_status=$cpu_pressure_status
pressure_sample_count_requested=$pressure_sample_count
pressure_sample_duration_seconds=$pressure_sample_duration
mem_available_pct_min=$mem_available_min
mem_available_pct_median=$mem_available_median
mem_available_pct_average=$mem_available_average
mem_available_pct_max=$mem_available_max
mem_available_pct_threshold=$mem_available_threshold
mem_available_pct_threshold_exceedance_count=$mem_available_exceedances
mem_available_pct_critical_threshold=$mem_available_critical_threshold
mem_available_pct_critical_threshold_exceedance_count=$mem_available_critical_exceedances
swap_used_pct_max=$swap_used_max
swap_in_pages_per_second_max=$swap_in_max
swap_in_pages_per_second_threshold=$swap_in_threshold
swap_in_pages_per_second_threshold_exceedance_count=$swap_in_exceedances
swap_out_pages_per_second_max=$swap_out_max
swap_out_pages_per_second_threshold=$swap_out_threshold
swap_out_pages_per_second_threshold_exceedance_count=$swap_out_exceedances
major_faults_per_second_max=$major_fault_max
major_faults_per_second_threshold=$major_fault_threshold
major_faults_per_second_threshold_exceedance_count=$major_fault_exceedances
memory_psi_some_avg10_pct_max=$memory_psi_some_max
memory_psi_some_avg10_pct_threshold=$memory_psi_some_threshold
memory_psi_some_avg10_pct_threshold_exceedance_count=$memory_psi_some_exceedances
memory_psi_full_avg10_pct_max=$memory_psi_full_max
memory_psi_full_avg10_pct_threshold=$memory_psi_full_threshold
memory_psi_full_avg10_pct_threshold_exceedance_count=$memory_psi_full_exceedances
cpu_psi_some_avg10_pct_max=$cpu_psi_some_max
cpu_psi_some_avg10_pct_threshold=$cpu_psi_some_threshold
cpu_psi_some_avg10_pct_threshold_exceedance_count=$cpu_psi_some_exceedances
run_queue_per_vcpu_max=$run_queue_max
run_queue_per_vcpu_threshold=$run_queue_threshold
run_queue_per_vcpu_threshold_exceedance_count=$run_queue_exceedances
os=${os_name:-unknown}
kernel=$(uname -r)
virtualization=$virt
cpu_sample_status=$cpu_sample_status
cpu_sample_method=$cpu_sample_method
cpu_sample_count=$cpu_sample_count
cpu_sample_duration_seconds=$cpu_sample_duration
iowait_pct=$iowait
iowait_min_pct=$iowait_min
iowait_median_pct=$iowait_median
iowait_average_pct=$iowait_average
iowait_max_pct=$iowait
iowait_threshold_pct=$iowait_threshold
iowait_threshold_exceedance_count=$iowait_exceedances
steal_pct=$steal
steal_min_pct=$steal_min
steal_median_pct=$steal_median
steal_average_pct=$steal_average
steal_max_pct=$steal
steal_threshold_pct=$steal_threshold
steal_threshold_exceedance_count=$steal_exceedances
load_sample_status=$load_status
vcpu_count=$vcpu_count
load_1m=$load_1m
load_5m=$load_5m
load_15m=$load_15m
load_1m_per_vcpu=$load_per_vcpu
load_1m_per_vcpu_threshold=$load_threshold
io_pressure_status=$io_pressure_status
io_pressure_some_avg10_pct=$io_pressure_some
io_pressure_full_avg10_pct=$io_pressure_full
failed_services_informational=$informational
failed_services_unknown=$unknown
failed_services_role_relevant=$role_relevant
failed_services_critical=$critical
failed_allowlist_external_status=$FAILED_ALLOWLIST_EXTERNAL_STATUS
failed_allowlist_external_entries=$FAILED_ALLOWLIST_EXTERNAL_ENTRIES
package_manager=$package_manager
package_update_evidence_status=$package_update_evidence_status
updates_total=$updates_total_report
kernel_updates=$kernel_updates_report
phased_updates=$phased_updates_report
normal_updates=$normal_updates_report
held_packages=$held_packages
broken_package_state=$broken_package_state
full_upgrade_removals=$full_upgrade_removals
apt_refresh_status=$apt_refresh_status
apt_index_status=$apt_index_status
apt_simulation_status=$apt_simulation_status
reboot_required=$reboot
main_reason=$reason
recommended_action=$action
full_report_sha256=$(sha256sum "$full" | awk '{print $1}')
EOT
  then
    return 1
  fi
  emit_ranked_findings || return 1
  chmod 600 "$out" || return 1
}

audit_section_temp_path() {
  local directory="$1" completed_sections="$2"
  [[ "$directory" == /* && "$completed_sections" =~ ^[0-9]+$ ]] || return 1
  printf '%s/.section-%s-%s.tmp\n' "$directory" "$$" "$completed_sections"
}

redact() {
  report_redact_stream
}

update_message() {
  local kernel_updates="${1:-0}" phased_updates="${2:-0}"
  if (( kernel_updates > 0 && phased_updates > 0 )); then
    UPDATE_REASON="Ожидают плановые обновления: ядро — ${kernel_updates}, поэтапно отложено Ubuntu — ${phased_updates}"
    UPDATE_ACTION="Просмотреть отчёт и выполнить обновление отдельно штатными средствами ОС; поэтапно отложенные пакеты принудительно устанавливать не требуется"
  elif (( kernel_updates > 0 )); then
    UPDATE_REASON="Доступно плановое обновление ядра: ${kernel_updates}"
    UPDATE_ACTION="Просмотреть отчёт и выполнить обновление отдельно штатными средствами ОС; перезагрузку проводить контролируемо"
  elif (( phased_updates > 0 )); then
    UPDATE_REASON="Ubuntu поэтапно отложила обновления: ${phased_updates}"
    UPDATE_ACTION="Дополнительные действия не требуются; принудительно устанавливать поэтапно отложенные пакеты не нужно"
  else
    UPDATE_REASON="Существенных проблем не найдено"
    UPDATE_ACTION="Дополнительные действия не требуются"
  fi
}

FAILED_ALLOWLIST_EXTERNAL_STATUS=not_present
FAILED_ALLOWLIST_EXTERNAL_ENTRIES=0
FAILED_ALLOWLIST_LOADED_FOR=""
FAILED_ALLOWLIST_EXTERNAL_UNITS=()

# Built-in defaults preserve one-file distribution. The optional external file
# only adds exact unit names; it is never required for normal operation.
DEFAULT_INFORMATIONAL_UNITS=(
  apt-daily.service
  apt-daily-upgrade.service
  man-db.service
  motd-news.service
  logrotate.service
  fstrim.service
  e2scrub_all.service
  update-notifier-download.service
  snapd.seeded.service
)

is_builtin_informational_unit() {
  local unit="$1" item
  for item in "${DEFAULT_INFORMATIONAL_UNITS[@]}"; do
    [[ "$unit" == "$item" ]] && return 0
  done
  return 1
}

failed_allowlist_stat_uid() {
  stat -c %u -- "$1" 2>/dev/null || stat -f %u "$1" 2>/dev/null
}

failed_allowlist_stat_mode() {
  local mode
  if mode="$(stat -c %a -- "$1" 2>/dev/null)"; then
    printf '%s\n' "$mode"
    return 0
  fi
  mode="$(stat -f %Lp "$1" 2>/dev/null)" || return 1
  [[ "$mode" =~ ^[0-7]+$ ]] || return 1
  (( ${#mode} <= 4 )) || mode="${mode: -4}"
  mode="${mode#0}"
  printf '%s\n' "$mode"
}

failed_allowlist_parent_chain_is_safe() {
  local file="$1" expected_uid="$2" parent current component owner mode numeric
  local -a components=()
  parent="${file%/*}"
  [[ -n "$parent" ]] || parent=/
  IFS=/ read -r -a components <<<"${parent#/}"
  current=/
  for component in "${components[@]}"; do
    [[ -n "$component" ]] || continue
    current="${current%/}/$component"
    [[ -d "$current" && ! -L "$current" ]] || return 1
    owner="$(failed_allowlist_stat_uid "$current" || true)"
    mode="$(failed_allowlist_stat_mode "$current" || true)"
    [[ "$owner" =~ ^[0-9]+$ && "$mode" =~ ^[0-7]{3,4}$ ]] || return 1
    [[ "$owner" == 0 || "$owner" == "$expected_uid" ]] || return 1
    numeric=$((8#$mode))
    if (( (numeric & 0022) != 0 )); then
      (( owner == 0 && (numeric & 01000) != 0 )) || return 1
    fi
  done
}

load_external_failed_services_allowlist() {
  local expected_uid="${1:-0}"
  local line mode owner_uid group_digit other_digit invalid=0
  local -a candidate=()

  FAILED_ALLOWLIST_EXTERNAL_STATUS=not_present
  FAILED_ALLOWLIST_EXTERNAL_ENTRIES=0
  FAILED_ALLOWLIST_EXTERNAL_UNITS=()
  FAILED_ALLOWLIST_LOADED_FOR="$FAILED_SERVICES_ALLOWLIST_FILE"

  [[ "$expected_uid" =~ ^[0-9]+$ ]] || expected_uid=0
  [[ "$FAILED_SERVICES_ALLOWLIST_FILE" =~ ^/[A-Za-z0-9._/-]+$ &&
     ! "$FAILED_SERVICES_ALLOWLIST_FILE" =~ (^|/)\.\.?(/|$) &&
     "$FAILED_SERVICES_ALLOWLIST_FILE" != */ ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ ! -L "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ -e "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || return 0
  failed_allowlist_parent_chain_is_safe "$FAILED_SERVICES_ALLOWLIST_FILE" "$expected_uid" || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ -f "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ -r "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=unreadable
    return 0
  }

  owner_uid="$(failed_allowlist_stat_uid "$FAILED_SERVICES_ALLOWLIST_FILE" || true)"
  if [[ ! "$owner_uid" =~ ^[0-9]+$ || "$owner_uid" != "$expected_uid" ]]; then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi

  mode="$(failed_allowlist_stat_mode "$FAILED_SERVICES_ALLOWLIST_FILE" || true)"
  if [[ ! "$mode" =~ ^[0-7]{3,4}$ ]]; then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi
  group_digit="${mode: -2:1}"
  other_digit="${mode: -1}"
  if (( (group_digit & 2) != 0 || (other_digit & 2) != 0 )); then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi

  while IFS= read -r line || [[ -n "$line" ]]; do
    line="$(printf '%s' "$line" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    [[ -n "$line" ]] || continue
    [[ "$line" == \#* ]] && continue
    if [[ ! "$line" =~ ^[^[:space:]#]+\.(service|socket|timer|mount|automount|swap|path|target|slice|scope|device)$ ]]; then
      invalid=1
      continue
    fi
    candidate+=("$line")
  done <"$FAILED_SERVICES_ALLOWLIST_FILE"

  if (( invalid != 0 )); then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi

  FAILED_ALLOWLIST_EXTERNAL_UNITS=("${candidate[@]}")
  FAILED_ALLOWLIST_EXTERNAL_ENTRIES="${#FAILED_ALLOWLIST_EXTERNAL_UNITS[@]}"
  FAILED_ALLOWLIST_EXTERNAL_STATUS=loaded
}

ensure_external_failed_services_allowlist_loaded() {
  local expected_uid="${1:-0}"
  [[ "$FAILED_ALLOWLIST_LOADED_FOR" == "$FAILED_SERVICES_ALLOWLIST_FILE:$expected_uid" ]] ||
    load_external_failed_services_allowlist "$expected_uid"
  FAILED_ALLOWLIST_LOADED_FOR="$FAILED_SERVICES_ALLOWLIST_FILE:$expected_uid"
}

failed_services_allowlist_status() {
  ensure_external_failed_services_allowlist_loaded "${1:-0}"
  printf 'failed_allowlist_external_status=%s\n' "$FAILED_ALLOWLIST_EXTERNAL_STATUS"
  printf 'failed_allowlist_external_entries=%s\n' "$FAILED_ALLOWLIST_EXTERNAL_ENTRIES"
}

is_external_informational_unit() {
  local unit="$1" expected_uid="${2:-0}" item
  ensure_external_failed_services_allowlist_loaded "$expected_uid"
  [[ "$FAILED_ALLOWLIST_EXTERNAL_STATUS" == loaded ]] || return 1
  for item in "${FAILED_ALLOWLIST_EXTERNAL_UNITS[@]}"; do
    [[ "$unit" == "$item" ]] && return 0
  done
  return 1
}

service_role_context() {
  local unit="$1" role="${2:-generic}"
  case "$role:$unit" in
    web:nginx.service|web:apache2.service|web:caddy.service) printf 'role_relevant' ;;
    database:postgresql.service|database:mysql.service|database:mariadb.service) printf 'role_relevant' ;;
    vpn:x-ui.service|vpn:xray.service|proxy:x-ui.service|proxy:xray.service|xray:xray.service) printf 'role_relevant' ;;
    mail:postfix.service|mail:dovecot.service) printf 'role_relevant' ;;
    *) printf 'generic' ;;
  esac
}

service_severity() {
  local unit="$1" virt="${2:-unknown}" expected_uid="${3:-0}"
  case "$unit" in
    ssh.service|sshd.service|systemd-networkd.service|NetworkManager.service|networking.service|systemd-resolved.service)
      printf 'critical'
      ;;
    fwupd.service|fwupd-refresh.service)
      if [[ "$virt" != "none" && "$virt" != "unknown" && -n "$virt" ]]; then printf 'informational'; else printf 'unknown'; fi
      ;;
    *)
      if is_builtin_informational_unit "$unit" || is_external_informational_unit "$unit" "$expected_uid"; then
        printf 'informational'
      else
        printf 'unknown'
      fi
      ;;
  esac
}

classify_failed_service_line() {
  local unit="$1" virt="${2:-unknown}" role="${3:-generic}" expected_uid="${4:-0}"
  printf '%s|severity=%s|context=%s\n' "$unit" "$(service_severity "$unit" "$virt" "$expected_uid")" "$(service_role_context "$unit" "$role")"
}

classify_failed_services() {
  local names="${1:-}" virt="${2:-unknown}" role="${3:-generic}" expected_uid="${4:-0}"
  local service severity context
  FAILED_INFORMATIONAL_COUNT=0
  FAILED_UNKNOWN_COUNT=0
  FAILED_CRITICAL_COUNT=0
  FAILED_ROLE_RELEVANT_COUNT=0
  FAILED_INFORMATIONAL_NAMES=""
  FAILED_UNKNOWN_NAMES=""
  FAILED_CRITICAL_NAMES=""
  FAILED_ROLE_RELEVANT_NAMES=""
  ensure_external_failed_services_allowlist_loaded "$expected_uid"

  while IFS= read -r service; do
    [[ -n "$service" ]] || continue
    severity="$(service_severity "$service" "$virt" "$expected_uid")"
    context="$(service_role_context "$service" "$role")"
    case "$severity" in
      critical)
        FAILED_CRITICAL_COUNT=$((FAILED_CRITICAL_COUNT+1))
        FAILED_CRITICAL_NAMES+="${FAILED_CRITICAL_NAMES:+,}${service}"
        ;;
      informational)
        FAILED_INFORMATIONAL_COUNT=$((FAILED_INFORMATIONAL_COUNT+1))
        FAILED_INFORMATIONAL_NAMES+="${FAILED_INFORMATIONAL_NAMES:+,}${service}"
        ;;
      *)
        if [[ "$context" == role_relevant ]]; then
          FAILED_ROLE_RELEVANT_COUNT=$((FAILED_ROLE_RELEVANT_COUNT+1))
          FAILED_ROLE_RELEVANT_NAMES+="${FAILED_ROLE_RELEVANT_NAMES:+,}${service}"
        else
          FAILED_UNKNOWN_COUNT=$((FAILED_UNKNOWN_COUNT+1))
          FAILED_UNKNOWN_NAMES+="${FAILED_UNKNOWN_NAMES:+,}${service}"
        fi
        ;;
    esac
  done <<<"$names"
}

build_update_sets() {
  local all="$1" phased="$2" out_dir="$3"
  local kernel="$out_dir/kernel.txt" phased_non_kernel="$out_dir/phased-non-kernel.txt" normal="$out_dir/normal.txt"
  grep -E '^linux-(headers|image|virtual|modules|tools)' "$all" >"$kernel" || true
  awk 'FILENAME==ARGV[1]{k[$0]=1;next} FILENAME==ARGV[2]{a[$0]=1;next} a[$0] && !k[$0]'     "$kernel" "$all" "$phased" >"$phased_non_kernel" || true
  awk 'FILENAME==ARGV[1]{x[$0]=1;next} FILENAME==ARGV[2]{x[$0]=1;next} !x[$0]'     "$kernel" "$phased_non_kernel" "$all" >"$normal" || true
}

severity_to_verdict() {
  local max_severity="${1:-0}"
  if (( max_severity >= 40 )); then printf 'FAIL'; elif (( max_severity >= 15 )); then printf 'WARN'; else printf 'PASS'; fi
}

port_inventory() {
  if ! command -v ss >/dev/null 2>&1; then
    echo "port_inventory_status=unsupported"
    return 0
  fi
  echo "scope|protocol|address|port|process"
  ss -H -lntup 2>/dev/null | awk '
    {
      proto=$1; local_addr=$5; process="unknown";
      if (match($0,/users:\(\(\"[^\"]+\"/)) {
        process=substr($0,RSTART+9,RLENGTH-10)
      }
      address=local_addr; port="unknown";
      if (local_addr ~ /^\[/) {
        sub(/^\[/,"",address); sub(/\]:[0-9]+$/, "", address)
        match(local_addr,/\]:[0-9]+$/); if (RSTART>0) port=substr(local_addr,RSTART+2)
      } else {
        n=split(local_addr,a,":"); port=a[n]; sub(/:[^:]+$/, "", address)
      }
      scope="external";
      if (address=="127.0.0.1" || address ~ /^127\./ || address=="::1" || address ~ /^127\.0\.0\./) scope="local"
      else if (address=="0.0.0.0" || address=="*" || address=="::" || address=="[::]") scope="all_interfaces"
      printf "%s|%s|%s|%s|%s\n",scope,proto,address,port,process
    }'
}

  audit_machine_value_once() {
    local file="$1" key="$2"
    awk -v key="$key" '
      index($0,"=") > 1 {
        current=substr($0,1,index($0,"=")-1)
        if(current==key) {
          count++
          value=substr($0,index($0,"=")+1)
        }
      }
      END {
        if(count != 1) exit 1
        print value
      }
    ' "$file"
  }

  audit_validate_summary_contract() {
    local file="$1" history_required="${2:-0}" key value expected_full_sha
    [[ -s "$file" && ! -L "$file" ]] || return 1
    LC_ALL=C awk '
      NR==1 {
        if($0 !~ /^Server Toolkit v[A-Za-z0-9._-]+$/) invalid=1
        next
      }
      index($0,"=") < 2 { invalid=1; next }
      {
        key=substr($0,1,index($0,"=")-1)
        value=substr($0,index($0,"=")+1)
        if(key !~ /^[a-z][a-z0-9_]*$/ || value ~ /[[:cntrl:]]/ || seen[key]++) invalid=1
        records++
      }
      END { exit (invalid || records == 0) }
    ' "$file" || return 1
    for key in       verdict risk_score main_reason recommended_action       diagnostic_schema_version diagnostic_method_version       diagnostic_coverage_status diagnostic_required_checks diagnostic_completed_checks       access_readiness_schema_version access_readiness_status access_readiness_confidence       ssh_effective_kbd_interactive_authentication ssh_effective_authentication_methods       ssh_effective_context_status       access_readiness_not_checked_status access_readiness_not_checked_families       network_time_readiness_schema_version network_time_readiness_status network_time_readiness_confidence network_time_readiness_coverage_status       network_name_service_resolution_status network_name_service_resolution_requested_count network_name_service_resolution_success_count       network_time_sync_status network_time_external_reachability_status network_time_domain_tls_status       network_time_readiness_not_checked_status network_time_readiness_not_checked_families       findings_schema_version findings_total package_update_evidence_status       apt_simulation_status full_report_sha256; do
      audit_machine_value_once "$file" "$key" >/dev/null || return 1
    done
    value="$(audit_machine_value_once "$file" verdict)" || return 1
    [[ "$value" =~ ^(PASS|WARN|FAIL)$ ]] || return 1
    value="$(audit_machine_value_once "$file" risk_score)" || return 1
    [[ "$value" =~ ^[0-9]+$ ]] || return 1
    value="$(audit_machine_value_once "$file" diagnostic_schema_version)" || return 1
    [[ "$value" == 10 ]] || return 1
    value="$(audit_machine_value_once "$file" diagnostic_method_version)" || return 1
    [[ "$value" == diagnostic-app-service-v2 ]] || return 1
    value="$(audit_machine_value_once "$file" diagnostic_required_checks)" || return 1
    [[ "$value" == 13 ]] || return 1
    value="$(audit_machine_value_once "$file" diagnostic_completed_checks)" || return 1
    [[ "$value" =~ ^[0-9]+$ ]] && (( value <= 13 )) || return 1
    value="$(audit_machine_value_once "$file" diagnostic_coverage_status)" || return 1
    [[ "$value" =~ ^(complete|limited|partial)$ ]] || return 1
    value="$(audit_machine_value_once "$file" access_readiness_schema_version)" || return 1
    [[ "$value" == 1 ]] || return 1
    value="$(audit_machine_value_once "$file" access_readiness_status)" || return 1
    [[ "$value" =~ ^(REVIEW|UNKNOWN)$ ]] || return 1
    value="$(audit_machine_value_once "$file" access_readiness_confidence)" || return 1
    [[ "$value" =~ ^(MEDIUM|LIMITED)$ ]] || return 1
    value="$(audit_machine_value_once "$file" access_readiness_not_checked_status)" || return 1
    [[ "$value" == 'NOT CHECKED' ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_readiness_schema_version)" || return 1
    [[ "$value" == 1 ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_readiness_status)" || return 1
    [[ "$value" =~ ^(READY|REVIEW|UNKNOWN|PENDING_RECHECK)$ ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_readiness_confidence)" || return 1
    [[ "$value" =~ ^(MEDIUM|LIMITED)$ ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_readiness_coverage_status)" || return 1
    [[ "$value" =~ ^(complete|limited)$ ]] || return 1
    value="$(audit_machine_value_once "$file" network_name_service_resolution_status)" || return 1
    [[ "$value" =~ ^(RESOLVED|PARTIAL|NO_SUCCESS|UNKNOWN)$ ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_sync_status)" || return 1
    [[ "$value" =~ ^(SYNCED|UNSYNCED_REVIEW|UNKNOWN|PENDING_RECHECK)$ ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_external_reachability_status)" || return 1
    [[ "$value" == NOT_CHECKED ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_domain_tls_status)" || return 1
    [[ "$value" == NOT_CHECKED ]] || return 1
    value="$(audit_machine_value_once "$file" network_time_readiness_not_checked_status)" || return 1
    [[ "$value" == 'NOT CHECKED' ]] || return 1
    [[ -n "$(audit_machine_value_once "$file" main_reason)" ]] || return 1
    [[ -n "$(audit_machine_value_once "$file" recommended_action)" ]] || return 1
    expected_full_sha="$(sha256sum "$full" | awk '{print $1}')" || return 1
    value="$(audit_machine_value_once "$file" full_report_sha256)" || return 1
    [[ "$value" == "$expected_full_sha" && "$value" =~ ^[0-9a-f]{64}$ ]] || return 1
    if (( history_required == 1 )); then
      for key in historical_comparison_status historical_reports_scanned historical_trusted_candidates historical_untrusted_candidates historical_incompatible_candidates; do
        audit_machine_value_once "$file" "$key" >/dev/null || return 1
      done
    fi
  }

  audit_build_summary_atomic() {
    local phase="$1" target="$2" tmp="${2}.tmp"
    rm -f -- "$tmp" 2>/dev/null || return 1
    make_summary "$phase" "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    audit_validate_summary_contract "$tmp" 0 || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    chmod 600 "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    mv -f -- "$tmp" "$target"
  }

  audit_append_history_atomic() {
    local target="$1" tmp="${1}.tmp"
    rm -f -- "$tmp" 2>/dev/null || return 1
    cp -- "$target" "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    append_historical_comparison "$REPORT_ROOT" "$run_dir" "$tmp" "$host" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    audit_validate_summary_contract "$tmp" 1 || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    chmod 600 "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    mv -f -- "$tmp" "$target"
  }

  audit_write_result_atomic() {
    local target="$result" tmp="${result}.tmp"
    rm -f -- "$tmp" 2>/dev/null || return 1
    result="$tmp"
    write_result || { result="$target"; rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    result="$target"
    [[ -s "$tmp" && ! -L "$tmp" ]] || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    awk '
      /^Результат: / { result++ }
      /^Причина: / { reason++ }
      /^Рекомендуемое действие: / { action++ }
      END { exit !(result==1 && reason==1 && action==1 && NR==3) }
    ' "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    chmod 600 "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    mv -f -- "$tmp" "$target"
  }

  audit_write_readable_atomic() {
    local target="$readable" tmp="${readable}.tmp" heading
    rm -f -- "$tmp" 2>/dev/null || return 1
    readable="$tmp"
    write_readable_summary || { readable="$target"; rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    readable="$target"
    [[ -s "$tmp" && ! -L "$tmp" ]] || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    for heading in РЕЗУЛЬТАТ УВЕРЕННОСТЬ "ПОКРЫТИЕ ПРОВЕРОК" "ДОСТУП И ГОТОВНОСТЬ" "ОГРАНИЧЕНИЯ ГОТОВНОСТИ" ПРИЧИНА "НАХОДКИ ПО ВАЖНОСТИ" "РЕКОМЕНДУЕМОЕ ДЕЙСТВИЕ"; do
      grep -Fq "$heading" "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    done
    chmod 600 "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    mv -f -- "$tmp" "$target"
  }

  audit_write_metadata_atomic() {
    local tmp="${meta}.tmp" summary_sha readable_sha full_sha key
    summary_sha="$(sha256sum "$summary" | awk '{print $1}')" || return 1
    readable_sha="$(sha256sum "$readable" | awk '{print $1}')" || return 1
    full_sha="$(sha256sum "$full" | awk '{print $1}')" || return 1
    rm -f -- "$tmp" 2>/dev/null || return 1
    if ! cat >"$tmp" <<EOT
server=$host
stamp=$stamp
mode=audit
version=$VERSION
audit_policy=read_only
full_report_privacy=local_sensitive
full_report_sharing_policy=manual_review_required
redaction_scope=defense_in_depth_not_a_sharing_guarantee
summary_sha256=$summary_sha
readable_summary_sha256=$readable_sha
full_report_sha256=$full_sha
EOT
    then
      rm -f -- "$tmp" 2>/dev/null || true
      return 1
    fi
    audit_validate_metrics_file "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    for key in server stamp mode version audit_policy full_report_privacy full_report_sharing_policy redaction_scope summary_sha256 readable_summary_sha256 full_report_sha256; do
      audit_machine_value_once "$tmp" "$key" >/dev/null || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    done
    chmod 600 "$tmp" || { rm -f -- "$tmp" 2>/dev/null || true; return 1; }
    mv -f -- "$tmp" "$meta"
  }

main() {
  if (( $# > 1 )); then
    audit_only_print_usage_error
    return 2
  fi
  case "$MODE" in
    audit) ;;
    --help|-h)
      audit_only_print_help
      return 0
      ;;
    --version|-V)
      audit_only_print_version
      return 0
      ;;
    *)
      echo "Эта публичная сборка поддерживает только безопасный режим audit." >&2
      audit_only_print_usage_error
      return 2
      ;;
  esac
  [[ $EUID -eq 0 ]] || { echo "Запуск требуется через sudo." >&2; exit 1; }
  audit_validate_configuration || exit 1
  if [[ "$SERVER_TOOLKIT_PRODUCTION_MODE" == 1 &&
        "$SERVER_TOOLKIT_ENVIRONMENT_CLEAN" != 1 ]]; then
    progress_capture_presentation_input
    audit_reexec_clean_environment
  fi
  audit_prepare_privileged_environment || exit $?
  if ! platform_assert_supported /etc/os-release; then
    exit 3
  fi
  audit_validate_configuration || exit 1

  local host stamp run_dir full summary result readable meta apt_sim trusted_metrics
  host="$(sanitize_label "$(hostname -s 2>/dev/null || hostname)")"
  stamp="$(date -u +%Y%m%dT%H%M%SZ)"
  umask 077
  if ! audit_prepare_report_root "$REPORT_ROOT"; then
    echo "Каталог отчётов должен быть выделенным каталогом владельца запуска с правами 700; symlink, широкий или непустой чужой каталог запрещён." >&2
    exit 1
  fi
  if ! run_dir="$(audit_create_run_dir "$REPORT_ROOT" "$host" "$stamp" "$MODE")"; then
    echo "Не удалось атомарно создать уникальный каталог отчёта." >&2
    exit 1
  fi
  full="$run_dir/full-report.txt"
  summary="$run_dir/technical-summary.txt"
  result="$run_dir/result.txt"
  readable="$run_dir/readable-summary.txt"
  meta="$run_dir/metadata.env"
  apt_sim="$run_dir/apt-full-upgrade-simulation.txt"
  trusted_metrics="$run_dir/.trusted-metrics"
  AUDIT_TRUSTED_METRICS_FILE="$trusted_metrics"
  AUDIT_ARTIFACT_TMP_DIR="$run_dir"
  trap 'audit_cleanup_private_scratch' EXIT
  : >"$trusted_metrics" || { echo "Не удалось создать private metrics scratch." >&2; exit 1; }
  chmod 600 "$trusted_metrics" || { echo "Не удалось защитить private metrics scratch." >&2; exit 1; }
  # report directory initialized atomically and reverified above
  trap 'progress_signal HUP "$run_dir"' HUP
  trap 'progress_signal INT "$run_dir"' INT
  trap 'progress_signal TERM "$run_dir"' TERM
  trap 'progress_exit_cleanup' EXIT
  progress_init "$run_dir" "$host"

  section() {
    local title="$1" tmp rc
    shift
    progress_section_start "$title"
    tmp="$(audit_section_temp_path "$run_dir" "$PROGRESS_COMPLETED_SECTIONS")" || return 1
    AUDIT_ACTIVE_SECTION_TMP="$tmp"
    if ! { echo; echo "===== $title ====="; } >>"$full"; then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      return 1
    fi
    set +e
    progress_run_child "$@" >"$tmp" 2>&1
    rc=$?
    set -e
    if ! redact <"$tmp" >>"$full"; then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      return 1
    fi
    if ! rm -f -- "$tmp" || [[ -e "$tmp" || -L "$tmp" ]]; then
      AUDIT_ACTIVE_SECTION_TMP=""
      return 1
    fi
    AUDIT_ACTIVE_SECTION_TMP=""
    if (( rc == 124 || rc == 137 )); then
      progress_fail "Диагностический этап превысил лимит ${CURRENT_STAGE_TIMEOUT} секунд" "Повторить audit; если остановка повторится, прислать название этапа и локальный отчёт" "$run_dir"
      return 1
    fi
    if (( rc == 125 )); then
      progress_fail "Не удалось запустить безопасный ограничитель времени" "Проверить защищённый каталог отчёта и повторить audit" "$run_dir"
      return 1
    fi
    if (( rc != 0 )); then
      printf 'section_status=unavailable rc=%s\n' "$rc" >>"$full" || return 1
    fi
    progress_section_complete "$title"
    return 0
  }
  audit_capture_redacted_callback() {
    local callback="$1" destination="$2" callback_rc redactor_rc
    local -a callback_status=()
    set +e
    "$callback" 2>&1 | redact >>"$destination"
    callback_status=("${PIPESTATUS[@]}")
    callback_rc="${callback_status[0]}"
    redactor_rc="${callback_status[1]}"
    (( redactor_rc == 0 )) || return 70
    (( callback_rc == 0 )) || return 71
    return 0
  }
  trusted_section() {
    local title="$1" producer="$2" raw_callback="${3:-}" tmp rc
    progress_section_start "$title"
    tmp="$(mktemp "$run_dir/.trusted-section.XXXXXX")" || return 1
    AUDIT_ACTIVE_SECTION_TMP="$tmp"
    if ! { echo; echo "===== $title ====="; } >>"$full"; then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      return 1
    fi
    set +e
    progress_run_child "$producer" >"$tmp" 2>&1
    rc=$?
    set -e
    if ! redact <"$tmp" >>"$full"; then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      return 1
    fi
    if (( rc == 124 || rc == 137 )); then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      progress_fail "Диагностический этап превысил лимит ${CURRENT_STAGE_TIMEOUT} секунд" "Повторить audit; если остановка повторится, прислать название этапа и локальный отчёт" "$run_dir"
      return 1
    fi
    if (( rc == 125 )); then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      progress_fail "Не удалось запустить безопасный ограничитель времени" "Проверить защищённый каталог отчёта и повторить audit" "$run_dir"
      return 1
    fi
    if (( rc != 0 )) || ! audit_validate_metrics_file "$tmp"; then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      progress_fail "Диагностический этап вернул недостоверные структурированные данные" "Повторить audit; если ошибка повторится, прислать название этапа и локальный отчёт" "$run_dir"
      return 1
    fi
    if ! cat "$tmp" >>"$trusted_metrics"; then
      rm -f -- "$tmp" 2>/dev/null || true
      AUDIT_ACTIVE_SECTION_TMP=""
      return 1
    fi
    if ! rm -f -- "$tmp" || [[ -e "$tmp" || -L "$tmp" ]]; then
      AUDIT_ACTIVE_SECTION_TMP=""
      return 1
    fi
    AUDIT_ACTIVE_SECTION_TMP=""
    if [[ -n "$raw_callback" ]]; then
      set +e
      progress_run_child audit_capture_redacted_callback "$raw_callback" "$full"
      rc=$?
      set -e
      if (( rc == 124 || rc == 137 )); then
        progress_fail "Дополнительный диагностический контекст превысил лимит ${CURRENT_STAGE_TIMEOUT} секунд" "Повторить audit; если остановка повторится, прислать название этапа и локальный отчёт" "$run_dir"
        return 1
      fi
      if (( rc == 70 )); then
        progress_fail "Не удалось безопасно записать дополнительный диагностический контекст" "Проверить свободное место и повторить audit" "$run_dir"
        return 1
      fi
      if (( rc == 125 )); then
        progress_fail "Не удалось запустить безопасный ограничитель времени" "Проверить защищённый каталог отчёта и повторить audit" "$run_dir"
        return 1
      fi
      if (( rc == 71 )); then
        printf 'raw_context_status=unavailable\n' >>"$full" || return 1
      elif (( rc != 0 )); then
        return 1
      fi
    fi
    progress_section_complete "$title"
    return 0
  }
  shell_cmd() {
    audit_run_clean_shell "$1"
  }
  package_index_status() {
    if ! command -v apt-get >/dev/null 2>&1; then
      printf 'apt_refresh_status=unsupported\napt_index_status=unsupported\napt_index_age_hours=unknown\npackage_results_confidence=unknown\n'
      return 0
    fi
    echo "apt_refresh_status=not_performed_read_only"
    local newest=0 file mtime now age_seconds age_hours status confidence
    while IFS= read -r -d '' file; do
      mtime="$(stat -c %Y "$file" 2>/dev/null || echo 0)"
      (( mtime > newest )) && newest="$mtime"
    done < <(find /var/lib/apt/lists -maxdepth 1 -type f \
      \( -name '*_InRelease' -o -name '*_Release' \) -print0 2>/dev/null || true)
    if (( newest == 0 )); then
      printf 'apt_index_status=missing\napt_index_age_hours=unknown\napt_index_last_modified=unknown\npackage_results_confidence=unknown\n'
      return 0
    fi
    now="$(date +%s)"; age_seconds=$(( now - newest )); (( age_seconds < 0 )) && age_seconds=0
    age_hours=$(( age_seconds / 3600 ))
    if (( age_hours <= APT_INDEX_FRESH_HOURS )); then status=fresh; confidence=high
    elif (( age_hours <= APT_INDEX_STALE_HOURS )); then status=stale; confidence=limited
    else status=very_stale; confidence=limited
    fi
    printf 'apt_index_status=%s\napt_index_age_hours=%s\napt_index_last_modified=%s\npackage_results_confidence=%s\n' \
      "$status" "$age_hours" "$(date -u -d "@$newest" -Is 2>/dev/null || echo unknown)" "$confidence"
  }
  simulate_upgrade() {
    local rc redact_rc removals
    local -a simulation_status=()
    if ! command -v apt-get >/dev/null 2>&1; then
      : >"$apt_sim" || return 1
      printf 'apt_simulation_status=unsupported\nfull_upgrade_removals=unavailable\n'
      return 0
    fi
    set +e
    apt-get -s full-upgrade 2>&1 | redact >"$apt_sim"
    simulation_status=("${PIPESTATUS[@]}")
    rc="${simulation_status[0]}"
    redact_rc="${simulation_status[1]}"
    set -e
    if (( redact_rc != 0 )); then
      rm -f -- "$apt_sim" 2>/dev/null || return 1
      printf 'apt_simulation_status=failed\nfull_upgrade_removals=unavailable\n'
      return 0
    fi
    if (( rc == 124 || rc == 137 )); then
      printf 'apt_simulation_status=timeout\nfull_upgrade_removals=unavailable\n'
      return "$rc"
    fi
    if (( rc != 0 )); then
      printf 'apt_simulation_status=failed\nfull_upgrade_removals=unavailable\n'
      return 0
    fi
    if removals="$(apt_parse_full_upgrade_removals "$apt_sim")"; then
      printf 'apt_simulation_status=ok\nfull_upgrade_removals=%s\n' "$removals"
    else
      printf 'apt_simulation_status=unparsed\nfull_upgrade_removals=unavailable\n'
    fi
  }
  apt_simulation_raw_context() {
    [[ -f "$apt_sim" ]] && cat "$apt_sim"
  }
  collect_report() {
    local phase="$1"
    {
      echo "Server Toolkit v$VERSION"
      echo "mode=$MODE"
      echo "phase=$phase"
      echo "audit_policy=read_only"
      echo "platform_contract_version=$PLATFORM_CONTRACT_VERSION"
      echo "platform_support_status=$PLATFORM_SUPPORT_STATUS"
      echo "platform_support_reason=$PLATFORM_SUPPORT_REASON"
      echo "platform_validation_status=$PLATFORM_VALIDATION_STATUS"
      echo "platform_supported_families=$PLATFORM_SUPPORTED_FAMILIES"
      echo "platform_validated_list=$PLATFORM_VALIDATED_LIST"
      echo "platform_supported_list=$PLATFORM_SUPPORTED_LIST"
      echo "platform_id=$PLATFORM_ID"
      echo "platform_version_id=$PLATFORM_VERSION_ID"
      echo "utc=$(date -u -Is)"
      echo "hostname=$host"
    } >>"$full" || return 1
    section "$phase SERVER IDENTITY" audit_emit_server_identity "$host" "$PROVIDER_LABEL" "$LOCATION_LABEL" "$ROLE_LABEL" || return 1
    section "$phase IDENTITY RAW" shell_cmd 'hostnamectl 2>/dev/null || true; cat /etc/os-release 2>/dev/null || true; uname -a' || return 1
    section "$phase UPTIME" shell_cmd 'uptime; cat /proc/loadavg' || return 1
    section "$phase CPU" shell_cmd 'lscpu 2>/dev/null || true' || return 1
    trusted_section "$phase CPU SAMPLE" sample_cpu || return 1
    trusted_section "$phase MEMORY" sample_memory_cpu_pressure_metrics pressure_raw_context || return 1
    trusted_section "$phase DISK" sample_storage_metrics storage_raw_inventory || return 1
    trusted_section "$phase NETWORK" sample_server_network_metrics network_raw_context || return 1
    section "$phase PUBLIC IP" shell_cmd 'if command -v curl >/dev/null 2>&1; then curl -q -fsS --max-time 8 https://api.ipify.org 2>/dev/null || true; echo; curl -q -fsS --max-time 8 https://api64.ipify.org 2>/dev/null || true; echo; else echo public_ip_status=unsupported_no_curl; fi' || return 1
    section "$phase DNS" shell_cmd 'cat /etc/resolv.conf' || return 1
    section "$phase LISTENING PORTS RAW" shell_cmd 'ss -lntup 2>/dev/null || true' || return 1
    section "$phase PORT INVENTORY" port_inventory || return 1
    section "$phase FIREWALL" report_firewall_evidence || return 1
    section "$phase FAILED SERVICES" shell_cmd 'systemctl --failed --no-legend --plain 2>/dev/null || true' || return 1
    trusted_section "$phase RESTARTING SERVICES" sample_application_services || return 1
    trusted_section "$phase ACCESS READINESS" sample_access_readiness_metrics || return 1
    section "$phase VIRTUALIZATION" report_virtualization_evidence || return 1
    section "$phase SYSTEM ERRORS" report_system_journal_evidence || return 1
    section "$phase KERNEL WARNINGS" report_kernel_journal_evidence || return 1
    section "$phase INTERNET NOISE" shell_cmd 'printf "ssh_internet_noise_24h="; journalctl -u ssh -u sshd --since "24 hours ago" --no-pager 2>/dev/null | grep -Eic "invalid user|failed password|timeout before authentication|preauth" || true' || return 1
    trusted_section "$phase PACKAGE INDEX" package_index_status || return 1
    section "$phase PACKAGE STATE" shell_cmd 'apt list --upgradable 2>/dev/null || true; apt-mark showhold 2>/dev/null || true; dpkg --audit 2>/dev/null || true; test -f /var/run/reboot-required && cat /var/run/reboot-required || echo reboot_not_required' || return 1
    trusted_section "$phase UPGRADE SIMULATION" simulate_upgrade apt_simulation_raw_context || return 1
    trusted_section "$phase NETWORK TIME READINESS" sample_network_time_readiness_metrics || return 1
    section "$phase LATENCY" shell_cmd 'for h in 1.1.1.1 8.8.8.8 github.com; do ping -c 3 -W 2 "$h" 2>/dev/null || true; done' || return 1
    section "$phase DOWNLOAD" shell_cmd 'if command -v curl >/dev/null 2>&1; then curl -q -fsSL --max-time 25 -o /dev/null -w "status=%{http_code} time=%{time_total}s speed=%{speed_download}B/s\n" https://github.com/ 2>/dev/null || true; else echo download_status=unsupported_no_curl; fi' || return 1
  }
  last_metric() {
    awk -v key="$1" '
      index($0,key "=")==1 { value=substr($0,length(key)+2) }
      END { print value }
    ' "$trusted_metrics"
  }
  classify_updates() {
    local apt_index_status held_output broken_output all="$run_dir/upgradable.txt" phased="$run_dir/phased.txt"
    apt_index_status="$(last_metric apt_index_status)"; apt_index_status="${apt_index_status:-unknown}"
    updates_total=0; kernel_updates=0; phased_updates=0; normal_updates=0
    held_packages=unavailable; broken_package_state=unavailable; full_upgrade_removals=unavailable; package_manager=apt
    printf -v PACKAGE_UPDATE_EVIDENCE_STATUS '%s' unavailable
    if ! command -v apt-get >/dev/null 2>&1; then package_manager=unsupported; return 0; fi
    case "$apt_index_status" in
      fresh|stale|very_stale)
        if apt list --upgradable 2>/dev/null | tail -n +2 | sed '/^$/d' | cut -d/ -f1 | sort -u >"$all"; then
          printf -v PACKAGE_UPDATE_EVIDENCE_STATUS '%s' available
        else
          : >"$all"
        fi
        ;;
      *)
        : >"$all"
        ;;
    esac
    : >"$phased"
    if [[ -s "$apt_sim" ]]; then
      awk '/deferred due to phasing:/{f=1;next} f && /^The following/{exit} f {for(i=1;i<=NF;i++) if($i !~ /^$/) print $i}' "$apt_sim" | sort -u >"$phased" || true
    fi
    build_update_sets "$all" "$phased" "$run_dir"
    updates_total="$(wc -l <"$all" | tr -d ' ')"
    kernel_updates="$(wc -l <"$run_dir/kernel.txt" | tr -d ' ')"
    phased_updates="$(wc -l <"$run_dir/phased-non-kernel.txt" | tr -d ' ')"
    normal_updates="$(wc -l <"$run_dir/normal.txt" | tr -d ' ')"
    if command -v apt-mark >/dev/null 2>&1 && held_output="$(apt-mark showhold 2>/dev/null)"; then
      held_packages="$(printf '%s\n' "$held_output" | sed '/^[[:space:]]*$/d' | wc -l | tr -d ' ')"
      [[ "$held_packages" =~ ^[0-9]+$ ]] || held_packages=unavailable
    fi
    if command -v dpkg >/dev/null 2>&1 && broken_output="$(dpkg --audit 2>/dev/null)"; then
      if [[ "$broken_output" =~ [^[:space:]] ]]; then broken_package_state=1; else broken_package_state=0; fi
    fi
    full_upgrade_removals="$(last_metric full_upgrade_removals)"
    [[ "$full_upgrade_removals" =~ ^[0-9]+$ ]] || full_upgrade_removals=unavailable
  }
  network_status() {
    command -v getent >/dev/null 2>&1 || return 2
    command -v curl >/dev/null 2>&1 || return 2
    local host ok=0
    for host in archive.ubuntu.com github.com; do
      getent ahosts "$host" >/dev/null 2>&1 || continue
      if curl -q -4 -fsS --connect-timeout 5 --max-time 10           -o /dev/null "https://$host/" >/dev/null 2>&1 ||         curl -q -6 -fsS --connect-timeout 5 --max-time 10           -o /dev/null "https://$host/" >/dev/null 2>&1; then
        ok=1
      fi
    done
    ((ok==1))
  }
  write_result() {
    local verdict reason action label
    verdict="$(awk -F= '$1=="verdict"{count++; value=$2} END{if(count!=1) exit 1; print value}' "$summary")" || return 1
    reason="$(awk -F= '$1=="main_reason"{count++; value=substr($0,index($0,"=")+1)} END{if(count!=1) exit 1; print value}' "$summary")" || return 1
    action="$(awk -F= '$1=="recommended_action"{count++; value=substr($0,index($0,"=")+1)} END{if(count!=1) exit 1; print value}' "$summary")" || return 1
    [[ -n "$reason" && -n "$action" ]] || return 1
    case "$verdict" in
      PASS) label="система исправна" ;;
      WARN) label="есть замечания" ;;
      FAIL) label="обнаружена проблема" ;;
      *) return 1 ;;
    esac
    printf 'Результат: %s\nПричина: %s\nРекомендуемое действие: %s\n' "$label" "$reason" "$action" >"$result"
  }

  write_readable_summary() {
    local label reason action confidence coverage_status coverage_completed coverage_required coverage_missing coverage_limited coverage_text
    local count duration
    local iowait_min iowait_median iowait_average iowait_max iowait_exceedances
    local steal_min steal_median steal_average steal_max steal_exceedances
    local root_source root_filesystem root_used_pct root_inode_used_pct root_read_only storage_device storage_operations
    local storage_activity_windows storage_latency_windows storage_latency_status storage_await_min storage_await_median
    local storage_await_average storage_await_max storage_await_exceedances storage_read_await_max storage_write_await_max storage_util_max storage_queue_max
    local pressure_count pressure_duration mem_available_min mem_available_median mem_available_average mem_available_max mem_available_exceedances
    local swap_used_max swap_in_max swap_out_max major_fault_max memory_psi_some_max memory_psi_full_max cpu_psi_some_max run_queue_max
    local network_interface network_count network_activity network_resets network_retrans_ratio network_retrans_exceedances
    local network_timeouts network_timeout_exceedances network_syn network_listen_drops network_listen_overflows network_aborts network_errors network_drops
    local application_status application_journal_status application_window application_records application_truncated application_sqlite application_timeouts
    local service_units service_restarted service_restart_total service_restart_max service_failures service_restart_events role_events history_text findings_text platform_notice
    local access_status access_confidence ssh_access firewall_readiness package_readiness ssh_root ssh_password ssh_pubkey ssh_ports ssh_config_bind ssh_listener_bind
    local ufw_status nft_status nft_policy iptables_status iptables_policy ip6tables_status ip6tables_policy firewall_sources access_correlation access_correlation_text access_limitations access_not_checked access_not_checked_text
    local network_time_status network_time_confidence network_time_coverage network_time_ipv4_status network_time_ipv4_interface network_time_ipv6_status network_time_ipv6_interface
    local network_time_primary_interface network_time_mtu network_time_mtu_status network_time_mtu_profile network_time_resolver network_time_name_service network_time_name_service_requested network_time_name_service_success
    local network_time_sync network_time_native_sync network_time_ntp network_time_can_ntp network_time_timezone network_time_uptime network_time_external network_time_domain_tls network_time_limitations network_time_not_checked network_time_not_checked_text
    local PROGRESS_COLOR=0
    label="$(sed -n 's/^Результат: //p' "$result")"
    reason="$(sed -n 's/^Причина: //p' "$result")"
    action="$(sed -n 's/^Рекомендуемое действие: //p' "$result")"
    confidence="$(awk -F= '$1=="diagnostic_confidence"{print $2}' "$summary")"
    coverage_status="$(awk -F= '$1=="diagnostic_coverage_status"{print $2}' "$summary")"
    coverage_completed="$(awk -F= '$1=="diagnostic_completed_checks"{print $2}' "$summary")"
    coverage_required="$(awk -F= '$1=="diagnostic_required_checks"{print $2}' "$summary")"
    coverage_missing="$(awk -F= '$1=="diagnostic_missing_checks"{print $2}' "$summary")"
    coverage_limited="$(awk -F= '$1=="diagnostic_limited_checks"{print $2}' "$summary")"
    count="$(awk -F= '$1=="cpu_sample_count"{print $2}' "$summary")"
    duration="$(awk -F= '$1=="cpu_sample_duration_seconds"{print $2}' "$summary")"
    iowait_min="$(awk -F= '$1=="iowait_min_pct"{print $2}' "$summary")"
    iowait_median="$(awk -F= '$1=="iowait_median_pct"{print $2}' "$summary")"
    iowait_average="$(awk -F= '$1=="iowait_average_pct"{print $2}' "$summary")"
    iowait_max="$(awk -F= '$1=="iowait_max_pct"{print $2}' "$summary")"
    iowait_exceedances="$(awk -F= '$1=="iowait_threshold_exceedance_count"{print $2}' "$summary")"
    steal_min="$(awk -F= '$1=="steal_min_pct"{print $2}' "$summary")"
    steal_median="$(awk -F= '$1=="steal_median_pct"{print $2}' "$summary")"
    steal_average="$(awk -F= '$1=="steal_average_pct"{print $2}' "$summary")"
    steal_max="$(awk -F= '$1=="steal_max_pct"{print $2}' "$summary")"
    steal_exceedances="$(awk -F= '$1=="steal_threshold_exceedance_count"{print $2}' "$summary")"
    root_source="$(awk -F= '$1=="root_source"{print $2}' "$summary")"
    root_filesystem="$(awk -F= '$1=="root_filesystem"{print $2}' "$summary")"
    root_used_pct="$(awk -F= '$1=="root_used_pct"{print $2}' "$summary")"
    root_inode_used_pct="$(awk -F= '$1=="root_inode_used_pct"{print $2}' "$summary")"
    root_read_only="$(awk -F= '$1=="root_mount_read_only"{print $2}' "$summary")"
    storage_device="$(awk -F= '$1=="storage_device"{print $2}' "$summary")"
    storage_operations="$(awk -F= '$1=="storage_device_operations"{print $2}' "$summary")"
    storage_activity_windows="$(awk -F= '$1=="storage_device_activity_windows"{print $2}' "$summary")"
    storage_latency_windows="$(awk -F= '$1=="storage_device_latency_windows"{print $2}' "$summary")"
    storage_latency_status="$(awk -F= '$1=="storage_latency_evidence_status"{print $2}' "$summary")"
    storage_await_min="$(awk -F= '$1=="storage_await_ms_min"{print $2}' "$summary")"
    storage_await_median="$(awk -F= '$1=="storage_await_ms_median"{print $2}' "$summary")"
    storage_await_average="$(awk -F= '$1=="storage_await_ms_average"{print $2}' "$summary")"
    storage_await_max="$(awk -F= '$1=="storage_await_ms_max"{print $2}' "$summary")"
    storage_await_exceedances="$(awk -F= '$1=="storage_await_ms_threshold_exceedance_count"{print $2}' "$summary")"
    storage_read_await_max="$(awk -F= '$1=="storage_read_await_ms_max"{print $2}' "$summary")"
    storage_write_await_max="$(awk -F= '$1=="storage_write_await_ms_max"{print $2}' "$summary")"
    storage_util_max="$(awk -F= '$1=="storage_util_pct_max"{print $2}' "$summary")"
    storage_queue_max="$(awk -F= '$1=="storage_queue_depth_max"{print $2}' "$summary")"
    pressure_count="$(awk -F= '$1=="pressure_sample_count_requested"{print $2}' "$summary")"
    pressure_duration="$(awk -F= '$1=="pressure_sample_duration_seconds"{print $2}' "$summary")"
    mem_available_min="$(awk -F= '$1=="mem_available_pct_min"{print $2}' "$summary")"
    mem_available_median="$(awk -F= '$1=="mem_available_pct_median"{print $2}' "$summary")"
    mem_available_average="$(awk -F= '$1=="mem_available_pct_average"{print $2}' "$summary")"
    mem_available_max="$(awk -F= '$1=="mem_available_pct_max"{print $2}' "$summary")"
    mem_available_exceedances="$(awk -F= '$1=="mem_available_pct_threshold_exceedance_count"{print $2}' "$summary")"
    swap_used_max="$(awk -F= '$1=="swap_used_pct_max"{print $2}' "$summary")"
    swap_in_max="$(awk -F= '$1=="swap_in_pages_per_second_max"{print $2}' "$summary")"
    swap_out_max="$(awk -F= '$1=="swap_out_pages_per_second_max"{print $2}' "$summary")"
    major_fault_max="$(awk -F= '$1=="major_faults_per_second_max"{print $2}' "$summary")"
    memory_psi_some_max="$(awk -F= '$1=="memory_psi_some_avg10_pct_max"{print $2}' "$summary")"
    memory_psi_full_max="$(awk -F= '$1=="memory_psi_full_avg10_pct_max"{print $2}' "$summary")"
    cpu_psi_some_max="$(awk -F= '$1=="cpu_psi_some_avg10_pct_max"{print $2}' "$summary")"
    run_queue_max="$(awk -F= '$1=="run_queue_per_vcpu_max"{print $2}' "$summary")"
    network_interface="$(awk -F= '$1=="network_primary_interface"{print $2}' "$summary")"
    network_count="$(awk -F= '$1=="network_counter_sample_count"{print $2}' "$summary")"
    network_activity="$(awk -F= '$1=="network_counter_activity_windows"{print $2}' "$summary")"
    network_resets="$(awk -F= '$1=="network_counter_reset_windows"{print $2}' "$summary")"
    network_retrans_ratio="$(awk -F= '$1=="network_tcp_retrans_ratio_pct_max"{print $2}' "$summary")"
    network_retrans_exceedances="$(awk -F= '$1=="network_tcp_retrans_ratio_pct_threshold_exceedance_count"{print $2}' "$summary")"
    network_timeouts="$(awk -F= '$1=="network_tcp_timeout_events_per_second_max"{print $2}' "$summary")"
    network_timeout_exceedances="$(awk -F= '$1=="network_tcp_timeout_events_per_second_threshold_exceedance_count"{print $2}' "$summary")"
    network_syn="$(awk -F= '$1=="network_tcp_syn_retrans_events_per_second_max"{print $2}' "$summary")"
    network_listen_drops="$(awk -F= '$1=="network_listen_drop_events_per_second_max"{print $2}' "$summary")"
    network_listen_overflows="$(awk -F= '$1=="network_listen_overflow_events_per_second_max"{print $2}' "$summary")"
    network_aborts="$(awk -F= '$1=="network_tcp_abort_timeout_events_per_second_max"{print $2}' "$summary")"
    network_errors="$(awk -F= '$1=="network_interface_error_events_per_second_max"{print $2}' "$summary")"
    network_drops="$(awk -F= '$1=="network_interface_drop_events_per_second_max"{print $2}' "$summary")"
    application_status="$(awk -F= '$1=="application_service_sample_status"{print $2}' "$summary")"
    application_journal_status="$(awk -F= '$1=="application_journal_status"{print $2}' "$summary")"
    application_window="$(awk -F= '$1=="application_journal_window"{print $2}' "$summary")"
    application_records="$(awk -F= '$1=="application_journal_records_scanned"{print $2}' "$summary")"
    application_truncated="$(awk -F= '$1=="application_journal_truncated"{print $2}' "$summary")"
    application_sqlite="$(awk -F= '$1=="application_sqlite_lock_events_24h"{print $2}' "$summary")"
    application_timeouts="$(awk -F= '$1=="application_timeout_events_24h"{print $2}' "$summary")"
    service_units="$(awk -F= '$1=="service_units_observed"{print $2}' "$summary")"
    service_restarted="$(awk -F= '$1=="service_units_with_restarts"{print $2}' "$summary")"
    service_restart_total="$(awk -F= '$1=="service_restart_count_total"{print $2}' "$summary")"
    service_restart_max="$(awk -F= '$1=="service_restart_count_max"{print $2}' "$summary")"
    service_failures="$(awk -F= '$1=="service_failure_events_24h"{print $2}' "$summary")"
    service_restart_events="$(awk -F= '$1=="service_restart_events_24h"{print $2}' "$summary")"
    role_events="$(awk -F= '$1=="application_role_relevant_events_24h"{print $2}' "$summary")"
    access_status="$(awk -F= '$1=="access_readiness_status"{print $2}' "$summary")"; access_status="${access_status:-UNKNOWN}"
    access_confidence="$(awk -F= '$1=="access_readiness_confidence"{print $2}' "$summary")"; access_confidence="${access_confidence:-LIMITED}"
    ssh_access="$(awk -F= '$1=="ssh_access_status"{print $2}' "$summary")"; ssh_access="${ssh_access:-UNKNOWN}"
    firewall_readiness="$(awk -F= '$1=="firewall_readiness_status"{print $2}' "$summary")"; firewall_readiness="${firewall_readiness:-UNKNOWN}"
    package_readiness="$(awk -F= '$1=="package_readiness_status"{print $2}' "$summary")"; package_readiness="${package_readiness:-UNKNOWN}"
    ssh_root="$(awk -F= '$1=="ssh_effective_permit_root_login"{print $2}' "$summary")"; ssh_root="${ssh_root:-unavailable}"
    ssh_password="$(awk -F= '$1=="ssh_effective_password_authentication"{print $2}' "$summary")"; ssh_password="${ssh_password:-unavailable}"
    ssh_keyboard="$(awk -F= '$1=="ssh_effective_kbd_interactive_authentication"{print $2}' "$summary")"; ssh_keyboard="${ssh_keyboard:-unavailable}"
    ssh_pubkey="$(awk -F= '$1=="ssh_effective_pubkey_authentication"{print $2}' "$summary")"; ssh_pubkey="${ssh_pubkey:-unavailable}"
    ssh_authentication_methods="$(awk -F= '$1=="ssh_effective_authentication_methods"{print $2}' "$summary")"; ssh_authentication_methods="${ssh_authentication_methods:-unavailable}"
    ssh_context="$(awk -F= '$1=="ssh_effective_context_status"{print $2}' "$summary")"; ssh_context="${ssh_context:-unavailable}"
    ssh_ports="$(awk -F= '$1=="ssh_effective_port_set"{print $2}' "$summary")"; ssh_ports="${ssh_ports:-unavailable}"
    ssh_config_bind="$(awk -F= '$1=="ssh_effective_listen_address_scope"{print $2}' "$summary")"; ssh_config_bind="${ssh_config_bind:-unavailable}"
    ssh_listener_bind="$(awk -F= '$1=="ssh_listener_scope"{print $2}' "$summary")"; ssh_listener_bind="${ssh_listener_bind:-unavailable}"
    ufw_status="$(awk -F= '$1=="firewall_ufw_status"{print $2}' "$summary")"; ufw_status="${ufw_status:-unavailable}"
    nft_status="$(awk -F= '$1=="firewall_nft_status"{print $2}' "$summary")"; nft_status="${nft_status:-unavailable}"
    nft_policy="$(awk -F= '$1=="firewall_nft_input_policy"{print $2}' "$summary")"; nft_policy="${nft_policy:-unavailable}"
    iptables_status="$(awk -F= '$1=="firewall_iptables_status"{print $2}' "$summary")"; iptables_status="${iptables_status:-unavailable}"
    iptables_policy="$(awk -F= '$1=="firewall_iptables_input_policy"{print $2}' "$summary")"; iptables_policy="${iptables_policy:-unavailable}"
    ip6tables_status="$(awk -F= '$1=="firewall_ip6tables_status"{print $2}' "$summary")"; ip6tables_status="${ip6tables_status:-unavailable}"
    ip6tables_policy="$(awk -F= '$1=="firewall_ip6tables_input_policy"{print $2}' "$summary")"; ip6tables_policy="${ip6tables_policy:-unavailable}"
    firewall_sources="$(awk -F= '$1=="local_firewall_enforcement_sources"{print $2}' "$summary")"; firewall_sources="${firewall_sources:-none}"
    access_correlation="$(awk -F= '$1=="access_readiness_correlation"{print $2}' "$summary")"; access_correlation="${access_correlation:-evidence_incomplete_no_healthy_inference}"
    access_limitations="$(awk -F= '$1=="access_readiness_limitations"{print $2}' "$summary")"; access_limitations="${access_limitations:-local_read_only_evidence_only}"
    access_not_checked="$(awk -F= '$1=="access_readiness_not_checked_families"{print $2}' "$summary")"; access_not_checked="${access_not_checked:-users,persistence,image_provenance,containers,integrity,backup_restore}"
    access_not_checked_text="${access_not_checked//,/, }"
    network_time_status="$(awk -F= '$1=="network_time_readiness_status"{print $2}' "$summary")"; network_time_status="${network_time_status:-UNKNOWN}"
    network_time_confidence="$(awk -F= '$1=="network_time_readiness_confidence"{print $2}' "$summary")"; network_time_confidence="${network_time_confidence:-LIMITED}"
    network_time_coverage="$(awk -F= '$1=="network_time_readiness_coverage_status"{print $2}' "$summary")"; network_time_coverage="${network_time_coverage:-limited}"
    network_time_ipv4_status="$(awk -F= '$1=="network_ipv4_default_route_status"{print $2}' "$summary")"; network_time_ipv4_status="${network_time_ipv4_status:-UNKNOWN}"
    network_time_ipv4_interface="$(awk -F= '$1=="network_ipv4_default_interface"{print $2}' "$summary")"; network_time_ipv4_interface="${network_time_ipv4_interface:-unavailable}"
    network_time_ipv6_status="$(awk -F= '$1=="network_ipv6_default_route_status"{print $2}' "$summary")"; network_time_ipv6_status="${network_time_ipv6_status:-UNKNOWN}"
    network_time_ipv6_interface="$(awk -F= '$1=="network_ipv6_default_interface"{print $2}' "$summary")"; network_time_ipv6_interface="${network_time_ipv6_interface:-unavailable}"
    network_time_primary_interface="$(awk -F= '$1=="network_readiness_primary_interface"{print $2}' "$summary")"; network_time_primary_interface="${network_time_primary_interface:-unavailable}"
    network_time_mtu="$(awk -F= '$1=="network_primary_interface_mtu"{print $2}' "$summary")"; network_time_mtu="${network_time_mtu:-unavailable}"
    network_time_mtu_status="$(awk -F= '$1=="network_mtu_status"{print $2}' "$summary")"; network_time_mtu_status="${network_time_mtu_status:-UNKNOWN}"
    network_time_mtu_profile="$(awk -F= '$1=="network_mtu_profile"{print $2}' "$summary")"; network_time_mtu_profile="${network_time_mtu_profile:-UNKNOWN}"
    network_time_resolver="$(awk -F= '$1=="network_resolver_configuration_status"{print $2}' "$summary")"; network_time_resolver="${network_time_resolver:-UNKNOWN}"
    network_time_name_service="$(awk -F= '$1=="network_name_service_resolution_status"{print $2}' "$summary")"; network_time_name_service="${network_time_name_service:-UNKNOWN}"
    network_time_name_service_requested="$(awk -F= '$1=="network_name_service_resolution_requested_count"{print $2}' "$summary")"; network_time_name_service_requested="${network_time_name_service_requested:-unavailable}"
    network_time_name_service_success="$(awk -F= '$1=="network_name_service_resolution_success_count"{print $2}' "$summary")"; network_time_name_service_success="${network_time_name_service_success:-unavailable}"
    network_time_sync="$(awk -F= '$1=="network_time_sync_status"{print $2}' "$summary")"; network_time_sync="${network_time_sync:-UNKNOWN}"
    network_time_native_sync="$(awk -F= '$1=="network_time_ntp_synchronized"{print $2}' "$summary")"; network_time_native_sync="${network_time_native_sync:-unavailable}"
    network_time_ntp="$(awk -F= '$1=="network_time_ntp_enabled"{print $2}' "$summary")"; network_time_ntp="${network_time_ntp:-unavailable}"
    network_time_can_ntp="$(awk -F= '$1=="network_time_can_ntp"{print $2}' "$summary")"; network_time_can_ntp="${network_time_can_ntp:-unavailable}"
    network_time_timezone="$(awk -F= '$1=="network_time_timezone"{print $2}' "$summary")"; network_time_timezone="${network_time_timezone:-unavailable}"
    network_time_uptime="$(awk -F= '$1=="network_time_uptime_seconds"{print $2}' "$summary")"; network_time_uptime="${network_time_uptime:-unavailable}"
    network_time_external="$(awk -F= '$1=="network_time_external_reachability_status"{print $2}' "$summary")"; network_time_external="${network_time_external:-NOT_CHECKED}"
    network_time_domain_tls="$(awk -F= '$1=="network_time_domain_tls_status"{print $2}' "$summary")"; network_time_domain_tls="${network_time_domain_tls:-NOT_CHECKED}"
    network_time_limitations="$(awk -F= '$1=="network_time_readiness_limitations"{print $2}' "$summary")"; network_time_limitations="${network_time_limitations:-local_read_only_evidence_only}"
    network_time_not_checked="$(awk -F= '$1=="network_time_readiness_not_checked_families"{print $2}' "$summary")"; network_time_not_checked="${network_time_not_checked:-external_reachability,path_mtu,remote_clock_reference,domain_tls}"
    network_time_not_checked_text="${network_time_not_checked//,/, }"
    case "$access_correlation" in
      root_and_password_capable_auth_with_non_loopback_or_wildcard_ssh_bind_requires_review)
        access_correlation_text="Root и password-capable authentication сопоставлены с SSH bind вне loopback; нужна проверка владельца"
        ;;
      default_context_is_key_oriented_but_match_contexts_are_not_exhaustively_evaluated)
        access_correlation_text="Default SSH context key-oriented, но все Match contexts не проверены"
        ;;
      sampled_ssh_context_differs_from_default_and_other_match_contexts_remain_unchecked)
        access_correlation_text="Проверенный SSH context отличается от default; остальные Match contexts не проверены"
        ;;
      local_firewall_status_or_backend_policy_requires_review)
        access_correlation_text="Локальный firewall status или политика backend требуют проверки"
        ;;
      effective_ssh_configuration_or_local_bind_requires_owner_review)
        access_correlation_text="Effective SSH или локальный bind требуют проверки владельца"
        ;;
      *) access_correlation_text="Доказательств недостаточно для здорового вывода" ;;
    esac
    history_text="$(history_format_summary "$summary")"
    findings_text="$(ranked_findings_readable_text "$summary" "$FINDINGS_READABLE_LIMIT")"
    platform_notice="$(platform_release_notice_text "$summary")"
    case "$coverage_status" in
      complete) coverage_text="complete: ${coverage_completed}/${coverage_required}." ;;
      limited) coverage_text="limited: ${coverage_completed}/${coverage_required}. Ограничено: ${coverage_limited}." ;;
      *) coverage_text="partial: ${coverage_completed}/${coverage_required}. Недоступно: ${coverage_missing}." ;;
    esac
    {
      printf 'Server Toolkit\n'
      progress_print_block "РЕЗУЛЬТАТ" "$label"
      progress_print_block "УВЕРЕННОСТЬ" "${confidence:-LIMITED}"
      progress_print_block "ПОКРЫТИЕ ПРОВЕРОК" "$coverage_text"
      progress_print_block "ДОСТУП И ГОТОВНОСТЬ" "Статус ${access_status}; уверенность ${access_confidence}. SSH: ${ssh_access}; effective root ${ssh_root}, password ${ssh_password}, keyboard-interactive ${ssh_keyboard}, pubkey ${ssh_pubkey}, AuthenticationMethods ${ssh_authentication_methods}, context ${ssh_context}, port ${ssh_ports}, configured bind ${ssh_config_bind}, local listener bind ${ssh_listener_bind}. Local firewall: ${firewall_readiness}; UFW ${ufw_status}, nft ${nft_status}/${nft_policy}, iptables IPv4 ${iptables_status}/${iptables_policy}, IPv6 ${ip6tables_status}/${ip6tables_policy}; enforcement sources ${firewall_sources}. Packages: ${package_readiness}. Корреляция: ${access_correlation_text}. Внешняя достижимость не проверялась."
      progress_print_block "ОГРАНИЧЕНИЯ ГОТОВНОСТИ" "NOT CHECKED: ${access_not_checked_text}. ${access_limitations}. Эти семейства не считаются здоровыми или пройденными."
      progress_print_block "СЕТЬ И ВРЕМЯ" "Статус ${network_time_status}; уверенность ${network_time_confidence}; coverage ${network_time_coverage}. Default route IPv4 ${network_time_ipv4_status} (${network_time_ipv4_interface}), IPv6 ${network_time_ipv6_status} (${network_time_ipv6_interface}); primary ${network_time_primary_interface}, MTU ${network_time_mtu} (${network_time_mtu_status}/${network_time_mtu_profile}). Resolver ${network_time_resolver}; name service/NSS ${network_time_name_service} (${network_time_name_service_success}/${network_time_name_service_requested}). Time ${network_time_sync}; native synchronized ${network_time_native_sync}, NTP ${network_time_ntp}, CanNTP ${network_time_can_ntp}, timezone ${network_time_timezone}, uptime ${network_time_uptime}s. External reachability ${network_time_external}; domain/TLS ${network_time_domain_tls}. NOT CHECKED: ${network_time_not_checked_text}. Ограничения: ${network_time_limitations}."
      progress_print_block "ПРИЧИНА" "$reason"
      progress_print_block "ИЗМЕРЕНИЯ CPU / I/O" "I/O wait: min ${iowait_min}%, median ${iowait_median}%, avg ${iowait_average}%, max ${iowait_max}%, превышений ${iowait_exceedances}/${count}. CPU steal: min ${steal_min}%, median ${steal_median}%, avg ${steal_average}%, max ${steal_max}%, превышений ${steal_exceedances}/${count}. Метод: ${count} интервалов за ${duration} секунд."
      progress_print_block "ПАМЯТЬ И CPU PRESSURE" "Доступная память: min ${mem_available_min}%, median ${mem_available_median}%, avg ${mem_available_average}%, max ${mem_available_max}%, низких окон ${mem_available_exceedances}/${pressure_count}. Swap занято max ${swap_used_max}%; swap in/out max ${swap_in_max}/${swap_out_max} страниц/с; major faults max ${major_fault_max}/с. PSI memory some/full max ${memory_psi_some_max}%/${memory_psi_full_max}%; PSI CPU some max ${cpu_psi_some_max}%; run queue max ${run_queue_max} на vCPU. Метод: ${pressure_count} интервалов за ${pressure_duration} секунд."
      progress_print_block "СЕТЕВЫЕ СЧЁТЧИКИ" "Интерфейс ${network_interface}; ${network_count} окон, активных ${network_activity}, reset/discard ${network_resets}. TCP retrans max ${network_retrans_ratio}%, превышений ${network_retrans_exceedances}; timeouts max ${network_timeouts}/с, окон ${network_timeout_exceedances}; SYN retrans max ${network_syn}/с; listen drops/overflows max ${network_listen_drops}/${network_listen_overflows}/с; abort timeout max ${network_aborts}/с; interface errors/drops max ${network_errors}/${network_drops}/с."
      progress_print_block "ПРИЛОЖЕНИЯ И СЛУЖБЫ" "Статус ${application_status}; окно ${application_window}; журнал ${application_journal_status}, записей ${application_records}, ограничен: ${application_truncated}. SQLite locks ${application_sqlite}; application timeouts ${application_timeouts}; события failure/restart ${service_failures}/${service_restart_events}. Systemd: служб ${service_units}, с restart counter ${service_restarted}, рестартов всего/max ${service_restart_total}/${service_restart_max}. События служб роли: ${role_events}."
      progress_print_block "ХРАНИЛИЩЕ" "Корень: ${root_source}, ${root_filesystem}, занято ${root_used_pct}%, inode ${root_inode_used_pct}%, read-only: ${root_read_only}. Устройство: ${storage_device}; операций ${storage_operations}; активных окон ${storage_activity_windows}; latency-окон ${storage_latency_windows}; статус latency: ${storage_latency_status}. Await ms: min ${storage_await_min}, median ${storage_await_median}, avg ${storage_await_average}, max ${storage_await_max}, read max ${storage_read_await_max}, write max ${storage_write_await_max}, превышений ${storage_await_exceedances}. Util max ${storage_util_max}%; queue max ${storage_queue_max}."
      progress_print_block "СРАВНЕНИЕ С ПРЕДЫДУЩИМ АУДИТОМ" "$history_text"
      [[ -z "$platform_notice" ]] || progress_print_block "ПЛАТФОРМА" "$platform_notice"
      progress_print_block "НАХОДКИ ПО ВАЖНОСТИ" "$findings_text"
      progress_print_block "РЕКОМЕНДУЕМОЕ ДЕЙСТВИЕ" "$action"
      progress_print_block "ТЕХНИЧЕСКАЯ СВОДКА" "technical-summary.txt"
    } >"$readable"
  }

  if ! : >"$full"; then
    progress_fail "Не удалось создать полный отчёт" "Проверить свободное место и права на каталог отчёта" "$run_dir"
    exit 1
  fi
  if ! collect_report pre; then
    progress_fail "Не удалось безопасно завершить сбор диагностических данных" "Повторить audit; если ошибка повторится, прислать последний этап и локальный отчёт" "$run_dir"
    exit 1
  fi
  if ! audit_validate_metrics_file "$trusted_metrics"; then
    progress_fail "Собранные структурированные данные не прошли итоговую проверку целостности" "Повторить audit; если ошибка повторится, сохранить локальный отчёт для анализа" "$run_dir"
    exit 1
  fi
  progress_set_absolute 90 "Анализ результатов" 12
  CURRENT_STAGE_TIMEOUT=120
  if ! progress_run_child audit_build_summary_atomic pre "$summary"; then
    progress_fail "Не удалось сформировать техническое заключение" "Проверить локальный полный отчёт и повторить audit" "$run_dir"
    exit 1
  fi
  CURRENT_STAGE_TIMEOUT=60
  if ! progress_run_child audit_append_history_atomic "$summary"; then
    progress_fail "Не удалось безопасно подготовить историческое сравнение" "Проверить права на каталог отчётов и повторить audit" "$run_dir"
    exit 1
  fi
  progress_set_absolute 95 "Подготовка результата" 8
  CURRENT_STAGE_TIMEOUT=45
  if ! progress_run_child audit_write_result_atomic; then
    progress_fail "Не удалось подготовить пользовательский результат" "Проверить свободное место и права на каталог отчёта" "$run_dir"
    exit 1
  fi
  if ! progress_run_child audit_write_readable_atomic; then
    progress_fail "Не удалось подготовить читаемую сводку" "Проверить свободное место и права на каталог отчёта" "$run_dir"
    exit 1
  fi
  progress_set_absolute 98 "Финализация отчёта" 8
  if ! progress_run_child audit_write_metadata_atomic; then
    progress_fail "Не удалось записать метаданные отчёта" "Проверить свободное место и права на каталог отчёта" "$run_dir"
    exit 1
  fi
  if ! chmod 600 "$full" "$summary" "$result" "$readable" "$meta"; then
    progress_fail "Не удалось установить безопасные права на отчёт" "Проверить права на каталог отчёта" "$run_dir"
    exit 1
  fi
  progress_complete
  audit_cleanup_private_scratch
  trap - HUP INT TERM EXIT
  local display_verdict display_label display_reason display_action display_colour display_confidence
  local display_elapsed
  local display_coverage_status display_coverage_completed display_coverage_required display_coverage_missing display_coverage_limited display_coverage_text
  local display_count display_duration display_findings_text display_platform_notice
  local display_iowait_min display_iowait_median display_iowait_average display_iowait_max display_iowait_exceedances
  local display_steal_min display_steal_median display_steal_average display_steal_max display_steal_exceedances
  local display_root_source display_root_filesystem display_root_used_pct display_root_inode_used_pct display_root_read_only
  local display_storage_device display_storage_operations display_storage_activity_windows display_storage_latency_windows
  local display_storage_latency_status display_storage_await_min display_storage_await_median display_storage_await_average
  local display_storage_await_max display_storage_await_exceedances display_storage_read_await_max display_storage_write_await_max
  local display_storage_util_max display_storage_queue_max
  local display_pressure_count display_pressure_duration display_mem_available_min display_mem_available_median
  local display_mem_available_average display_mem_available_max display_mem_available_exceedances display_swap_used_max
  local display_swap_in_max display_swap_out_max display_major_fault_max display_memory_psi_some_max display_memory_psi_full_max
  local display_cpu_psi_some_max display_run_queue_max
  local display_network_interface display_network_count display_network_activity display_network_resets
  local display_network_retrans_ratio display_network_retrans_exceedances display_network_timeouts display_network_timeout_exceedances
  local display_network_syn display_network_listen_drops display_network_listen_overflows display_network_aborts display_network_errors display_network_drops
  local display_application_status display_application_journal_status display_application_window display_application_records display_application_truncated
  local display_application_sqlite display_application_timeouts display_service_units display_service_restarted
  local display_service_restart_total display_service_restart_max display_service_failures display_service_restart_events display_role_events
  local display_history_text display_access_status display_access_confidence display_ssh_access display_firewall_readiness display_package_readiness
  local display_ssh_root display_ssh_password display_ssh_pubkey display_ssh_ports display_ssh_config_bind display_ssh_listener_bind
  local display_ufw_status display_nft_status display_nft_policy display_iptables_status display_iptables_policy display_ip6tables_status display_ip6tables_policy
  local display_firewall_sources display_access_correlation display_access_correlation_text display_access_limitations display_access_not_checked display_access_not_checked_text
  local display_network_time_status display_network_time_confidence display_network_time_coverage display_network_time_ipv4_status display_network_time_ipv4_interface display_network_time_ipv6_status display_network_time_ipv6_interface
  local display_network_time_primary_interface display_network_time_mtu display_network_time_mtu_status display_network_time_mtu_profile display_network_time_resolver display_network_time_name_service display_network_time_name_service_requested display_network_time_name_service_success
  local display_network_time_sync display_network_time_native_sync display_network_time_ntp display_network_time_can_ntp display_network_time_timezone display_network_time_uptime display_network_time_external display_network_time_domain_tls display_network_time_limitations display_network_time_not_checked display_network_time_not_checked_text
  display_verdict="$(awk -F= '/^verdict=/{print $2}' "$summary")"
  display_label="$(sed -n 's/^Результат: //p' "$result")"
  display_reason="$(sed -n 's/^Причина: //p' "$result")"
  display_action="$(sed -n 's/^Рекомендуемое действие: //p' "$result")"
  display_confidence="$(awk -F= '$1=="diagnostic_confidence"{print $2}' "$summary")"
  display_coverage_status="$(awk -F= '$1=="diagnostic_coverage_status"{print $2}' "$summary")"
  display_coverage_completed="$(awk -F= '$1=="diagnostic_completed_checks"{print $2}' "$summary")"
  display_coverage_required="$(awk -F= '$1=="diagnostic_required_checks"{print $2}' "$summary")"
  display_coverage_missing="$(awk -F= '$1=="diagnostic_missing_checks"{print $2}' "$summary")"
  display_coverage_limited="$(awk -F= '$1=="diagnostic_limited_checks"{print $2}' "$summary")"
  display_count="$(awk -F= '$1=="cpu_sample_count"{print $2}' "$summary")"
  display_duration="$(awk -F= '$1=="cpu_sample_duration_seconds"{print $2}' "$summary")"
  display_iowait_min="$(awk -F= '$1=="iowait_min_pct"{print $2}' "$summary")"
  display_iowait_median="$(awk -F= '$1=="iowait_median_pct"{print $2}' "$summary")"
  display_iowait_average="$(awk -F= '$1=="iowait_average_pct"{print $2}' "$summary")"
  display_iowait_max="$(awk -F= '$1=="iowait_max_pct"{print $2}' "$summary")"
  display_iowait_exceedances="$(awk -F= '$1=="iowait_threshold_exceedance_count"{print $2}' "$summary")"
  display_steal_min="$(awk -F= '$1=="steal_min_pct"{print $2}' "$summary")"
  display_steal_median="$(awk -F= '$1=="steal_median_pct"{print $2}' "$summary")"
  display_steal_average="$(awk -F= '$1=="steal_average_pct"{print $2}' "$summary")"
  display_steal_max="$(awk -F= '$1=="steal_max_pct"{print $2}' "$summary")"
  display_steal_exceedances="$(awk -F= '$1=="steal_threshold_exceedance_count"{print $2}' "$summary")"
  display_root_source="$(awk -F= '$1=="root_source"{print $2}' "$summary")"
  display_root_filesystem="$(awk -F= '$1=="root_filesystem"{print $2}' "$summary")"
  display_root_used_pct="$(awk -F= '$1=="root_used_pct"{print $2}' "$summary")"
  display_root_inode_used_pct="$(awk -F= '$1=="root_inode_used_pct"{print $2}' "$summary")"
  display_root_read_only="$(awk -F= '$1=="root_mount_read_only"{print $2}' "$summary")"
  display_storage_device="$(awk -F= '$1=="storage_device"{print $2}' "$summary")"
  display_storage_operations="$(awk -F= '$1=="storage_device_operations"{print $2}' "$summary")"
  display_storage_activity_windows="$(awk -F= '$1=="storage_device_activity_windows"{print $2}' "$summary")"
  display_storage_latency_windows="$(awk -F= '$1=="storage_device_latency_windows"{print $2}' "$summary")"
  display_storage_latency_status="$(awk -F= '$1=="storage_latency_evidence_status"{print $2}' "$summary")"
  display_storage_await_min="$(awk -F= '$1=="storage_await_ms_min"{print $2}' "$summary")"
  display_storage_await_median="$(awk -F= '$1=="storage_await_ms_median"{print $2}' "$summary")"
  display_storage_await_average="$(awk -F= '$1=="storage_await_ms_average"{print $2}' "$summary")"
  display_storage_await_max="$(awk -F= '$1=="storage_await_ms_max"{print $2}' "$summary")"
  display_storage_await_exceedances="$(awk -F= '$1=="storage_await_ms_threshold_exceedance_count"{print $2}' "$summary")"
  display_storage_read_await_max="$(awk -F= '$1=="storage_read_await_ms_max"{print $2}' "$summary")"
  display_storage_write_await_max="$(awk -F= '$1=="storage_write_await_ms_max"{print $2}' "$summary")"
  display_storage_util_max="$(awk -F= '$1=="storage_util_pct_max"{print $2}' "$summary")"
  display_storage_queue_max="$(awk -F= '$1=="storage_queue_depth_max"{print $2}' "$summary")"
  display_pressure_count="$(awk -F= '$1=="pressure_sample_count_requested"{print $2}' "$summary")"
  display_pressure_duration="$(awk -F= '$1=="pressure_sample_duration_seconds"{print $2}' "$summary")"
  display_mem_available_min="$(awk -F= '$1=="mem_available_pct_min"{print $2}' "$summary")"
  display_mem_available_median="$(awk -F= '$1=="mem_available_pct_median"{print $2}' "$summary")"
  display_mem_available_average="$(awk -F= '$1=="mem_available_pct_average"{print $2}' "$summary")"
  display_mem_available_max="$(awk -F= '$1=="mem_available_pct_max"{print $2}' "$summary")"
  display_mem_available_exceedances="$(awk -F= '$1=="mem_available_pct_threshold_exceedance_count"{print $2}' "$summary")"
  display_swap_used_max="$(awk -F= '$1=="swap_used_pct_max"{print $2}' "$summary")"
  display_swap_in_max="$(awk -F= '$1=="swap_in_pages_per_second_max"{print $2}' "$summary")"
  display_swap_out_max="$(awk -F= '$1=="swap_out_pages_per_second_max"{print $2}' "$summary")"
  display_major_fault_max="$(awk -F= '$1=="major_faults_per_second_max"{print $2}' "$summary")"
  display_memory_psi_some_max="$(awk -F= '$1=="memory_psi_some_avg10_pct_max"{print $2}' "$summary")"
  display_memory_psi_full_max="$(awk -F= '$1=="memory_psi_full_avg10_pct_max"{print $2}' "$summary")"
  display_cpu_psi_some_max="$(awk -F= '$1=="cpu_psi_some_avg10_pct_max"{print $2}' "$summary")"
  display_run_queue_max="$(awk -F= '$1=="run_queue_per_vcpu_max"{print $2}' "$summary")"
  display_network_interface="$(awk -F= '$1=="network_primary_interface"{print $2}' "$summary")"
  display_network_count="$(awk -F= '$1=="network_counter_sample_count"{print $2}' "$summary")"
  display_network_activity="$(awk -F= '$1=="network_counter_activity_windows"{print $2}' "$summary")"
  display_network_resets="$(awk -F= '$1=="network_counter_reset_windows"{print $2}' "$summary")"
  display_network_retrans_ratio="$(awk -F= '$1=="network_tcp_retrans_ratio_pct_max"{print $2}' "$summary")"
  display_network_retrans_exceedances="$(awk -F= '$1=="network_tcp_retrans_ratio_pct_threshold_exceedance_count"{print $2}' "$summary")"
  display_network_timeouts="$(awk -F= '$1=="network_tcp_timeout_events_per_second_max"{print $2}' "$summary")"
  display_network_timeout_exceedances="$(awk -F= '$1=="network_tcp_timeout_events_per_second_threshold_exceedance_count"{print $2}' "$summary")"
  display_network_syn="$(awk -F= '$1=="network_tcp_syn_retrans_events_per_second_max"{print $2}' "$summary")"
  display_network_listen_drops="$(awk -F= '$1=="network_listen_drop_events_per_second_max"{print $2}' "$summary")"
  display_network_listen_overflows="$(awk -F= '$1=="network_listen_overflow_events_per_second_max"{print $2}' "$summary")"
  display_network_aborts="$(awk -F= '$1=="network_tcp_abort_timeout_events_per_second_max"{print $2}' "$summary")"
  display_network_errors="$(awk -F= '$1=="network_interface_error_events_per_second_max"{print $2}' "$summary")"
  display_network_drops="$(awk -F= '$1=="network_interface_drop_events_per_second_max"{print $2}' "$summary")"
  display_application_status="$(awk -F= '$1=="application_service_sample_status"{print $2}' "$summary")"
  display_application_journal_status="$(awk -F= '$1=="application_journal_status"{print $2}' "$summary")"
  display_application_window="$(awk -F= '$1=="application_journal_window"{print $2}' "$summary")"
  display_application_records="$(awk -F= '$1=="application_journal_records_scanned"{print $2}' "$summary")"
  display_application_truncated="$(awk -F= '$1=="application_journal_truncated"{print $2}' "$summary")"
  display_application_sqlite="$(awk -F= '$1=="application_sqlite_lock_events_24h"{print $2}' "$summary")"
  display_application_timeouts="$(awk -F= '$1=="application_timeout_events_24h"{print $2}' "$summary")"
  display_service_units="$(awk -F= '$1=="service_units_observed"{print $2}' "$summary")"
  display_service_restarted="$(awk -F= '$1=="service_units_with_restarts"{print $2}' "$summary")"
  display_service_restart_total="$(awk -F= '$1=="service_restart_count_total"{print $2}' "$summary")"
  display_service_restart_max="$(awk -F= '$1=="service_restart_count_max"{print $2}' "$summary")"
  display_service_failures="$(awk -F= '$1=="service_failure_events_24h"{print $2}' "$summary")"
  display_service_restart_events="$(awk -F= '$1=="service_restart_events_24h"{print $2}' "$summary")"
  display_role_events="$(awk -F= '$1=="application_role_relevant_events_24h"{print $2}' "$summary")"
  display_access_status="$(awk -F= '$1=="access_readiness_status"{print $2}' "$summary")"
  display_access_confidence="$(awk -F= '$1=="access_readiness_confidence"{print $2}' "$summary")"
  display_ssh_access="$(awk -F= '$1=="ssh_access_status"{print $2}' "$summary")"
  display_firewall_readiness="$(awk -F= '$1=="firewall_readiness_status"{print $2}' "$summary")"
  display_package_readiness="$(awk -F= '$1=="package_readiness_status"{print $2}' "$summary")"
  display_ssh_root="$(awk -F= '$1=="ssh_effective_permit_root_login"{print $2}' "$summary")"
  display_ssh_password="$(awk -F= '$1=="ssh_effective_password_authentication"{print $2}' "$summary")"
  display_ssh_keyboard="$(awk -F= '$1=="ssh_effective_kbd_interactive_authentication"{print $2}' "$summary")"
  display_ssh_pubkey="$(awk -F= '$1=="ssh_effective_pubkey_authentication"{print $2}' "$summary")"
  display_ssh_authentication_methods="$(awk -F= '$1=="ssh_effective_authentication_methods"{print $2}' "$summary")"
  display_ssh_context="$(awk -F= '$1=="ssh_effective_context_status"{print $2}' "$summary")"
  display_ssh_ports="$(awk -F= '$1=="ssh_effective_port_set"{print $2}' "$summary")"
  display_ssh_config_bind="$(awk -F= '$1=="ssh_effective_listen_address_scope"{print $2}' "$summary")"
  display_ssh_listener_bind="$(awk -F= '$1=="ssh_listener_scope"{print $2}' "$summary")"
  display_ufw_status="$(awk -F= '$1=="firewall_ufw_status"{print $2}' "$summary")"
  display_nft_status="$(awk -F= '$1=="firewall_nft_status"{print $2}' "$summary")"
  display_nft_policy="$(awk -F= '$1=="firewall_nft_input_policy"{print $2}' "$summary")"
  display_iptables_status="$(awk -F= '$1=="firewall_iptables_status"{print $2}' "$summary")"
  display_iptables_policy="$(awk -F= '$1=="firewall_iptables_input_policy"{print $2}' "$summary")"
  display_ip6tables_status="$(awk -F= '$1=="firewall_ip6tables_status"{print $2}' "$summary")"
  display_ip6tables_policy="$(awk -F= '$1=="firewall_ip6tables_input_policy"{print $2}' "$summary")"
  display_firewall_sources="$(awk -F= '$1=="local_firewall_enforcement_sources"{print $2}' "$summary")"
  display_access_correlation="$(awk -F= '$1=="access_readiness_correlation"{print $2}' "$summary")"
  display_access_limitations="$(awk -F= '$1=="access_readiness_limitations"{print $2}' "$summary")"
  display_access_not_checked="$(awk -F= '$1=="access_readiness_not_checked_families"{print $2}' "$summary")"
  display_access_not_checked_text="${display_access_not_checked//,/, }"
  display_network_time_status="$(awk -F= '$1=="network_time_readiness_status"{print $2}' "$summary")"; display_network_time_status="${display_network_time_status:-UNKNOWN}"
  display_network_time_confidence="$(awk -F= '$1=="network_time_readiness_confidence"{print $2}' "$summary")"; display_network_time_confidence="${display_network_time_confidence:-LIMITED}"
  display_network_time_coverage="$(awk -F= '$1=="network_time_readiness_coverage_status"{print $2}' "$summary")"; display_network_time_coverage="${display_network_time_coverage:-limited}"
  display_network_time_ipv4_status="$(awk -F= '$1=="network_ipv4_default_route_status"{print $2}' "$summary")"; display_network_time_ipv4_status="${display_network_time_ipv4_status:-UNKNOWN}"
  display_network_time_ipv4_interface="$(awk -F= '$1=="network_ipv4_default_interface"{print $2}' "$summary")"; display_network_time_ipv4_interface="${display_network_time_ipv4_interface:-unavailable}"
  display_network_time_ipv6_status="$(awk -F= '$1=="network_ipv6_default_route_status"{print $2}' "$summary")"; display_network_time_ipv6_status="${display_network_time_ipv6_status:-UNKNOWN}"
  display_network_time_ipv6_interface="$(awk -F= '$1=="network_ipv6_default_interface"{print $2}' "$summary")"; display_network_time_ipv6_interface="${display_network_time_ipv6_interface:-unavailable}"
  display_network_time_primary_interface="$(awk -F= '$1=="network_readiness_primary_interface"{print $2}' "$summary")"; display_network_time_primary_interface="${display_network_time_primary_interface:-unavailable}"
  display_network_time_mtu="$(awk -F= '$1=="network_primary_interface_mtu"{print $2}' "$summary")"; display_network_time_mtu="${display_network_time_mtu:-unavailable}"
  display_network_time_mtu_status="$(awk -F= '$1=="network_mtu_status"{print $2}' "$summary")"; display_network_time_mtu_status="${display_network_time_mtu_status:-UNKNOWN}"
  display_network_time_mtu_profile="$(awk -F= '$1=="network_mtu_profile"{print $2}' "$summary")"; display_network_time_mtu_profile="${display_network_time_mtu_profile:-UNKNOWN}"
  display_network_time_resolver="$(awk -F= '$1=="network_resolver_configuration_status"{print $2}' "$summary")"; display_network_time_resolver="${display_network_time_resolver:-UNKNOWN}"
  display_network_time_name_service="$(awk -F= '$1=="network_name_service_resolution_status"{print $2}' "$summary")"; display_network_time_name_service="${display_network_time_name_service:-UNKNOWN}"
  display_network_time_name_service_requested="$(awk -F= '$1=="network_name_service_resolution_requested_count"{print $2}' "$summary")"; display_network_time_name_service_requested="${display_network_time_name_service_requested:-unavailable}"
  display_network_time_name_service_success="$(awk -F= '$1=="network_name_service_resolution_success_count"{print $2}' "$summary")"; display_network_time_name_service_success="${display_network_time_name_service_success:-unavailable}"
  display_network_time_sync="$(awk -F= '$1=="network_time_sync_status"{print $2}' "$summary")"; display_network_time_sync="${display_network_time_sync:-UNKNOWN}"
  display_network_time_native_sync="$(awk -F= '$1=="network_time_ntp_synchronized"{print $2}' "$summary")"; display_network_time_native_sync="${display_network_time_native_sync:-unavailable}"
  display_network_time_ntp="$(awk -F= '$1=="network_time_ntp_enabled"{print $2}' "$summary")"; display_network_time_ntp="${display_network_time_ntp:-unavailable}"
  display_network_time_can_ntp="$(awk -F= '$1=="network_time_can_ntp"{print $2}' "$summary")"; display_network_time_can_ntp="${display_network_time_can_ntp:-unavailable}"
  display_network_time_timezone="$(awk -F= '$1=="network_time_timezone"{print $2}' "$summary")"; display_network_time_timezone="${display_network_time_timezone:-unavailable}"
  display_network_time_uptime="$(awk -F= '$1=="network_time_uptime_seconds"{print $2}' "$summary")"; display_network_time_uptime="${display_network_time_uptime:-unavailable}"
  display_network_time_external="$(awk -F= '$1=="network_time_external_reachability_status"{print $2}' "$summary")"; display_network_time_external="${display_network_time_external:-NOT_CHECKED}"
  display_network_time_domain_tls="$(awk -F= '$1=="network_time_domain_tls_status"{print $2}' "$summary")"; display_network_time_domain_tls="${display_network_time_domain_tls:-NOT_CHECKED}"
  display_network_time_limitations="$(awk -F= '$1=="network_time_readiness_limitations"{print $2}' "$summary")"; display_network_time_limitations="${display_network_time_limitations:-local_read_only_evidence_only}"
  display_network_time_not_checked="$(awk -F= '$1=="network_time_readiness_not_checked_families"{print $2}' "$summary")"; display_network_time_not_checked="${display_network_time_not_checked:-external_reachability,path_mtu,remote_clock_reference,domain_tls}"
  display_network_time_not_checked_text="${display_network_time_not_checked//,/, }"
  case "$display_access_correlation" in
    root_and_password_capable_auth_with_non_loopback_or_wildcard_ssh_bind_requires_review)
      display_access_correlation_text="Root и password-capable authentication сопоставлены с SSH bind вне loopback; нужна проверка владельца"
      ;;
    default_context_is_key_oriented_but_match_contexts_are_not_exhaustively_evaluated)
      display_access_correlation_text="Default SSH context key-oriented, но все Match contexts не проверены"
      ;;
    sampled_ssh_context_differs_from_default_and_other_match_contexts_remain_unchecked)
      display_access_correlation_text="Проверенный SSH context отличается от default; остальные Match contexts не проверены"
      ;;
    local_firewall_status_or_backend_policy_requires_review)
      display_access_correlation_text="Локальный firewall status или политика backend требуют проверки"
      ;;
    effective_ssh_configuration_or_local_bind_requires_owner_review)
      display_access_correlation_text="Effective SSH или локальный bind требуют проверки владельца"
      ;;
    *) display_access_correlation_text="Доказательств недостаточно для здорового вывода" ;;
  esac
  display_history_text="$(history_format_summary "$summary")"
  display_findings_text="$(ranked_findings_readable_text "$summary" "$FINDINGS_READABLE_LIMIT")"
  display_platform_notice="$(platform_release_notice_text "$summary")"
  case "$display_verdict" in
    PASS) display_colour=green ;;
    WARN) display_colour=yellow ;;
    FAIL) display_colour=red ;;
    *) display_colour=reset ;;
  esac
  case "$display_coverage_status" in
    complete) display_coverage_text="complete: ${display_coverage_completed}/${display_coverage_required}." ;;
    limited) display_coverage_text="limited: ${display_coverage_completed}/${display_coverage_required}. Ограничено: ${display_coverage_limited}." ;;
    *) display_coverage_text="partial: ${display_coverage_completed}/${display_coverage_required}. Недоступно: ${display_coverage_missing}." ;;
  esac
  display_elapsed="$(sonar_elapsed_seconds)"
  sonar_render_summary_result_if_tty     "$summary" "$host" "$display_coverage_completed" "$display_coverage_required"     "$display_elapsed" "$run_dir"
  progress_print_block "РЕЗУЛЬТАТ" "$display_label" "$display_colour"
  progress_print_block "УВЕРЕННОСТЬ" "$display_confidence"
  progress_print_block "ПОКРЫТИЕ ПРОВЕРОК" "$display_coverage_text"
  progress_print_block "ДОСТУП И ГОТОВНОСТЬ" "Статус ${display_access_status}; уверенность ${display_access_confidence}. SSH: ${display_ssh_access}; effective root ${display_ssh_root}, password ${display_ssh_password}, keyboard-interactive ${display_ssh_keyboard}, pubkey ${display_ssh_pubkey}, AuthenticationMethods ${display_ssh_authentication_methods}, context ${display_ssh_context}, port ${display_ssh_ports}, configured bind ${display_ssh_config_bind}, local listener bind ${display_ssh_listener_bind}. Local firewall: ${display_firewall_readiness}; UFW ${display_ufw_status}, nft ${display_nft_status}/${display_nft_policy}, iptables IPv4 ${display_iptables_status}/${display_iptables_policy}, IPv6 ${display_ip6tables_status}/${display_ip6tables_policy}; enforcement sources ${display_firewall_sources}. Packages: ${display_package_readiness}. Корреляция: ${display_access_correlation_text}. Внешняя достижимость не проверялась."
  progress_print_block "ОГРАНИЧЕНИЯ ГОТОВНОСТИ" "NOT CHECKED: ${display_access_not_checked_text}. ${display_access_limitations}. Эти семейства не считаются здоровыми или пройденными."
  progress_print_block "СЕТЬ И ВРЕМЯ" "Статус ${display_network_time_status}; уверенность ${display_network_time_confidence}; coverage ${display_network_time_coverage}. Default route IPv4 ${display_network_time_ipv4_status} (${display_network_time_ipv4_interface}), IPv6 ${display_network_time_ipv6_status} (${display_network_time_ipv6_interface}); primary ${display_network_time_primary_interface}, MTU ${display_network_time_mtu} (${display_network_time_mtu_status}/${display_network_time_mtu_profile}). Resolver ${display_network_time_resolver}; name service/NSS ${display_network_time_name_service} (${display_network_time_name_service_success}/${display_network_time_name_service_requested}). Time ${display_network_time_sync}; native synchronized ${display_network_time_native_sync}, NTP ${display_network_time_ntp}, CanNTP ${display_network_time_can_ntp}, timezone ${display_network_time_timezone}, uptime ${display_network_time_uptime}s. External reachability ${display_network_time_external}; domain/TLS ${display_network_time_domain_tls}. NOT CHECKED: ${display_network_time_not_checked_text}. Ограничения: ${display_network_time_limitations}."
  progress_print_block "ПРИЧИНА" "$display_reason"
  progress_print_block "ИЗМЕРЕНИЯ CPU / I/O" "I/O wait: min ${display_iowait_min}%, median ${display_iowait_median}%, avg ${display_iowait_average}%, max ${display_iowait_max}%, превышений ${display_iowait_exceedances}/${display_count}. CPU steal: min ${display_steal_min}%, median ${display_steal_median}%, avg ${display_steal_average}%, max ${display_steal_max}%, превышений ${display_steal_exceedances}/${display_count}. Метод: ${display_count} интервалов за ${display_duration} секунд."
  progress_print_block "ПАМЯТЬ И CPU PRESSURE" "Доступная память: min ${display_mem_available_min}%, median ${display_mem_available_median}%, avg ${display_mem_available_average}%, max ${display_mem_available_max}%, низких окон ${display_mem_available_exceedances}/${display_pressure_count}. Swap занято max ${display_swap_used_max}%; swap in/out max ${display_swap_in_max}/${display_swap_out_max} страниц/с; major faults max ${display_major_fault_max}/с. PSI memory some/full max ${display_memory_psi_some_max}%/${display_memory_psi_full_max}%; PSI CPU some max ${display_cpu_psi_some_max}%; run queue max ${display_run_queue_max} на vCPU. Метод: ${display_pressure_count} интервалов за ${display_pressure_duration} секунд."
  progress_print_block "СЕТЕВЫЕ СЧЁТЧИКИ" "Интерфейс ${display_network_interface}; ${display_network_count} окон, активных ${display_network_activity}, reset/discard ${display_network_resets}. TCP retrans max ${display_network_retrans_ratio}%, превышений ${display_network_retrans_exceedances}; timeouts max ${display_network_timeouts}/с, окон ${display_network_timeout_exceedances}; SYN retrans max ${display_network_syn}/с; listen drops/overflows max ${display_network_listen_drops}/${display_network_listen_overflows}/с; abort timeout max ${display_network_aborts}/с; interface errors/drops max ${display_network_errors}/${display_network_drops}/с."
  progress_print_block "ПРИЛОЖЕНИЯ И СЛУЖБЫ" "Статус ${display_application_status}; окно ${display_application_window}; журнал ${display_application_journal_status}, записей ${display_application_records}, ограничен: ${display_application_truncated}. SQLite locks ${display_application_sqlite}; application timeouts ${display_application_timeouts}; события failure/restart ${display_service_failures}/${display_service_restart_events}. Systemd: служб ${display_service_units}, с restart counter ${display_service_restarted}, рестартов всего/max ${display_service_restart_total}/${display_service_restart_max}. События служб роли: ${display_role_events}."
  progress_print_block "ХРАНИЛИЩЕ" "Корень: ${display_root_source}, ${display_root_filesystem}, занято ${display_root_used_pct}%, inode ${display_root_inode_used_pct}%, read-only: ${display_root_read_only}. Устройство: ${display_storage_device}; операций ${display_storage_operations}; активных окон ${display_storage_activity_windows}; latency-окон ${display_storage_latency_windows}; статус latency: ${display_storage_latency_status}. Await ms: min ${display_storage_await_min}, median ${display_storage_await_median}, avg ${display_storage_await_average}, max ${display_storage_await_max}, read max ${display_storage_read_await_max}, write max ${display_storage_write_await_max}, превышений ${display_storage_await_exceedances}. Util max ${display_storage_util_max}%; queue max ${display_storage_queue_max}."
  progress_print_block "СРАВНЕНИЕ С ПРЕДЫДУЩИМ АУДИТОМ" "$display_history_text"
  [[ -z "$display_platform_notice" ]] || progress_print_block "ПЛАТФОРМА" "$display_platform_notice"
  progress_print_block "НАХОДКИ ПО ВАЖНОСТИ" "$display_findings_text"
  progress_print_block "РЕКОМЕНДУЕМОЕ ДЕЙСТВИЕ" "$display_action"
  progress_print_block "ОТЧЁТ" "Технический отчёт подготовлен."
  progress_print_block "ЛОКАЛЬНАЯ КОПИЯ" "$run_dir"
}

if [[ "$SERVER_TOOLKIT_IS_SOURCED" == 0 ]]; then main "$@"; fi
