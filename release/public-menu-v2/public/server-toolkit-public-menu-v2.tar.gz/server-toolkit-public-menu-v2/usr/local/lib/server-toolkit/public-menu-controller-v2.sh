# Public one-shot menu controller for the fixed public v2 backends.
# This file is sourced only by the protected, fixed-path public launcher.
# shellcheck shell=bash disable=SC2030,SC2031,SC2034

PUBLIC_MENU_WINCH_COUNT=0
PUBLIC_MENU_RENDER_VALID=0
PUBLIC_MENU_ABORTED=0
PUBLIC_MENU_CHOICE=""
PUBLIC_MENU_TTY_STATE=""
PUBLIC_MENU_TTY_ACTIVE=0
PUBLIC_MENU_INPUT_HEX=""
PUBLIC_MENU_INPUT_COUNT=0
PUBLIC_MENU_INPUT_SAW_ESCAPE=0
PUBLIC_MENU_INPUT_SAW_CONTROL=0
PUBLIC_MENU_RESIZE_PENDING=0
PUBLIC_MENU_PENDING_DIGIT_HEX=""
PUBLIC_MENU_CORRECTIONS=0
PUBLIC_MENU_REJECTION_MESSAGE=""
readonly PUBLIC_MENU_CLEANUP_DRAIN_SECONDS=2
readonly PUBLIC_MENU_TIMEOUT_KILL_AFTER_SECONDS=1
readonly PUBLIC_MENU_MAX_CORRECTIONS=2
readonly PUBLIC_MENU_MAX_RESIZES=8

public_menu_error() {
  printf 'ERROR: %s\n' "$1" >&2
  return "${2:-2}"
}

public_menu_signal_exit() {
  # A second fatal signal must not restore the default disposition while the
  # first handler is still draining queued bytes and restoring the TTY.
  trap ':' HUP INT QUIT TERM WINCH
  local status="$1"
  PUBLIC_MENU_ABORTED=1
  public_menu_terminal_drain_to_idle >/dev/null 2>&1 || true
  public_menu_terminal_restore >/dev/null 2>&1 || true
  exit "$status"
}

public_menu_terminal_exit_cleanup() {
  # Keep cleanup non-interruptible inside its single-reader drain/restore
  # critical section. Resetting first could terminate with raw mode live.
  trap ':' HUP INT QUIT TERM WINCH
  trap - EXIT
  public_menu_terminal_drain_to_idle >/dev/null 2>&1 || true
  public_menu_terminal_restore >/dev/null 2>&1 || true
  trap - HUP INT QUIT TERM WINCH
}

public_menu_stty() {
  if [[ -x /bin/stty ]]; then
    /bin/stty "$@" </dev/tty
  elif [[ -x /usr/bin/stty ]]; then
    /usr/bin/stty "$@" </dev/tty
  else
    return 126
  fi
}

public_menu_terminal_restore() {
  local saved="$PUBLIC_MENU_TTY_STATE"
  (( PUBLIC_MENU_TTY_ACTIVE == 1 )) || return 0
  [[ -n "$saved" && "$saved" != *[$'\r\n']* ]] || return 1
  if ! public_menu_stty "$saved" >/dev/null 2>&1; then
    # Keep the saved state live so a signal/error cleanup can retry once.
    public_menu_stty "$saved" >/dev/null 2>&1 || return 1
  fi
  PUBLIC_MENU_TTY_ACTIVE=0
  PUBLIC_MENU_TTY_STATE=""
}

public_menu_terminal_begin_byte_input() {
  local saved
  saved="$(public_menu_stty -g 2>/dev/null)" || return 126
  [[ -n "$saved" && "$saved" != *[$'\r\n']* ]] || return 126
  PUBLIC_MENU_TTY_STATE="$saved"
  PUBLIC_MENU_TTY_ACTIVE=1
  # Preserve exact CR, LF, and CRLF shapes for explicit terminator validation.
  # Echo stays disabled: only controller-validated digits are ever rendered.
  # VTIME bounds every idle byte-read window.
  if ! public_menu_stty -echo -icanon -icrnl min 0 time 2 >/dev/null 2>&1; then
    public_menu_terminal_restore >/dev/null 2>&1 || true
    return 126
  fi
}

public_menu_terminal_columns() {
  local size="" columns=""
  if [[ -x /bin/stty ]]; then
    size="$(/bin/stty size </dev/tty 2>/dev/null || true)"
    columns="${size##* }"
  elif [[ -x /usr/bin/stty ]]; then
    size="$(/usr/bin/stty size </dev/tty 2>/dev/null || true)"
    columns="${size##* }"
  fi
  [[ "$columns" =~ ^[0-9]+$ ]] || columns="${COLUMNS:-}"
  [[ "$columns" =~ ^[0-9]+$ ]] || columns=80
  (( columns > 240 )) && columns=240
  printf '%s' "$columns"
}

public_menu_utf8_locale() {
  local candidate charmap probe='Ж'
  if [[ ${#PUBLIC_MENU_DISPLAY_VERSION} -ge 1 && ${#probe} -eq 1 ]]; then
    printf '%s' "${LC_ALL:-${LC_CTYPE:-${LANG:-C}}}"
    return 0
  fi
  [[ -x /usr/bin/locale ]] || return 1
  for candidate in C.UTF-8 C.utf8 en_US.UTF-8; do
    charmap="$(LC_ALL="$candidate" /usr/bin/locale charmap 2>/dev/null || true)"
    [[ "$charmap" == UTF-8 ]] || continue
    if (LC_ALL="$candidate"; [[ ${#probe} -eq 1 ]]) 2>/dev/null; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

public_menu_locale_requests_ascii() {
  local requested="${LC_ALL:-${LC_CTYPE:-${LANG:-}}}"
  case "$requested" in
    C|POSIX) return 0 ;;
    *) return 1 ;;
  esac
}

public_menu_prepare_presentation() {
  local columns utf8_locale colours=0
  declare -F sonar_set_width >/dev/null || return 126
  declare -F sonar_configure_symbols >/dev/null || return 126
  declare -F sonar_frame_top >/dev/null || return 126
  declare -F sonar_frame_bottom >/dev/null || return 126
  declare -F sonar_separator >/dev/null || return 126
  declare -F sonar_box_text >/dev/null || return 126
  declare -F sonar_blank >/dev/null || return 126
  columns="$(public_menu_terminal_columns)"
  sonar_set_width "$columns" || return 2
  utf8_locale="$(public_menu_utf8_locale)" || return 2
  SONAR_UTF8_LOCALE="$utf8_locale"
  if public_menu_locale_requests_ascii; then
    SONAR_UNICODE=0
  else
    SONAR_UNICODE=1
  fi
  SONAR_COLOR=0
  if (( SONAR_UNICODE == 1 )) && [[ -z "${NO_COLOR:-}" &&
       -x /usr/bin/tput ]]; then
    colours="$(/usr/bin/tput colors 2>/dev/null || true)"
    [[ "$colours" =~ ^[0-9]+$ ]] || colours=0
    (( colours >= 8 )) && SONAR_COLOR=1
  fi
  sonar_configure_symbols
}

public_menu_render_frame() {
  local version="${1:-v1.0.0}"
  local digit="${2:-_}" state="${3:-Жду цифру}" notice="${4:-}"
  sonar_frame_top "SERVER TOOLKIT · ${version}"
  sonar_box_text "  [1] Полный аудит"
  sonar_box_text "  [2] Быстрая проверка"
  sonar_box_text "  [3] Последний отчёт"
  sonar_box_text "  [0] Выход"
  sonar_blank
  sonar_separator
  sonar_box_text "Цифра 0-3, затем Enter" muted
  sonar_box_text "ВЫБОР ${SONAR_POINTER} $digit" active
  sonar_box_text "$state" active
  sonar_box_text "$notice" attention
  sonar_frame_bottom
}

public_menu_render() {
  public_menu_prepare_presentation || return $?
  public_menu_render_frame "$1" "${2:-_}" "${3:-Жду цифру}" "${4:-}"
}

public_menu_refresh_state() {
  local digit="${1:-_}" state="$2" notice="${3:-}"
  local generation="$PUBLIC_MENU_WINCH_COUNT"
  PUBLIC_MENU_RENDER_VALID=0
  # The cursor is one line below the 12-line frame. Refresh only its final
  # four lines for an actual state transition; idle polls emit nothing.
  printf '\033[4A\r' || return 2
  sonar_box_text "ВЫБОР ${SONAR_POINTER} $digit" active || return 2
  sonar_box_text "$state" active || return 2
  sonar_box_text "$notice" attention || return 2
  sonar_frame_bottom || return 2
  if (( PUBLIC_MENU_WINCH_COUNT != generation )); then
    PUBLIC_MENU_RESIZE_PENDING=1
    return 75
  fi
  PUBLIC_MENU_RENDER_VALID=1
}

public_menu_handle_winch() {
  PUBLIC_MENU_WINCH_COUNT=$((PUBLIC_MENU_WINCH_COUNT+1))
  PUBLIC_MENU_RENDER_VALID=0
  PUBLIC_MENU_RESIZE_PENDING=1
}

public_menu_process_pending_resize() {
  local processed=0
  if (( PUBLIC_MENU_WINCH_COUNT > PUBLIC_MENU_MAX_RESIZES )); then
    public_menu_error 'too many terminal resizes; no choice was accepted.' 2
    return
  fi
  while (( PUBLIC_MENU_RESIZE_PENDING == 1 )); do
    processed=$((processed+1))
    if (( processed > PUBLIC_MENU_MAX_RESIZES )); then
      public_menu_error 'too many terminal resizes; no choice was accepted.' 2
      return
    fi
    PUBLIC_MENU_RESIZE_PENDING=0
    PUBLIC_MENU_RENDER_VALID=0
    PUBLIC_MENU_PENDING_DIGIT_HEX=""
    PUBLIC_MENU_CORRECTIONS=0
    public_menu_terminal_drain_to_idle >/dev/null 2>&1 || return 2
    public_menu_terminal_restore >/dev/null 2>&1 || return 2
    if ! printf '\033[H\033[2J' ||
        ! public_menu_render "$PUBLIC_MENU_DISPLAY_VERSION" _ \
          'Подготовка ввода' 'Размер изменён: выбор сброшен'; then
      public_menu_error 'the resized terminal cannot render the menu safely.' 2
      return
    fi
    # A resize invalidates all bytes entered against the former frame.  Only a
    # fully rendered replacement frame may accept a completely fresh choice.
    PUBLIC_MENU_RENDER_VALID=1
  done
}

public_menu_require_backend() {
  local backend="$1"
  if [[ ! -x /usr/bin/stat ]]; then
    public_menu_error 'required executable is unavailable: /usr/bin/stat' 126
    return
  fi
  if (( EUID != 0 )) && [[ ! -x /usr/bin/sudo ]]; then
    public_menu_error 'required executable is unavailable: /usr/bin/sudo' 126
    return
  fi
  if ! declare -F public_validate_complete_bundle >/dev/null ||
      ! public_validate_complete_bundle ||
      ! trusted_public_backend "$backend"; then
    printf 'ERROR: public menu v2 bundle failed its final readable-surface or backend-metadata recheck before privileged dispatch: %s\n' \
      "$backend" >&2
    return 126
  fi
}

public_menu_select_backend() {
  case "$1" in
    0)
      return 0
      ;;
    1)
      PUBLIC_MENU_BACKEND="$PUBLIC_AUDIT_ARTIFACT"
      PUBLIC_MENU_BACKEND_LABEL='audit-v1'
      ;;
    2)
      PUBLIC_MENU_BACKEND="$PUBLIC_QUICK_ARTIFACT"
      PUBLIC_MENU_BACKEND_LABEL='quick-v2'
      ;;
    3)
      PUBLIC_MENU_BACKEND="$PUBLIC_LAST_REPORT_ARTIFACT"
      PUBLIC_MENU_BACKEND_LABEL='last-report-v2'
      ;;
    *)
      public_menu_error 'invalid menu choice; expected exactly 0, 1, 2, or 3.' 2
      return
      ;;
  esac
}

public_menu_render_self_check() {
  local columns admin_value admin_state commands_value commands_state
  local outcome footer1 footer2 preflight_status=0
  columns="$(public_menu_terminal_columns)"
  # This unprivileged screen proves only the visible command/path metadata.
  # It never claims that sudo authorization or backend execution succeeded.
  if (( EUID == 0 )); then
    admin_value='запуск уже от root'; admin_state=ок
  else
    admin_value='sudo -n: права не проверены'; admin_state='нет данных'
  fi
  commands_value="${PUBLIC_MENU_BACKEND_LABEL}: путь проверен"
  commands_state='нет данных'
  outcome=ready

  if (( EUID != 0 )) && [[ ! -x /usr/bin/sudo ]]; then
    admin_value='sudo не найден'; admin_state=СБОЙ
    outcome=missing-command; preflight_status=126
  fi
  if [[ ! -x /usr/bin/stat ]] ||
      ! declare -F public_validate_complete_bundle >/dev/null ||
      ! public_validate_complete_bundle ||
      ! trusted_public_backend "$PUBLIC_MENU_BACKEND"; then
    commands_value="${PUBLIC_MENU_BACKEND_LABEL} недоступен"
    commands_state=СБОЙ
    outcome=missing-command; preflight_status=126
  fi

  if (( preflight_status == 0 )); then
    footer1='Пути проверены ▸ запуск ещё не выполнен'
    if (( EUID == 0 )); then
      footer2='Запуск от root ▸ backend напрямую, без пароля'
    else
      footer2='Без запроса пароля ▸ при отказе выполни sudo -v'
    fi
  else
    footer1='Запуск остановлен ▸ самопроверка не пройдена'
    footer2='Исправь СБОЙ ▸ повтори выбор'
  fi
  sonar_render_self_check "$outcome" \
    "$admin_value" "$admin_state" \
    "$commands_value" "$commands_state" \
    'проверит backend' 'нет данных' \
    "${columns} колонок" ок \
    "$footer1" "$footer2"
  return "$preflight_status"
}

public_menu_invoke_dispatcher() {
  local action="$1" dispatch_status=0
  case "$action" in
    audit|quick-check|last-report|verify) ;;
    *) public_menu_error 'invalid literal dispatcher action.' 2; return ;;
  esac
  if (( EUID == 0 )); then
    exec "$PUBLIC_MENU_DISPATCHER" "$action"
  fi
  if [[ ! -x /usr/bin/sudo ]]; then
    public_menu_error 'required executable is unavailable: /usr/bin/sudo' 126
    return
  fi
  /usr/bin/sudo -n -- "$PUBLIC_MENU_DISPATCHER" "$action" || dispatch_status=$?
  if (( dispatch_status != 0 )); then
    printf '%s\n' \
      'Не удалось выполнить команду через sudo без запроса пароля.' \
      'Выполни отдельно: sudo -v' \
      'Затем снова запусти Server Toolkit и повтори выбор.' >&2
  fi
  return "$dispatch_status"
}

public_menu_dispatch() {
  local choice="$1" show_self_check="${2:-0}" action=""
  PUBLIC_MENU_BACKEND=""
  PUBLIC_MENU_BACKEND_LABEL=""
  public_menu_select_backend "$choice" || return $?
  [[ "$choice" == 0 ]] && return 0

  if [[ "$show_self_check" == 1 ]]; then
    public_menu_render_self_check || return $?
  fi

  # Recheck immediately before the privileged boundary. The earlier check is
  # presentation evidence only and never authorizes this exec.
  public_menu_require_backend "$PUBLIC_MENU_BACKEND" || return $?
  case "$choice" in
    1) action=audit ;;
    2) action=quick-check ;;
    3) action=last-report ;;
  esac
  public_menu_invoke_dispatcher "$action"
}

public_menu_verify() {
  public_validate_complete_bundle || {
    public_menu_error 'public menu v2 readable surface or opaque backend metadata validation failed.' 126
    return
  }
  public_menu_invoke_dispatcher verify
}

public_menu_collect_byte_burst() {
  local hard_cap_seconds="$1" classification payload count encoded
  local saw_escape saw_control read_status=0
  PUBLIC_MENU_INPUT_HEX=""
  PUBLIC_MENU_INPUT_COUNT=0
  PUBLIC_MENU_INPUT_SAW_ESCAPE=0
  PUBLIC_MENU_INPUT_SAW_CONTROL=0
  [[ "$hard_cap_seconds" =~ ^[1-9][0-9]*$ ]] || return 126
  [[ -x /usr/bin/timeout && -x /usr/bin/od && -x /usr/bin/awk ]] || return 126
  # od, unlike the Bash 3.2 read builtin, preserves NUL bytes. With VMIN=0
  # and VTIME=2 it streams a finite burst and exits after 0.2 idle seconds.
  # timeout provides an independent wall-clock boundary when a writer never
  # becomes idle. awk retains only the first three bytes, a capped count, and
  # two cause flags. Partial classification after timeout is discarded below.
  classification="$(
    set -o pipefail
    LC_ALL=C /usr/bin/timeout --foreground --signal=TERM \
      --kill-after="${PUBLIC_MENU_TIMEOUT_KILL_AFTER_SECONDS}s" \
      "${hard_cap_seconds}s" /usr/bin/od -An -v -t x1 </dev/tty 2>/dev/null |
      LC_ALL=C /usr/bin/awk '
        BEGIN {
          count = 0; retained = 0; invalid = 0; encoded = ""
          saw_escape = 0; saw_control = 0
        }
        {
          for (field = 1; field <= NF; field++) {
            if ($field !~ /^[0-9a-f][0-9a-f]$/) {
              invalid = 1
              continue
            }
            if (count < 4) count++
            if (retained < 3) {
              encoded = encoded $field
              retained++
            }
            if ($field == "1b") saw_escape = 1
            if ($field ~ /^(0[0-9bcef]|1[0-9a-f]|7f)$/) saw_control = 1
          }
        }
        END {
          if (invalid) {
            print "BROKEN"
          } else if (count == 0) {
            print "EMPTY"
          } else {
            printf "DATA:%d:%s:%d:%d\n", count, encoded, saw_escape, saw_control
          }
        }
      '
  )" || read_status=$?
  if (( read_status != 0 )); then
    case "$read_status" in
      124|137) return 124 ;;
      *) return 126 ;;
    esac
  fi
  case "$classification" in
    EMPTY)
      PUBLIC_MENU_INPUT_HEX=""
      PUBLIC_MENU_INPUT_COUNT=0
      PUBLIC_MENU_INPUT_SAW_ESCAPE=0
      PUBLIC_MENU_INPUT_SAW_CONTROL=0
      return 0
      ;;
    DATA:*) ;;
    *) return 126 ;;
  esac
  payload="${classification#DATA:}"
  count="${payload%%:*}"; payload="${payload#*:}"
  encoded="${payload%%:*}"; payload="${payload#*:}"
  saw_escape="${payload%%:*}"; saw_control="${payload#*:}"
  case "$count:$encoded:$saw_escape:$saw_control" in
    1:[0-9a-f][0-9a-f]:[01]:[01]|\
    2:[0-9a-f][0-9a-f][0-9a-f][0-9a-f]:[01]:[01]|\
    3:[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]:[01]:[01]|\
    4:[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]:[01]:[01]) ;;
    *) return 126 ;;
  esac
  PUBLIC_MENU_INPUT_HEX="$encoded"
  PUBLIC_MENU_INPUT_COUNT="$count"
  PUBLIC_MENU_INPUT_SAW_ESCAPE="$saw_escape"
  PUBLIC_MENU_INPUT_SAW_CONTROL="$saw_control"
}

public_menu_terminal_drain_to_idle() {
  local hard_cap_seconds="$PUBLIC_MENU_CLEANUP_DRAIN_SECONDS"
  (( PUBLIC_MENU_TTY_ACTIVE == 1 )) || return 0
  # Signal and EXIT paths must not restore canonical mode while a finite paste
  # tail is still queued. Signal handlers never start another reader; WINCH
  # only marks a pending resize, which is processed synchronously after the
  # active read returns. A reader failure remains fail-closed and never
  # dispatches.
  public_menu_collect_byte_burst "$hard_cap_seconds"
}

public_menu_hex_is_digit() {
  case "$1" in 30|31|32|33) return 0 ;; *) return 1 ;; esac
}

public_menu_consume_input() {
  local count="$PUBLIC_MENU_INPUT_COUNT" encoded="$PUBLIC_MENU_INPUT_HEX"
  local byte="" index=0
  PUBLIC_MENU_REJECTION_MESSAGE=""

  if (( PUBLIC_MENU_INPUT_SAW_ESCAPE == 1 ||
        PUBLIC_MENU_INPUT_SAW_CONTROL == 1 )); then
    PUBLIC_MENU_REJECTION_MESSAGE='ESC/управл. ввод отклонён'
    return 2
  fi
  if (( count == 4 )); then
    case "$encoded" in
      *0a*|*0d*) PUBLIC_MENU_REJECTION_MESSAGE='Лишние байты после Enter' ;;
      *) PUBLIC_MENU_REJECTION_MESSAGE='Слишком много байтов ввода' ;;
    esac
    return 2
  fi

  while (( index < count )); do
    byte="${encoded:$((index*2)):2}"
    if public_menu_hex_is_digit "$byte"; then
      if [[ -z "$PUBLIC_MENU_PENDING_DIGIT_HEX" ]]; then
        PUBLIC_MENU_PENDING_DIGIT_HEX="$byte"
      elif [[ "$byte" == "$PUBLIC_MENU_PENDING_DIGIT_HEX" ]]; then
        PUBLIC_MENU_REJECTION_MESSAGE='Повтор цифры: нажми Enter'
        return 2
      elif (( PUBLIC_MENU_CORRECTIONS >= PUBLIC_MENU_MAX_CORRECTIONS )); then
        PUBLIC_MENU_REJECTION_MESSAGE='Лимит исправлений исчерпан'
        return 2
      else
        PUBLIC_MENU_PENDING_DIGIT_HEX="$byte"
        PUBLIC_MENU_CORRECTIONS=$((PUBLIC_MENU_CORRECTIONS+1))
      fi
      index=$((index+1))
      continue
    fi

    case "$byte" in
      0a|0d)
        if [[ -z "$PUBLIC_MENU_PENDING_DIGIT_HEX" ]]; then
          PUBLIC_MENU_REJECTION_MESSAGE='Сначала введи цифру 0-3'
          return 2
        fi
        if [[ "$byte" == 0d && $((index+1)) -lt count &&
              "${encoded:$(((index+1)*2)):2}" == 0a ]]; then
          index=$((index+1))
        fi
        if (( index+1 != count )); then
          PUBLIC_MENU_REJECTION_MESSAGE='Лишние байты после Enter'
          return 2
        fi
        return 0
        ;;
      *)
        PUBLIC_MENU_REJECTION_MESSAGE='Допустима только цифра 0-3'
        return 2
        ;;
    esac
  done
  return 1
}

public_menu_finish_input_failure() {
  local message="$1" drain_status=0 restore_status=0
  public_menu_terminal_drain_to_idle >/dev/null 2>&1 || drain_status=$?
  public_menu_terminal_restore >/dev/null 2>&1 || restore_status=$?
  if (( restore_status != 0 )); then
    public_menu_error 'the original terminal state could not be restored; no choice was accepted.' 2
    return
  fi
  if (( drain_status != 0 )); then
    if (( drain_status == 124 || drain_status == 137 )); then
      public_menu_error "$message; cleanup drain reached its hard time cap." 2
    else
      public_menu_error 'the terminal input queue could not be drained safely.' 2
    fi
    return
  fi
  public_menu_error "$message" 2
}

public_menu_read_choice() {
  local choice_generation=0 notice=""
  local consume_status=0 read_status=0 drain_status=0 trailing_count=0 pending_digit="_"
  while :; do
    if (( PUBLIC_MENU_RESIZE_PENDING == 1 )); then
      public_menu_process_pending_resize || return $?
    fi
    if (( PUBLIC_MENU_ABORTED == 1 || PUBLIC_MENU_RENDER_VALID != 1 )); then
      public_menu_error 'menu frame is no longer valid; no choice was accepted.' 2
      return
    fi
    public_menu_terminal_begin_byte_input || {
      public_menu_error 'interactive byte-safe terminal input is unavailable.' 126
      return
    }
    choice_generation="$PUBLIC_MENU_WINCH_COUNT"

    # The first raw-mode burst is always residue, never an answer. The frame
    # explicitly remains in a preparation state until this drain reaches idle.
    read_status=0
    public_menu_terminal_drain_to_idle || read_status=$?
    if (( read_status != 0 )); then
      if (( read_status == 124 || read_status == 137 )); then
        public_menu_finish_input_failure 'очередь старого ввода не освободилась; ничего не запущено.'
      else
        public_menu_finish_input_failure 'terminal residue could not be discarded safely.'
      fi
      return
    fi
    if (( PUBLIC_MENU_ABORTED == 1 )); then
      public_menu_terminal_restore >/dev/null 2>&1 || true
      return 2
    fi
    if (( PUBLIC_MENU_WINCH_COUNT != choice_generation )); then
      public_menu_process_pending_resize || return $?
      continue
    fi
    notice=""
    (( PUBLIC_MENU_INPUT_COUNT > 0 )) && notice='Старый ввод отброшен'
    public_menu_refresh_state _ 'Жду цифру' "$notice" || {
        if (( PUBLIC_MENU_RESIZE_PENDING == 1 )); then
          public_menu_process_pending_resize || return $?
          continue
        fi
        public_menu_finish_input_failure 'menu waiting state could not be rendered safely.'
        return
      }
    PUBLIC_MENU_PENDING_DIGIT_HEX=""
    PUBLIC_MENU_CORRECTIONS=0
    while :; do
      read_status=0
      public_menu_collect_byte_burst "$PUBLIC_MENU_CLEANUP_DRAIN_SECONDS" || read_status=$?
      if (( PUBLIC_MENU_ABORTED == 1 )); then
        public_menu_terminal_restore >/dev/null 2>&1 || true
        return 2
      fi
      if (( PUBLIC_MENU_WINCH_COUNT != choice_generation )); then
        public_menu_process_pending_resize || return $?
        continue 2
      fi
      if (( read_status != 0 )); then
        if (( read_status == 124 || read_status == 137 )); then
          PUBLIC_MENU_PENDING_DIGIT_HEX=""
          PUBLIC_MENU_CORRECTIONS=0
          public_menu_refresh_state _ 'Жду цифру' \
            'Непрерывный ввод отброшен' || {
              (( PUBLIC_MENU_RESIZE_PENDING == 1 )) && continue 2
              public_menu_finish_input_failure 'menu waiting state could not be rendered safely.'
              return
            }
          continue
        else
          public_menu_finish_input_failure 'terminal bytes could not be read safely.'
        fi
        return
      fi
      if (( PUBLIC_MENU_INPUT_COUNT == 0 )); then
        continue
      fi

      consume_status=0
      public_menu_consume_input || consume_status=$?
      if (( consume_status == 1 )); then
        pending_digit="${PUBLIC_MENU_PENDING_DIGIT_HEX#3}"
        public_menu_refresh_state "$pending_digit" 'Жду Enter' \
          "Исправлений ${PUBLIC_MENU_CORRECTIONS}/${PUBLIC_MENU_MAX_CORRECTIONS}" || {
            (( PUBLIC_MENU_RESIZE_PENDING == 1 )) && continue 2
            public_menu_finish_input_failure 'validated digit could not be rendered safely.'
            return
          }
        continue
      fi
      if (( consume_status == 2 )); then
        notice="$PUBLIC_MENU_REJECTION_MESSAGE"
        PUBLIC_MENU_PENDING_DIGIT_HEX=""
        PUBLIC_MENU_CORRECTIONS=0
        drain_status=0
        public_menu_terminal_drain_to_idle >/dev/null 2>&1 || drain_status=$?
        if (( drain_status != 0 )); then
          if (( drain_status != 124 && drain_status != 137 )); then
            public_menu_finish_input_failure 'the terminal input queue could not be drained safely.'
            return
          fi
        fi
        if (( PUBLIC_MENU_WINCH_COUNT != choice_generation )); then
          public_menu_process_pending_resize || return $?
          continue 2
        fi
        public_menu_refresh_state _ 'Жду цифру' "$notice" || {
            (( PUBLIC_MENU_RESIZE_PENDING == 1 )) && continue 2
            public_menu_finish_input_failure 'menu re-prompt could not be rendered safely.'
            return
          }
        continue
      fi

      pending_digit="${PUBLIC_MENU_PENDING_DIGIT_HEX#3}"
      public_menu_refresh_state "$pending_digit" 'Выбор подтверждён' \
        'Проверяю очередь ввода' || {
          (( PUBLIC_MENU_RESIZE_PENDING == 1 )) && continue 2
          public_menu_finish_input_failure 'validated choice could not be rendered safely.'
          return
        }

      # A complete candidate earns one final drain-to-idle. Any byte racing
      # the terminator invalidates this attempt and is never dispatched.
      read_status=0
      public_menu_collect_byte_burst "$PUBLIC_MENU_CLEANUP_DRAIN_SECONDS" || read_status=$?
      if (( read_status != 0 )); then
        if (( read_status == 124 || read_status == 137 )); then
          trailing_count=4
        else
          public_menu_finish_input_failure 'the terminal input queue could not be checked safely.'
          return
        fi
      else
        trailing_count="$PUBLIC_MENU_INPUT_COUNT"
      fi
      if (( PUBLIC_MENU_WINCH_COUNT != choice_generation )); then
        public_menu_process_pending_resize || return $?
        continue 2
      fi
      if (( trailing_count > 0 )); then
        notice='Лишние байты после Enter'
        PUBLIC_MENU_PENDING_DIGIT_HEX=""
        PUBLIC_MENU_CORRECTIONS=0
        drain_status=0
        public_menu_terminal_drain_to_idle >/dev/null 2>&1 || drain_status=$?
        if (( drain_status != 0 )); then
          if (( drain_status != 124 && drain_status != 137 )); then
            public_menu_finish_input_failure 'the terminal input queue could not be drained safely.'
            return
          fi
        fi
        public_menu_refresh_state _ 'Жду цифру' "$notice" || {
            (( PUBLIC_MENU_RESIZE_PENDING == 1 )) && continue 2
            public_menu_finish_input_failure 'menu re-prompt could not be rendered safely.'
            return
          }
        continue
      fi
      break
    done

    if (( PUBLIC_MENU_ABORTED == 1 || PUBLIC_MENU_RENDER_VALID != 1 )); then
      public_menu_finish_input_failure 'terminal changed during input validation; no choice was accepted.'
      return
    fi
    if ! public_menu_terminal_restore; then
      public_menu_error 'the original terminal state could not be restored; no choice was accepted.' 2
      return
    fi
    case "$PUBLIC_MENU_PENDING_DIGIT_HEX" in
      30) PUBLIC_MENU_CHOICE=0 ;;
      31) PUBLIC_MENU_CHOICE=1 ;;
      32) PUBLIC_MENU_CHOICE=2 ;;
      33) PUBLIC_MENU_CHOICE=3 ;;
      *) public_menu_error 'validated menu digit was lost before dispatch.' 2; return ;;
    esac
    return 0
  done
}

public_menu_run() {
  local version="$1"
  trap 'public_menu_terminal_exit_cleanup' EXIT
  trap 'public_menu_signal_exit 129' HUP
  trap 'public_menu_signal_exit 130' INT
  trap 'public_menu_signal_exit 131' QUIT
  trap 'public_menu_signal_exit 143' TERM
  trap 'public_menu_handle_winch' WINCH

  PUBLIC_MENU_WINCH_COUNT=0
  PUBLIC_MENU_RENDER_VALID=0
  PUBLIC_MENU_ABORTED=0
  PUBLIC_MENU_RESIZE_PENDING=0
  PUBLIC_MENU_TTY_STATE=""
  PUBLIC_MENU_TTY_ACTIVE=0
  PUBLIC_MENU_INPUT_HEX=""
  PUBLIC_MENU_INPUT_COUNT=0
  PUBLIC_MENU_PENDING_DIGIT_HEX=""
  PUBLIC_MENU_CORRECTIONS=0
  public_menu_render "$version" _ 'Подготовка ввода' \
    'Старый ввод будет отброшен' || {
    trap - HUP INT QUIT TERM WINCH
    public_menu_error 'the Sonar menu cannot be rendered safely in this terminal.' 2
    return
  }
  PUBLIC_MENU_RENDER_VALID=1
  PUBLIC_MENU_CHOICE=""
  if ! public_menu_read_choice; then
    public_menu_terminal_restore >/dev/null 2>&1 || true
    trap - HUP INT QUIT TERM WINCH
    return 2
  fi
  # A resize after the validated line but before exec must also fail closed.
  trap 'public_menu_signal_exit 2' WINCH
  if (( PUBLIC_MENU_ABORTED == 1 || PUBLIC_MENU_RENDER_VALID != 1 )); then
    trap - HUP INT QUIT TERM WINCH
    public_menu_error 'menu frame became invalid before dispatch.' 2
    return
  fi
  if [[ "$PUBLIC_MENU_CHOICE" == 0 ]]; then
    public_menu_terminal_restore >/dev/null 2>&1 || true
    trap - HUP INT QUIT TERM WINCH
    return 0
  fi
  public_menu_dispatch "$PUBLIC_MENU_CHOICE" 1
}
