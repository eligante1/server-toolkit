#!/usr/bin/env bash
# Bounded read-only application and systemd service evidence.

APPLICATION_JOURNAL_WINDOW="24 hours ago"
APPLICATION_JOURNAL_MAX_RECORDS=5000
APPLICATION_SQLITE_LOCK_WARN_COUNT=2
APPLICATION_TIMEOUT_WARN_COUNT=5
SERVICE_FAILURE_WARN_COUNT=3
SERVICE_RESTART_WARN_COUNT=3
ROLE_SERVICE_EVENT_WARN_COUNT=3

application_parse_systemctl_show() {
  awk -F= '
    function flush_unit() {
      if (id == "") return
      units++
      if (restarts ~ /^[0-9]+$/) {
        total += restarts
        if (restarts > 0) affected++
        if (restarts > maximum) maximum = restarts
      } else {
        invalid++
      }
      id=""; restarts=""
    }
    /^$/ { flush_unit(); next }
    $1=="Id" { if (id != "") flush_unit(); id=$2; next }
    $1=="NRestarts" { restarts=$2; next }
    END {
      flush_unit()
      printf "service_units_observed=%d\n", units+0
      printf "service_units_with_restarts=%d\n", affected+0
      printf "service_restart_count_total=%d\n", total+0
      printf "service_restart_count_max=%d\n", maximum+0
      printf "service_restart_counter_invalid_units=%d\n", invalid+0
    }
  '
}

application_systemctl_show() {
  systemctl show --type=service --all --property=Id --property=NRestarts --no-pager
}

application_journal_output() {
  journalctl --since "$APPLICATION_JOURNAL_WINDOW" --no-pager \
    -n "$APPLICATION_JOURNAL_MAX_RECORDS" -o json --output-fields=MESSAGE
}

application_role_journal_output() {
  journalctl -u x-ui.service -u xray.service --since "$APPLICATION_JOURNAL_WINDOW" \
    --no-pager -n "$APPLICATION_JOURNAL_MAX_RECORDS" -o json --output-fields=MESSAGE
}

application_count_lines() {
  awk 'NF {count++} END {print count+0}'
}

application_count_pattern() {
  local pattern="$1"
  grep -Eic "$pattern" || true
}

application_emit_unavailable_restart_counters() {
  printf '%s\n' \
    'service_restart_counter_status=unavailable' \
    'service_restart_counter_scope=systemd_manager_lifetime' \
    'service_units_observed=unavailable' \
    'service_units_with_restarts=unavailable' \
    'service_restart_count_total=unavailable' \
    'service_restart_count_max=unavailable' \
    'service_restart_counter_invalid_units=unavailable'
}

application_emit_unavailable_journal_counters() {
  printf '%s\n' \
    'application_journal_status=unavailable' \
    "application_journal_window=$APPLICATION_JOURNAL_WINDOW" \
    "application_journal_max_records=$APPLICATION_JOURNAL_MAX_RECORDS" \
    'application_journal_records_scanned=unavailable' \
    'application_journal_truncated=unavailable' \
    'application_sqlite_lock_events_24h=unavailable' \
    'application_timeout_events_24h=unavailable' \
    'service_failure_events_24h=unavailable' \
    'service_restart_events_24h=unavailable'
}

sample_application_services() {
  local systemctl_output restart_metrics restart_invalid restart_status
  local journal_output journal_status journal_records journal_truncated
  local sqlite_locks timeouts service_failures service_restarts
  local role_output role_status role_records role_truncated role_events
  local sample_status=unavailable available_sources=0

  printf 'application_service_sample_method=systemd_restart_counters_and_bounded_journal_patterns\n'
  printf 'application_sqlite_lock_threshold=%s\n' "$APPLICATION_SQLITE_LOCK_WARN_COUNT"
  printf 'application_timeout_threshold=%s\n' "$APPLICATION_TIMEOUT_WARN_COUNT"
  printf 'service_failure_event_threshold=%s\n' "$SERVICE_FAILURE_WARN_COUNT"
  printf 'service_restart_threshold=%s\n' "$SERVICE_RESTART_WARN_COUNT"
  printf 'role_service_event_threshold=%s\n' "$ROLE_SERVICE_EVENT_WARN_COUNT"

  if command -v systemctl >/dev/null 2>&1 && \
     systemctl_output="$(application_systemctl_show 2>/dev/null)" && \
     restart_metrics="$(printf '%s\n' "$systemctl_output" | application_parse_systemctl_show)"; then
    restart_invalid="$(printf '%s\n' "$restart_metrics" | awk -F= '$1=="service_restart_counter_invalid_units"{print $2}')"
    if [[ "$restart_invalid" =~ ^[0-9]+$ ]] && (( restart_invalid == 0 )); then restart_status=ok
    else restart_status=limited
    fi
    printf 'service_restart_counter_status=%s\n' "$restart_status"
    printf 'service_restart_counter_scope=systemd_manager_lifetime\n'
    printf '%s\n' "$restart_metrics"
    available_sources=$((available_sources+1))
  else
    application_emit_unavailable_restart_counters
  fi

  if command -v journalctl >/dev/null 2>&1 && \
     journal_output="$(application_journal_output 2>/dev/null)"; then
    journal_records="$(printf '%s\n' "$journal_output" | application_count_lines)"
    if [[ "$journal_records" =~ ^[0-9]+$ ]] && (( journal_records >= APPLICATION_JOURNAL_MAX_RECORDS )); then
      journal_status=limited; journal_truncated=yes
    else
      journal_status=ok; journal_truncated=no
    fi
    sqlite_locks="$(printf '%s\n' "$journal_output" | application_count_pattern 'database is locked')"
    timeouts="$(printf '%s\n' "$journal_output" | application_count_pattern 'context deadline exceeded|i/o timeout|connection timed out|request timed out|operation timed out')"
    service_failures="$(printf '%s\n' "$journal_output" | application_count_pattern 'start request repeated too quickly|failed with result|main process exited')"
    service_restarts="$(printf '%s\n' "$journal_output" | application_count_pattern 'scheduled restart job|restart counter is at')"
    printf 'application_journal_status=%s\n' "$journal_status"
    printf 'application_journal_window=%s\n' "$APPLICATION_JOURNAL_WINDOW"
    printf 'application_journal_max_records=%s\n' "$APPLICATION_JOURNAL_MAX_RECORDS"
    printf 'application_journal_records_scanned=%s\n' "$journal_records"
    printf 'application_journal_truncated=%s\n' "$journal_truncated"
    printf 'application_sqlite_lock_events_24h=%s\n' "$sqlite_locks"
    printf 'application_timeout_events_24h=%s\n' "$timeouts"
    printf 'service_failure_events_24h=%s\n' "$service_failures"
    printf 'service_restart_events_24h=%s\n' "$service_restarts"
    available_sources=$((available_sources+1))
  else
    application_emit_unavailable_journal_counters
  fi

  case "${ROLE_LABEL:-generic}" in
    vpn|proxy|xray|hub|streaming-test)
      if command -v journalctl >/dev/null 2>&1 && \
         role_output="$(application_role_journal_output 2>/dev/null)"; then
        role_records="$(printf '%s\n' "$role_output" | application_count_lines)"
        if [[ "$role_records" =~ ^[0-9]+$ ]] && (( role_records >= APPLICATION_JOURNAL_MAX_RECORDS )); then
          role_status=limited; role_truncated=yes
        else
          role_status=ok; role_truncated=no
        fi
        role_events="$(printf '%s\n' "$role_output" | application_count_pattern 'database is locked|context deadline exceeded|i/o timeout|connection timed out|request timed out|operation timed out|start request repeated too quickly|failed with result|main process exited|scheduled restart job|restart counter is at')"
      else
        role_status=unavailable; role_records=unavailable; role_truncated=unavailable; role_events=unavailable
      fi
      ;;
    *) role_status=not_applicable; role_records=0; role_truncated=no; role_events=0 ;;
  esac
  printf 'application_role_scope_status=%s\n' "$role_status"
  printf 'application_role_journal_records_scanned=%s\n' "$role_records"
  printf 'application_role_journal_truncated=%s\n' "$role_truncated"
  printf 'application_role_relevant_events_24h=%s\n' "$role_events"

  if (( available_sources == 2 )); then
    if [[ "$restart_status" == ok && "$journal_status" == ok && \
          ( "$role_status" == ok || "$role_status" == not_applicable ) ]]; then sample_status=ok
    else sample_status=limited
    fi
  elif (( available_sources == 1 )); then
    sample_status=limited
  fi
  printf 'application_service_sample_status=%s\n' "$sample_status"
}
