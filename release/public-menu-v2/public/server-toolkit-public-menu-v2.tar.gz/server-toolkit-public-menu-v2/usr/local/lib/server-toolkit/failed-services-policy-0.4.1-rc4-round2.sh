#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
export LC_ALL=C LANG=C

FAILED_SERVICES_ALLOWLIST_FILE="${SERVER_TOOLKIT_FAILED_SERVICES_ALLOWLIST_FILE:-/etc/server-toolkit/failed-services.allowlist}"
FAILED_ALLOWLIST_EXTERNAL_STATUS=not_present
FAILED_ALLOWLIST_EXTERNAL_ENTRIES=0
FAILED_ALLOWLIST_LOADED_FOR=""
FAILED_ALLOWLIST_EXTERNAL_UNITS=()

# Built-in defaults preserve one-file distribution. The optional external file
# only adds exact unit names; it is never required for normal operation.
DEFAULT_INFORMATIONAL_UNITS=(
  apt-daily.service
  apt-daily-upgrade.service
  man-db.service
  motd-news.service
  logrotate.service
  fstrim.service
  e2scrub_all.service
  update-notifier-download.service
  snapd.seeded.service
)

is_builtin_informational_unit() {
  local unit="$1" item
  for item in "${DEFAULT_INFORMATIONAL_UNITS[@]}"; do
    [[ "$unit" == "$item" ]] && return 0
  done
  return 1
}

failed_allowlist_stat_uid() {
  stat -c %u -- "$1" 2>/dev/null || stat -f %u "$1" 2>/dev/null
}

failed_allowlist_stat_mode() {
  local mode
  if mode="$(stat -c %a -- "$1" 2>/dev/null)"; then
    printf '%s\n' "$mode"
    return 0
  fi
  mode="$(stat -f %Lp "$1" 2>/dev/null)" || return 1
  [[ "$mode" =~ ^[0-7]+$ ]] || return 1
  (( ${#mode} <= 4 )) || mode="${mode: -4}"
  mode="${mode#0}"
  printf '%s\n' "$mode"
}

failed_allowlist_parent_chain_is_safe() {
  local file="$1" expected_uid="$2" parent current component owner mode numeric
  local -a components=()
  parent="${file%/*}"
  [[ -n "$parent" ]] || parent=/
  IFS=/ read -r -a components <<<"${parent#/}"
  current=/
  for component in "${components[@]}"; do
    [[ -n "$component" ]] || continue
    current="${current%/}/$component"
    [[ -d "$current" && ! -L "$current" ]] || return 1
    owner="$(failed_allowlist_stat_uid "$current" || true)"
    mode="$(failed_allowlist_stat_mode "$current" || true)"
    [[ "$owner" =~ ^[0-9]+$ && "$mode" =~ ^[0-7]{3,4}$ ]] || return 1
    [[ "$owner" == 0 || "$owner" == "$expected_uid" ]] || return 1
    numeric=$((8#$mode))
    if (( (numeric & 0022) != 0 )); then
      (( owner == 0 && (numeric & 01000) != 0 )) || return 1
    fi
  done
}

load_external_failed_services_allowlist() {
  local expected_uid="${1:-0}"
  local line mode owner_uid group_digit other_digit invalid=0
  local -a candidate=()

  FAILED_ALLOWLIST_EXTERNAL_STATUS=not_present
  FAILED_ALLOWLIST_EXTERNAL_ENTRIES=0
  FAILED_ALLOWLIST_EXTERNAL_UNITS=()
  FAILED_ALLOWLIST_LOADED_FOR="$FAILED_SERVICES_ALLOWLIST_FILE"

  [[ "$expected_uid" =~ ^[0-9]+$ ]] || expected_uid=0
  [[ "$FAILED_SERVICES_ALLOWLIST_FILE" =~ ^/[A-Za-z0-9._/-]+$ &&
     ! "$FAILED_SERVICES_ALLOWLIST_FILE" =~ (^|/)\.\.?(/|$) &&
     "$FAILED_SERVICES_ALLOWLIST_FILE" != */ ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ ! -L "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ -e "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || return 0
  failed_allowlist_parent_chain_is_safe "$FAILED_SERVICES_ALLOWLIST_FILE" "$expected_uid" || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ -f "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  }
  [[ -r "$FAILED_SERVICES_ALLOWLIST_FILE" ]] || {
    FAILED_ALLOWLIST_EXTERNAL_STATUS=unreadable
    return 0
  }

  owner_uid="$(failed_allowlist_stat_uid "$FAILED_SERVICES_ALLOWLIST_FILE" || true)"
  if [[ ! "$owner_uid" =~ ^[0-9]+$ || "$owner_uid" != "$expected_uid" ]]; then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi

  mode="$(failed_allowlist_stat_mode "$FAILED_SERVICES_ALLOWLIST_FILE" || true)"
  if [[ ! "$mode" =~ ^[0-7]{3,4}$ ]]; then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi
  group_digit="${mode: -2:1}"
  other_digit="${mode: -1}"
  if (( (group_digit & 2) != 0 || (other_digit & 2) != 0 )); then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi

  while IFS= read -r line || [[ -n "$line" ]]; do
    line="$(printf '%s' "$line" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    [[ -n "$line" ]] || continue
    [[ "$line" == \#* ]] && continue
    if [[ ! "$line" =~ ^[^[:space:]#]+\.(service|socket|timer|mount|automount|swap|path|target|slice|scope|device)$ ]]; then
      invalid=1
      continue
    fi
    candidate+=("$line")
  done <"$FAILED_SERVICES_ALLOWLIST_FILE"

  if (( invalid != 0 )); then
    FAILED_ALLOWLIST_EXTERNAL_STATUS=invalid
    return 0
  fi

  FAILED_ALLOWLIST_EXTERNAL_UNITS=("${candidate[@]}")
  FAILED_ALLOWLIST_EXTERNAL_ENTRIES="${#FAILED_ALLOWLIST_EXTERNAL_UNITS[@]}"
  FAILED_ALLOWLIST_EXTERNAL_STATUS=loaded
}

ensure_external_failed_services_allowlist_loaded() {
  local expected_uid="${1:-0}"
  [[ "$FAILED_ALLOWLIST_LOADED_FOR" == "$FAILED_SERVICES_ALLOWLIST_FILE:$expected_uid" ]] ||
    load_external_failed_services_allowlist "$expected_uid"
  FAILED_ALLOWLIST_LOADED_FOR="$FAILED_SERVICES_ALLOWLIST_FILE:$expected_uid"
}

failed_services_allowlist_status() {
  ensure_external_failed_services_allowlist_loaded "${1:-0}"
  printf 'failed_allowlist_external_status=%s\n' "$FAILED_ALLOWLIST_EXTERNAL_STATUS"
  printf 'failed_allowlist_external_entries=%s\n' "$FAILED_ALLOWLIST_EXTERNAL_ENTRIES"
}

is_external_informational_unit() {
  local unit="$1" expected_uid="${2:-0}" item
  ensure_external_failed_services_allowlist_loaded "$expected_uid"
  [[ "$FAILED_ALLOWLIST_EXTERNAL_STATUS" == loaded ]] || return 1
  for item in "${FAILED_ALLOWLIST_EXTERNAL_UNITS[@]}"; do
    [[ "$unit" == "$item" ]] && return 0
  done
  return 1
}

service_role_context() {
  local unit="$1" role="${2:-generic}"
  case "$role:$unit" in
    web:nginx.service|web:apache2.service|web:caddy.service) printf 'role_relevant' ;;
    database:postgresql.service|database:mysql.service|database:mariadb.service) printf 'role_relevant' ;;
    vpn:x-ui.service|vpn:xray.service|proxy:x-ui.service|proxy:xray.service|xray:xray.service) printf 'role_relevant' ;;
    mail:postfix.service|mail:dovecot.service) printf 'role_relevant' ;;
    *) printf 'generic' ;;
  esac
}

service_severity() {
  local unit="$1" virt="${2:-unknown}" expected_uid="${3:-0}"
  case "$unit" in
    ssh.service|sshd.service|systemd-networkd.service|NetworkManager.service|networking.service|systemd-resolved.service)
      printf 'critical'
      ;;
    fwupd.service|fwupd-refresh.service)
      if [[ "$virt" != "none" && "$virt" != "unknown" && -n "$virt" ]]; then printf 'informational'; else printf 'unknown'; fi
      ;;
    *)
      if is_builtin_informational_unit "$unit" || is_external_informational_unit "$unit" "$expected_uid"; then
        printf 'informational'
      else
        printf 'unknown'
      fi
      ;;
  esac
}

classify_failed_service_line() {
  local unit="$1" virt="${2:-unknown}" role="${3:-generic}" expected_uid="${4:-0}"
  printf '%s|severity=%s|context=%s\n' "$unit" "$(service_severity "$unit" "$virt" "$expected_uid")" "$(service_role_context "$unit" "$role")"
}

classify_failed_services() {
  local names="${1:-}" virt="${2:-unknown}" role="${3:-generic}" expected_uid="${4:-0}"
  local service severity context
  FAILED_INFORMATIONAL_COUNT=0
  FAILED_UNKNOWN_COUNT=0
  FAILED_CRITICAL_COUNT=0
  FAILED_ROLE_RELEVANT_COUNT=0
  FAILED_INFORMATIONAL_NAMES=""
  FAILED_UNKNOWN_NAMES=""
  FAILED_CRITICAL_NAMES=""
  FAILED_ROLE_RELEVANT_NAMES=""
  ensure_external_failed_services_allowlist_loaded "$expected_uid"

  while IFS= read -r service; do
    [[ -n "$service" ]] || continue
    severity="$(service_severity "$service" "$virt" "$expected_uid")"
    context="$(service_role_context "$service" "$role")"
    case "$severity" in
      critical)
        FAILED_CRITICAL_COUNT=$((FAILED_CRITICAL_COUNT+1))
        FAILED_CRITICAL_NAMES+="${FAILED_CRITICAL_NAMES:+,}${service}"
        ;;
      informational)
        FAILED_INFORMATIONAL_COUNT=$((FAILED_INFORMATIONAL_COUNT+1))
        FAILED_INFORMATIONAL_NAMES+="${FAILED_INFORMATIONAL_NAMES:+,}${service}"
        ;;
      *)
        if [[ "$context" == role_relevant ]]; then
          FAILED_ROLE_RELEVANT_COUNT=$((FAILED_ROLE_RELEVANT_COUNT+1))
          FAILED_ROLE_RELEVANT_NAMES+="${FAILED_ROLE_RELEVANT_NAMES:+,}${service}"
        else
          FAILED_UNKNOWN_COUNT=$((FAILED_UNKNOWN_COUNT+1))
          FAILED_UNKNOWN_NAMES+="${FAILED_UNKNOWN_NAMES:+,}${service}"
        fi
        ;;
    esac
  done <<<"$names"
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  classify_failed_service_line "${1:?unit required}" "${2:-unknown}" "${3:-generic}"
fi
