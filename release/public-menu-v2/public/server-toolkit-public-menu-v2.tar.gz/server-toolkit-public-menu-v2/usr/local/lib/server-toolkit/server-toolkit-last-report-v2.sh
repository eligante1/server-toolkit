#!/bin/bash -p

# Read-only viewer for the newest finalized public audit report.
# Production always uses /var/server-toolkit. A different root is reachable
# only through the explicitly gated, source-only test entrypoint at EOF.

server_toolkit_last_report_v2_stat_uid() {
  /usr/bin/stat -c %u -- "$1" 2>/dev/null ||
    /usr/bin/stat -f %u "$1" 2>/dev/null
}

server_toolkit_last_report_v2_stat_mode() {
  local mode
  if mode="$(/usr/bin/stat -c %a -- "$1" 2>/dev/null)"; then
    printf '%s\n' "$mode"
    return 0
  fi
  mode="$(/usr/bin/stat -f %Lp "$1" 2>/dev/null)" || return 1
  mode="${mode#0}"
  printf '%s\n' "$mode"
}

server_toolkit_last_report_v2_stat_size() {
  /usr/bin/stat -c %s -- "$1" 2>/dev/null ||
    /usr/bin/stat -f %z "$1" 2>/dev/null
}

server_toolkit_last_report_v2_safe_parent_directory() {
  local path="$1" owner mode group_digit other_digit
  [[ -d "$path" && ! -L "$path" ]] || return 1
  owner="$(server_toolkit_last_report_v2_stat_uid "$path")" || return 1
  mode="$(server_toolkit_last_report_v2_stat_mode "$path")" || return 1
  [[ "$owner" == 0 && "$mode" =~ ^[0-7]{3,4}$ ]] || return 1
  group_digit="${mode: -2:1}"
  other_digit="${mode: -1}"
  [[ "$group_digit" != [2367] && "$other_digit" != [2367] ]]
}

server_toolkit_last_report_v2_validate_production_parent_chain() {
  [[ "$1" == /var/server-toolkit ]] || return 1
  server_toolkit_last_report_v2_safe_parent_directory / || return 1
  server_toolkit_last_report_v2_safe_parent_directory /var
}

server_toolkit_last_report_v2_validate_text_bytes() {
  local path="$1" maximum_lines="$2" maximum_line_bytes="$3" ascii_only="$4"
  local line_count
  [[ "$maximum_lines" =~ ^[0-9]+$ && "$maximum_line_bytes" =~ ^[0-9]+$ ]] || return 1
  [[ "$ascii_only" == 0 || "$ascii_only" == 1 ]] || return 1

  /usr/bin/od -An -v -t u1 -- "$path" 2>/dev/null | /usr/bin/awk -v ascii_only="$ascii_only" '
    {
      for (i = 1; i <= NF; i++) {
        byte = $i + 0
        if (byte == 0 || byte == 27 || byte == 127 ||
            (byte < 32 && byte != 10) || (ascii_only == 1 && byte > 127)) {
          exit 1
        }
      }
    }
  ' || return 1

  if [[ "$ascii_only" == 0 ]]; then
    /usr/bin/iconv -f UTF-8 -t UTF-8 -- "$path" >/dev/null 2>&1 || return 1
    /usr/bin/iconv -f UTF-8 -t UTF-32BE -- "$path" 2>/dev/null |
      /usr/bin/od -An -v -t x1 | /usr/bin/awk '
        function hex_value(character) {
          return index("0123456789abcdef", tolower(character)) - 1
        }
        {
          for (i = 1; i <= NF; i++) {
            if ($i !~ /^[0-9a-fA-F][0-9a-fA-F]$/) exit 1
            byte = hex_value(substr($i, 1, 1)) * 16 + hex_value(substr($i, 2, 1))
            codepoint = codepoint * 256 + byte
            octets++
            if (octets == 4) {
              if ((codepoint >= 128 && codepoint <= 159) || codepoint == 173 ||
                  codepoint == 1564 || (codepoint >= 8203 && codepoint <= 8207) ||
                  (codepoint >= 8232 && codepoint <= 8238) ||
                  (codepoint >= 8288 && codepoint <= 8303) || codepoint == 65279 ||
                  (codepoint >= 65529 && codepoint <= 65531) ||
                  (codepoint >= 64976 && codepoint <= 65007) ||
                  (codepoint % 65536 == 65534) || (codepoint % 65536 == 65535)) {
                exit 1
              }
              codepoint = 0
              octets = 0
            }
          }
        }
        END { if (octets != 0) exit 1 }
      ' || return 1
  fi
  line_count="$(LC_ALL=C /usr/bin/awk -v maximum_line_bytes="$maximum_line_bytes" '
    length($0) > maximum_line_bytes { exit 1 }
    END { if (NR == 0) exit 1; print NR }
  ' "$path")" || return 1
  [[ "$line_count" =~ ^[0-9]+$ ]] || return 1
  (( line_count <= maximum_lines ))
}

server_toolkit_last_report_v2_sha256() {
  local digest
  if [[ -x /usr/bin/sha256sum ]]; then
    digest="$(/usr/bin/sha256sum -- "$1" 2>/dev/null)" || return 1
    digest="${digest%% *}"
  elif [[ -x /usr/bin/shasum ]]; then
    digest="$(/usr/bin/shasum -a 256 -- "$1" 2>/dev/null)" || return 1
    digest="${digest%% *}"
  else
    return 1
  fi
  [[ "$digest" =~ ^[0-9a-f]{64}$ ]] || return 1
  printf '%s\n' "$digest"
}

server_toolkit_last_report_v2_safe_directory() {
  local path="$1" expected_uid="$2" expected_mode="$3" owner mode
  [[ -d "$path" && ! -L "$path" ]] || return 1
  owner="$(server_toolkit_last_report_v2_stat_uid "$path")" || return 1
  mode="$(server_toolkit_last_report_v2_stat_mode "$path")" || return 1
  [[ "$owner" == "$expected_uid" && "$mode" == "$expected_mode" ]]
}

server_toolkit_last_report_v2_safe_file() {
  local path="$1" expected_uid="$2" expected_mode="$3"
  local minimum="$4" maximum="$5" owner mode size
  [[ -f "$path" && ! -L "$path" ]] || return 1
  owner="$(server_toolkit_last_report_v2_stat_uid "$path")" || return 1
  mode="$(server_toolkit_last_report_v2_stat_mode "$path")" || return 1
  size="$(server_toolkit_last_report_v2_stat_size "$path")" || return 1
  [[ "$owner" == "$expected_uid" && "$mode" == "$expected_mode" ]] || return 1
  [[ "$size" =~ ^[0-9]+$ ]] || return 1
  (( size >= minimum && size <= maximum ))
}

server_toolkit_last_report_v2_verify_marker() {
  local marker="$1" expected_uid="$2" value
  server_toolkit_last_report_v2_safe_file "$marker" "$expected_uid" 600 30 30 ||
    return 1
  IFS= read -r value <"$marker" || return 1
  [[ "$value" == server-toolkit-report-root-v1 ]]
}

server_toolkit_last_report_v2_enumerate_root() {
  local root="$1"
  if /usr/bin/find "$root" -mindepth 1 -maxdepth 1 -print0 2>/dev/null; then
    # An empty NUL-delimited record is impossible for find -print0. It is the
    # completion sentinel consumed by select_newest; no sentinel means fail.
    printf '\0'
  fi
}

server_toolkit_last_report_v2_select_newest() {
  local root="$1" path base stamp selected="" selected_stamp="" tied=0
  local candidates=0 entries=0 enumeration_complete=0
  while IFS= read -r -d '' path; do
    if [[ -z "$path" ]]; then
      (( enumeration_complete == 0 )) || return 1
      enumeration_complete=1
      continue
    fi
    (( enumeration_complete == 0 )) || return 1
    entries=$((entries + 1))
    (( entries <= 2048 )) || return 1
    base="${path##*/}"
    if [[ "$base" =~ ^([A-Za-z0-9._-]{1,63})_([0-9]{8}T[0-9]{6}Z)_([0-9]+)_([0-9]+)_audit$ ]]; then
      candidates=$((candidates + 1))
      (( candidates <= 1024 )) || return 1
      stamp="${BASH_REMATCH[2]}"
      if [[ -z "$selected" || "$stamp" > "$selected_stamp" ]]; then
        selected="$path"
        selected_stamp="$stamp"
        tied=0
      elif [[ "$stamp" == "$selected_stamp" ]]; then
        tied=1
      fi
    fi
  done < <(server_toolkit_last_report_v2_enumerate_root "$root")
  (( enumeration_complete == 1 )) || return 1
  [[ -n "$selected" && "$tied" == 0 ]] || return 1
  printf '%s\n' "$selected"
}

server_toolkit_last_report_v2_parse_metadata() {
  local metadata="$1" line key value
  local server_seen=0 stamp_seen=0 mode_seen=0 version_seen=0 policy_seen=0
  local privacy_seen=0 sharing_seen=0 redaction_seen=0 summary_seen=0
  local readable_seen=0 full_seen=0

  STK_LAST_REPORT_META_SERVER=
  STK_LAST_REPORT_META_STAMP=
  STK_LAST_REPORT_META_VERSION=
  STK_LAST_REPORT_META_SUMMARY_SHA256=
  STK_LAST_REPORT_META_READABLE_SHA256=

  server_toolkit_last_report_v2_validate_text_bytes "$metadata" 32 512 1 || return 1

  while IFS= read -r line; do
    # The raw-byte validator above is the authoritative control-byte boundary.
    # This is an identity transform after successful validation and keeps the
    # mutation test sensitive to accidental removal of that boundary.
    [[ -n "$line" && "$line" == *=* ]] || return 1
    key="${line%%=*}"
    value="${line#*=}"
    case "$key" in
      server)
        (( server_seen == 0 )) || return 1
        [[ "$value" =~ ^[A-Za-z0-9._-]{1,63}$ ]] || return 1
        server_seen=1
        STK_LAST_REPORT_META_SERVER="$value"
        ;;
      stamp)
        (( stamp_seen == 0 )) || return 1
        [[ "$value" =~ ^[0-9]{8}T[0-9]{6}Z$ ]] || return 1
        stamp_seen=1
        STK_LAST_REPORT_META_STAMP="$value"
        ;;
      mode)
        (( mode_seen == 0 )) || return 1
        [[ "$value" == audit ]] || return 1
        mode_seen=1
        ;;
      version)
        (( version_seen == 0 )) || return 1
        [[ "$value" == 0.4.1-rc4-round2-audit-only-expert-beta1 ]] || return 1
        version_seen=1
        STK_LAST_REPORT_META_VERSION="$value"
        ;;
      audit_policy)
        (( policy_seen == 0 )) || return 1
        [[ "$value" == read_only ]] || return 1
        policy_seen=1
        ;;
      full_report_privacy)
        (( privacy_seen == 0 )) || return 1
        [[ "$value" == local_sensitive ]] || return 1
        privacy_seen=1
        ;;
      full_report_sharing_policy)
        (( sharing_seen == 0 )) || return 1
        [[ "$value" == manual_review_required ]] || return 1
        sharing_seen=1
        ;;
      redaction_scope)
        (( redaction_seen == 0 )) || return 1
        [[ "$value" == defense_in_depth_not_a_sharing_guarantee ]] || return 1
        redaction_seen=1
        ;;
      summary_sha256)
        (( summary_seen == 0 )) || return 1
        [[ "$value" =~ ^[0-9a-f]{64}$ ]] || return 1
        summary_seen=1
        STK_LAST_REPORT_META_SUMMARY_SHA256="$value"
        ;;
      readable_summary_sha256)
        (( readable_seen == 0 )) || return 1
        [[ "$value" =~ ^[0-9a-f]{64}$ ]] || return 1
        readable_seen=1
        STK_LAST_REPORT_META_READABLE_SHA256="$value"
        ;;
      full_report_sha256)
        (( full_seen == 0 )) || return 1
        [[ "$value" =~ ^[0-9a-f]{64}$ ]] || return 1
        full_seen=1
        ;;
      *)
        return 1
        ;;
    esac
  done < <(LC_ALL=C /usr/bin/tr -d '\000' <"$metadata")

  (( server_seen == 1 && stamp_seen == 1 && mode_seen == 1 &&
     version_seen == 1 && policy_seen == 1 && privacy_seen == 1 &&
     sharing_seen == 1 && redaction_seen == 1 && summary_seen == 1 &&
     readable_seen == 1 && full_seen == 1 ))
}

server_toolkit_last_report_v2_machine_value_once() {
  local file="$1" wanted="$2"
  /usr/bin/awk -v wanted="$wanted" '
    index($0, "=") > 1 {
      key = substr($0, 1, index($0, "=") - 1)
      if (key == wanted) {
        count++
        value = substr($0, index($0, "=") + 1)
      }
    }
    END {
      if (count != 1) exit 1
      print value
    }
  ' "$file"
}

server_toolkit_last_report_v2_parse_coverage_list() {
  local raw="$1" item remainder seen='|' count=0

  STK_LAST_REPORT_LIST_COUNT=0
  STK_LAST_REPORT_LIST_SET='|'
  [[ "$raw" != none ]] || return 0
  [[ "$raw" =~ ^[a-z][a-z0-9_]*(,[a-z][a-z0-9_]*)*$ ]] || return 1

  remainder="$raw"
  while [[ -n "$remainder" ]]; do
    if [[ "$remainder" == *,* ]]; then
      item="${remainder%%,*}"
      remainder="${remainder#*,}"
    else
      item="$remainder"
      remainder=
    fi
    case "$item" in
      cpu_sample|load_sample|kernel_journal|systemd_failed_services|apt_index|apt_simulation|network_check|storage_filesystem|storage_device_io|memory_pressure|cpu_pressure|network_counters|application_service_events)
        ;;
      *)
        return 1
        ;;
    esac
    [[ "$seen" != *"|$item|"* ]] || return 1
    seen="${seen}${item}|"
    count=$((count + 1))
    (( count <= 13 )) || return 1
  done

  STK_LAST_REPORT_LIST_COUNT="$count"
  STK_LAST_REPORT_LIST_SET="$seen"
}

server_toolkit_last_report_v2_parse_technical_summary() {
  local summary="$1" header mode policy status required completed missing limited
  local schema method expected_schema expected_method expected_required
  local missing_count limited_count limited_set item remainder

  STK_LAST_REPORT_SCOPE=
  STK_LAST_REPORT_COVERAGE_STATUS=
  STK_LAST_REPORT_COVERAGE_REQUIRED=
  STK_LAST_REPORT_COVERAGE_COMPLETED=

  server_toolkit_last_report_v2_validate_text_bytes "$summary" 2048 16384 0 || return 1
  LC_ALL=C /usr/bin/awk '
    NR == 1 {
      if ($0 !~ /^Server Toolkit v[A-Za-z0-9._+-]+$/) invalid = 1
      next
    }
    index($0, "=") < 2 { invalid = 1; next }
    {
      key = substr($0, 1, index($0, "=") - 1)
      value = substr($0, index($0, "=") + 1)
      if (key !~ /^[a-z][a-z0-9_]*$/ || seen[key]++) invalid = 1
      records++
    }
    END { exit (invalid || records == 0) }
  ' "$summary" || return 1

  IFS= read -r header <"$summary" || return 1
  [[ "$header" == "Server Toolkit v$STK_LAST_REPORT_META_VERSION" ]] || return 1
  case "$STK_LAST_REPORT_META_VERSION" in
    0.4.1-rc4-round2-audit-only-expert-beta1)
      expected_schema=10
      expected_method=diagnostic-app-service-v2
      expected_required=13
      ;;
    *)
      return 1
      ;;
  esac
  mode="$(server_toolkit_last_report_v2_machine_value_once "$summary" mode)" || return 1
  policy="$(server_toolkit_last_report_v2_machine_value_once "$summary" audit_policy)" || return 1
  schema="$(server_toolkit_last_report_v2_machine_value_once "$summary" diagnostic_schema_version)" || return 1
  method="$(server_toolkit_last_report_v2_machine_value_once "$summary" diagnostic_method_version)" || return 1
  status="$(server_toolkit_last_report_v2_machine_value_once "$summary" diagnostic_coverage_status)" || return 1
  required="$(server_toolkit_last_report_v2_machine_value_once "$summary" diagnostic_required_checks)" || return 1
  completed="$(server_toolkit_last_report_v2_machine_value_once "$summary" diagnostic_completed_checks)" || return 1
  missing="$(server_toolkit_last_report_v2_machine_value_once "$summary" diagnostic_missing_checks)" || return 1
  limited="$(server_toolkit_last_report_v2_machine_value_once "$summary" diagnostic_limited_checks)" || return 1

  [[ "$mode" == audit && "$policy" == read_only ]] || return 1
  [[ "$schema" == "$expected_schema" && "$method" == "$expected_method" ]] || return 1
  [[ "$status" =~ ^(complete|limited|partial)$ ]] || return 1
  [[ "$required" == "$expected_required" ]] || return 1
  case "$completed" in
    0|1|2|3|4|5|6|7|8|9|10|11|12|13) ;;
    *) return 1 ;;
  esac
  (( ${#missing} <= 512 && ${#limited} <= 512 )) || return 1

  server_toolkit_last_report_v2_parse_coverage_list "$missing" || return 1
  missing_count="$STK_LAST_REPORT_LIST_COUNT"
  server_toolkit_last_report_v2_parse_coverage_list "$limited" || return 1
  limited_count="$STK_LAST_REPORT_LIST_COUNT"
  limited_set="$STK_LAST_REPORT_LIST_SET"

  remainder="$missing"
  while [[ "$remainder" != none && -n "$remainder" ]]; do
    if [[ "$remainder" == *,* ]]; then
      item="${remainder%%,*}"
      remainder="${remainder#*,}"
    else
      item="$remainder"
      remainder=
    fi
    [[ "$limited_set" != *"|$item|"* ]] || return 1
  done
  (( completed + missing_count + limited_count == expected_required )) || return 1

  case "$status" in
    complete)
      (( completed == expected_required && missing_count == 0 && limited_count == 0 )) || return 1
      ;;
    limited)
      (( completed < expected_required && missing_count == 0 && limited_count > 0 )) || return 1
      ;;
    partial)
      (( completed < expected_required && missing_count > 0 )) || return 1
      ;;
  esac

  STK_LAST_REPORT_SCOPE=audit
  STK_LAST_REPORT_COVERAGE_STATUS="$status"
  STK_LAST_REPORT_COVERAGE_REQUIRED="$required"
  STK_LAST_REPORT_COVERAGE_COMPLETED="$completed"
}

server_toolkit_last_report_v2_stamp_epoch() {
  local stamp="$1" formatted epoch
  formatted="${stamp:0:4}-${stamp:4:2}-${stamp:6:2} ${stamp:9:2}:${stamp:11:2}:${stamp:13:2} UTC"
  if [[ -x /usr/bin/date ]] &&
     epoch="$(/usr/bin/date -u -d "$formatted" +%s 2>/dev/null)"; then
    :
  elif [[ -x /bin/date ]] &&
       epoch="$(/bin/date -j -u -f '%Y%m%dT%H%M%SZ' "$stamp" +%s 2>/dev/null)"; then
    :
  else
    return 1
  fi
  [[ "$epoch" =~ ^[0-9]+$ ]] || return 1
  printf '%s\n' "$epoch"
}

server_toolkit_last_report_v2_verified_view() {
  local root="$1" expected_uid="$2" now="$3"
  local marker run_dir latest_recheck base host stamp metadata readable summary
  local actual_hash actual_summary_hash stamp_epoch age iso_stamp coverage_text

  [[ "$root" == /* && "$root" != / && "$root" != */ ]] || return 1
  [[ "$expected_uid" =~ ^[0-9]+$ && "$now" =~ ^[0-9]+$ ]] || return 1
  server_toolkit_last_report_v2_safe_directory "$root" "$expected_uid" 700 || return 1
  marker="$root/.server-toolkit-report-root"
  server_toolkit_last_report_v2_verify_marker "$marker" "$expected_uid" || return 1

  run_dir="$(server_toolkit_last_report_v2_select_newest "$root")" || return 1
  base="${run_dir##*/}"
  [[ "$base" =~ ^([A-Za-z0-9._-]{1,63})_([0-9]{8}T[0-9]{6}Z)_([0-9]+)_([0-9]+)_audit$ ]] ||
    return 1
  host="${BASH_REMATCH[1]}"
  stamp="${BASH_REMATCH[2]}"
  server_toolkit_last_report_v2_safe_directory "$run_dir" "$expected_uid" 700 || return 1

  metadata="$run_dir/metadata.env"
  readable="$run_dir/readable-summary.txt"
  summary="$run_dir/technical-summary.txt"
  server_toolkit_last_report_v2_safe_file "$metadata" "$expected_uid" 600 1 65536 || return 1
  server_toolkit_last_report_v2_safe_file "$readable" "$expected_uid" 600 1 1048576 || return 1
  server_toolkit_last_report_v2_safe_file "$summary" "$expected_uid" 600 1 2097152 || return 1
  server_toolkit_last_report_v2_parse_metadata "$metadata" || return 1
  [[ "$STK_LAST_REPORT_META_SERVER" == "$host" &&
     "$STK_LAST_REPORT_META_STAMP" == "$stamp" ]] || return 1
  actual_hash="$(server_toolkit_last_report_v2_sha256 "$readable")" || return 1
  [[ "$actual_hash" == "$STK_LAST_REPORT_META_READABLE_SHA256" ]] || return 1
  actual_summary_hash="$(server_toolkit_last_report_v2_sha256 "$summary")" || return 1
  [[ "$actual_summary_hash" == "$STK_LAST_REPORT_META_SUMMARY_SHA256" ]] || return 1
  server_toolkit_last_report_v2_validate_text_bytes "$readable" 512 512 0 || return 1
  server_toolkit_last_report_v2_parse_technical_summary "$summary" || return 1

  stamp_epoch="$(server_toolkit_last_report_v2_stamp_epoch "$stamp")" || return 1
  (( stamp_epoch <= now )) || return 1
  age=$((now - stamp_epoch))
  iso_stamp="${stamp:0:4}-${stamp:4:2}-${stamp:6:2}T${stamp:9:2}:${stamp:11:2}:${stamp:13:2}Z"

  # Recheck the trusted boundary immediately before emitting report bytes.
  server_toolkit_last_report_v2_safe_directory "$root" "$expected_uid" 700 || return 1
  server_toolkit_last_report_v2_verify_marker "$marker" "$expected_uid" || return 1
  server_toolkit_last_report_v2_safe_directory "$run_dir" "$expected_uid" 700 || return 1
  server_toolkit_last_report_v2_safe_file "$metadata" "$expected_uid" 600 1 65536 || return 1
  server_toolkit_last_report_v2_safe_file "$readable" "$expected_uid" 600 1 1048576 || return 1
  server_toolkit_last_report_v2_safe_file "$summary" "$expected_uid" 600 1 2097152 || return 1
  server_toolkit_last_report_v2_parse_metadata "$metadata" || return 1
  [[ "$STK_LAST_REPORT_META_SERVER" == "$host" &&
     "$STK_LAST_REPORT_META_STAMP" == "$stamp" ]] || return 1
  actual_hash="$(server_toolkit_last_report_v2_sha256 "$readable")" || return 1
  [[ "$actual_hash" == "$STK_LAST_REPORT_META_READABLE_SHA256" ]] || return 1
  actual_summary_hash="$(server_toolkit_last_report_v2_sha256 "$summary")" || return 1
  [[ "$actual_summary_hash" == "$STK_LAST_REPORT_META_SUMMARY_SHA256" ]] || return 1
  server_toolkit_last_report_v2_validate_text_bytes "$readable" 512 512 0 || return 1
  server_toolkit_last_report_v2_parse_technical_summary "$summary" || return 1
  latest_recheck="$(server_toolkit_last_report_v2_select_newest "$root")" || return 1
  [[ "$latest_recheck" == "$run_dir" ]] || return 1

  coverage_text="${STK_LAST_REPORT_COVERAGE_STATUS} ${STK_LAST_REPORT_COVERAGE_COMPLETED}/${STK_LAST_REPORT_COVERAGE_REQUIRED}"

  printf '%s\n' \
    'ИСТОРИЧЕСКИЙ ОТЧЁТ — НЕ ТЕКУЩАЯ ПРОВЕРКА' \
    "Время отчёта (UTC): $iso_stamp" \
    "Возраст отчёта: $age сек." \
    "Область: scope=${STK_LAST_REPORT_SCOPE}; только проверенная readable-summary; текущее состояние сервера не подтверждается." \
    "Покрытие: $coverage_text" \
    ''
  /bin/cat -- "$readable"
}

server_toolkit_last_report_v2_main() {
  local now rc=0
  if (( $# != 1 )) || [[ "$1" != last-report ]]; then
    printf '%s\n' 'ERROR: expected exactly: server-toolkit last-report' >&2
    return 2
  fi
  if (( EUID != 0 )); then
    printf '%s\n' 'ERROR: last-report requires the protected root-owned report boundary.' >&2
    return 1
  fi
  now="$(/usr/bin/date -u +%s 2>/dev/null)" || return 1
  server_toolkit_last_report_v2_validate_production_parent_chain /var/server-toolkit || return 1
  server_toolkit_last_report_v2_verified_view /var/server-toolkit 0 "$now" || rc=$?
  if (( rc != 0 )); then
    printf '%s\n' 'ERROR: no verified last report is available.' >&2
    return 1
  fi
}

_server_toolkit_last_report_v2_sourced=0
if (return 0 2>/dev/null); then
  _server_toolkit_last_report_v2_sourced=1
fi

if (( _server_toolkit_last_report_v2_sourced == 1 )); then
  unset -f server_toolkit_last_report_v2_test_main 2>/dev/null || true
  unset -f server_toolkit_last_report_v2_test_partial_enumerator_failure 2>/dev/null || true
  if [[ "${SERVER_TOOLKIT_LAST_REPORT_V2_TEST_HOOK:-}" == source-only-explicit-test-root &&
        "${SERVER_TOOLKIT_PRODUCTION_MODE:-0}" != 1 &&
        "${SERVER_TOOLKIT_ENVIRONMENT_CLEAN:-0}" != 1 ]]; then
    server_toolkit_last_report_v2_test_main() {
      if (( $# != 3 )); then
        return 2
      fi
      [[ "${SERVER_TOOLKIT_LAST_REPORT_V2_TEST_HOOK:-}" == source-only-explicit-test-root &&
         "${SERVER_TOOLKIT_PRODUCTION_MODE:-0}" != 1 &&
         "${SERVER_TOOLKIT_ENVIRONMENT_CLEAN:-0}" != 1 ]] || return 126
      server_toolkit_last_report_v2_verified_view "$1" "$2" "$3"
    }
    server_toolkit_last_report_v2_test_partial_enumerator_failure() (
      if (( $# != 4 )); then
        return 2
      fi
      [[ "${SERVER_TOOLKIT_LAST_REPORT_V2_TEST_HOOK:-}" == source-only-explicit-test-root &&
         "${SERVER_TOOLKIT_PRODUCTION_MODE:-0}" != 1 &&
         "${SERVER_TOOLKIT_ENVIRONMENT_CLEAN:-0}" != 1 ]] || return 126
      STK_LAST_REPORT_TEST_PARTIAL_PATH="$4"
      server_toolkit_last_report_v2_enumerate_root() {
        printf '%s\0' "$STK_LAST_REPORT_TEST_PARTIAL_PATH"
        return 1
      }
      server_toolkit_last_report_v2_verified_view "$1" "$2" "$3"
    )
  fi
  unset _server_toolkit_last_report_v2_sourced
  return 0
fi

unset _server_toolkit_last_report_v2_sourced
set -Eeuo pipefail
IFS=$'\n\t'
PATH=/usr/bin:/bin:/usr/sbin:/sbin
unset CDPATH GLOBIGNORE BASH_ENV ENV
LC_ALL=C
LANG=C
export IFS PATH LC_ALL LANG
server_toolkit_last_report_v2_main "$@"
