# Server Toolkit "Sonar" terminal presentation primitives.
# This module renders already-computed data only. It must not inspect the
# system, classify diagnostics, or alter machine-readable report contracts.
# shellcheck shell=bash

SONAR_MIN_WIDTH=34
SONAR_PRODUCTION_MIN_WIDTH=60
SONAR_MAX_WIDTH=72
SONAR_LAYOUT_THRESHOLD=52
SONAR_COLUMNS=80
SONAR_WIDTH=56
SONAR_UNICODE=1
SONAR_COLOR=0
SONAR_UTF8_LOCALE=C
SONAR_SCREEN_ACTIVE=0
SONAR_PRESENTATION_READY=0
SONAR_RESTORE_IN_PROGRESS=0
SONAR_HEARTBEAT_DISABLED_FILE=""
SONAR_RENDER_LOCK_DIR=""
SONAR_RENDER_LOCK_OWNED=0
SONAR_RENDER_LOCK_DEPTH=0
SONAR_ACTIVE_GROUP=-1
SONAR_STARTED_AT=0
SONAR_LAST_TICK=0
SONAR_LAST_DONE=0
SONAR_LAST_TOTAL=29
SONAR_HOST=""
SONAR_OUTPUT_FD=2

SONAR_AUDIT_ROWS=(
  "Сервер и система"
  "Процессор"
  "Память"
  "Диски"
  "Сеть и маршруты"
  "Обновления"
  "Службы"
  "Безопасность"
  "Отчёт"
)
# shellcheck disable=SC2034 # retained for the presentation group metadata contract
SONAR_GROUP_TOTALS=(3 2 1 1 9 3 4 3 3)
SONAR_GROUP_DONE=(0 0 0 0 0 0 0 0 0)
SONAR_GROUP_VALUES=("" "" "" "" "" "" "" "" "")
SONAR_GROUP_STATES=("" "" "" "" "" "" "" "" "")

sonar_repeat() {
  local glyph="$1" count="$2" result="" i
  (( count < 0 )) && count=0
  for ((i=0; i<count; i++)); do result="${result}${glyph}"; done
  printf '%s' "$result"
}

sonar_configure_symbols() {
  if (( SONAR_UNICODE == 1 )); then
    SONAR_TL='┌'; SONAR_H='─'; SONAR_TR='┐'; SONAR_V='│'
    SONAR_BL='└'; SONAR_BR='┘'; SONAR_ML='├'; SONAR_MR='┤'
    SONAR_BAR_LEFT='◄'; SONAR_BAR_RIGHT='►'
    SONAR_BAR_FULL='▓'; SONAR_BAR_EMPTY='░'
    SONAR_ELLIPSIS='…'; SONAR_POINTER='▸'
  else
    SONAR_TL='+'; SONAR_H='-'; SONAR_TR='+'; SONAR_V='|'
    SONAR_BL='+'; SONAR_BR='+'; SONAR_ML='+'; SONAR_MR='+'
    SONAR_BAR_LEFT='<'; SONAR_BAR_RIGHT='>'
    SONAR_BAR_FULL='#'; SONAR_BAR_EMPTY='.'
    SONAR_ELLIPSIS='>'; SONAR_POINTER='>'
  fi
}

sonar_runtime_configure() {
  local run_dir="$1"
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
  [[ "$run_dir" == /* && "$run_dir" != *$'\n'* &&
     -d "$run_dir" && ! -L "$run_dir" ]] || return 2
  SONAR_HEARTBEAT_DISABLED_FILE="$run_dir/.sonar-heartbeat-disabled"
  SONAR_RENDER_LOCK_DIR="$run_dir/.sonar-render-lock"
  if [[ ! -e "$SONAR_HEARTBEAT_DISABLED_FILE" &&
        ! -L "$SONAR_HEARTBEAT_DISABLED_FILE" &&
        ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]; then
    return 0
  fi
  SONAR_HEARTBEAT_DISABLED_FILE=""
  SONAR_RENDER_LOCK_DIR=""
  return 2
}

sonar_render_lock_acquire() {
  local attempt
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || return 0
  if (( SONAR_RENDER_LOCK_OWNED == 1 )); then
    SONAR_RENDER_LOCK_DEPTH=$((SONAR_RENDER_LOCK_DEPTH+1))
    return 0
  fi
  for ((attempt=0; attempt<200; attempt++)); do
    if /bin/mkdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null; then
      SONAR_RENDER_LOCK_OWNED=1
      SONAR_RENDER_LOCK_DEPTH=1
      return 0
    fi
    if [[ ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]; then
      # The current owner can release between our failed mkdir and inspection.
      # That is ordinary contention, not an unsafe path type; retry boundedly.
      /bin/sleep 0.01
      continue
    fi
    [[ -d "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]] ||
      return 2
    /bin/sleep 0.01
  done
  return 2
}

sonar_render_lock_release() {
  (( SONAR_RENDER_LOCK_OWNED == 1 )) || return 0
  if (( SONAR_RENDER_LOCK_DEPTH > 1 )); then
    SONAR_RENDER_LOCK_DEPTH=$((SONAR_RENDER_LOCK_DEPTH-1))
    return 0
  fi
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || {
    SONAR_RENDER_LOCK_OWNED=0
    SONAR_RENDER_LOCK_DEPTH=0
    return 2
  }
  /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null || return 2
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
}

sonar_render_lock_exit_release() {
  (( SONAR_RENDER_LOCK_OWNED == 1 )) || return 0
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || return 2
  /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null || return 2
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
}

sonar_recover_stale_render_lock() {
  (( SONAR_RENDER_LOCK_OWNED == 0 && SONAR_RENDER_LOCK_DEPTH == 0 )) || return 2
  [[ -n "$SONAR_RENDER_LOCK_DIR" ]] || return 0
  if [[ ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]; then
    return 0
  fi
  [[ -d "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]] ||
    return 2
  # Only an empty lock directory is recoverable. This is called exclusively
  # after the heartbeat identity has been verified and its death proven. A
  # concurrent owner-aware EXIT unlock may win the rmdir race; absence is the
  # same safe end state.
  if /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null; then
    return 0
  fi
  [[ ! -e "$SONAR_RENDER_LOCK_DIR" && ! -L "$SONAR_RENDER_LOCK_DIR" ]]
}

sonar_disable_heartbeat_updates() {
  [[ -n "$SONAR_HEARTBEAT_DISABLED_FILE" ]] || return 2
  if [[ -e "$SONAR_HEARTBEAT_DISABLED_FILE" ||
        -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]; then
    [[ -f "$SONAR_HEARTBEAT_DISABLED_FILE" &&
       ! -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]
    return
  fi
  (umask 077; set -o noclobber; : >"$SONAR_HEARTBEAT_DISABLED_FILE") \
    2>/dev/null || return 2
  [[ -f "$SONAR_HEARTBEAT_DISABLED_FILE" &&
     ! -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]
}

sonar_heartbeat_updates_disabled() {
  [[ -n "$SONAR_HEARTBEAT_DISABLED_FILE" ]] || return 1
  [[ -e "$SONAR_HEARTBEAT_DISABLED_FILE" ||
     -L "$SONAR_HEARTBEAT_DISABLED_FILE" ]]
}

sonar_runtime_cleanup() {
  local rc=0
  if (( SONAR_RENDER_LOCK_OWNED == 1 )); then
    sonar_render_lock_exit_release || rc=2
  fi
  if [[ -n "$SONAR_HEARTBEAT_DISABLED_FILE" ]]; then
    /bin/rm -f -- "$SONAR_HEARTBEAT_DISABLED_FILE" 2>/dev/null || rc=2
  fi
  if [[ -n "$SONAR_RENDER_LOCK_DIR" &&
        ( -e "$SONAR_RENDER_LOCK_DIR" || -L "$SONAR_RENDER_LOCK_DIR" ) ]]; then
    /bin/rmdir -- "$SONAR_RENDER_LOCK_DIR" 2>/dev/null || rc=2
  fi
  SONAR_HEARTBEAT_DISABLED_FILE=""
  SONAR_RENDER_LOCK_DIR=""
  SONAR_RENDER_LOCK_OWNED=0
  SONAR_RENDER_LOCK_DEPTH=0
  return "$rc"
}

sonar_set_width() {
  local columns="$1"
  [[ "$columns" =~ ^[0-9]+$ ]] || columns=80
  # shellcheck disable=SC2034 # retained for the shared presentation state contract
  SONAR_COLUMNS="$columns"
  if (( columns < SONAR_MIN_WIDTH )); then
    SONAR_WIDTH="$SONAR_MIN_WIDTH"
    return 1
  fi
  SONAR_WIDTH="$columns"
  (( SONAR_WIDTH > SONAR_MAX_WIDTH )) && SONAR_WIDTH="$SONAR_MAX_WIDTH"
  return 0
}

sonar_text_length() {
  local text="$1"
  local LC_ALL="$SONAR_UTF8_LOCALE"
  printf '%s' "${#text}"
}

sonar_truncate() {
  local text="$1" width="$2" length
  local LC_ALL="$SONAR_UTF8_LOCALE"
  (( width > 0 )) || return 0
  length="${#text}"
  if (( length <= width )); then
    printf '%s' "$text"
  elif (( width == 1 )); then
    printf '%s' "$SONAR_ELLIPSIS"
  else
    printf '%s%s' "${text:0:width-1}" "$SONAR_ELLIPSIS"
  fi
}

sonar_fit() {
  local text="$1" width="$2" fitted length
  local LC_ALL="$SONAR_UTF8_LOCALE"
  fitted="$(sonar_truncate "$text" "$width")"
  length="${#fitted}"
  printf '%s' "$fitted"
  sonar_repeat ' ' $((width-length))
}

sonar_colour() {
  local role="$1"
  (( SONAR_COLOR == 1 )) || return 0
  case "$role" in
    background) printf '\033[48;2;10;14;8m' ;;
    primary) printf '\033[38;2;159;191;127m' ;;
    muted) printf '\033[38;2;74;92;54m' ;;
    active) printf '\033[38;2;232;255;192m' ;;
    attention) printf '\033[38;2;255;200;74m' ;;
    failure) printf '\033[1;38;2;255;122;82m' ;;
    reset) printf '\033[0m' ;;
  esac
}

sonar_state_role() {
  case "$1" in
    внимание) printf 'attention' ;;
    СБОЙ) printf 'failure' ;;
    ок|"нет данных"|"") printf 'muted' ;;
    *) printf 'active' ;;
  esac
}

sonar_state_is_valid() {
  case "$1" in
    ""|ок|внимание|СБОЙ|"нет данных") return 0 ;;
    *) return 1 ;;
  esac
}

sonar_spinner_glyph() {
  local tick="$1"
  local -a unicode_spinner=('/' '|' '\\' '|')
  local -a ascii_spinner=('/' '|' '\\' '|')
  if (( SONAR_UNICODE == 1 )); then
    printf '%s' "${unicode_spinner[$((tick % 4))]}"
  else
    printf '%s' "${ascii_spinner[$((tick % 4))]}"
  fi
}

sonar_frame_top() {
  local title="$1" available title_length fill
  available=$((SONAR_WIDTH-5))
  title="$(sonar_truncate "$title" "$available")"
  title_length="$(sonar_text_length "$title")"
  fill=$((SONAR_WIDTH-title_length-5))
  printf '%s%s%s%s %s %s%s%s%s\n' \
    "$(sonar_colour primary)" "$SONAR_TL" "$SONAR_H" \
    "$(sonar_colour reset)$(sonar_colour primary)" "$title" \
    "$(sonar_repeat "$SONAR_H" "$fill")" "$SONAR_TR" \
    "$(sonar_colour reset)" ""
}

sonar_frame_bottom() {
  printf '%s%s%s%s%s\n' "$(sonar_colour primary)" "$SONAR_BL" \
    "$(sonar_repeat "$SONAR_H" $((SONAR_WIDTH-2)))" "$SONAR_BR" \
    "$(sonar_colour reset)"
}

sonar_separator() {
  printf '%s%s%s%s%s\n' "$(sonar_colour primary)" "$SONAR_ML" \
    "$(sonar_repeat "$SONAR_H" $((SONAR_WIDTH-2)))" "$SONAR_MR" \
    "$(sonar_colour reset)"
}

sonar_box_text() {
  local text="$1" role="${2:-primary}" content
  content="$(sonar_fit "$text" $((SONAR_WIDTH-4)))"
  printf '%s%s%s %s%s%s %s%s%s\n' \
    "$(sonar_colour primary)" "$SONAR_V" "$(sonar_colour reset)" \
    "$(sonar_colour "$role")" "$content" "$(sonar_colour reset)" \
    "$(sonar_colour primary)" "$SONAR_V" "$(sonar_colour reset)"
}

sonar_blank() {
  sonar_box_text "" primary
}

sonar_progress_text() {
  local done="$1" total="$2" elapsed="$3" suffix bar_width filled empty
  local clock minutes seconds
  [[ "$done" =~ ^[0-9]+$ ]] || done=0
  [[ "$total" =~ ^[1-9][0-9]*$ ]] || total=1
  (( done > total )) && done="$total"
  [[ "$elapsed" =~ ^[0-9]+$ ]] || elapsed=0
  (( elapsed > 5999 )) && elapsed=5999
  minutes=$((elapsed/60)); seconds=$((elapsed%60))
  printf -v clock '%02d:%02d' "$minutes" "$seconds"
  suffix="  ${done}/${total}   ${clock}"
  bar_width=$((SONAR_WIDTH-6-${#suffix}))
  (( bar_width < 1 )) && bar_width=1
  filled=$((bar_width*done/total)); empty=$((bar_width-filled))
  printf '%s%s%s%s%s%s%s%s%s%s' \
    "$(sonar_colour primary)" "$SONAR_V " "$SONAR_BAR_LEFT" \
    "$(sonar_repeat "$SONAR_BAR_FULL" "$filled")" \
    "$(sonar_colour muted)" "$(sonar_repeat "$SONAR_BAR_EMPTY" "$empty")" \
    "$(sonar_colour primary)" "$SONAR_BAR_RIGHT" "$suffix" \
    "$(sonar_fit '' $((SONAR_WIDTH-3-bar_width-2-${#suffix})))${SONAR_V}$(sonar_colour reset)"
}

sonar_render_progress() {
  sonar_progress_text "$@"
  printf '\n'
}

sonar_name_parts() {
  local name="$1" width="$2" length dots
  local LC_ALL="$SONAR_UTF8_LOCALE"
  SONAR_NAME_LABEL=""
  SONAR_NAME_DOTS=""
  length="${#name}"
  if (( length >= width-1 )); then
    SONAR_NAME_LABEL="$(sonar_truncate "$name" "$width")"
    return 0
  fi
  dots=$((width-length-1))
  SONAR_NAME_LABEL="${name} "
  SONAR_NAME_DOTS="$(sonar_repeat '.' "$dots")"
}

sonar_render_check() {
  local name="$1" value="$2" state="$3" active="${4:-0}"
  local name_width value_field state_field state_role
  if (( active == 1 )); then
    state="$(sonar_spinner_glyph "$SONAR_LAST_TICK")"
    state_role=active
  else
    sonar_state_is_valid "$state" || return 2
    state_role="$(sonar_state_role "$state")"
  fi
  if (( SONAR_WIDTH >= SONAR_LAYOUT_THRESHOLD )); then
    name_width=$((SONAR_WIDTH-28))
  else
    name_width=$((SONAR_WIDTH-15))
  fi
  sonar_name_parts "$name" "$name_width"
  state_field="$(sonar_fit "$state" 10)"
  printf '%s%s%s %s%s%s%s%s' \
    "$(sonar_colour primary)" "$SONAR_V" "$(sonar_colour reset)" \
    "$(sonar_colour primary)" "$SONAR_NAME_LABEL" \
    "$(sonar_colour muted)" "$SONAR_NAME_DOTS" "$(sonar_colour reset)"
  if (( SONAR_WIDTH >= SONAR_LAYOUT_THRESHOLD )); then
    value_field="$(sonar_fit "$value" 12)"
    printf ' %s%s%s ' "$(sonar_colour primary)" "$value_field" "$(sonar_colour reset)"
  else
    printf ' '
  fi
  printf '%s%s%s %s%s%s\n' "$(sonar_colour "$state_role")" "$state_field" \
    "$(sonar_colour reset)" "$(sonar_colour primary)" "$SONAR_V" \
    "$(sonar_colour reset)"
}

sonar_render_footer() {
  sonar_box_text "$1" "${2:-muted}"
}

sonar_render_input() {
  sonar_box_text "$1 ${SONAR_POINTER} _" active
}

sonar_render_menu() {
  local version="${1:-v0.4.1}"
  sonar_frame_top "SERVER TOOLKIT · ${version}"
  sonar_blank
  sonar_box_text "  [1] Полный аудит"
  sonar_box_text "  [2] Быстрая проверка"
  sonar_box_text "  [3] Последний отчёт"
  sonar_blank
  sonar_box_text "  [0] Выход"
  sonar_blank
  sonar_separator
  sonar_render_input "ВЫБОР"
  sonar_frame_bottom
}

sonar_render_self_check() {
  local outcome="$1" admin_value="$2" admin_state="$3"
  local commands_value="$4" commands_state="$5"
  local space_value="$6" space_state="$7"
  local terminal_value="$8" terminal_state="$9"
  local footer1="${10}" footer2="${11:-}"
  case "$outcome" in
    ready|no-admin|missing-command) ;;
    *) return 2 ;;
  esac
  sonar_state_is_valid "$admin_state" || return 2
  sonar_state_is_valid "$commands_state" || return 2
  sonar_state_is_valid "$space_state" || return 2
  sonar_state_is_valid "$terminal_state" || return 2
  sonar_frame_top 'SERVER TOOLKIT · САМОПРОВЕРКА'
  sonar_blank
  sonar_render_check 'Права администратора' "$admin_value" "$admin_state"
  sonar_render_check 'Требуемые команды' "$commands_value" "$commands_state"
  sonar_render_check 'Место для отчёта' "$space_value" "$space_state"
  sonar_render_check 'Терминал' "$terminal_value" "$terminal_state"
  sonar_blank
  sonar_separator
  sonar_render_footer "$footer1"
  [[ -z "$footer2" ]] || sonar_render_footer "$footer2"
  sonar_frame_bottom
}

sonar_reset_audit_state() {
  SONAR_GROUP_DONE=(0 0 0 0 0 0 0 0 0)
  SONAR_GROUP_VALUES=("" "" "" "" "" "" "" "" "")
  SONAR_GROUP_STATES=("" "" "" "" "" "" "" "")
  SONAR_ACTIVE_GROUP=-1
  SONAR_LAST_TICK=0
}

sonar_group_for_stage() {
  case "$1" in
    'Сервер и система'|'Подробности системы'|'Время работы') printf '0' ;;
    'Процессор'|'Нагрузка процессора') printf '1' ;;
    'Память') printf '2' ;;
    'Диски') printf '3' ;;
    'Сетевые интерфейсы'|'Внешний адрес'|'DNS'|'Сетевые порты'|'Анализ портов'|'Межсетевой экран'|'Системное время'|'Задержка сети'|'Скорость доступа') printf '4' ;;
    'Индекс пакетов'|'Состояние пакетов'|'Проверка обновления') printf '5' ;;
    'Состояние служб'|'Повторные сбои служб'|'Системные ошибки'|'Предупреждения ядра') printf '6' ;;
    'Базовая безопасность'|'Виртуализация'|'Внешний шум SSH') printf '7' ;;
    *) printf '8' ;;
  esac
}

sonar_begin_stage() {
  SONAR_ACTIVE_GROUP="$(sonar_group_for_stage "$1")"
}

sonar_finish_stage() {
  local stage="$1" outcome="$2" group
  : "$outcome"
  group="$(sonar_group_for_stage "$stage")"
  SONAR_GROUP_DONE[$group]=$(( ${SONAR_GROUP_DONE[$group]:-0} + 1 ))
  SONAR_ACTIVE_GROUP=-1
}

sonar_render_audit() {
  local host="${1:-}" done="${2:-0}" total="${3:-29}" elapsed="${4:-0}"
  local active="${5:--1}" tick="${6:-0}" index
  SONAR_LAST_TICK="$tick"
  sonar_frame_top "SERVER TOOLKIT · АУДИТ${host:+ · $host}"
  sonar_render_progress "$done" "$total" "$elapsed"
  sonar_blank
  for ((index=0; index<${#SONAR_AUDIT_ROWS[@]}; index++)); do
    if (( index == active )); then
      sonar_render_check "${SONAR_AUDIT_ROWS[$index]}" "${SONAR_GROUP_VALUES[$index]:-}" "" 1
    else
      sonar_render_check "${SONAR_AUDIT_ROWS[$index]}" "${SONAR_GROUP_VALUES[$index]:-}" "${SONAR_GROUP_STATES[$index]:-}"
    fi
  done
  sonar_frame_bottom
}

sonar_result_collect_rows() {
  local encoded name value state target count=0
  shift 8
  SONAR_RESULT_ROWS=()
  for target in СБОЙ внимание 'нет данных'; do
    for encoded in "$@"; do
      name="${encoded%%|*}"
      value="${encoded#*|}"; value="${value%%|*}"
      state="${encoded##*|}"
      [[ "$state" == "$target" ]] || continue
      SONAR_RESULT_ROWS[$count]="${name}|${value}|${state}"
      count=$((count+1))
      (( count >= 5 )) && return 0
    done
  done
}

sonar_render_result() {
  local host="$1" done="$2" total="$3" elapsed="$4" report_path="$5"
  local failures="$6" warnings="$7" missing="$8"
  local encoded name value state
  shift 8
  sonar_result_collect_rows "$host" "$done" "$total" "$elapsed" "$report_path" "$failures" "$warnings" "$missing" "$@"
  sonar_frame_top "SERVER TOOLKIT · РЕЗУЛЬТАТ${host:+ · $host}"
  sonar_render_progress "$done" "$total" "$elapsed"
  sonar_blank
  for encoded in "${SONAR_RESULT_ROWS[@]}"; do
    name="${encoded%%|*}"
    value="${encoded#*|}"; value="${value%%|*}"
    state="${encoded##*|}"
    sonar_render_check "$name" "$value" "$state"
  done
  (( ${#SONAR_RESULT_ROWS[@]} > 0 )) || sonar_blank
  sonar_separator
  sonar_render_footer "Проверено ${done} из ${total} · сбой ${failures} · внимание ${warnings} · нет данных ${missing}"
  sonar_render_footer "Отчёт ${SONAR_POINTER} ${report_path}"
  sonar_frame_bottom
}

sonar_elapsed_seconds() {
  local now elapsed
  if ! [[ "$SONAR_STARTED_AT" =~ ^[1-9][0-9]*$ ]]; then
    printf '0'
    return 0
  fi
  now="$(date +%s)"
  elapsed=$((now-SONAR_STARTED_AT))
  (( elapsed < 0 )) && elapsed=0
  printf '%s' "$elapsed"
}

sonar_stdout_is_tty() {
  [[ -t 1 ]]
}

sonar_presentation_ready_for_result() {
  (( SONAR_PRESENTATION_READY == 1 )) || return 1
  (( PROGRESS_INTERACTIVE == 1 )) || return 1
  [[ "$SONAR_STARTED_AT" =~ ^[1-9][0-9]*$ ]] || return 1
  case "${PROGRESS_MODE:-off}" in
    off|plain) return 1 ;;
  esac
  sonar_heartbeat_updates_disabled && return 1
  sonar_stdout_is_tty
}

sonar_render_result_if_tty() {
  local columns
  sonar_presentation_ready_for_result || return 0
  if [[ "${PROGRESS_PRESENTATION_INPUT_VALIDATED:-0}" != 1 && "${TERM:-dumb}" == dumb ]]; then
    return 0
  fi
  columns="$(progress_terminal_columns)"
  sonar_set_width "$columns" || return 0
  sonar_configure_symbols
  sonar_render_result "$@"
}

sonar_summary_value_once() {
  local file="$1" key="$2"
  awk -F= -v key="$key" '
    $1==key { count++; value=substr($0,index($0,"=")+1) }
    END { if(count!=1) exit 1; print value }
  ' "$file"
}

sonar_render_summary_result_if_tty() {
  local summary="$1" host="$2" done="$3" total="$4" elapsed="$5" report_path="$6"
  local findings rank code verdict observed unit state failures=0 warnings=0 missing=0
  local -a rows=()
  sonar_presentation_ready_for_result || return 0
  findings="$(sonar_summary_value_once "$summary" findings_total)" || return 2
  [[ "$findings" =~ ^[0-9]+$ ]] || return 2
  (( findings <= 256 )) || return 2
  for ((rank=1; rank<=findings; rank++)); do
    code="$(sonar_summary_value_once "$summary" "finding_${rank}_code")" || return 2
    verdict="$(sonar_summary_value_once "$summary" "finding_${rank}_verdict")" || return 2
    observed="$(sonar_summary_value_once "$summary" "finding_${rank}_observed_value")" || return 2
    unit="$(sonar_summary_value_once "$summary" "finding_${rank}_unit")" || return 2
    case "$code" in
      *INCOMPLETE*|*UNAVAILABLE*|DIAGNOSTIC_EVIDENCE_LIMITED)
        state='нет данных'; missing=$((missing+1))
        ;;
      *)
        case "$verdict" in
          FAIL) state=СБОЙ; failures=$((failures+1)) ;;
          WARN) state=внимание; warnings=$((warnings+1)) ;;
          PASS) state=ок ;;
          *) state='нет данных'; missing=$((missing+1)) ;;
        esac
        ;;
    esac
    code="${code//|/ }"
    observed="${observed//|/ }"; unit="${unit//|/ }"
    rows[${#rows[@]}]="${code}|${observed}${unit:+ ${unit}}|${state}"
  done
  if (( ${#rows[@]} > 0 )); then
    sonar_render_result_if_tty "$host" "$done" "$total" "$elapsed" "$report_path" \
      "$failures" "$warnings" "$missing" "${rows[@]}"
  else
    sonar_render_result_if_tty "$host" "$done" "$total" "$elapsed" "$report_path" \
      "$failures" "$warnings" "$missing"
  fi
}

sonar_render_quick() {
  local done="$1" elapsed="$2" active="$3" tick="$4" footer1="$5" footer2="$6"
  local index encoded name value state
  local -a rows=()
  shift 6
  rows=("$@")
  SONAR_LAST_TICK="$tick"
  sonar_frame_top 'SERVER TOOLKIT · БЫСТРАЯ ПРОВЕРКА'
  sonar_render_progress "$done" 4 "$elapsed"
  sonar_blank
  for ((index=0; index<4; index++)); do
    encoded="${rows[$index]:-||}"
    name="${encoded%%|*}"
    value="${encoded#*|}"; value="${value%%|*}"
    state="${encoded##*|}"
    if (( index == active )); then
      sonar_render_check "$name" "$value" "" 1
    else
      sonar_render_check "$name" "$value" "$state"
    fi
  done
  sonar_blank; sonar_blank; sonar_blank; sonar_blank; sonar_blank
  sonar_separator
  sonar_render_footer "$footer1"
  sonar_render_footer "$footer2"
  sonar_frame_bottom
}

sonar_render_quick_result() {
  local done="$1" total="$2" elapsed="$3" footer1="$4" footer2="$5"
  local encoded name value state
  shift 5
  sonar_frame_top 'SERVER TOOLKIT · БЫСТРАЯ ПРОВЕРКА · ИТОГ'
  sonar_render_progress "$done" "$total" "$elapsed"
  sonar_blank
  for encoded in "$@"; do
    name="${encoded%%|*}"
    value="${encoded#*|}"; value="${value%%|*}"
    state="${encoded##*|}"
    [[ "$state" == ок ]] || sonar_render_check "$name" "$value" "$state"
  done
  sonar_blank; sonar_blank; sonar_blank; sonar_blank; sonar_blank
  sonar_separator
  sonar_render_footer "$footer1"
  sonar_render_footer "$footer2"
  sonar_frame_bottom
}

sonar_semantic_row() {
  local key="$1"
  case "$key" in
    progress) printf '2' ;;
    check:*) printf '%s' $((4+${key#check:})) ;;
    bottom) printf '%s' $((4+${#SONAR_AUDIT_ROWS[@]})) ;;
    *) return 2 ;;
  esac
}

sonar_semantic_column() {
  local key="$1" name_width
  case "$key" in
    line) printf '1' ;;
    state)
      if (( SONAR_WIDTH >= SONAR_LAYOUT_THRESHOLD )); then
        name_width=$((SONAR_WIDTH-28)); printf '%s' $((name_width+17))
      else
        name_width=$((SONAR_WIDTH-15)); printf '%s' $((name_width+4))
      fi
      ;;
    *) return 2 ;;
  esac
}

# This is the renderer's only absolute cursor-addressing primitive. Callers use
# semantic rows/columns and never perform relative cursor-up arithmetic.
sonar_put_at() {
  local row="$1" column="$2" text="$3"
  (( SONAR_SCREEN_ACTIVE == 1 )) || return 0
  printf '\033[%s;%sH%s' "$row" "$column" "$text" >&"$SONAR_OUTPUT_FD"
}

sonar_update_progress() {
  local line row column
  SONAR_LAST_DONE="$1"
  SONAR_LAST_TOTAL="$2"
  row="$(sonar_semantic_row progress)" || return 2
  column="$(sonar_semantic_column line)" || return 2
  line="$(sonar_progress_text "$1" "$2" "$3")"
  sonar_put_at "$row" "$column" "$line"
}

sonar_update_state() {
  local group="$1" state="$2" active="${3:-0}" row column role field
  row="$(sonar_semantic_row "check:${group}")" || return 2
  column="$(sonar_semantic_column state)" || return 2
  if (( active == 1 )); then
    state="$(sonar_spinner_glyph "$SONAR_LAST_TICK")"; role=active
  else
    sonar_state_is_valid "$state" || return 2
    role="$(sonar_state_role "$state")"
  fi
  field="$(sonar_fit "$state" 10)"
  sonar_put_at "$row" "$column" "$(sonar_colour "$role")${field}$(sonar_colour reset)"
}

sonar_screen_enter() {
  local host="$1" done="$2" total="$3" started="$4" now elapsed bottom rc=0
  (( SONAR_SCREEN_ACTIVE == 0 )) || return 0
  SONAR_PRESENTATION_READY=0
  [[ "$started" =~ ^[1-9][0-9]*$ ]] || return 2
  SONAR_HOST="$host"; SONAR_STARTED_AT="$started"
  SONAR_LAST_DONE="$done"; SONAR_LAST_TOTAL="$total"
  now="$(date +%s)"; elapsed=$((now-started)); (( elapsed < 0 )) && elapsed=0
  SONAR_SCREEN_ACTIVE=1
  printf '\033[?1049h\033[?25l\033[H\033[2J%s' "$(sonar_colour background)" >&"$SONAR_OUTPUT_FD" || rc=2
  sonar_render_audit "$host" "$done" "$total" "$elapsed" "$SONAR_ACTIVE_GROUP" 0 >&"$SONAR_OUTPUT_FD" || rc=2
  bottom="$(sonar_semantic_row bottom)" || rc=2
  if [[ -n "$bottom" ]]; then
    printf '\033[3;%sr' "$bottom" >&"$SONAR_OUTPUT_FD" || rc=2
  fi
  if (( rc != 0 )); then
    SONAR_PRESENTATION_READY=0
    return "$rc"
  fi
  SONAR_PRESENTATION_READY=1
}

sonar_screen_redraw() {
  local now elapsed bottom
  (( SONAR_SCREEN_ACTIVE == 1 )) || return 0
  now="$(date +%s)"; elapsed=$((now-SONAR_STARTED_AT)); (( elapsed < 0 )) && elapsed=0
  printf '\033[r\033[H\033[2J%s' "$(sonar_colour background)" >&"$SONAR_OUTPUT_FD"
  sonar_render_audit "$SONAR_HOST" "$SONAR_LAST_DONE" "$SONAR_LAST_TOTAL" "$elapsed" "$SONAR_ACTIVE_GROUP" "$SONAR_LAST_TICK" >&"$SONAR_OUTPUT_FD"
  bottom="$(sonar_semantic_row bottom)" || return 2
  printf '\033[3;%sr' "$bottom" >&"$SONAR_OUTPUT_FD"
}

sonar_screen_restore() {
  local rc=0
  trap '' WINCH
  (( SONAR_RESTORE_IN_PROGRESS == 0 )) || return 0
  SONAR_RESTORE_IN_PROGRESS=1
  if (( SONAR_SCREEN_ACTIVE == 1 )); then
    printf '\033[0m\033[r\033[?25h\033[?1049l' >&"$SONAR_OUTPUT_FD" || rc=2
  fi
  (( rc == 0 )) || SONAR_PRESENTATION_READY=0
  SONAR_SCREEN_ACTIVE=0
  PROGRESS_CURSOR_HIDDEN=0
  SONAR_RESTORE_IN_PROGRESS=0
  return "$rc"
}

sonar_sync_width_from_terminal() {
  local columns
  columns="$(progress_terminal_columns)"
  sonar_set_width "$columns" || return 1
  (( SONAR_COLUMNS >= SONAR_PRODUCTION_MIN_WIDTH )) || return 1
  sonar_configure_symbols
}

sonar_handle_winch() {
  local columns rc=0 locked=0
  (( SONAR_SCREEN_ACTIVE == 1 )) || return 0
  columns="$(progress_terminal_columns)"
  if ! sonar_set_width "$columns" ||
      (( SONAR_COLUMNS < SONAR_PRODUCTION_MIN_WIDTH )); then
    PROGRESS_INTERACTIVE=0
    SONAR_PRESENTATION_READY=0
    if [[ -n "$SONAR_RENDER_LOCK_DIR" ]]; then
      sonar_render_lock_acquire || {
        SONAR_PRESENTATION_READY=0
        return 2
      }
      if ! sonar_disable_heartbeat_updates; then
        sonar_render_lock_release || true
        return 2
      fi
      sonar_screen_restore || rc=2
      sonar_render_lock_release || rc=2
    else
      sonar_screen_restore || rc=2
    fi
    return "$rc"
  fi
  if [[ -n "$SONAR_RENDER_LOCK_DIR" ]]; then
    sonar_render_lock_acquire || {
      SONAR_PRESENTATION_READY=0
      return 2
    }
    locked=1
    if sonar_heartbeat_updates_disabled; then
      PROGRESS_INTERACTIVE=0
      SONAR_PRESENTATION_READY=0
      sonar_screen_restore || rc=2
      sonar_render_lock_release || rc=2
      return "$rc"
    fi
  fi
  PROGRESS_PRESENTATION_COLUMNS="$columns"
  sonar_configure_symbols
  if ! sonar_screen_redraw; then
    SONAR_PRESENTATION_READY=0
    rc=2
  fi
  if (( locked == 1 )); then
    if ! sonar_render_lock_release; then
      SONAR_PRESENTATION_READY=0
      rc=2
    fi
  fi
  return "$rc"
}
