#!/bin/bash -p
# Positive-inclusion public quick check. It never sources the full audit.
# shellcheck disable=SC2034,SC2163,SC2329

QUICK_CHECK_IS_SOURCED=0
[[ "${BASH_SOURCE[0]}" != "$0" ]] && QUICK_CHECK_IS_SOURCED=1
QUICK_CHECK_PRODUCTION_MODE="${QUICK_CHECK_PRODUCTION_MODE:-0}"
QUICK_CHECK_CLEAN_STAGE="${QUICK_CHECK_CLEAN_STAGE:-0}"
QUICK_PRESENTATION_TTY="${QUICK_PRESENTATION_TTY:-0}"
QUICK_PRESENTATION_COLUMNS="${QUICK_PRESENTATION_COLUMNS:-80}"
QUICK_PRESENTATION_UNICODE="${QUICK_PRESENTATION_UNICODE:-0}"
QUICK_PRESENTATION_COLOR="${QUICK_PRESENTATION_COLOR:-0}"
QUICK_CHECK_SIGNAL_IN_PROGRESS=0
QUICK_CHECK_CLEANUP_UNVERIFIED=0
QUICK_CHECK_RETRY_CHILD_PID=""
QUICK_CHECK_RETRY_CHILD_IDENTITY=""
QUICK_CHECK_USER_STDERR_READY=0

readonly QUICK_CHECK_VERSION=2
readonly QUICK_CHECK_COMMAND=quick-check
readonly QUICK_CHECK_EXECUTED='server_system,memory_compute_pressure,storage,services'
readonly QUICK_CHECK_OMITTED='cpu_full,network,packages,security,report'
readonly QUICK_CHECK_INSTALL_ROOT='/usr/local/lib/server-toolkit'

quick_check_usage_error() {
  printf 'Использование: server-toolkit quick-check\n' >&2
}

quick_check_user_error() {
  if (( QUICK_CHECK_USER_STDERR_READY == 1 )); then
    printf '%s\n' "$1" >&9
  else
    printf '%s\n' "$1" >&2
  fi
}

quick_check_module_paths() {
  local root="$1"
  printf '%s\n' \
    "$root/sonar-presentation-0.4.1-rc4-round2.sh" \
    "$root/progress-0.4.1-rc4-round2.sh" \
    "$root/platform-compatibility-0.4.1-rc4-round2.sh" \
    "$root/pressure-diagnostics-0.4.1-rc4-round2.sh" \
    "$root/storage-diagnostics-0.4.1-rc4-round2.sh" \
    "$root/application-service-diagnostics-0.4.1-rc4-round2.sh" \
    "$root/failed-services-policy-0.4.1-rc4-round2.sh" \
    "$root/quick-check-classifier-v2.sh"
}

if (( QUICK_CHECK_IS_SOURCED == 1 )); then
  if (( QUICK_CHECK_PRODUCTION_MODE == 1 )); then
    _quick_module_root="$QUICK_CHECK_INSTALL_ROOT"
  else
    _quick_core_dir="$(cd "$(/usr/bin/dirname "${BASH_SOURCE[0]}")" && pwd)"
    _quick_module_root="$(cd "$_quick_core_dir/../lib" && pwd)"
    unset _quick_core_dir
  fi
  while IFS= read -r _quick_module; do
    [[ -f "$_quick_module" && ! -L "$_quick_module" ]] || return 126
    # All paths are fixed by quick_check_module_paths. Production validates the
    # complete root-owned chain before this source phase is reachable.
    # shellcheck disable=SC1090
    source "$_quick_module" || return 126
  done < <(quick_check_module_paths "$_quick_module_root")
  unset _quick_module _quick_module_root
fi

quick_check_tty_size() {
  if [[ -x /bin/stty ]]; then
    /bin/stty size </dev/tty 2>/dev/null
  elif [[ -x /usr/bin/stty ]]; then
    /usr/bin/stty size </dev/tty 2>/dev/null
  else
    return 1
  fi
}

quick_check_stdio_is_tty() { [[ -t 1 && -t 2 ]]; }

quick_check_capture_presentation_profile() {
  local size="" columns="" fallback="${COLUMNS:-80}"
  local locale_value="${LC_ALL:-${LC_CTYPE:-${LANG:-}}}"
  QUICK_PRESENTATION_TTY=0
  QUICK_PRESENTATION_UNICODE=0
  QUICK_PRESENTATION_COLOR=0
  size="$(quick_check_tty_size 2>/dev/null || true)"
  if [[ "$size" =~ ^[0-9]{1,4}[[:space:]][0-9]{1,4}$ ]]; then
    columns="${size##* }"
  else
    columns="$fallback"
  fi
  [[ "$columns" =~ ^[0-9]{1,3}$ ]] || columns=80
  columns=$((10#$columns)); (( columns < 34 )) && columns=34; (( columns > 240 )) && columns=240
  QUICK_PRESENTATION_COLUMNS="$columns"
  if quick_check_stdio_is_tty && [[ "${TERM:-dumb}" != dumb ]]; then
    QUICK_PRESENTATION_TTY=1
    case "$locale_value" in C|POSIX|'') ;; *) QUICK_PRESENTATION_UNICODE=1 ;; esac
    [[ -n "${NO_COLOR:-}" ]] || QUICK_PRESENTATION_COLOR=1
  fi
}

quick_check_bootstrap_clean() {
  local quick_artifact="${BASH_SOURCE[0]}"
  exec -c /bin/bash --noprofile --norc -p -c '
    set -Eeuo pipefail
    printf -v IFS "\n\t"
    bootstrap_stat_uid() {
      local value
      value="$(/usr/bin/stat -c %u -- "$1" 2>/dev/null)" ||
        value="$(/usr/bin/stat -f %u "$1" 2>/dev/null)" || return 1
      [[ "$value" =~ ^[0-9]+$ ]] || return 1
      printf "%s\n" "$value"
    }
    bootstrap_stat_mode() {
      local value
      value="$(/usr/bin/stat -c %a -- "$1" 2>/dev/null)" ||
        value="$(/usr/bin/stat -f %Lp "$1" 2>/dev/null)" || return 1
      [[ "$value" =~ ^[0-7]{3,4}$ ]] || return 1
      value="${value#0}"; printf "%s\n" "$value"
    }
    bootstrap_directory_is_trusted() {
      local path="$1" owner mode numeric
      [[ -d "$path" && ! -L "$path" ]] || return 1
      owner="$(bootstrap_stat_uid "$path")" || return 1
      mode="$(bootstrap_stat_mode "$path")" || return 1
      [[ "$owner" == 0 ]] || return 1
      numeric=$((8#$mode)); (( (numeric & 0022) == 0 ))
    }
    bootstrap_artifact_is_trusted() {
      local artifact="$1" expected_mode="$2" parent current component owner mode
      local -a components=()
      [[ "$artifact" =~ ^/[A-Za-z0-9._/-]+$ && "$artifact" != */ &&
         "$artifact" != *//* && ! "$artifact" =~ (^|/)\.\.?(/|$) ]] || return 1
      parent="${artifact%/*}"; [[ -n "$parent" ]] || parent=/
      bootstrap_directory_is_trusted / || return 1
      IFS=/ read -r -a components <<<"${parent#/}"
      current=/
      for component in "${components[@]}"; do
        [[ -n "$component" ]] || continue
        current="${current%/}/$component"
        bootstrap_directory_is_trusted "$current" || return 1
      done
      [[ -f "$artifact" && ! -L "$artifact" ]] || return 1
      owner="$(bootstrap_stat_uid "$artifact")" || return 1
      mode="$(bootstrap_stat_mode "$artifact")" || return 1
      [[ "$owner" == 0 && "$mode" == "$expected_mode" ]]
    }
    quick_artifact="$1"; tty="$2"; columns="$3"; unicode="$4"; color="$5"; shift 5
    [[ "$quick_artifact" == /usr/local/lib/server-toolkit/server-toolkit-quick-v2.sh ]] || exit 126
    [[ "$tty" =~ ^[01]$ && "$columns" =~ ^[0-9]{2,3}$ &&
       "$unicode" =~ ^[01]$ && "$color" =~ ^[01]$ ]] || exit 126
    (( columns >= 34 && columns <= 240 )) || exit 126
    (( $# == 8 )) || exit 126
    bootstrap_artifact_is_trusted "$quick_artifact" 700 || exit 126
    for module in "$@"; do bootstrap_artifact_is_trusted "$module" 644 || exit 126; done
    cd / || exit 126
    bootstrap_artifact_is_trusted "$quick_artifact" 700 || exit 126
    for module in "$@"; do bootstrap_artifact_is_trusted "$module" 644 || exit 126; done
    QUICK_CHECK_PRODUCTION_MODE=1
    QUICK_CHECK_CLEAN_STAGE=1
    QUICK_PRESENTATION_TTY="$tty"
    QUICK_PRESENTATION_COLUMNS="$columns"
    QUICK_PRESENTATION_UNICODE="$unicode"
    QUICK_PRESENTATION_COLOR="$color"
    source "$quick_artifact" || exit 126
    quick_check_main quick-check
  ' server-toolkit-quick-clean "$quick_artifact" \
    "$QUICK_PRESENTATION_TTY" "$QUICK_PRESENTATION_COLUMNS" \
    "$QUICK_PRESENTATION_UNICODE" "$QUICK_PRESENTATION_COLOR" \
    "$QUICK_CHECK_INSTALL_ROOT/sonar-presentation-0.4.1-rc4-round2.sh" \
    "$QUICK_CHECK_INSTALL_ROOT/progress-0.4.1-rc4-round2.sh" \
    "$QUICK_CHECK_INSTALL_ROOT/platform-compatibility-0.4.1-rc4-round2.sh" \
    "$QUICK_CHECK_INSTALL_ROOT/pressure-diagnostics-0.4.1-rc4-round2.sh" \
    "$QUICK_CHECK_INSTALL_ROOT/storage-diagnostics-0.4.1-rc4-round2.sh" \
    "$QUICK_CHECK_INSTALL_ROOT/application-service-diagnostics-0.4.1-rc4-round2.sh" \
    "$QUICK_CHECK_INSTALL_ROOT/failed-services-policy-0.4.1-rc4-round2.sh" \
    "$QUICK_CHECK_INSTALL_ROOT/quick-check-classifier-v2.sh"
  printf 'Не удалось запустить quick-check в пустом окружении.\n' >&2
  return 126
}

quick_check_prepare_environment() {
  local name
  [[ "$-" == *p* && "$QUICK_CHECK_CLEAN_STAGE" == 1 && $EUID -eq 0 ]] || return 126
  while IFS= read -r name; do
    [[ "$name" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || return 126
    export -n "$name" 2>/dev/null || return 126
  done < <(compgen -e)
  PATH=/usr/sbin:/usr/bin:/sbin:/bin; HOME=/root; LC_ALL=C; LANG=C; TERM=dumb; TZ=UTC
  export PATH HOME LC_ALL LANG TERM TZ
  umask 077
  ROLE_LABEL=generic; PROGRESS_MODE=off; PROGRESS_WIDTH=34
}

quick_check_make_runtime() {
  local runtime attempt
  for ((attempt=1; attempt<=100; attempt++)); do
    runtime="/run/server-toolkit-quick-v2.$$.${RANDOM}.${attempt}"
    if /bin/mkdir -m 700 -- "$runtime" 2>/dev/null; then
      progress_runtime_dir_is_safe "$runtime" || { /bin/rmdir -- "$runtime" 2>/dev/null || true; return 1; }
      printf '%s\n' "$runtime"; return 0
    fi
    [[ -e "$runtime" || -L "$runtime" ]] || return 1
  done
  return 1
}

quick_check_owned_stage() {
  local producer="$1" owner_file="$2" own_pid identity old_umask noclobber_was_set=0
  local pid_file="${QUICK_CHECK_RUNTIME_DIR:-}/.quick-stage-pid"
  [[ "$producer" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || return 125
  [[ "$owner_file" == "${QUICK_CHECK_RUNTIME_DIR:-}/.quick-stage-owner" ]] || return 125
  [[ ! -e "$owner_file" && ! -L "$owner_file" ]] || return 125
  [[ ! -e "$pid_file" && ! -L "$pid_file" ]] || return 125
  old_umask="$(umask)"
  [[ -o noclobber ]] && noclobber_was_set=1
  umask 077
  set -o noclobber
  if ! /bin/sh -c 'printf "%s\n" "$PPID"' >"$pid_file"; then
    (( noclobber_was_set == 1 )) || set +o noclobber
    umask "$old_umask"
    return 125
  fi
  (( noclobber_was_set == 1 )) || set +o noclobber
  umask "$old_umask"
  progress_child_guard_file_is_safe "$pid_file" || return 125
  IFS= read -r own_pid <"$pid_file" || return 125
  /bin/rm -f -- "$pid_file" || return 125
  [[ "$own_pid" =~ ^[1-9][0-9]*$ && "$own_pid" -gt 1 ]] || return 125
  identity="$(progress_capture_process_identity "$own_pid" 2>/dev/null)" || return 125
  [[ -n "$identity" ]] || return 125
  (umask 077; set -o noclobber
    printf 'pid=%s\nidentity=%s\n' "$own_pid" "$identity" >"$owner_file") || return 125
  progress_child_guard_file_is_safe "$owner_file" || return 125
  "$producer"
}

quick_check_preserve_stage_owner() {
  local owner_file="$1" line pid="" identity="" count=0
  [[ "$owner_file" == "${QUICK_CHECK_RUNTIME_DIR:-}/.quick-stage-owner" ]] || return 1
  progress_child_guard_file_is_safe "$owner_file" || return 1
  while IFS= read -r line; do
    count=$((count + 1))
    (( count <= 2 )) || return 1
    case "$line" in
      pid=*) [[ -z "$pid" ]] || return 1; pid="${line#pid=}" ;;
      identity=*) [[ -z "$identity" ]] || return 1; identity="${line#identity=}" ;;
      *) return 1 ;;
    esac
  done <"$owner_file"
  [[ "$count" == 2 && "$pid" =~ ^[1-9][0-9]*$ && "$pid" -gt 1 &&
     -n "$identity" ]] || return 1
  QUICK_CHECK_RETRY_CHILD_PID="$pid"
  QUICK_CHECK_RETRY_CHILD_IDENTITY="$identity"
  QUICK_CHECK_CLEANUP_UNVERIFIED=1
}

quick_check_restore_retry_owner() {
  local pid="${QUICK_CHECK_RETRY_CHILD_PID:-}"
  local identity="${QUICK_CHECK_RETRY_CHILD_IDENTITY:-}" current state
  [[ -n "$pid" || -n "$identity" ]] || return 0
  [[ "$pid" =~ ^[1-9][0-9]*$ && "$pid" -gt 1 && -n "$identity" ]] || return 2
  current="$(progress_capture_process_identity "$pid" 2>/dev/null || true)"
  if [[ "$current" == "$identity" ]]; then
    PROGRESS_ACTIVE_CHILD_PID="$pid"
    PROGRESS_ACTIVE_CHILD_IDENTITY="$identity"
    return 0
  fi
  state="$(progress_process_state "$pid")"
  if [[ "$state" == Z* ]] || ! /bin/kill -0 "$pid" 2>/dev/null; then
    wait "$pid" 2>/dev/null || true
    return 0
  fi
  return 2
}

quick_check_remove_runtime() {
  local runtime="${QUICK_CHECK_RUNTIME_DIR:-}" rc=0 cleanup_rc=0 heartbeat_rc=0
  local was_unverified="${QUICK_CHECK_CLEANUP_UNVERIFIED:-0}"
  if (( PROGRESS_CLEANUP_IN_PROGRESS == 1 )); then
    return "${PROGRESS_CLEANUP_STATUS:-2}"
  fi
  if [[ -z "${QUICK_CHECK_RETRY_CHILD_PID:-}" &&
        "${PROGRESS_ACTIVE_CHILD_PID:-}" =~ ^[1-9][0-9]*$ &&
        -n "${PROGRESS_ACTIVE_CHILD_IDENTITY:-}" ]]; then
    QUICK_CHECK_RETRY_CHILD_PID="$PROGRESS_ACTIVE_CHILD_PID"
    QUICK_CHECK_RETRY_CHILD_IDENTITY="$PROGRESS_ACTIVE_CHILD_IDENTITY"
  fi
  # A signal can enter while progress_run_child still owns control, before
  # quick_check_run_stage can inspect its return status. Preserve the stage
  # identity record first so the shared terminator cannot erase our only
  # retriable owner evidence.
  if [[ -n "$runtime" && -z "${QUICK_CHECK_RETRY_CHILD_PID:-}" &&
        ( -e "$runtime/.quick-stage-owner" || -L "$runtime/.quick-stage-owner" ) ]]; then
    quick_check_preserve_stage_owner "$runtime/.quick-stage-owner" ||
      QUICK_CHECK_CLEANUP_UNVERIFIED=1
  fi
  was_unverified="${QUICK_CHECK_CLEANUP_UNVERIFIED:-0}"
  if [[ "$was_unverified" == 0 && -z "$runtime" && -z "${PROGRESS_ACTIVE_CHILD_PID:-}" &&
        -z "${PROGRESS_HEARTBEAT_PID:-}" &&
        -z "${PROGRESS_CHILD_GUARD_DIR:-}" ]]; then
    PROGRESS_CLEANUP_DONE=1
    PROGRESS_CLEANUP_STATUS=0
    QUICK_CHECK_CLEANUP_UNVERIFIED=0
    return 0
  fi
  PROGRESS_CLEANUP_IN_PROGRESS=1
  PROGRESS_CLEANUP_DONE=0
  # The process runner's machine diagnostics are intentionally contained here:
  # a signal/timeout must not print protocol internals into the user TTY.
  progress_stop_heartbeat 2>/dev/null || heartbeat_rc=$?
  quick_check_restore_retry_owner 2>/dev/null || cleanup_rc=$?
  if (( cleanup_rc == 0 )); then
    progress_terminate_active_child 2>/dev/null || cleanup_rc=$?
  fi
  # Once the owned runner reported a single-snapshot/otherwise unverified
  # timeout cleanup, this inner process cannot certify absence of late forks.
  # Only the outer isolated session may make that claim, so retain the runtime
  # and ownership record even when the direct child is now gone.
  (( was_unverified == 0 )) || cleanup_rc=2
  if (( heartbeat_rc != 0 || cleanup_rc != 0 )); then
    rc=2
  else
    progress_remove_child_guard 2>/dev/null || rc=2
    if [[ -n "$runtime" ]]; then
      /bin/rm -f -- "$runtime/system.env" "$runtime/pressure.env" \
        "$runtime/storage.env" "$runtime/services.env" "$runtime/metrics.env" \
        "$runtime/result.env" "$runtime/.quick-stage-owner" \
        "$runtime/.quick-stage-runner.err" "$runtime/.quick-stage-pid" \
        2>/dev/null || rc=2
      /bin/rmdir -- "$runtime" 2>/dev/null || rc=2
    fi
  fi
  PROGRESS_CLEANUP_STATUS="$rc"
  PROGRESS_CLEANUP_IN_PROGRESS=0
  if (( rc == 0 )); then
    PROGRESS_CLEANUP_DONE=1
    QUICK_CHECK_CLEANUP_UNVERIFIED=0
    QUICK_CHECK_RETRY_CHILD_PID=""
    QUICK_CHECK_RETRY_CHILD_IDENTITY=""
    QUICK_CHECK_RUNTIME_DIR=""
    PROGRESS_RUNTIME_DIR=""
  else
    # Keep every remaining identity/path intact. EXIT gets one independent
    # retry instead of losing the evidence needed for bounded cleanup.
    PROGRESS_CLEANUP_DONE=0
    QUICK_CHECK_CLEANUP_UNVERIFIED=1
  fi
  if (( QUICK_CHECK_SIGNAL_IN_PROGRESS == 0 )) &&
      [[ -n "${PROGRESS_PENDING_SIGNAL:-}" ]]; then
    progress_dispatch_pending_signal
  fi
  return "$rc"
}

quick_check_exit() {
  local original_rc=$? cleanup_rc=0
  quick_check_remove_runtime || cleanup_rc=$?
  if (( cleanup_rc != 0 )); then
    quick_check_user_error "quick_check_cleanup_status=unverified rc=$cleanup_rc"
    (( original_rc == 0 )) && return "$cleanup_rc"
  fi
  return "$original_rc"
}

quick_check_signal_code() {
  case "$1" in HUP) printf '129\n' ;; INT) printf '130\n' ;; *) printf '143\n' ;; esac
}

quick_check_queue_signal() {
  progress_queue_signal "$1" 'quick-check'
}

quick_check_signal_dispatch() {
  local signal="$1" code="$2"
  local cleanup_rc=0
  if (( PROGRESS_CHILD_STARTING == 1 || PROGRESS_HEARTBEAT_STARTING == 1 ||
        PROGRESS_CLEANUP_IN_PROGRESS == 1 ||
        PROGRESS_SIGNAL_IN_PROGRESS == 1 ||
        QUICK_CHECK_SIGNAL_IN_PROGRESS == 1 )); then
    quick_check_queue_signal "$signal"
    return 0
  fi
  QUICK_CHECK_SIGNAL_IN_PROGRESS=1
  PROGRESS_SIGNAL_IN_PROGRESS=1
  trap 'quick_check_queue_signal HUP' HUP
  trap 'quick_check_queue_signal INT' INT
  trap 'quick_check_queue_signal TERM' TERM
  quick_check_remove_runtime || cleanup_rc=$?
  if (( cleanup_rc != 0 )); then
    quick_check_user_error "quick_check_cleanup_status=unverified rc=$cleanup_rc"
  fi
  quick_check_user_error "Quick-check прерван сигналом $signal."
  trap '' HUP INT TERM
  exit "$code"
}

# progress_run_child owns the startup safe boundaries and calls this dynamic
# dispatch target after clearing CHILD_STARTING/HEARTBEAT_STARTING. Override the
# full-audit wording while retaining its reviewed queue and identity protocol.
progress_signal() {
  local signal="$1" code
  code="$(quick_check_signal_code "$signal")"
  quick_check_signal_dispatch "$signal" "$code"
}

quick_check_signal() {
  local signal="$1" code="$2"
  quick_check_signal_dispatch "$signal" "$code"
}

quick_check_cpu_read_vcpu_count() {
  if [[ -x /usr/bin/nproc ]]; then /usr/bin/nproc; else /usr/bin/getconf _NPROCESSORS_ONLN 2>/dev/null; fi
}
cpu_read_vcpu_count() { quick_check_cpu_read_vcpu_count; }

quick_check_system_metrics() {
  printf 'platform_contract_version=%s\n' "$PLATFORM_CONTRACT_VERSION"
  printf 'platform_support_status=%s\n' "$PLATFORM_SUPPORT_STATUS"
  printf 'platform_validation_status=%s\n' "$PLATFORM_VALIDATION_STATUS"
  printf 'platform_id=%s\n' "$PLATFORM_ID"
  printf 'platform_version_id=%s\n' "$PLATFORM_VERSION_ID"
}

quick_check_run_stage() {
  local timeout_seconds="$1" producer="$2" output="$3" rc=0
  local owner_file="${QUICK_CHECK_RUNTIME_DIR:-}/.quick-stage-owner"
  local runner_error="${QUICK_CHECK_RUNTIME_DIR:-}/.quick-stage-runner.err"
  CURRENT_STAGE_TIMEOUT="$timeout_seconds"
  /bin/rm -f -- "$owner_file" "$runner_error" \
    "${QUICK_CHECK_RUNTIME_DIR:-}/.quick-stage-pid" 2>/dev/null || return 125
  set +e
  progress_run_child quick_check_owned_stage "$producer" "$owner_file" \
    >"$output" 2>"$runner_error"
  rc=$?
  set -e
  if (( rc != 0 )); then
    if /usr/bin/grep -Fq 'progress_timeout_cleanup_status=unverified' "$runner_error"; then
      if quick_check_preserve_stage_owner "$owner_file"; then
        quick_check_user_error "quick_check_stage_cleanup_status=unverified rc=$rc owner=preserved"
      else
        QUICK_CHECK_CLEANUP_UNVERIFIED=1
        quick_check_user_error "quick_check_stage_cleanup_status=unverified rc=$rc owner=unavailable"
      fi
    else
      quick_check_user_error "quick_check_stage_status=failed rc=$rc"
    fi
    return "$rc"
  fi
  /bin/rm -f -- "$owner_file" "$runner_error" 2>/dev/null || return 125
  quick_validate_metrics_file "$output"
}

quick_check_machine_value() { quick_metric_value "$@"; }

quick_check_configure_presentation() {
  (( QUICK_PRESENTATION_TTY == 1 )) || return 1
  SONAR_COLUMNS="$QUICK_PRESENTATION_COLUMNS"
  sonar_set_width "$QUICK_PRESENTATION_COLUMNS" || return 1
  SONAR_UTF8_LOCALE="$(progress_detect_utf8_locale)"
  SONAR_UNICODE=0
  [[ "$QUICK_PRESENTATION_UNICODE" == 1 && "$SONAR_UTF8_LOCALE" != C ]] && SONAR_UNICODE=1
  SONAR_COLOR="$QUICK_PRESENTATION_COLOR"
  sonar_configure_symbols
}

quick_check_render_initial() {
  quick_check_configure_presentation || return 0
  sonar_render_quick 0 0 0 0 \
    'Быстрая проверка · 4 из 9 проверок' 'Это не полный аудит' \
    'Сервер и система||' 'Память||' 'Диски||' 'Службы||'
}

quick_check_render_result() {
  local result="$1" elapsed="$2" state_system state_memory state_storage state_services
  local value_system value_memory value_storage value_services compute_state footer1
  state_system="$(quick_human_state "$(quick_check_machine_value "$result" check_server_system)")"
  state_memory="$(quick_human_state "$(quick_check_machine_value "$result" check_memory)")"
  state_storage="$(quick_human_state "$(quick_check_machine_value "$result" check_storage)")"
  state_services="$(quick_human_state "$(quick_check_machine_value "$result" check_services)")"
  value_system="$(quick_check_machine_value "$result" value_server_system)"
  value_memory="$(quick_check_machine_value "$result" value_memory)"
  value_storage="$(quick_check_machine_value "$result" value_storage)"
  value_services="$(quick_check_machine_value "$result" value_services)"
  compute_state="$(quick_check_machine_value "$result" check_compute_pressure)"
  footer1='Быстрая проверка · 4 из 9 проверок'
  if [[ "$compute_state" == warn || "$compute_state" == fail ]]; then
    footer1="4 из 9 · $value_memory"
  fi
  if quick_check_configure_presentation; then
    sonar_render_quick_result 4 4 "$elapsed" \
      "$footer1" 'Это не полный аудит · 5 групп не выполнялись' \
      "Сервер и система|$value_system|$state_system" \
      "Память|$value_memory|$state_memory" \
      "Диски|$value_storage|$state_storage" \
      "Службы|$value_services|$state_services"
  else
    /bin/cat "$result"
    printf '\nБыстрая проверка · 4 из 9 проверок\n'
    printf 'Сервер и система: %s\n' "$state_system"
    printf 'Память: %s\n' "$state_memory"
    printf 'Диски: %s\n' "$state_storage"
    printf 'Службы: %s\n' "$state_services"
    printf 'Это не полный аудит · 5 групп не выполнялись\n'
  fi
}

quick_check_main() {
  local command="${1:-}" system pressure storage services metrics result rc=0 started elapsed
  (( $# == 1 )) || { quick_check_usage_error; return 2; }
  [[ "$command" == "$QUICK_CHECK_COMMAND" ]] || { quick_check_usage_error; return 2; }
  (( QUICK_CHECK_IS_SOURCED == 1 )) || return 126
  quick_check_prepare_environment || return $?
  trap 'quick_check_signal HUP 129' HUP
  trap 'quick_check_signal INT 130' INT
  trap 'quick_check_signal TERM 143' TERM
  trap quick_check_exit EXIT
  platform_assert_supported /etc/os-release || return $?
  QUICK_CHECK_RUNTIME_DIR="$(quick_check_make_runtime)" || return 1
  PROGRESS_RUNTIME_DIR="$QUICK_CHECK_RUNTIME_DIR"
  PROGRESS_CLEANUP_IN_PROGRESS=0; PROGRESS_CLEANUP_DONE=0; PROGRESS_CLEANUP_STATUS=0
  exec 9>&2
  QUICK_CHECK_USER_STDERR_READY=1
  started=$SECONDS
  quick_check_render_initial >&2

  system="$QUICK_CHECK_RUNTIME_DIR/system.env"; pressure="$QUICK_CHECK_RUNTIME_DIR/pressure.env"
  storage="$QUICK_CHECK_RUNTIME_DIR/storage.env"; services="$QUICK_CHECK_RUNTIME_DIR/services.env"
  metrics="$QUICK_CHECK_RUNTIME_DIR/metrics.env"; result="$QUICK_CHECK_RUNTIME_DIR/result.env"
  quick_check_run_stage 15 quick_check_system_metrics "$system" || rc=$?
  (( rc == 0 )) && quick_check_run_stage 20 sample_memory_cpu_pressure_metrics "$pressure" || rc=$?
  (( rc == 0 )) && quick_check_run_stage 20 sample_storage_metrics "$storage" || rc=$?
  (( rc == 0 )) && quick_check_run_stage 60 quick_collect_services_metrics "$services" || rc=$?
  if (( rc != 0 )); then printf 'quick-check: этап завершился с rc=%s\n' "$rc" >&2; return 1; fi
  /bin/cat "$system" "$pressure" "$storage" "$services" >"$metrics" || return 1
  quick_validate_metrics_file "$metrics" || return 1
  quick_build_summary "$metrics" "$result" || return 1
  elapsed=$((SECONDS-started)); (( elapsed < 0 )) && elapsed=0
  quick_check_render_result "$result" "$elapsed" || return $?
  # EXIT traps cannot portably turn an otherwise successful shell exit into a
  # failure. Make success conditional on a verified cleanup here, then remove
  # the trap only after the runtime and ownership state are proven gone.
  if quick_check_remove_runtime; then
    :
  else
    rc=$?
    [[ "$rc" =~ ^[1-9][0-9]*$ ]] || rc=2
    (( rc <= 255 )) || rc=2
    quick_check_user_error "quick_check_cleanup_status=unverified rc=$rc"
    return "$rc"
  fi
  trap - EXIT
  QUICK_CHECK_USER_STDERR_READY=0
  exec 9>&-
  return 0
}

quick_check_entry() {
  (( $# == 1 )) || { quick_check_usage_error; return 2; }
  [[ "$1" == "$QUICK_CHECK_COMMAND" ]] || { quick_check_usage_error; return 2; }
  [[ "$-" == *p* ]] || { printf 'Небезопасный способ запуска quick-check.\n' >&2; return 126; }
  [[ $EUID -eq 0 ]] || { printf 'Quick-check требуется запускать через проверенный sudo controller.\n' >&2; return 1; }
  quick_check_capture_presentation_profile
  quick_check_bootstrap_clean
}

if (( QUICK_CHECK_IS_SOURCED == 0 )); then
  set -Eeuo pipefail
  IFS=$'\n\t'
  quick_check_entry "$@"
fi
