#!/usr/bin/env bash
# Bounded read-only root-filesystem and backing-device diagnostics.

# The builder embeds this module; the summary module consumes these public thresholds.
# shellcheck disable=SC2034
STORAGE_SAMPLE_COUNT=5
STORAGE_SAMPLE_INTERVAL_SECONDS=1
STORAGE_COMMAND_TIMEOUT_SECONDS=5
STORAGE_MIN_OPS_PER_WINDOW=5
STORAGE_AWAIT_WARN_MS=50.00
STORAGE_UTIL_WARN_PCT=90.00
STORAGE_QUEUE_WARN=2.00
STORAGE_FS_WARN_PCT=90
STORAGE_FS_CRITICAL_PCT=95
STORAGE_INODE_WARN_PCT=90
STORAGE_INODE_CRITICAL_PCT=95

storage_run_bounded() {
  command -v timeout >/dev/null 2>&1 || return 127
  timeout --signal=TERM --kill-after=2s "${STORAGE_COMMAND_TIMEOUT_SECONDS}s" "$@"
}

storage_read_root_mount() {
  if command -v findmnt >/dev/null 2>&1; then
    storage_run_bounded findmnt -n -o SOURCE,FSTYPE,OPTIONS,TARGET / 2>/dev/null
    return
  fi
  awk '$2=="/" {print $1, $3, $4, $2; exit}' /proc/mounts 2>/dev/null
}

storage_read_root_space() {
  storage_run_bounded df -Pk / 2>/dev/null | awk 'NR==2 {
    used=$3+0; total=$2+0; available=$4+0
    pct=$5; gsub(/%/,"",pct)
    if(pct !~ /^[0-9]+$/) exit 1
    printf "%d %d %d %d\n",total,used,available,pct
  }'
}

storage_read_root_inodes() {
  storage_run_bounded df -Pi / 2>/dev/null | awk 'NR==2 {
    total=$2+0; used=$3+0; available=$4+0
    pct=$5; gsub(/%/,"",pct)
    if(pct !~ /^[0-9]+$/) exit 1
    printf "%d %d %d %d\n",total,used,available,pct
  }'
}

storage_resolve_device() {
  local source="$1" kname=""
  [[ "$source" == /dev/* ]] || return 1
  if command -v lsblk >/dev/null 2>&1; then
    kname="$(storage_run_bounded lsblk -ndo KNAME "$source" 2>/dev/null | head -1 || true)"
  fi
  if [[ -z "$kname" ]]; then
    kname="$(basename "$(readlink -f "$source" 2>/dev/null || printf '%s' "$source")")"
  fi
  [[ -n "$kname" && -r "/sys/class/block/$kname/stat" ]] || return 1
  printf '%s\n' "$kname"
}

storage_read_device_stat() {
  local device="$1"
  [[ "$device" =~ ^[A-Za-z0-9._!+-]+$ ]] || return 1
  awk '{for(i=1;i<=11;i++){if($i !~ /^[0-9]+$/) exit 1; printf "%s%s",$i,(i==11?ORS:OFS)}}' \
    "/sys/class/block/$device/stat" 2>/dev/null
}

storage_wait_interval() {
  sleep "$1"
}

storage_pair_metrics() {
  local before="$1" after="$2" interval_ms="$3" minimum_ops="$4"
  awk -v before="$before" -v after="$after" -v interval_ms="$interval_ms" -v minimum_ops="$minimum_ops" 'BEGIN {
    if(split(before,A," ")<11 || split(after,B," ")<11) exit 1
    for(i=1;i<=11;i++) {
      if(A[i] !~ /^[0-9]+$/ || B[i] !~ /^[0-9]+$/) exit 1
      if(i!=9 && B[i]<A[i]) exit 1
      D[i]=B[i]-A[i]
    }
    if(interval_ms<=0) exit 1
    operations=D[1]+D[5]
    await_value=(operations>=minimum_ops ? sprintf("%.2f",(D[4]+D[8])/operations) : "unavailable")
    read_await=(D[1]>=minimum_ops ? sprintf("%.2f",D[4]/D[1]) : "unavailable")
    write_await=(D[5]>=minimum_ops ? sprintf("%.2f",D[8]/D[5]) : "unavailable")
    utilization=100*D[10]/interval_ms
    if(utilization>100) utilization=100
    queue=D[11]/interval_ms
    printf "%d %d %d %s %.2f %.2f %d %s %s\n",operations,D[1],D[5],await_value,utilization,queue,B[9],read_await,write_await
  }'
}

storage_metric_stats() {
  local prefix="$1" threshold="$2"
  shift 2
  printf '%s\n' "$@" | awk -v prefix="$prefix" -v threshold="$threshold" '
    function sort_values( i,j,t) {
      for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) if(v[j]<v[i]) {t=v[i];v[i]=v[j];v[j]=t}
    }
    /^[0-9]+([.][0-9]+)?$/ {
      v[++n]=$1
      sum+=$1
      if($1>threshold) exceed++
    }
    END {
      if(n==0) exit 1
      sort_values()
      if(n%2) median=v[(n+1)/2]; else median=(v[n/2]+v[n/2+1])/2
      printf "%s_min=%.2f\n",prefix,v[1]
      printf "%s_median=%.2f\n",prefix,median
      printf "%s_average=%.2f\n",prefix,sum/n
      printf "%s_max=%.2f\n",prefix,v[n]
      printf "%s_threshold=%.2f\n",prefix,threshold
      printf "%s_threshold_exceedance_count=%d\n",prefix,exceed+0
    }'
}

storage_raw_inventory() {
  printf 'storage_raw_inventory_status=begin\n'
  if command -v df >/dev/null 2>&1; then
    storage_run_bounded df -hT 2>/dev/null || true
    storage_run_bounded df -ih 2>/dev/null || true
  fi
  if command -v lsblk >/dev/null 2>&1; then
    storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL,TRAN 2>/dev/null || \
      storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL 2>/dev/null || \
      storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINT,MODEL,TRAN 2>/dev/null || \
      storage_run_bounded lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINT,MODEL 2>/dev/null || true
  fi
  printf 'storage_raw_inventory_status=end\n'
}

sample_storage_metrics() {
  local mount_data source filesystem options target root_read_only filesystem_status
  local space_data inode_data total used available used_pct inode_total inode_used inode_available inode_used_pct
  local device before after pair i interval_ms status latency_status
  local operations read_ops write_ops await_value utilization queue inflight read_await write_await
  local -a awaits=() read_awaits=() write_awaits=() utilizations=() queues=()
  local completed=0 activity_windows=0 latency_windows=0 total_operations=0

  printf 'storage_sample_method=sysfs_block_stat_delta_windows\n'
  printf 'storage_sample_count_requested=%s\n' "$STORAGE_SAMPLE_COUNT"
  printf 'storage_sample_interval_seconds=%s\n' "$STORAGE_SAMPLE_INTERVAL_SECONDS"
  printf 'storage_min_ops_per_window=%s\n' "$STORAGE_MIN_OPS_PER_WINDOW"

  mount_data="$(storage_read_root_mount || true)"
  space_data="$(storage_read_root_space || true)"
  inode_data="$(storage_read_root_inodes || true)"
  if [[ -n "$mount_data" && -n "$space_data" && -n "$inode_data" ]]; then
    IFS=' ' read -r source filesystem options target <<<"$mount_data"
    IFS=' ' read -r total used available used_pct <<<"$space_data"
    IFS=' ' read -r inode_total inode_used inode_available inode_used_pct <<<"$inode_data"
    if [[ -n "$source" && -n "$filesystem" && "$total" =~ ^[0-9]+$ && "$used_pct" =~ ^[0-9]+$ && "$inode_used_pct" =~ ^[0-9]+$ ]]; then
      filesystem_status=ok
    else
      filesystem_status=unavailable
    fi
  else
    source=unavailable; filesystem=unavailable; options=unavailable; target=/
    total=unavailable; used=unavailable; available=unavailable; used_pct=unavailable
    inode_total=unavailable; inode_used=unavailable; inode_available=unavailable; inode_used_pct=unavailable
    filesystem_status=unavailable
  fi
  case ",${options}," in
    *,ro,*) root_read_only=yes ;;
    *,rw,*) root_read_only=no ;;
    *) root_read_only=unknown ;;
  esac
  printf 'storage_filesystem_status=%s\n' "$filesystem_status"
  printf 'root_source=%s\nroot_filesystem=%s\nroot_mountpoint=%s\nroot_mount_read_only=%s\n' \
    "$source" "$filesystem" "${target:-/}" "$root_read_only"
  printf 'root_total_kib=%s\nroot_used_kib=%s\nroot_available_kib=%s\nroot_used_pct=%s\n' \
    "$total" "$used" "$available" "$used_pct"
  printf 'root_inode_total=%s\nroot_inode_used=%s\nroot_inode_available=%s\nroot_inode_used_pct=%s\n' \
    "$inode_total" "$inode_used" "$inode_available" "$inode_used_pct"

  device="$(storage_resolve_device "$source" || true)"
  if [[ -z "$device" ]]; then
    printf 'storage_device_status=unsupported\nstorage_device=%s\n' "${source:-unavailable}"
    printf 'storage_device_sample_status=unavailable\nstorage_device_sample_count=0\nstorage_device_activity_windows=0\nstorage_device_latency_windows=0\nstorage_device_operations=unavailable\n'
    printf 'storage_await_ms_min=unavailable\nstorage_await_ms_median=unavailable\nstorage_await_ms_average=unavailable\nstorage_await_ms_max=unavailable\nstorage_await_ms_threshold=%.2f\nstorage_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
    printf 'storage_read_await_ms_min=unavailable\nstorage_read_await_ms_median=unavailable\nstorage_read_await_ms_average=unavailable\nstorage_read_await_ms_max=unavailable\nstorage_read_await_ms_threshold=%.2f\nstorage_read_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
    printf 'storage_write_await_ms_min=unavailable\nstorage_write_await_ms_median=unavailable\nstorage_write_await_ms_average=unavailable\nstorage_write_await_ms_max=unavailable\nstorage_write_await_ms_threshold=%.2f\nstorage_write_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
    printf 'storage_util_pct_min=unavailable\nstorage_util_pct_median=unavailable\nstorage_util_pct_average=unavailable\nstorage_util_pct_max=unavailable\nstorage_util_pct_threshold=%.2f\nstorage_util_pct_threshold_exceedance_count=unavailable\n' "$STORAGE_UTIL_WARN_PCT"
    printf 'storage_queue_depth_min=unavailable\nstorage_queue_depth_median=unavailable\nstorage_queue_depth_average=unavailable\nstorage_queue_depth_max=unavailable\nstorage_queue_depth_threshold=%.2f\nstorage_queue_depth_threshold_exceedance_count=unavailable\n' "$STORAGE_QUEUE_WARN"
    printf 'storage_latency_evidence_status=unavailable\nstorage_device_inflight=unavailable\n'
    return 0
  fi

  printf 'storage_device_status=ok\nstorage_device=%s\n' "$device"
  interval_ms=$((STORAGE_SAMPLE_INTERVAL_SECONDS * 1000))
  before="$(storage_read_device_stat "$device" || true)"
  for ((i=1; i<=STORAGE_SAMPLE_COUNT; i++)); do
    storage_wait_interval "$STORAGE_SAMPLE_INTERVAL_SECONDS"
    after="$(storage_read_device_stat "$device" || true)"
    pair="$(storage_pair_metrics "$before" "$after" "$interval_ms" "$STORAGE_MIN_OPS_PER_WINDOW" 2>/dev/null || true)"
    before="$after"
    [[ -n "$pair" ]] || continue
    IFS=' ' read -r operations read_ops write_ops await_value utilization queue inflight read_await write_await <<<"$pair"
    completed=$((completed+1))
    total_operations=$((total_operations+operations))
    utilizations+=("$utilization")
    queues+=("$queue")
    if (( operations > 0 )); then activity_windows=$((activity_windows+1)); fi
    if [[ "$await_value" != unavailable ]]; then
      awaits+=("$await_value")
      latency_windows=$((latency_windows+1))
    fi
    [[ "$read_await" == unavailable ]] || read_awaits+=("$read_await")
    [[ "$write_await" == unavailable ]] || write_awaits+=("$write_await")
    printf 'storage_sample_%s_operations=%s\n' "$completed" "$operations"
    printf 'storage_sample_%s_read_operations=%s\n' "$completed" "$read_ops"
    printf 'storage_sample_%s_write_operations=%s\n' "$completed" "$write_ops"
    printf 'storage_sample_%s_await_ms=%s\n' "$completed" "$await_value"
    printf 'storage_sample_%s_read_await_ms=%s\n' "$completed" "$read_await"
    printf 'storage_sample_%s_write_await_ms=%s\n' "$completed" "$write_await"
    printf 'storage_sample_%s_util_pct=%s\n' "$completed" "$utilization"
    printf 'storage_sample_%s_queue_depth=%s\n' "$completed" "$queue"
    printf 'storage_sample_%s_inflight=%s\n' "$completed" "$inflight"
  done

  if (( completed == STORAGE_SAMPLE_COUNT )); then status=ok
  elif (( completed > 0 )); then status=partial
  else status=unavailable
  fi
  if (( latency_windows >= 2 )); then latency_status=ok
  elif (( latency_windows == 1 )); then latency_status=limited
  elif (( activity_windows > 0 )); then latency_status=insufficient_activity
  else latency_status=idle
  fi
  printf 'storage_device_sample_status=%s\n' "$status"
  printf 'storage_device_sample_count=%s\nstorage_device_activity_windows=%s\nstorage_device_latency_windows=%s\nstorage_device_operations=%s\n' \
    "$completed" "$activity_windows" "$latency_windows" "$total_operations"
  printf 'storage_latency_evidence_status=%s\n' "$latency_status"
  printf 'storage_device_inflight=%s\n' "${inflight:-unavailable}"

  if (( ${#awaits[@]} > 0 )); then
    storage_metric_stats storage_await_ms "$STORAGE_AWAIT_WARN_MS" "${awaits[@]}"
  else
    printf 'storage_await_ms_min=unavailable\nstorage_await_ms_median=unavailable\nstorage_await_ms_average=unavailable\nstorage_await_ms_max=unavailable\nstorage_await_ms_threshold=%.2f\nstorage_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
  fi
  if (( ${#read_awaits[@]} > 0 )); then
    storage_metric_stats storage_read_await_ms "$STORAGE_AWAIT_WARN_MS" "${read_awaits[@]}"
  else
    printf 'storage_read_await_ms_min=unavailable\nstorage_read_await_ms_median=unavailable\nstorage_read_await_ms_average=unavailable\nstorage_read_await_ms_max=unavailable\nstorage_read_await_ms_threshold=%.2f\nstorage_read_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
  fi
  if (( ${#write_awaits[@]} > 0 )); then
    storage_metric_stats storage_write_await_ms "$STORAGE_AWAIT_WARN_MS" "${write_awaits[@]}"
  else
    printf 'storage_write_await_ms_min=unavailable\nstorage_write_await_ms_median=unavailable\nstorage_write_await_ms_average=unavailable\nstorage_write_await_ms_max=unavailable\nstorage_write_await_ms_threshold=%.2f\nstorage_write_await_ms_threshold_exceedance_count=unavailable\n' "$STORAGE_AWAIT_WARN_MS"
  fi
  if (( ${#utilizations[@]} > 0 )); then
    storage_metric_stats storage_util_pct "$STORAGE_UTIL_WARN_PCT" "${utilizations[@]}"
    storage_metric_stats storage_queue_depth "$STORAGE_QUEUE_WARN" "${queues[@]}"
  else
    printf 'storage_util_pct_min=unavailable\nstorage_util_pct_median=unavailable\nstorage_util_pct_average=unavailable\nstorage_util_pct_max=unavailable\nstorage_util_pct_threshold=%.2f\nstorage_util_pct_threshold_exceedance_count=unavailable\n' "$STORAGE_UTIL_WARN_PCT"
    printf 'storage_queue_depth_min=unavailable\nstorage_queue_depth_median=unavailable\nstorage_queue_depth_average=unavailable\nstorage_queue_depth_max=unavailable\nstorage_queue_depth_threshold=%.2f\nstorage_queue_depth_threshold_exceedance_count=unavailable\n' "$STORAGE_QUEUE_WARN"
  fi
}

sample_storage() {
  sample_storage_metrics
  storage_raw_inventory
}
